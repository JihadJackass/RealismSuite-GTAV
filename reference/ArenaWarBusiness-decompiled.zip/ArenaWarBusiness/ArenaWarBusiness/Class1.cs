using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;
using NativeUI;

namespace ArenaWarBusiness
{
	public class Class1 : Script
	{
		private bool firstTime = true;

		public Vector3 MarkerEnter;

		public Vector3 MarkerExit;

		public Vector3 MenuMarker;

		public Vector3 RoofEnterMarker;

		public Vector3 RoofExitMarker;

		public Vector3 HeliSpawn;

		public Vector3 GarageMarker;

		public Vector3 CarSpawn;

		public Vector3 WherehouseMarker;

		public Vector3 WherehouseEnter;

		private ScriptSettings Config;

		private ScriptSettings OnlineInteriorsConfig;

		private Keys Key1;

		public Vector3 BuyMarker;

		public Vector3 BuyMarker2;

		public int num;

		private MenuPool modMenuPool;

		private UIMenu Missions;

		private UIMenu VehicleGaragePool;

		private UIMenu mainMenu;

		private UIMenu methgarage;

		private UIMenu VehicleWherehouseOptions;

		private UIMenu ProductStock;

		public bool bought;

		public int purchaselvl;

		public int maxstocks;

		public float stocksvalue;

		public float profitMargin;

		public int stockscount;

		public int stockstimer;

		public int waittime;

		public int DisplayWait;

		public bool EnemySetup;

		public int Chooseenemynum;

		public Vehicle VehicleId;

		public bool VehicleSetup;

		private List<WeaponHash> weapons = Enum.GetValues(typeof(WeaponHash)).Cast<WeaponHash>().ToList();

		public string carid;

		public int vehiclemissionid;

		public bool setupdelivery;

		public Vector3 DeliveryMaker;

		public Blip DeliveryLoc;

		public Blip ballasBlip1;

		public Vector3 Deliverypoint;

		public UIMenu Garage;

		public UIMenu Sourcingmenu;

		public UIMenu SupplyRunsmenu;

		public UIMenu OrganizationOptions;

		public bool setupwantedfordelivery;

		public int waittimeforwanted;

		public Vehicle AirVehicle;

		public int BuzzardBought;

		public int FMJBought;

		public int A911Bought;

		public int X80Bought;

		public int SEVEN70Bought;

		public int wherehosuebought;

		public int cargaragebought;

		public VehicleHash VehicleIdentifier;

		public Vehicle VehicleName;

		public bool foundvehicleyet;

		public Vector3 Vehicleloc;

		public Blip VehicleMarker;

		public Vehicle Vehicletoget;

		public Vector3 VehicleSpawn;

		public bool hasgotvehicle;

		private Blip Enemy;

		private Ped EnemyPed;

		private Vector3 EnemyLoc;

		public Random VehicleLoc;

		public Random VehicleRan;

		public Vehicle VehicleMissioncar;

		public Vector3 VehicleLocation;

		public int Missionnum;

		public Blip DestoryVehicle;

		private Random RandomWanted;

		private Random randomwantedwait;

		private int triggerwanted;

		public int Aircraftstorage;

		public bool warnedplayer;

		public Vector3 AircraftStorageLoc;

		public Blip AircraftStorageMarker;

		public Blip VehicleWarehouseMarker;

		public int GunLockerBought;

		public int MoneyVaultBought;

		public int DockBought;

		public int VehicleLotBought;

		public Vector3 Dockloc;

		public Blip DockBlip;

		public Vector3 LotLoc;

		public Blip LotBlip;

		public float SourcingPayout;

		public bool SourcingCheckingforDamage;

		public int AATrailerABought;

		public int AATrailerBBought;

		public int AATrailerCBought;

		public string OrganizationName;

		public UIMenu AssetRecoveryMenu;

		public bool TriggeredWanted;

		public int ValkyrieBought;

		public int AkulaBought;

		public int HunterBought;

		public int SavageBought;

		public int AnnihilatorBought;

		public Blip ConvoyBlip1;

		public Blip ConvoyBlip2;

		public Blip ConvoyBlip3;

		public int convoysetup;

		public bool checkforconvoy;

		public int UseCustomWaitTime;

		public bool setWaittime;

		public Vector3 Radiopos;

		public int turretedlimo;

		public int assassinationmission;

		public int assassinationpayout;

		public Blip TowerBlip;

		public Blip TowerBlip2;

		public Blip TowerBlip3;

		public string Design;

		public UIMenu Sourcingmenu2;

		public string SourcedVehicle;

		public bool NewVehicleSourcing;

		public float increaseGain;

		public AllStocks Allstocks;

		public UIMenu SpecialMissions;

		public List<Ped> Guards = new List<Ped>();

		public List<Ped> Driver = new List<Ped>();

		public Vehicle VtoGet;

		public Blip VtoGetBlip;

		public Blip VtoGetBlip1;

		public Blip VtoGetBlip2;

		public Blip VtoGetBlip3;

		public Blip VtoGetBlip4;

		public Blip VtoGetBlip5;

		public Blip VtoGetBlip6;

		public Blip VtoGetBlip7;

		public bool GotCar;

		public Vehicle VtoGet1;

		public Vehicle VtoGet2;

		public Vehicle VtoGet3;

		public Vehicle VtoGet4;

		public Vehicle VtoGet5;

		public Vehicle VtoGet6;

		public Vehicle VtoGet7;

		public int Vehiclesleft;

		public Blip DropzoneBlip;

		public Vector3 Dropzone;

		public bool VehicleisDamaged;

		public int Vehiclehealth;

		public Vehicle RentedVehicle;

		public bool startedRent;

		public int RentTimer;

		public int RentalvehicleHealth;

		public bool ISinPiracyScamMission;

		public int Piracymission;

		public int TimerLeft;

		public VehicleHash RandomVehicle;

		public bool HackhasStarted;

		public Vector3 GoPoint;

		public int StockTimer;

		public int StockTimer2;

		public float stocktoloose;

		public UIMenu PointtoPointMenu;

		private MenuPool GarageMenuPool;

		public UIMenu GarageMenu;

		public UIMenu VehicleMenu;

		public Vector3 GarageMenuSpawn;

		public bool IsInInterior;

		public SaveCar SC;

		public string Loadpath = "scripts//ArenaWarBusiness//Vehicles//";

		public Vector3 GarageAMarkerOuside = new Vector3(-365f, -1871f, 19f);

		public Vector3 GarageBMarkerOuside = new Vector3(-388f, -1880f, 19f);

		public Vector3 GarageAMarkerInside = new Vector3(172f, 5163f, 10f);

		public Vector3 GarageBMarkerInside = new Vector3(172f, 5216f, 10f);

		public Vector3 GarageAMarkerExit = new Vector3(172f, 5217f, 10f);

		public Vector3 GarageBMarkerExit;

		public Vector3 SecondEntry = new Vector3(168f, 5210f, -90f);

		public Vector3 Racemarker2 = new Vector3(2800f, -3800f, 140f);

		public bool isinsecondVehicleBay;

		private MenuPool GarageMenuPool2;

		public UIMenu GarageMenu2;

		public UIMenu VehicleMenu2;

		public Vector3 VehicleBayMarker = new Vector3(169f, 5157f, -90f);

		public Vector3 GarageMenuMarker2 = new Vector3(171f, 5186f, 10f);

		public float vehiclehealth;

		public List<string> NStadium;

		public int timer;

		public int TimeLeft;

		public float moneytobeawarded;

		public Vector3 RamdomLocationVar;

		public Vector3 CheckPointPosition;

		public int CheckPointsreached;

		public Vector3 MineLoc1;

		public Vector3 MineLoc2;

		public Vector3 MineLoc3;

		public Vector3 MineLoc4;

		public Vector3 MineLoc5;

		public Vector3 MineLoc6;

		public Vector3 MineLoc7;

		public Vector3 MineLoc8;

		public Vector3 MineLoc9;

		public int missiletimer;

		public Vector3 ArenaExit = new Vector3(2810f, -3897f, 139f);

		public Vector3 ArenaEntry = new Vector3(221f, 5180f, -89f);

		private MenuPool ArenaGarageMenuPool;

		public UIMenu ArenaGarageMenu;

		public UIMenu ArenaVehicleMenu;

		public Vector3 ArenaVehicleMenuMarker = new Vector3(-394f, -1871f, 19f);

		public Vector3 ArenaVehicleMarker = new Vector3(2815f, -3909f, 140f);

		public List<Ped> Peds;

		public Vector3 StadiumUpperExit = new Vector3(211.903f, 5199.94f, -90f);

		public Vector3 StadiumUpperEntry = new Vector3(-242.472f, -1995.96f, 24f);

		public Vector3 VipEntry = new Vector3(217.034f, 5159.5f, -90f);

		public Vector3 VipExit = new Vector3(2797.71f, -3942.01f, 184f);

		public UIMenu DeathMatch;

		public Vector3 Startpos;

		public int vehicleHealth;

		public UIMenu RCKing;

		public UIMenu DeathMatch2;

		public List<Blip> PedBlips;

		public Vector3 JackpotTable = new Vector3(2796.17f, -3933.43f, 182f);

		public bool lockz;

		public Enableinteriors EI;

		public Vector3 EndPointPos = new Vector3(-382f, -1835f, 20f);

		public Blip EndPointBlip;

		public bool SetupPed;

		public int PedsCounted;

		public Vector3 CarSpawn1;

		public Vector3 CarSpawn2;

		public Vector3 CarSpawn3;

		public Vector3 CarSpawn4;

		public string MarkerColorString;

		public Color MarkerColor;

		public int Timer2;

		public bool DropedVehicleA;

		public bool DropedVehicleB;

		public bool DropedVehicleC;

		public List<Vehicle> VehiclestoCarryA;

		public List<Vehicle> VehiclestoCarryB;

		public List<Vehicle> VehiclestoCarryC;

		private UIMenu VehicleSoccer;

		private UIMenu SmashandGrab;

		public Vector3 Goal1 = new Vector3(2665f, -3800f, 140f);

		public Vector3 Goal2 = new Vector3(2926f, -3800f, 140f);

		public UIMenu HotRing;

		public Vector3 TargettoFireAt;

		public List<Vector3> TrapsPos;

		public bool UseMIssilesInVDM;

		public int CheckPointstoProceed;

		public List<int> HeadlightColor;

		public UIMenu VehicleLoadMenu;

		public Vector3 SleepPos = new Vector3(209f, 5164f, -90f);

		public Vector3 CharacterSwitchPos = new Vector3(211.37f, 5161.95f, -90f);

		public Vector3 Sitpos = new Vector3(210f, 5166.3f, -87f);

		public bool IsSitting;

		public UIMenu BeastWars;

		public Vehicle PLayerVehicle2;

		public Ped Friendlyped;

		public Vector3 DrinkPos = new Vector3(2810f, -3929f, 183f);

		public Vehicle Cerberus;

		public int CurrentCerberus;

		public int NightmareCerberusBought;

		public int ApocalypseCerberusBought;

		public int FutureShockCerberusBought;

		public Vector3 CerberusSpawn = new Vector3(159f, 5180f, -90f);

		public Vehicle Scarab;

		public int CurrentScarab;

		public int NightmareScarabBought;

		public int ApocalypseScarabBought;

		public int FutureShockScarabBought;

		public Vector3 ScarabSpawn = new Vector3(178f, 5189.4f, -90f);

		public Vehicle Dominator;

		public int CurrentDominator;

		public int NightmareDominatorBought;

		public int ApocalypseDominatorBought;

		public int FutureShockDominatorBought;

		public Vector3 DominatorSpawn = new Vector3(161f, 5171f, -90f);

		public Vehicle Imperator;

		public int CurrentImperator;

		public int NightmareImperatorBought;

		public int ApocalypseImperatorBought;

		public int FutureShockImperatorBought;

		public Vector3 ImperatorSpawn = new Vector3(177f, 5171f, -90f);

		public Vehicle Deathbike;

		public int CurrentDeathbike;

		public int NightmareDeathbikeBought;

		public int ApocalypseDeathbikeBought;

		public int FutureShockDeathbikeBought;

		public Vector3 DeathbikeSpawn = new Vector3(159f, 5158f, -90f);

		public Vehicle Issi;

		public int CurrentIssi;

		public int NightmareIssiBought;

		public int ApocalypseIssiBought;

		public int FutureShockIssiBought;

		public Vector3 IssiSpawn = new Vector3(160f, 5201f, -90f);

		public Vehicle Monster;

		public int CurrentMonster;

		public int NightmareMonsterBought;

		public int ApocalypseMonsterBought;

		public int FutureShockMonsterBought;

		public Vector3 MonsterSpawn = new Vector3(160f, 5189f, -90f);

		public Vehicle Impaler;

		public int CurrentImpaler;

		public int NightmareImpalerBought;

		public int ApocalypseImpalerBought;

		public int FutureShockImpalerBought;

		public Vector3 ImpalerSpawn = new Vector3(178f, 5201f, -90f);

		public Vehicle Slamvan;

		public int CurrentSlamvan;

		public int NightmareSlamvanBought;

		public int ApocalypseSlamvanBought;

		public int FutureShockSlamvanBought;

		public Vector3 SlamvanSpawn = new Vector3(160f, 5207f, -90f);

		public Vehicle Bruitus;

		public int CurrentBruitus = 1;

		public int NightmareBruitusBought = 1;

		public int ApocalypseBruitusBought = 1;

		public int FutureShockBruitusBought = 1;

		public Vector3 BruitusSpawn = new Vector3(178f, 5158f, -90f);

		public Vehicle Bruiser;

		public int CurrentBruiser;

		public int NightmareBruiserBought;

		public int ApocalypseBruiserBought;

		public int FutureShockBruiserBought;

		public Vector3 BruiserSpawn = new Vector3(159f, 5187f, 10f);

		public Vehicle ZR380;

		public int CurrentZR380;

		public int NightmareZR380Bought;

		public int ApocalypseZR380Bought;

		public int FutureShockZR380Bought;

		public Vector3 ZR380Spawn = new Vector3(182f, 5187f, 10f);

		public Vehicle Clique;

		public int CliqueBought;

		public Vector3 CliqueSpawn = new Vector3(180f, 5196f, 10f);

		public Vehicle Italigto;

		public int ItaligtoBought;

		public Vector3 ItaligtoSpawn = new Vector3(163f, 5196f, 10f);

		public Vehicle Tulip;

		public int TulipBought;

		public Vector3 TulipSpawn = new Vector3(163.48f, 5208.43f, 10f);

		public Vehicle Vamos;

		public int VamosBought;

		public Vector3 VamosSpawn = new Vector3(164.1225f, 5214.5f, 10f);

		public Vehicle Schlagen;

		public int SchlagenBought;

		public Vector3 SchlagenSpawn = new Vector3(180f, 5208f, 10f);

		public Vehicle Deviant;

		public int DeviantBought;

		public Vector3 DeviantSpawn = new Vector3(163f, 5177f, 10f);

		public Vehicle Toros;

		public int TorosBought;

		public Vector3 TorosSpawn = new Vector3(181.2755f, 5177.701f, 10f);

		public Vehicle Deveste;

		public int DevesteBought;

		public Vector3 DevesteSpawn = new Vector3(163f, 5165f, 10f);

		public Vehicle RcBandito;

		public int RcBanditoBought;

		public Vector3 RcBanditoSpawn = new Vector3(182f, 5165f, 11f);

		public Vector3 EnterMarkerA;

		public Vector3 EnterMarkerB;

		public Vector3 EnterMarkerC;

		public Vector3 ExitMarker;

		public Vector3 Vehicle1Loc = new Vector3(159f, 5187f, 10f);

		public Vehicle Vehicle1;

		public Vector3 Vehicle2Loc = new Vector3(162f, 5196f, 10f);

		public Vehicle Vehicle2;

		public Vector3 Vehicle3Loc = new Vector3(163f, 5208f, 10f);

		public Vehicle Vehicle3;

		public Vector3 Vehicle4Loc = new Vector3(163f, 5214f, 10f);

		public Vehicle Vehicle4;

		public Vector3 Vehicle5Loc = new Vector3(180f, 5208f, 10f);

		public Vehicle Vehicle5;

		public Vector3 Vehicle6Loc = new Vector3(181f, 5196f, 10f);

		public Vehicle Vehicle6;

		public Vector3 Vehicle7Loc = new Vector3(183f, 5187f, 10f);

		public Vehicle Vehicle7;

		public Vector3 Vehicle8Loc = new Vector3(181f, 5177f, 10f);

		public Vehicle Vehicle8;

		public Vector3 Vehicle9Loc = new Vector3(181f, 5165f, 10f);

		public Vehicle Vehicle9;

		public Vector3 Vehicle10Loc = new Vector3(163f, 5165f, 10f);

		public Vehicle Vehicle10;

		public Vector3 OutsideMenuMarker = new Vector3(-371.8876f, -1850f, 21f);

		private MenuPool PlayerGaragemodMenuPool;

		private UIMenu PlayerGarageMenu;

		private UIMenu PlayerGaragemainMenu;

		public Vector3 EntryMarker = new Vector3(-365f, -1871f, 20f);

		public Vector3 ExitMarker2 = new Vector3(-71.949f, -831.736f, 222.001f);

		private string path = "scripts//ArenaWarBusiness//PlayerGarage//";

		public Vehicle SaveVehicle;

		public Vector3 RemoveMarker = new Vector3(188f, 5186f, 10f);

		public Vector3 ExitMarker3 = new Vector3(172f, 5216f, 10f);

		public Vector3 GarageAEntryOutside = new Vector3(-365f, -1817f, 19f);

		private MenuPool RemoveMenuPool2;

		private UIMenu RemoveMenu;

		private UIMenu mainMenu2;

		public bool IsinInterior;

		public string GarageNum;

		public bool isInGarage;

		public Vector3 EnterGarageMarker = new Vector3(-371.8876f, -1850f, 21f);

		public Vector3 GarageEntry = new Vector3(-364.8876f, -1871f, 19f);

		public float VehicleABet;

		public float VehicleBBet;

		public float VehicleCBet;

		public float VehicleDBet;

		public Vehicle VehicleATarget;

		public Vehicle VehicleBTarget;

		public Vehicle VehicleCTarget;

		public Vehicle VehicleDTarget;

		public bool IsSpectatingMatch;

		public bool MissionSetup;

		public int MissionId;

		public int Race;

		public Vector3 FinishLine;

		public Vehicle VehicleA;

		public Vehicle VehicleB;

		public Vehicle VehicleC;

		public Vector3 RaceMarker;

		public int PlayersPos;

		public bool StartedRace;

		public bool IsLeading;

		public bool FinishedRace;

		public bool inRace;

		public Blip RaceBlip;

		public Blip FinishLineBLip;

		public int checkpointReaced;

		public bool TimeTrialOn;

		public UIMenu TimeTrial;

		public int TimeTrialTimer;

		public int TimeTrialTime;

		public VehicleHash VehicleChoosen;

		public int Damage;

		public int Damage2;

		public int CheckDamage;

		public bool IsCheck;

		public Vehicle Semi;

		public Vehicle Trailer;

		public UIMenu longhaul;

		public Vector3 Spawn = new Vector3(-50.3f, -1074f, 27f);

		public Vector3 End;

		public Blip EndPoint;

		public UIMenu Rivals;

		public UIMenu SpeedCam;

		public float Speedtobeat;

		public bool ClearVehiclsinRivalsRace;

		public Vector3 PointA;

		public Vector3 CheckPoint;

		public bool AiatCheckpoint;

		public Vehicle Chaser2;

		public bool ChaserActive;

		public int lap;

		public int checkpoint;

		public Vector3[] Route;

		public bool CircuitRace;

		public bool CircuitRace2;

		public int ACheck;

		public int BCheck;

		public int CCheck;

		public int Alap;

		public int Blap;

		public int Clap;

		public Vehicle PLayerVehicle;

		public bool PedsDieinPufofSmoke;

		public bool GotCargo;

		public UIMenu DemoltionMenMenu;

		private ScriptSettings ScriptConfig;

		public MenuPool ArenaMenuPool;

		public UIMenu ArenaMainMenu;

		public UIMenu ArenaMenu;

		public Vector3 ArenaMenuMarker = new Vector3(2789.97f, -3903.44f, 139f);

		public List<Prop> Props = new List<Prop>();

		public List<Vehicle> ExtraV = new List<Vehicle>();

		public List<Prop> Trap_Mines = new List<Prop>();

		public List<Prop> Trap_Spike = new List<Prop>();

		public List<Prop> Trap_Flipper = new List<Prop>();

		public List<Prop> Trap_Flipper2 = new List<Prop>();

		public List<Prop> Trap_Flame = new List<Prop>();

		public List<Prop> Trap_Turning = new List<Prop>();

		public List<Prop> Trap_GunTower = new List<Prop>();

		public UIMenu SkyWars;

		public UIMenu ChampionchipMatch;

		public UIMenu TurretMayhem;

		public bool TriggerEscape;

		public bool IsScriptEnabled;

		public Vehicle LastVehicle;

		public void SetupStadium()
		{
			NStadium = new List<string>();
			NStadium.Add("Set_Pit_Fence_Closed");
			NStadium.Add("Set_Pit_Fence_Demolition");
			NStadium.Add("Set_Pit_Fence_Oval");
			NStadium.Add("set_pit_fence_ovala");
			NStadium.Add("set_pit_fence_ovalb");
			NStadium.Add("Set_Pit_Fence_Wall");
			NStadium.Add("set_wall_no_pit");
			NStadium.Add("set_centreline_dystopian_05");
			NStadium.Add("set_centreline_scifi_05");
			NStadium.Add("Set_CentreLine_Wasteland_05");
			NStadium.Add("Set_Turrets");
			NStadium.Add("set_turrets_scifi");
			NStadium.Add("set_turrets_wasteland");
			NStadium.Add("Set_Team_Band_A");
			NStadium.Add("Set_Team_Band_B");
			NStadium.Add("Set_Team_Band_C");
			NStadium.Add("Set_Team_Band_D");
			NStadium.Add("Set_Lights_atlantis");
			NStadium.Add("Set_Lights_evening");
			NStadium.Add("Set_Lights_hell");
			NStadium.Add("Set_Lights_midday");
			NStadium.Add("Set_Lights_morning");
			NStadium.Add("Set_Lights_night");
			NStadium.Add("set_lights_sfnight");
			NStadium.Add("Set_Lights_saccharine");
			NStadium.Add("Set_Lights_sandstorm");
			NStadium.Add("Set_Lights_storm");
			NStadium.Add("Set_Lights_toxic");
			NStadium.Add("Set_Dystopian_01");
			NStadium.Add("Set_Dystopian_02");
			NStadium.Add("Set_Dystopian_03");
			NStadium.Add("Set_Dystopian_04");
			NStadium.Add("Set_Dystopian_05");
			NStadium.Add("Set_Dystopian_06");
			NStadium.Add("Set_Dystopian_07");
			NStadium.Add("Set_Dystopian_08");
			NStadium.Add("Set_Dystopian_09");
			NStadium.Add("Set_Dystopian_10");
			NStadium.Add("Set_Dystopian_11");
			NStadium.Add("Set_Dystopian_12");
			NStadium.Add("Set_Dystopian_13");
			NStadium.Add("Set_Dystopian_14");
			NStadium.Add("Set_Dystopian_15");
			NStadium.Add("Set_Dystopian_16");
			NStadium.Add("Set_Dystopian_17");
			NStadium.Add("Set_Scifi_01");
			NStadium.Add("Set_Scifi_02");
			NStadium.Add("Set_Scifi_03");
			NStadium.Add("Set_Scifi_04");
			NStadium.Add("Set_Scifi_05");
			NStadium.Add("Set_Scifi_06");
			NStadium.Add("Set_Scifi_07");
			NStadium.Add("Set_Scifi_08");
			NStadium.Add("Set_Scifi_09");
			NStadium.Add("Set_Scifi_10");
			NStadium.Add("Set_Wasteland_01");
			NStadium.Add("Set_Wasteland_02");
			NStadium.Add("Set_Wasteland_03");
			NStadium.Add("Set_Wasteland_04");
			NStadium.Add("Set_Wasteland_05");
			NStadium.Add("Set_Wasteland_06");
			NStadium.Add("Set_Wasteland_07");
			NStadium.Add("Set_Wasteland_08");
			NStadium.Add("Set_Wasteland_09");
			NStadium.Add("Set_Wasteland_10");
			NStadium.Add("Set_Dystopian_Scene");
			NStadium.Add("Set_Scifi_Scene");
			NStadium.Add("Set_Wasteland_Scene");
			NStadium.Add("Set_Crowd_A");
			NStadium.Add("Set_Crowd_B");
			NStadium.Add("Set_Crowd_C");
			NStadium.Add("Set_Crowd_D");
		}

		public void SetupTrapsPositions()
		{
			TrapsPos = new List<Vector3>();
			TrapsPos.Add(new Vector3(2759.76f, -3849f, 130f));
			TrapsPos.Add(new Vector3(2814.76f, -3853f, 130f));
			TrapsPos.Add(new Vector3(2870.76f, -3852f, 130f));
			TrapsPos.Add(new Vector3(2925.76f, -3838f, 130f));
			TrapsPos.Add(new Vector3(2949f, -3799f, 130f));
			TrapsPos.Add(new Vector3(2925f, -3754f, 130f));
			TrapsPos.Add(new Vector3(2867f, -3744f, 130f));
			TrapsPos.Add(new Vector3(2800f, -3745f, 130f));
			TrapsPos.Add(new Vector3(2742f, -3746f, 130f));
			TrapsPos.Add(new Vector3(2688f, -3752f, 130f));
			TrapsPos.Add(new Vector3(2653f, -3782f, 130f));
			TrapsPos.Add(new Vector3(2657f, -3727f, 130f));
			TrapsPos.Add(new Vector3(2710.01f, -3856f, 130f));
			TrapsPos.Add(new Vector3(2740.01f, -3873f, 136f));
			TrapsPos.Add(new Vector3(2772.01f, -3874f, 136f));
			TrapsPos.Add(new Vector3(2822.01f, -3876f, 136f));
			TrapsPos.Add(new Vector3(2885.01f, -3875f, 136f));
			TrapsPos.Add(new Vector3(2934.01f, -3858f, 136f));
			TrapsPos.Add(new Vector3(2962.01f, -3806f, 136f));
			TrapsPos.Add(new Vector3(2950.01f, -3754f, 136f));
			TrapsPos.Add(new Vector3(2903.01f, -3726f, 136f));
			TrapsPos.Add(new Vector3(2776.01f, -3722f, 136f));
			TrapsPos.Add(new Vector3(2649f, -3760f, 136f));
			TrapsPos.Add(new Vector3(2638f, -3827f, 136f));
			TrapsPos.Add(new Vector3(2704f, -3876f, 136f));
		}

		public void SpawnProp(string Prop, Vector3 Pos, Vector3 Rot, int i)
		{
			try
			{
				Model model = new Model(Prop);
				model.Request(250);
				if (model.IsInCdImage && model.IsValid)
				{
					while (!model.IsLoaded)
					{
						Script.Wait(50);
					}
					Prop[] nearbyProps = World.GetNearbyProps(Pos, 100f, model);
					Prop prop = World.CreateProp(model, Pos, Rot, false, false);
					prop.FreezePosition = true;
					Props.Add(prop);
				}
				model.MarkAsNoLongerNeeded();
			}
			catch (Exception)
			{
				UI.Notify("~r~ Prop : ~w~" + Prop + "~r~ Failed to spawn");
			}
		}

		private void CheckForScriptEnabled(string iniName)
		{
			try
			{
				ScriptConfig = ScriptSettings.Load(iniName);
				IsScriptEnabled = ScriptConfig.GetValue("ArenaWarBusiness", "MazeBankArena", IsScriptEnabled);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Config.ini Failed To Load.");
			}
		}

		public Class1()
		{
			VehiclestoCarryA = new List<Vehicle>();
			VehiclestoCarryB = new List<Vehicle>();
			VehiclestoCarryC = new List<Vehicle>();
			HeadlightColor = new List<int>();
			PedBlips = new List<Blip>();
			Peds = new List<Ped>();
			CheckForScriptEnabled("scripts//DisableBusinesses.ini");
			if (IsScriptEnabled)
			{
				EI = new Enableinteriors();
				Allstocks = new AllStocks();
				SC = new SaveCar();
				Setup();
				base.Tick += OnTick;
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
			}
		}

		private void LoadIniFile(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				MarkerColorString = Config.GetValue<string>("Setup", "MarkerColor", MarkerColorString);
				MarkerColor = Color.FromName(MarkerColorString);
				UseMIssilesInVDM = Config.GetValue("Setup", "UseMIssilesInVDM", UseMIssilesInVDM);
				Key1 = Config.GetValue("Configurations", "Key1", Key1);
				purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
				stockscount = Config.GetValue("Setup", "stockslevel", stockscount);
				stocksvalue = Config.GetValue("Setup", "StocksValue", stocksvalue);
				BuzzardBought = Config.GetValue("Setup", "BuzzardBought", BuzzardBought);
				FMJBought = Config.GetValue("Setup", "FMJBought", FMJBought);
				A911Bought = Config.GetValue("Setup", "911Bought", A911Bought);
				X80Bought = Config.GetValue("Setup", "X80Bought", X80Bought);
				SEVEN70Bought = Config.GetValue("Setup", "SEVEN70Bought", SEVEN70Bought);
				GunLockerBought = Config.GetValue("Setup", "GunLockerBought", GunLockerBought);
				MoneyVaultBought = Config.GetValue("Setup", " MoneyVaultBought", MoneyVaultBought);
				AATrailerABought = Config.GetValue("Setup", "AATrailerABought", AATrailerABought);
				AATrailerBBought = Config.GetValue("Setup", "AATrailerBBought", AATrailerBBought);
				AATrailerCBought = Config.GetValue("Setup", " AATrailerCBought", AATrailerCBought);
				ValkyrieBought = Config.GetValue("Setup", "ValkyrieBought", ValkyrieBought);
				SavageBought = Config.GetValue("Setup", "SavageBought", SavageBought);
				HunterBought = Config.GetValue("Setup", "HunterBought", HunterBought);
				AkulaBought = Config.GetValue("Setup", "AkulaBought", AkulaBought);
				AnnihilatorBought = Config.GetValue("Setup", "AnnihilatorBought", AnnihilatorBought);
				UseCustomWaitTime = Config.GetValue("Setup", "UseCustomWaitTime", UseCustomWaitTime);
				turretedlimo = Config.GetValue("Setup", "turretedlimo", turretedlimo);
				Design = Config.GetValue<string>("Design", "InteriorDesign", Design);
				CurrentCerberus = Config.GetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
				CurrentScarab = Config.GetValue("Vehicles", "CurrentScarab", CurrentScarab);
				CurrentDominator = Config.GetValue("Vehicles", "CurrentDominator", CurrentDominator);
				CurrentImperator = Config.GetValue("Vehicles", "CurrentImperator", CurrentImperator);
				CurrentDeathbike = Config.GetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
				CurrentIssi = Config.GetValue("Vehicles", "CurrentIssi", CurrentIssi);
				CurrentMonster = Config.GetValue("Vehicles", "CurrentMonster", CurrentMonster);
				CurrentImpaler = Config.GetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
				CurrentSlamvan = Config.GetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
				CurrentBruitus = Config.GetValue("Vehicles", "CurrentBrutus", CurrentBruitus);
				CurrentZR380 = Config.GetValue("Vehicles", "CurrentZR380", CurrentZR380);
				CurrentBruiser = Config.GetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
				NightmareCerberusBought = Config.GetValue("Vehicles", "NightmareCerberusBought", NightmareCerberusBought);
				ApocalypseCerberusBought = Config.GetValue("Vehicles", "ApocalypseCerberusBought", ApocalypseCerberusBought);
				FutureShockCerberusBought = Config.GetValue("Vehicles", "FutureShockCerberusBought", FutureShockCerberusBought);
				NightmareScarabBought = Config.GetValue("Vehicles", "NightmareScarabBought", NightmareScarabBought);
				ApocalypseScarabBought = Config.GetValue("Vehicles", "ApocalypseScarabBought", ApocalypseScarabBought);
				FutureShockScarabBought = Config.GetValue("Vehicles", "FutureShockScarabBought", FutureShockScarabBought);
				NightmareDominatorBought = Config.GetValue("Vehicles", "NightmareDominatorBought", NightmareDominatorBought);
				ApocalypseDominatorBought = Config.GetValue("Vehicles", "ApocalypseDominatorBought", ApocalypseDominatorBought);
				FutureShockDominatorBought = Config.GetValue("Vehicles", "FutureShockDominatorBought", FutureShockDominatorBought);
				NightmareImperatorBought = Config.GetValue("Vehicles", "NightmareImperatorBought", NightmareImperatorBought);
				ApocalypseImperatorBought = Config.GetValue("Vehicles", "ApocalypseImperatorBought", ApocalypseImperatorBought);
				FutureShockImperatorBought = Config.GetValue("Vehicles", "FutureShockImperatorBought", FutureShockImperatorBought);
				NightmareDeathbikeBought = Config.GetValue("Vehicles", "NightmareDeathbikeBought", NightmareDeathbikeBought);
				ApocalypseDeathbikeBought = Config.GetValue("Vehicles", "ApocalypseDeathbikeBought", ApocalypseDeathbikeBought);
				FutureShockDeathbikeBought = Config.GetValue("Vehicles", "FutureShockDeathbikeBought", FutureShockDeathbikeBought);
				NightmareIssiBought = Config.GetValue("Vehicles", "NightmareIssiBought", NightmareIssiBought);
				ApocalypseIssiBought = Config.GetValue("Vehicles", "ApocalypseIssiBought", ApocalypseIssiBought);
				FutureShockIssiBought = Config.GetValue("Vehicles", "FutureShockIssiBought", FutureShockIssiBought);
				NightmareMonsterBought = Config.GetValue("Vehicles", "NightmareMonsterBought", NightmareMonsterBought);
				ApocalypseMonsterBought = Config.GetValue("Vehicles", "ApocalypseMonsterBought", ApocalypseMonsterBought);
				FutureShockMonsterBought = Config.GetValue("Vehicles", "FutureShockMonsterBought", FutureShockMonsterBought);
				NightmareImpalerBought = Config.GetValue("Vehicles", "NightmareImpalerBought", NightmareImpalerBought);
				ApocalypseImpalerBought = Config.GetValue("Vehicles", "ApocalypseImpalerBought", ApocalypseImpalerBought);
				FutureShockImpalerBought = Config.GetValue("Vehicles", "FutureShockImpalerBought", FutureShockImpalerBought);
				NightmareSlamvanBought = Config.GetValue("Vehicles", "NightmareSlamvanBought", NightmareSlamvanBought);
				ApocalypseSlamvanBought = Config.GetValue("Vehicles", "ApocalypseSlamvanBought", ApocalypseSlamvanBought);
				FutureShockSlamvanBought = Config.GetValue("Vehicles", "FutureShockSlamvanBought", FutureShockSlamvanBought);
				NightmareBruitusBought = Config.GetValue("Vehicles", "NightmareBrutusBought", NightmareBruitusBought);
				ApocalypseBruitusBought = Config.GetValue("Vehicles", "ApocalypseBrutusBought", ApocalypseBruitusBought);
				FutureShockBruitusBought = Config.GetValue("Vehicles", "FutureShockBrutusBought", FutureShockBruitusBought);
				CurrentBruiser = Config.GetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
				NightmareBruiserBought = Config.GetValue("Vehicles", "NightmareBruiserBought", NightmareBruiserBought);
				ApocalypseBruiserBought = Config.GetValue("Vehicles", "ApocalypseBruiserBought", ApocalypseBruiserBought);
				FutureShockBruiserBought = Config.GetValue("Vehicles", "FutureShockBruiserBought", FutureShockBruiserBought);
				NightmareZR380Bought = Config.GetValue("Vehicles", "NightmareZR380Bought", NightmareZR380Bought);
				ApocalypseZR380Bought = Config.GetValue("Vehicles", "ApocalypseZR380Bought", ApocalypseZR380Bought);
				FutureShockZR380Bought = Config.GetValue("Vehicles", "FutureShockZR380Bought", FutureShockZR380Bought);
				CliqueBought = Config.GetValue("Vehicles", "CliqueBought", CliqueBought);
				ItaligtoBought = Config.GetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
				TulipBought = Config.GetValue("Vehicles", "TulipBought", TulipBought);
				VamosBought = Config.GetValue("Vehicles", "VamosBought", VamosBought);
				SchlagenBought = Config.GetValue("Vehicles", "SchlagenBought", SchlagenBought);
				DeviantBought = Config.GetValue("Vehicles", "DeviantBought", DeviantBought);
				TorosBought = Config.GetValue("Vehicles", "TorosBought", TorosBought);
				DevesteBought = Config.GetValue("Vehicles", "DevesteBought", DevesteBought);
				RcBanditoBought = Config.GetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
				if (CurrentBruiser == 0)
				{
					CurrentBruiser = 1;
				}
				if (CurrentBruitus == 0)
				{
					CurrentBruitus = 1;
				}
				if (CurrentCerberus == 0)
				{
					CurrentCerberus = 1;
				}
				if (CurrentDeathbike == 0)
				{
					CurrentDeathbike = 1;
				}
				if (CurrentDominator == 0)
				{
					CurrentDominator = 1;
				}
				if (CurrentImpaler == 0)
				{
					CurrentImpaler = 1;
				}
				if (CurrentImperator == 0)
				{
					CurrentImperator = 1;
				}
				if (CurrentIssi == 0)
				{
					CurrentIssi = 1;
				}
				if (CurrentMonster == 0)
				{
					CurrentMonster = 1;
				}
				if (CurrentScarab == 0)
				{
					CurrentScarab = 1;
				}
				if (CurrentSlamvan == 0)
				{
					CurrentSlamvan = 1;
				}
				if (CurrentZR380 == 0)
				{
					CurrentZR380 = 1;
				}
				maxstocks = 10 * purchaselvl;
				float num = (float)(125000 * purchaselvl) / 0.75f;
				profitMargin = (float)(0.85 * (double)purchaselvl + 0.0);
				increaseGain = num;
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: MazeBank.ini Failed To Load.");
			}
		}

		public Model RequestModel(string Prop)
		{
			Model result = new Model(Prop);
			result.Request(250);
			if (result.IsInCdImage && result.IsValid)
			{
				while (!result.IsLoaded)
				{
					Script.Wait(50);
				}
				return result;
			}
			result.MarkAsNoLongerNeeded();
			return result;
		}

		public Model RequestModel(VehicleHash Prop)
		{
			Model result = new Model(Prop);
			result.Request(250);
			if (result.IsInCdImage && result.IsValid)
			{
				while (!result.IsLoaded)
				{
					Script.Wait(50);
				}
				return result;
			}
			result.MarkAsNoLongerNeeded();
			return result;
		}

		private void Setup()
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Expected O, but got Unknown
			//IL_0220: Unknown result type (might be due to invalid IL or missing references)
			//IL_022a: Expected O, but got Unknown
			//IL_0252: Unknown result type (might be due to invalid IL or missing references)
			//IL_025c: Expected O, but got Unknown
			//IL_040c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0416: Expected O, but got Unknown
			//IL_0476: Unknown result type (might be due to invalid IL or missing references)
			//IL_0480: Expected O, but got Unknown
			//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f1: Expected O, but got Unknown
			//IL_0535: Unknown result type (might be due to invalid IL or missing references)
			//IL_053f: Expected O, but got Unknown
			ArenaMenuPool = new MenuPool();
			ArenaMainMenu = new UIMenu("Arena War ", "Select an Option");
			ArenaMenuPool.Add(ArenaMainMenu);
			ArenaMenu = ArenaMenuPool.AddSubMenu(ArenaMainMenu, "Arena Vehicles");
			EI.Enableinterior();
			EI.ReloadInterior();
			waittime = Allstocks.waittime;
			MarkerEnter = new Vector3(-377f, -1877f, 19f);
			MarkerExit = new Vector3(216f, 5205f, -90f);
			MenuMarker = new Vector3(205f, 5163f, -87f);
			RoofEnterMarker = new Vector3(-74f, -809f, 242.5f);
			RoofExitMarker = new Vector3(-66f, -819.158f, 320.5f);
			HeliSpawn = new Vector3(-75f, -818.158f, 325.5f);
			CarSpawn = new Vector3(-83f, -815.158f, 35f);
			GarageMarker = new Vector3(-81f, -813.158f, 35f);
			WherehouseEnter = new Vector3(926f, -2306.158f, 28.5f);
			VehicleSpawn = new Vector3(-36f, -939.158f, 29.5f);
			WherehouseMarker = new Vector3(254.6f, -3057f, 5.7f);
			AircraftStorageLoc = new Vector3(1679f, 3238f, 40f);
			Dockloc = new Vector3(3865f, 4463.66f, 2f);
			LotLoc = new Vector3(863f, 2173f, 51f);
			Radiopos = new Vector3(-79.33f, -804.844f, 243f);
			GarageMenuSpawn = new Vector3(169f, 5180f, -90f);
			SetupMarker();
			modMenuPool = new MenuPool();
			mainMenu = new UIMenu("Arena War ", "Select an Option");
			modMenuPool.Add(mainMenu);
			ArenaGarageMenuPool = new MenuPool();
			ArenaGarageMenu = new UIMenu("Arena War ", "Select an Option");
			ArenaGarageMenuPool.Add(ArenaGarageMenu);
			ArenaVehicleMenu = ArenaGarageMenuPool.AddSubMenu(ArenaGarageMenu, "Arena Vehicles");
			methgarage = modMenuPool.AddSubMenu(mainMenu, "Purchase Options");
			ProductStock = modMenuPool.AddSubMenu(mainMenu, "Product Options");
			SpecialMissions = modMenuPool.AddSubMenu(mainMenu, "Arena War Races (Missions)");
			SupplyRunsmenu = modMenuPool.AddSubMenu(mainMenu, "Special Missions (Missions)");
			PointtoPointMenu = modMenuPool.AddSubMenu(mainMenu, "Point to Point (Missions)");
			DeathMatch = modMenuPool.AddSubMenu(mainMenu, "Vehicle Death Matches (Missions)");
			ChampionchipMatch = modMenuPool.AddSubMenu(mainMenu, "Championchip Matches (Missions)");
			SkyWars = modMenuPool.AddSubMenu(mainMenu, "Sky Wars Death Matches (Missions)");
			TurretMayhem = modMenuPool.AddSubMenu(mainMenu, "Turret Mayhem Matches (Missions)");
			RCKing = modMenuPool.AddSubMenu(mainMenu, "RC King (Missions)");
			HotRing = modMenuPool.AddSubMenu(mainMenu, "Hot Ring (Missions)");
			SmashandGrab = modMenuPool.AddSubMenu(mainMenu, "Smash And Grab (Missions)");
			DemoltionMenMenu = modMenuPool.AddSubMenu(mainMenu, "Demoltion Men (Missions)");
			GarageMenuPool = new MenuPool();
			GarageMenu = new UIMenu("Vehicles Menu ", "Select an Option");
			GarageMenuPool.Add(GarageMenu);
			VehicleMenu = GarageMenuPool.AddSubMenu(GarageMenu, "Vehicle Options");
			VehicleLoadMenu = GarageMenuPool.AddSubMenu(GarageMenu, "Vehicle Load Options");
			GarageMenuPool2 = new MenuPool();
			GarageMenu2 = new UIMenu("Vehicles Menu ", "Select an Option");
			GarageMenuPool2.Add(GarageMenu2);
			VehicleMenu2 = GarageMenuPool2.AddSubMenu(GarageMenu2, "Vehicle Options");
			Setupbuisness();
			SetupStadium();
			SetupProduct();
			SetupTrapsPositions();
			SetupArenaMenu();
			PlayerGaragemodMenuPool = new MenuPool();
			PlayerGarageMenu = new UIMenu("Arena War", "Select an Option");
			PlayerGaragemodMenuPool.Add(PlayerGarageMenu);
			PlayerGaragemainMenu = PlayerGaragemodMenuPool.AddSubMenu(PlayerGarageMenu, "Garage Options");
			RemoveMenuPool2 = new MenuPool();
			mainMenu2 = new UIMenu("Remove a Vehicle", "Select an Option");
			RemoveMenuPool2.Add(mainMenu2);
			RemoveMenu = RemoveMenuPool2.AddSubMenu(mainMenu2, "Remove A Vehicle");
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_mod" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_Arena_Interior_Mod_2" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_mod" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_Arena_Interior_Mod_2" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_vip" });
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2799.529, -3930.539, 182.235 });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "xs_x18int01_pit_fenceoval_col" });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "xs_dystopian_17" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "xs_dystopian_17" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "xs_x18int01_pit_fenceoval_col" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			SetUpVehicles();
			SetUpVehicles2();
			SetupGarage();
			RemoveCar();
			SetupRaces();
			SetupSkyWars();
			SetupTurretMayhem();
			ChampionChipMatch();
			SetupSpecialMissions();
			SetupSpecialMissions2();
			SetupSpecialMissions3();
			SetupSpecialMissions4();
			SetupSpecialMissions5();
			SetupSpecialMissions6();
			SetupSpecialMissions8();
		}

		public void SetupTurretMayhem()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(TurretMayhem, "Turret Mayhem");
			UIMenuItem Race4 = new UIMenuItem("Turret Mayhem 1 (Wasteland 4)");
			uIMenu.AddItem(Race4);
			UIMenuItem Race5 = new UIMenuItem("Turret Mayhem 2 (Scifi 4)");
			uIMenu.AddItem(Race5);
			UIMenuItem Race6 = new UIMenuItem("Turret Mayhem 3 (Dystopian 4)");
			uIMenu.AddItem(Race6);
			UIMenuItem Race7 = new UIMenuItem("Turret Mayhem 4 (Dystopian 8)");
			uIMenu.AddItem(Race7);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race6)
				{
					MissionSetup = true;
					MissionId = 28;
					Race = 2;
					RaceMarker = new Vector3(2790f, -3879.2f, 140f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Turret Mayhem Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : Race around around the Circuit, all the while avoiding the Turret that are shooting at you");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					Game.Player.Character.IsInvincible = true;
					LoadDystopian_4();
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race7)
				{
					MissionSetup = true;
					MissionId = 28;
					Race = 2;
					RaceMarker = new Vector3(2790f, -3879.2f, 140f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Turret Mayhem Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : Race around around the Circuit, all the while avoiding the Turret that are shooting at you");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					Game.Player.Character.IsInvincible = true;
					LoadDystopian_8();
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race5)
				{
					MissionSetup = true;
					MissionId = 28;
					Race = 1;
					RaceMarker = new Vector3(2773f, -3853.73f, 130f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Turret Mayhem Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : Race around around the Circuit, all the while avoiding the Turret that are shooting at you");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle3 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle3, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					Game.Player.Character.IsInvincible = true;
					LoadScifi_4();
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race4)
				{
					MissionSetup = true;
					MissionId = 28;
					Race = 1;
					RaceMarker = new Vector3(2773f, -3853.73f, 130f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Turret Mayhem Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : Race around around the Circuit, all the while avoiding the Turret that are shooting at you");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle4 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle4, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					Game.Player.Character.IsInvincible = true;
					LoadWasteland_4();
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		public void SetupSkyWars()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			//IL_0071: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(SkyWars, "Sky Wars Matches");
			UIMenuItem Race4 = new UIMenuItem("Death Match (Dystopian A) 4x Opp");
			uIMenu.AddItem(Race4);
			UIMenuItem Race5 = new UIMenuItem("Death Match (Dystopian A) 8x Opp");
			uIMenu.AddItem(Race5);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race5)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop in Props)
					{
						if (prop != null)
						{
							prop.Delete();
						}
					}
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Race = 2;
					MissionId = 27;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
					Vector3 pos = new Vector3(-58.9f, -861f, 1000f);
					SpawnProp("xs_terrain_set_dystopian_10", pos, new Vector3(0f, 0f, 0f), 1);
					SpawnProp("xs_prop_arena_turret_01a", new Vector3(-42f, -871f, 1009f), new Vector3(0f, 0f, 0f), 1);
					if (Trap_Flame.Count > 0)
					{
						Trap_Flame.Clear();
					}
					if (Trap_Flipper.Count > 0)
					{
						Trap_Flipper.Clear();
					}
					if (Trap_Mines.Count > 0)
					{
						Trap_Mines.Clear();
					}
					if (Trap_Spike.Count > 0)
					{
						Trap_Spike.Clear();
					}
					if (Trap_Turning.Count > 0)
					{
						Trap_Turning.Clear();
					}
					if (Trap_GunTower.Count > 0)
					{
						Trap_GunTower.Clear();
					}
					List<string> list = new List<string>();
					List<Vector3> list2 = new List<Vector3>
					{
						new Vector3(23f, -915f, 1001.5f),
						new Vector3(45f, -863f, 1001.5f),
						new Vector3(31f, -810f, 1001.5f),
						new Vector3(-24f, -811f, 1001.5f),
						new Vector3(63f, -826f, 1001.5f),
						new Vector3(86f, -837.7f, 1001.5f),
						new Vector3(83.4f, -895.5f, 1001.5f),
						new Vector3(32.1f, -931.4f, 1001.5f),
						new Vector3(6f, -919.6f, 1001.5f),
						new Vector3(-32.1f, -942.1f, 1001.5f),
						new Vector3(-128.021f, -898.6f, 1001.5f),
						new Vector3(-124.2f, -856.3f, 1001.5f),
						new Vector3(108.6f, -830f, 1001.5f),
						new Vector3(-79.7f, -794f, 1001.5f),
						new Vector3(-123.3f, -791.4f, 1001.5f),
						new Vector3(-145.8f, -808.2f, 1001.5f),
						new Vector3(-155.6f, -836.8f, 1001.5f),
						new Vector3(-166.6f, -872.9f, 1001.5f),
						new Vector3(-196.814f, -913.4f, 1001.5f),
						new Vector3(-206.149f, -823.8f, 1001.5f),
						new Vector3(-74.46f, -794.8f, 1001.5f),
						new Vector3(-217.8f, -866.8f, 1001.5f),
						new Vector3(-151.7f, -919.1f, 1001.5f),
						new Vector3(-48.01f, -924.8f, 1001.5f),
						new Vector3(8.4f, -792.5f, 1001.5f),
						new Vector3(-122.2f, -833.44f, 1001.5f),
						new Vector3(-66.15f, 871.2f, 1001.5f)
					};
					foreach (Prop prop2 in Props)
					{
						if (prop2 != null)
						{
							prop2.HasCollision = true;
							prop2.FreezePosition = true;
						}
					}
					Random random = new Random();
					foreach (Vector3 item18 in list2)
					{
						int num = random.Next(0, 360);
						int num2 = random.Next(1, 150);
						if (num2 < 25)
						{
							SpawnProp("xs_prop_arena_spikes_01a", item18, new Vector3(0f, 0f, num), 1);
							Prop item2 = Props[Props.Count - 1];
							Trap_Spike.Add(item2);
						}
						if (num2 > 25 && num2 < 50)
						{
							Vector3 pos2 = new Vector3(item18.X, item18.Y, item18.Z - 0.6f);
							SpawnProp("xs_prop_arena_pit_fire_01a", pos2, new Vector3(0f, 0f, num), 1);
							Prop item3 = Props[Props.Count - 1];
							Trap_Flame.Add(item3);
						}
						if (num2 > 50 && num2 < 60)
						{
							SpawnProp("xs_prop_arena_landmine_01a", item18, new Vector3(0f, 0f, num), 1);
							Prop item4 = Props[Props.Count - 1];
							Trap_Mines.Add(item4);
						}
						if (num2 > 60 && num2 < 80)
						{
							Vector3 pos3 = new Vector3(item18.X, item18.Y, item18.Z - 0.4f);
							SpawnProp("xs_prop_arena_landmine_03a_wl", pos3, new Vector3(0f, 0f, num), 1);
							Prop item5 = Props[Props.Count - 1];
							Trap_Mines.Add(item5);
						}
						if (num2 > 80 && num2 < 100)
						{
							Vector3 pos4 = new Vector3(item18.X, item18.Y, item18.Z - 3f);
							SpawnProp("xs_prop_arena_flipper_small_01a", pos4, new Vector3(0f, 0f, num), 1);
							Prop item6 = Props[Props.Count - 1];
							Trap_Flipper.Add(item6);
						}
						if (num2 > 100 && num2 < 120)
						{
							Vector3 pos5 = new Vector3(item18.X, item18.Y, item18.Z - 3f);
							SpawnProp("xs_prop_arena_flipper_small_01a", pos5, new Vector3(0f, 0f, num), 1);
							Prop item7 = Props[Props.Count - 1];
							Trap_Flipper.Add(item7);
						}
						if (num2 > 120 && num2 < 145)
						{
							Vector3 pos6 = new Vector3(item18.X, item18.Y, item18.Z - 0.4f);
							SpawnProp("xs_prop_arena_turntable_03a", pos6, new Vector3(0f, 0f, num), 1);
							Prop item8 = Props[Props.Count - 1];
							Trap_Turning.Add(item8);
						}
						if (num2 > 145)
						{
							SpawnProp("xs_prop_arena_turret_post_01a", item18, new Vector3(0f, 0f, num), 1);
							Prop item9 = Props[Props.Count - 1];
							Trap_GunTower.Add(item9);
						}
					}
					foreach (Prop prop3 in Props)
					{
						if (prop3 != null)
						{
							prop3.HasCollision = true;
							prop3.FreezePosition = true;
						}
					}
					foreach (Prop item19 in Trap_Flipper2)
					{
						if (item19 != null)
						{
							item19.HasCollision = false;
							item19.IsVisible = false;
							item19.FreezePosition = true;
						}
					}
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(113f, -873f, 1005f), 85f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					ArenaGarageMenuPool.CloseAllMenus();
					modMenuPool.CloseAllMenus();
					GarageMenuPool.CloseAllMenus();
					GarageMenuPool2.CloseAllMenus();
				}
				if (item == Race4)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop4 in Props)
					{
						if (prop4 != null)
						{
							prop4.Delete();
						}
					}
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Race = 1;
					MissionId = 27;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
					Vector3 pos7 = new Vector3(-58.9f, -861f, 1000f);
					SpawnProp("xs_terrain_set_dystopian_10", pos7, new Vector3(0f, 0f, 0f), 1);
					SpawnProp("xs_prop_arena_turret_01a", new Vector3(-42f, -871f, 1009f), new Vector3(0f, 0f, 0f), 1);
					if (Trap_Flame.Count > 0)
					{
						Trap_Flame.Clear();
					}
					if (Trap_Flipper.Count > 0)
					{
						Trap_Flipper.Clear();
					}
					if (Trap_Mines.Count > 0)
					{
						Trap_Mines.Clear();
					}
					if (Trap_Spike.Count > 0)
					{
						Trap_Spike.Clear();
					}
					if (Trap_Turning.Count > 0)
					{
						Trap_Turning.Clear();
					}
					if (Trap_GunTower.Count > 0)
					{
						Trap_GunTower.Clear();
					}
					List<string> list3 = new List<string>();
					List<Vector3> list4 = new List<Vector3>
					{
						new Vector3(23f, -915f, 1001.5f),
						new Vector3(45f, -863f, 1001.5f),
						new Vector3(31f, -810f, 1001.5f),
						new Vector3(-24f, -811f, 1001.5f),
						new Vector3(63f, -826f, 1001.5f),
						new Vector3(86f, -837.7f, 1001.5f),
						new Vector3(83.4f, -895.5f, 1001.5f),
						new Vector3(32.1f, -931.4f, 1001.5f),
						new Vector3(6f, -919.6f, 1001.5f),
						new Vector3(-32.1f, -942.1f, 1001.5f),
						new Vector3(-128.021f, -898.6f, 1001.5f),
						new Vector3(-124.2f, -856.3f, 1001.5f),
						new Vector3(108.6f, -830f, 1001.5f),
						new Vector3(-79.7f, -794f, 1001.5f),
						new Vector3(-123.3f, -791.4f, 1001.5f),
						new Vector3(-145.8f, -808.2f, 1001.5f),
						new Vector3(-155.6f, -836.8f, 1001.5f),
						new Vector3(-166.6f, -872.9f, 1001.5f),
						new Vector3(-196.814f, -913.4f, 1001.5f),
						new Vector3(-206.149f, -823.8f, 1001.5f),
						new Vector3(-74.46f, -794.8f, 1001.5f),
						new Vector3(-217.8f, -866.8f, 1001.5f),
						new Vector3(-151.7f, -919.1f, 1001.5f),
						new Vector3(-48.01f, -924.8f, 1001.5f),
						new Vector3(8.4f, -792.5f, 1001.5f),
						new Vector3(-122.2f, -833.44f, 1001.5f),
						new Vector3(-66.15f, 871.2f, 1001.5f)
					};
					foreach (Prop prop5 in Props)
					{
						if (prop5 != null)
						{
							prop5.HasCollision = true;
							prop5.FreezePosition = true;
						}
					}
					Random random2 = new Random();
					foreach (Vector3 item20 in list4)
					{
						int num3 = random2.Next(0, 360);
						int num4 = random2.Next(1, 150);
						if (num4 < 25)
						{
							SpawnProp("xs_prop_arena_spikes_01a", item20, new Vector3(0f, 0f, num3), 1);
							Prop item10 = Props[Props.Count - 1];
							Trap_Spike.Add(item10);
						}
						if (num4 > 25 && num4 < 50)
						{
							Vector3 pos8 = new Vector3(item20.X, item20.Y, item20.Z - 0.6f);
							SpawnProp("xs_prop_arena_pit_fire_01a", pos8, new Vector3(0f, 0f, num3), 1);
							Prop item11 = Props[Props.Count - 1];
							Trap_Flame.Add(item11);
						}
						if (num4 > 50 && num4 < 60)
						{
							SpawnProp("xs_prop_arena_landmine_01a", item20, new Vector3(0f, 0f, num3), 1);
							Prop item12 = Props[Props.Count - 1];
							Trap_Mines.Add(item12);
						}
						if (num4 > 60 && num4 < 80)
						{
							Vector3 pos9 = new Vector3(item20.X, item20.Y, item20.Z - 0.4f);
							SpawnProp("xs_prop_arena_landmine_03a_wl", pos9, new Vector3(0f, 0f, num3), 1);
							Prop item13 = Props[Props.Count - 1];
							Trap_Mines.Add(item13);
						}
						if (num4 > 80 && num4 < 100)
						{
							Vector3 pos10 = new Vector3(item20.X, item20.Y, item20.Z - 3f);
							SpawnProp("xs_prop_arena_flipper_small_01a", pos10, new Vector3(0f, 0f, num3), 1);
							Prop item14 = Props[Props.Count - 1];
							Trap_Flipper.Add(item14);
						}
						if (num4 > 100 && num4 < 120)
						{
							Vector3 pos11 = new Vector3(item20.X, item20.Y, item20.Z - 3f);
							SpawnProp("xs_prop_arena_flipper_small_01a", pos11, new Vector3(0f, 0f, num3), 1);
							Prop item15 = Props[Props.Count - 1];
							Trap_Flipper.Add(item15);
						}
						if (num4 > 120 && num4 < 145)
						{
							Vector3 pos12 = new Vector3(item20.X, item20.Y, item20.Z - 0.4f);
							SpawnProp("xs_prop_arena_turntable_03a", pos12, new Vector3(0f, 0f, num3), 1);
							Prop item16 = Props[Props.Count - 1];
							Trap_Turning.Add(item16);
						}
						if (num4 > 145)
						{
							SpawnProp("xs_prop_arena_turret_post_01a", item20, new Vector3(0f, 0f, num3), 1);
							Prop item17 = Props[Props.Count - 1];
							Trap_GunTower.Add(item17);
						}
					}
					foreach (Prop prop6 in Props)
					{
						if (prop6 != null)
						{
							prop6.HasCollision = true;
							prop6.FreezePosition = true;
						}
					}
					foreach (Prop item21 in Trap_Flipper2)
					{
						if (item21 != null)
						{
							item21.HasCollision = false;
							item21.IsVisible = false;
							item21.FreezePosition = true;
						}
					}
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(113f, -873f, 1005f), 85f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					ArenaGarageMenuPool.CloseAllMenus();
					modMenuPool.CloseAllMenus();
					GarageMenuPool.CloseAllMenus();
					GarageMenuPool2.CloseAllMenus();
				}
			});
		}

		public void ChampionChipMatch()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Expected O, but got Unknown
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(ChampionchipMatch, "Championchip Matches");
			UIMenuItem Race15 = new UIMenuItem("Death Match (Scifi 2) 4x Opp");
			uIMenu.AddItem(Race15);
			UIMenuItem Race11 = new UIMenuItem("Death Match (Scifi 5) 4x Opp");
			uIMenu.AddItem(Race11);
			UIMenuItem Race12 = new UIMenuItem("Death Match (Scifi 10) 4x Opp");
			uIMenu.AddItem(Race12);
			UIMenuItem Race16 = new UIMenuItem("Death Match (Dystopian 5) 4x Opp");
			uIMenu.AddItem(Race16);
			UIMenuItem Race17 = new UIMenuItem("Death Match (Dystopian 10) 4x Opp");
			uIMenu.AddItem(Race17);
			UIMenuItem Race18 = new UIMenuItem("Death Match (Wasteland 5) 4x Opp");
			uIMenu.AddItem(Race18);
			UIMenuItem Race13 = new UIMenuItem("Death Match (Dystopian 7) 4x Opp");
			uIMenu.AddItem(Race13);
			UIMenuItem Race14 = new UIMenuItem("Death Match (Dystopian 12) 4x Opp");
			uIMenu.AddItem(Race14);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race14)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop in Props)
					{
						if (prop != null)
						{
							prop.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_12();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race13)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop2 in Props)
					{
						if (prop2 != null)
						{
							prop2.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_8();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race12)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop3 in Props)
					{
						if (prop3 != null)
						{
							prop3.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_10();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle3 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle3, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race11)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop4 in Props)
					{
						if (prop4 != null)
						{
							prop4.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle4 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle4, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race18)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop5 in Props)
					{
						if (prop5 != null)
						{
							prop5.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle5 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle5, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race17)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop6 in Props)
					{
						if (prop6 != null)
						{
							prop6.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_10();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle6 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle6, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race16)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop7 in Props)
					{
						if (prop7 != null)
						{
							prop7.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle7 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle7, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race15)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					foreach (Prop prop8 in Props)
					{
						if (prop8 != null)
						{
							prop8.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_2();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle8 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle8, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 26;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		public void SetupArenaMenu()
		{
			//IL_0176: Unknown result type (might be due to invalid IL or missing references)
			//IL_0180: Expected O, but got Unknown
			//IL_019a: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a4: Expected O, but got Unknown
			//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c1: Expected O, but got Unknown
			//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e0: Expected O, but got Unknown
			//IL_0205: Unknown result type (might be due to invalid IL or missing references)
			//IL_020f: Expected O, but got Unknown
			//IL_0222: Unknown result type (might be due to invalid IL or missing references)
			//IL_022c: Expected O, but got Unknown
			//IL_0241: Unknown result type (might be due to invalid IL or missing references)
			//IL_024b: Expected O, but got Unknown
			List<dynamic> TF = new List<object>();
			TF.Add(false);
			TF.Add(true);
			List<dynamic> Type = new List<object>();
			Type.Add("Apocalypse");
			Type.Add("Nightmare");
			Type.Add("Future Shock");
			List<dynamic> VEH = new List<object>();
			VEH.Add("Bruiser");
			VEH.Add("Bruitus");
			VEH.Add("Cerberus");
			VEH.Add("DeathBike");
			VEH.Add("Dominator");
			VEH.Add("Impaler");
			VEH.Add("Imperator");
			VEH.Add("Issi");
			VEH.Add("Monster");
			VEH.Add("Scarab");
			VEH.Add("Slamvan");
			VEH.Add("ZR380");
			UIMenu uIMenu = ArenaMenuPool.AddSubMenu(ArenaMenu, "Request Vehicle");
			UIMenuListItem V = new UIMenuListItem("Vehicle : ", (List<object>)VEH, 0);
			uIMenu.AddItem((UIMenuItem)(object)V);
			UIMenuListItem T = new UIMenuListItem("Type : ", (List<object>)Type, 0);
			uIMenu.AddItem((UIMenuItem)(object)T);
			UIMenuItem RequestV1 = new UIMenuItem("Request Vehicle");
			uIMenu.AddItem(RequestV1);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == RequestV1)
				{
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					string text = VEH[V.get_Index()];
					string text2 = Type[T.get_Index()];
					string text3 = "";
					VehicleHash vehicleHash = VehicleHash.Adder;
					if (text2.Equals("Apocalypse"))
					{
						text3 = "1Apocalypse.ini";
						if (text.Equals("Bruiser"))
						{
							vehicleHash = VehicleHash.Bruiser;
						}
						if (text.Equals("Bruitus"))
						{
							vehicleHash = VehicleHash.Brutus;
						}
						if (text.Equals("Cerberus"))
						{
							vehicleHash = VehicleHash.Cerberus;
						}
						if (text.Equals("DeathBike"))
						{
							vehicleHash = VehicleHash.Deathbike;
						}
						if (text.Equals("Dominator"))
						{
							vehicleHash = VehicleHash.Dominator4;
						}
						if (text.Equals("Impaler"))
						{
							vehicleHash = VehicleHash.Impaler2;
						}
						if (text.Equals("Imperator"))
						{
							vehicleHash = VehicleHash.Imperator;
						}
						if (text.Equals("Issi"))
						{
							vehicleHash = VehicleHash.Issi4;
						}
						if (text.Equals("Monster"))
						{
							vehicleHash = VehicleHash.Monster3;
						}
						if (text.Equals("Scarab"))
						{
							vehicleHash = VehicleHash.Scarab;
						}
						if (text.Equals("Slamvan"))
						{
							vehicleHash = VehicleHash.SlamVan4;
						}
						if (text.Equals("ZR380"))
						{
							vehicleHash = VehicleHash.ZR380;
						}
					}
					if (text2.Equals("Nightmare"))
					{
						text3 = "2NIghtmare.ini";
						if (text.Equals("Bruiser"))
						{
							vehicleHash = VehicleHash.Bruiser3;
						}
						if (text.Equals("Bruitus"))
						{
							vehicleHash = VehicleHash.Brutus3;
						}
						if (text.Equals("Cerberus"))
						{
							vehicleHash = VehicleHash.Cerberus3;
						}
						if (text.Equals("DeathBike"))
						{
							vehicleHash = VehicleHash.Deathbike3;
						}
						if (text.Equals("Dominator"))
						{
							vehicleHash = VehicleHash.Dominator6;
						}
						if (text.Equals("Impaler"))
						{
							vehicleHash = VehicleHash.Impaler4;
						}
						if (text.Equals("Imperator"))
						{
							vehicleHash = VehicleHash.Imperator3;
						}
						if (text.Equals("Issi"))
						{
							vehicleHash = VehicleHash.Issi6;
						}
						if (text.Equals("Monster"))
						{
							vehicleHash = VehicleHash.Monster5;
						}
						if (text.Equals("Scarab"))
						{
							vehicleHash = VehicleHash.Scarab3;
						}
						if (text.Equals("Slamvan"))
						{
							vehicleHash = VehicleHash.SlamVan6;
						}
						if (text.Equals("ZR380"))
						{
							vehicleHash = VehicleHash.ZR3803;
						}
					}
					if (text2.Equals("Future Shock"))
					{
						text3 = "3FutureShock.ini";
						if (text.Equals("Bruiser"))
						{
							vehicleHash = VehicleHash.Bruiser2;
						}
						if (text.Equals("Bruitus"))
						{
							vehicleHash = VehicleHash.Brutus2;
						}
						if (text.Equals("Cerberus"))
						{
							vehicleHash = VehicleHash.Cerberus2;
						}
						if (text.Equals("DeathBike"))
						{
							vehicleHash = VehicleHash.Deathbike2;
						}
						if (text.Equals("Dominator"))
						{
							vehicleHash = VehicleHash.Dominator5;
						}
						if (text.Equals("Impaler"))
						{
							vehicleHash = VehicleHash.Impaler3;
						}
						if (text.Equals("Imperator"))
						{
							vehicleHash = VehicleHash.Imperator2;
						}
						if (text.Equals("Issi"))
						{
							vehicleHash = VehicleHash.Issi5;
						}
						if (text.Equals("Monster"))
						{
							vehicleHash = VehicleHash.Monster4;
						}
						if (text.Equals("Scarab"))
						{
							vehicleHash = VehicleHash.Scarab2;
						}
						if (text.Equals("Slamvan"))
						{
							vehicleHash = VehicleHash.SlamVan5;
						}
						if (text.Equals("ZR380"))
						{
							vehicleHash = VehicleHash.ZR3802;
						}
					}
					SC.LoadIniFile(Loadpath + text + "//" + text3);
					Script.Wait(1);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicleHash, new Vector3(2785f, -3909.6f, 140f), 0f);
					Script.Wait(20);
					if (PLayerVehicle != null)
					{
						SC.Load(PLayerVehicle);
					}
				}
			});
			UIMenu uIMenu2 = ArenaMenuPool.AddSubMenu(ArenaMenu, "Request Random Vehicle");
			UIMenuListItem RNDMods = new UIMenuListItem("Random Mods : ", (List<object>)TF, 0);
			uIMenu2.AddItem((UIMenuItem)(object)RNDMods);
			UIMenuItem RequestV2 = new UIMenuItem("Request Vehicle");
			uIMenu2.AddItem(RequestV2);
			uIMenu2.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == RequestV2)
				{
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					Model vehicle = getVehicle();
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2785f, -3909.6f, 140f), 0f);
					if (TF[RNDMods.get_Index()] == true)
					{
						SetupRivalCar(0, PLayerVehicle);
					}
				}
			});
		}

		private void SetupMarker()
		{
			TowerBlip = World.CreateBlip(new Vector3(-371f, -1850f, 20f));
			Function.Call(Hash._0xDF735600A4696DAF, new InputArgument[2] { TowerBlip, 458 });
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { TowerBlip, 8 });
			TowerBlip.Name = "Arena War Business ";
			TowerBlip2 = World.CreateBlip(new Vector3(-393f, -1870f, 20f));
			Function.Call(Hash._0xDF735600A4696DAF, new InputArgument[2] { TowerBlip2, 269 });
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { TowerBlip2, 8 });
			TowerBlip2.Name = "Arena War Business (Arena Teleport)";
		}

		private void SetupRaces()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(SpecialMissions, "Races");
			UIMenuItem Race5 = new UIMenuItem("Arena War Race (3 Lap, RaceTrack)");
			uIMenu.AddItem(Race5);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race5)
				{
					MissionSetup = true;
					MissionId = 3;
					Race = 5;
					RaceMarker = new Vector3(1099f, 163f, 81f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Arena War Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : i just heard of a race down at the race track, teach thos fools a lesson!");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(1108f, 188f, 81f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
				}
			});
		}

		public void LoadCarinToRealWorld(Vehicle V)
		{
			if (V == ZR380)
			{
				ZR380 = null;
			}
			if (V == Bruiser)
			{
				Bruiser = null;
			}
			if (V == Clique)
			{
				Clique = null;
			}
			if (V == Italigto)
			{
				Italigto = null;
			}
			if (V == Vamos)
			{
				Vamos = null;
			}
			if (V == Tulip)
			{
				Tulip = null;
			}
			if (V == Schlagen)
			{
				Schlagen = null;
			}
			if (V == Deviant)
			{
				Deviant = null;
			}
			if (V == Toros)
			{
				Toros = null;
			}
			if (V == Deveste)
			{
				Deveste = null;
			}
			if (V == RcBandito)
			{
				RcBandito = null;
			}
			if (V == Cerberus)
			{
				Cerberus = null;
			}
			if (V == Deathbike)
			{
				Deathbike = null;
			}
			if (V == Scarab)
			{
				Scarab = null;
			}
			if (V == Dominator)
			{
				Dominator = null;
			}
			if (V == Slamvan)
			{
				Slamvan = null;
			}
			if (V == Monster)
			{
				Monster = null;
			}
			if (V == Issi)
			{
				Issi = null;
			}
			if (V == Impaler)
			{
				Impaler = null;
			}
			if (V == Imperator)
			{
				Imperator = null;
			}
			if (V == Bruitus)
			{
				Bruitus = null;
			}
			Vehicle vehicle = V;
			Vehicle vehicle2 = vehicle;
			V = null;
			IsInInterior = false;
			vehicle2.Position = new Vector3(-371.8876f, -1850f, 21f);
			vehicle2.Rotation = new Vector3(6f, -1f, 10f);
			Game.Player.Character.SetIntoVehicle(vehicle2, VehicleSeat.Driver);
			vehicle2.IsDriveable = true;
			DeleteVehicles();
			if (SaveVehicle != null)
			{
				SaveVehicle.MarkAsNoLongerNeeded();
			}
			SaveVehicle = vehicle2;
			SaveVehicle.IsDriveable = true;
			SaveVehicle.Repair();
			SaveVehicle.FreezePosition = false;
			SaveVehicle.HighBeamsOn = false;
			isInGarage = false;
			isinsecondVehicleBay = false;
			IsInInterior = false;
			IsinInterior = false;
			LastVehicle = null;
		}

		public void LoadCarinToRealWorld2(Vehicle V)
		{
			isInGarage = false;
			IsinInterior = false;
			Vehicle currentVehicle = Game.Player.Character.CurrentVehicle;
			Vehicle vehicle = currentVehicle;
			vehicle.Position = new Vector3(-371.8876f, -1850f, 21f);
			Game.Player.Character.SetIntoVehicle(vehicle, VehicleSeat.Driver);
			DestoryCars();
			DeleteVehicles();
			vehicle.IsDriveable = true;
			vehicle.Rotation = new Vector3(6f, -1f, 10f);
			if (SaveVehicle != null)
			{
				SaveVehicle.MarkAsNoLongerNeeded();
			}
			SaveVehicle = vehicle;
			SaveVehicle.IsDriveable = true;
			SaveVehicle.Repair();
			SaveVehicle.FreezePosition = false;
			SaveVehicle.HighBeamsOn = false;
			isInGarage = false;
			isinsecondVehicleBay = false;
			IsInInterior = false;
			IsinInterior = false;
			LastVehicle = null;
		}

		public void SaveLocalcar(string iniFile, Vehicle V, string FileName)
		{
			if (Game.Player.Character.CurrentVehicle != null)
			{
				UI.Notify(Loadpath + FileName + "//" + iniFile + ".ini");
				SC.LoadIniFile(Loadpath + FileName + "//" + iniFile + ".ini");
				SC.SaveWithoutDelete();
				UI.Notify("Alan : Save current vehicle");
			}
		}

		public void LoadVehicles()
		{
			DeleteVehicles();
			try
			{
				Cerberus = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Scarab = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Dominator = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Imperator = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Deathbike = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Issi = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Monster = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Impaler = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Slamvan = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Bruitus = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				DeleteVehicles();
				if (CurrentCerberus == 1)
				{
					if (ApocalypseCerberusBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Cerberus//1Apocalypse.ini");
						Cerberus = World.CreateVehicle(RequestModel(VehicleHash.Cerberus), CerberusSpawn, -90f);
						SC.Load(Cerberus);
					}
				}
				else if (CurrentCerberus == 3)
				{
					if (FutureShockCerberusBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Cerberus//3FutureShock.ini");
						Cerberus = World.CreateVehicle(RequestModel(VehicleHash.Cerberus2), CerberusSpawn, -90f);
						SC.Load(Cerberus);
					}
				}
				else if (CurrentCerberus == 2 && NightmareCerberusBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Cerberus//2NIghtmare.ini");
					Cerberus = World.CreateVehicle(RequestModel(VehicleHash.Cerberus3), CerberusSpawn, -90f);
					SC.Load(Cerberus);
				}
				if (CurrentScarab == 1)
				{
					if (ApocalypseScarabBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Scarab//1Apocalypse.ini");
						Scarab = World.CreateVehicle(RequestModel(VehicleHash.Scarab), ScarabSpawn, 90f);
						SC.Load(Scarab);
					}
				}
				else if (CurrentScarab == 3)
				{
					if (FutureShockScarabBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Scarab//3FutureShock.ini");
						Scarab = World.CreateVehicle(RequestModel(VehicleHash.Scarab2), ScarabSpawn, 90f);
						SC.Load(Scarab);
					}
				}
				else if (CurrentScarab == 2 && NightmareScarabBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Scarab//2NIghtmare.ini");
					Scarab = World.CreateVehicle(RequestModel(VehicleHash.Scarab3), ScarabSpawn, 90f);
					SC.Load(Scarab);
				}
				if (CurrentDominator == 1)
				{
					if (ApocalypseDominatorBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Dominator//1Apocalypse.ini");
						Dominator = World.CreateVehicle(RequestModel(VehicleHash.Dominator4), DominatorSpawn, -90f);
						SC.Load(Dominator);
					}
				}
				else if (CurrentDominator == 3)
				{
					if (FutureShockDominatorBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Dominator//3FutureShock.ini");
						Dominator = World.CreateVehicle(RequestModel(VehicleHash.Dominator5), DominatorSpawn, -90f);
						SC.Load(Dominator);
					}
				}
				else if (CurrentDominator == 2 && NightmareDominatorBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Dominator//2NIghtmare.ini");
					Dominator = World.CreateVehicle(RequestModel(VehicleHash.Dominator6), DominatorSpawn, -90f);
					SC.Load(Dominator);
				}
				if (CurrentImperator == 1)
				{
					if (ApocalypseDominatorBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Imperator//1Apocalypse.ini");
						Imperator = World.CreateVehicle(RequestModel(VehicleHash.Imperator), ImperatorSpawn, 90f);
						SC.Load(Imperator);
					}
				}
				else if (CurrentImperator == 3)
				{
					if (FutureShockImperatorBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Imperator//3FutureShock.ini");
						Imperator = World.CreateVehicle(RequestModel(VehicleHash.Imperator2), ImperatorSpawn, 90f);
						SC.Load(Imperator);
					}
				}
				else if (CurrentImperator == 2 && NightmareImperatorBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Imperator//2NIghtmare.ini");
					Imperator = World.CreateVehicle(RequestModel(VehicleHash.Imperator3), ImperatorSpawn, 90f);
					SC.Load(Imperator);
				}
				if (CurrentDeathbike == 1)
				{
					if (ApocalypseDeathbikeBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Deathbike//1Apocalypse.ini");
						Deathbike = World.CreateVehicle(RequestModel(VehicleHash.Deathbike), DeathbikeSpawn, -90f);
						SC.Load(Deathbike);
					}
				}
				else if (CurrentDeathbike == 3)
				{
					if (FutureShockDeathbikeBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Deathbike//3FutureShock.ini");
						Deathbike = World.CreateVehicle(RequestModel(VehicleHash.Deathbike2), DeathbikeSpawn, -90f);
						SC.Load(Deathbike);
					}
				}
				else if (CurrentDeathbike == 2 && NightmareDeathbikeBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Deathbike//2NIghtmare.ini");
					Deathbike = World.CreateVehicle(RequestModel(VehicleHash.Deathbike3), DeathbikeSpawn, -90f);
					SC.Load(Deathbike);
				}
				if (CurrentIssi == 1)
				{
					if (ApocalypseIssiBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Issi//1Apocalypse.ini");
						Issi = World.CreateVehicle(RequestModel(VehicleHash.Issi4), IssiSpawn, -90f);
						SC.Load(Issi);
					}
				}
				else if (CurrentIssi == 3)
				{
					if (FutureShockIssiBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Issi//3FutureShock.ini");
						Issi = World.CreateVehicle(RequestModel(VehicleHash.Issi5), IssiSpawn, -90f);
						SC.Load(Issi);
					}
				}
				else if (CurrentIssi == 2 && NightmareIssiBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Issi//2NIghtmare.ini");
					Issi = World.CreateVehicle(RequestModel(VehicleHash.Issi6), IssiSpawn, -90f);
					SC.Load(Issi);
				}
				if (CurrentMonster == 1)
				{
					if (ApocalypseMonsterBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Monster//1Apocalypse.ini");
						Monster = World.CreateVehicle(RequestModel(VehicleHash.Monster3), MonsterSpawn, -90f);
						SC.Load(Monster);
					}
				}
				else if (CurrentMonster == 3)
				{
					if (FutureShockMonsterBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Monster//3FutureShock.ini");
						Monster = World.CreateVehicle(RequestModel(VehicleHash.Monster4), MonsterSpawn, -90f);
						SC.Load(Monster);
					}
				}
				else if (CurrentMonster == 2 && NightmareMonsterBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Monster//2NIghtmare.ini");
					Monster = World.CreateVehicle(RequestModel(VehicleHash.Monster5), MonsterSpawn, -90f);
					SC.Load(Monster);
				}
				if (CurrentImpaler == 1)
				{
					if (ApocalypseImpalerBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Impaler//1Apocalypse.ini");
						Impaler = World.CreateVehicle(RequestModel(VehicleHash.Impaler2), ImpalerSpawn, 90f);
						SC.Load(Impaler);
					}
				}
				else if (CurrentImpaler == 3)
				{
					if (FutureShockImpalerBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Impaler//3FutureShock.ini");
						Impaler = World.CreateVehicle(RequestModel(VehicleHash.Impaler3), ImpalerSpawn, 90f);
						SC.Load(Impaler);
					}
				}
				else if (CurrentImpaler == 2 && NightmareImpalerBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Impaler//2NIghtmare.ini");
					Impaler = World.CreateVehicle(RequestModel(VehicleHash.Impaler4), ImpalerSpawn, 90f);
					SC.Load(Impaler);
				}
				if (CurrentSlamvan == 1)
				{
					if (ApocalypseSlamvanBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Slamvan//1Apocalypse.ini");
						Slamvan = World.CreateVehicle(RequestModel(VehicleHash.SlamVan4), SlamvanSpawn, -90f);
						SC.Load(Slamvan);
					}
				}
				else if (CurrentSlamvan == 3)
				{
					if (FutureShockSlamvanBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Slamvan//3FutureShock.ini");
						Slamvan = World.CreateVehicle(RequestModel(VehicleHash.SlamVan5), SlamvanSpawn, -90f);
						SC.Load(Slamvan);
					}
				}
				else if (CurrentSlamvan == 2 && NightmareSlamvanBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Slamvan//2NIghtmare.ini");
					Slamvan = World.CreateVehicle(RequestModel(VehicleHash.SlamVan6), SlamvanSpawn, -90f);
					SC.Load(Slamvan);
				}
				if (CurrentBruitus == 1)
				{
					if (ApocalypseBruitusBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Brutus//1Apocalypse.ini");
						Bruitus = World.CreateVehicle(RequestModel(VehicleHash.Brutus), BruitusSpawn, 90f);
						SC.Load(Bruitus);
					}
				}
				else if (CurrentBruitus == 3)
				{
					if (FutureShockBruitusBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Brutus//3FutureShock.ini");
						Bruitus = World.CreateVehicle(RequestModel(VehicleHash.Brutus2), BruitusSpawn, 90f);
						SC.Load(Bruitus);
					}
				}
				else if (CurrentBruitus == 2 && NightmareBruitusBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Brutus//2NIghtmare.ini");
					Bruitus = World.CreateVehicle(RequestModel(VehicleHash.Brutus3), BruitusSpawn, 90f);
					SC.Load(Bruitus);
				}
			}
			catch (NullReferenceException)
			{
				UI.Notify("~r~ Arena War Main Garage : Somthing went wrong while loading these vehicles, please retry, if it persists check the vehicle ini files for invald vehiclenames or contact HKH~w~");
			}
		}

		public void LoadVehicles2()
		{
			DeleteVehicles();
			try
			{
				ZR380 = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Bruiser = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Clique = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Italigto = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Tulip = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Vamos = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Schlagen = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Deveste = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Deviant = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				Toros = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				RcBandito = World.CreateVehicle(VehicleHash.Adder, new Vector3(0f, 0f, 0f));
				DeleteVehicles();
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				if (CurrentZR380 == 1)
				{
					if (ApocalypseZR380Bought == 1)
					{
						SC.LoadIniFile(Loadpath + "ZR380//1Apocalypse.ini");
						ZR380 = World.CreateVehicle(RequestModel(VehicleHash.ZR380), ZR380Spawn, 90f);
						SC.Load(ZR380);
					}
				}
				else if (CurrentZR380 == 3)
				{
					if (FutureShockZR380Bought == 1)
					{
						SC.LoadIniFile(Loadpath + "ZR380//3FutureShock.ini");
						ZR380 = World.CreateVehicle(RequestModel(VehicleHash.ZR3802), ZR380Spawn, 90f);
						SC.Load(ZR380);
					}
				}
				else if (CurrentZR380 == 2 && NightmareZR380Bought == 1)
				{
					SC.LoadIniFile(Loadpath + "ZR380//2NIghtmare.ini");
					ZR380 = World.CreateVehicle(RequestModel(VehicleHash.ZR3803), ZR380Spawn, 90f);
					SC.Load(ZR380);
				}
				Script.Wait(50);
				if (CurrentBruiser == 1)
				{
					if (ApocalypseBruiserBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Bruiser//1Apocalypse.ini");
						Bruiser = World.CreateVehicle(RequestModel(VehicleHash.Bruiser), BruiserSpawn, -90f);
						SC.Load(Bruiser);
					}
				}
				else if (CurrentBruiser == 3)
				{
					if (FutureShockBruiserBought == 1)
					{
						SC.LoadIniFile(Loadpath + "Bruiser//3FutureShock.ini");
						Bruiser = World.CreateVehicle(RequestModel(VehicleHash.Bruiser2), BruiserSpawn, -90f);
						SC.Load(Bruiser);
					}
				}
				else if (CurrentBruiser == 2 && NightmareBruiserBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Bruiser//2NIghtmare.ini");
					Bruiser = World.CreateVehicle(RequestModel(VehicleHash.Bruiser3), BruiserSpawn, -90f);
					SC.Load(Bruiser);
				}
				Script.Wait(50);
				if (CliqueBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Clique//Car.ini");
					Clique = World.CreateVehicle(RequestModel(VehicleHash.Clique), CliqueSpawn, 90f);
					SC.Load(Clique);
				}
				Script.Wait(50);
				if (ItaligtoBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Italigto//Car.ini");
					Italigto = World.CreateVehicle(RequestModel(VehicleHash.ItaliGTO), ItaligtoSpawn, -90f);
					SC.Load(Italigto);
				}
				Script.Wait(50);
				if (TulipBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Tulip//Car.ini");
					Tulip = World.CreateVehicle(RequestModel(VehicleHash.Tulip), TulipSpawn, -90f);
					SC.Load(Tulip);
				}
				Script.Wait(50);
				if (VamosBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Vamos//Car.ini");
					Vamos = World.CreateVehicle(RequestModel(VehicleHash.Vamos), VamosSpawn, -90f);
					SC.Load(Vamos);
				}
				Script.Wait(50);
				if (SchlagenBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Schlagen//Car.ini");
					Schlagen = World.CreateVehicle(RequestModel(VehicleHash.Schlagen), SchlagenSpawn, 90f);
					SC.Load(Schlagen);
				}
				Script.Wait(50);
				if (DeviantBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Deviant//Car.ini");
					Deviant = World.CreateVehicle(RequestModel(VehicleHash.Deviant), DeviantSpawn, -90f);
					SC.Load(Deviant);
				}
				Script.Wait(50);
				if (TorosBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Toros//Car.ini");
					Toros = World.CreateVehicle(RequestModel(VehicleHash.Toros), TorosSpawn, 90f);
					SC.Load(Toros);
				}
				Script.Wait(50);
				if (DevesteBought == 1)
				{
					SC.LoadIniFile(Loadpath + "Deveste//Car.ini");
					Deveste = World.CreateVehicle(RequestModel(VehicleHash.Deveste), DevesteSpawn, -90f);
					SC.Load(Deveste);
				}
				Script.Wait(50);
				if (RcBanditoBought == 1)
				{
					SC.LoadIniFile(Loadpath + "rcbandito//Car.ini");
					RcBandito = World.CreateVehicle(RequestModel(VehicleHash.RCBandito), RcBanditoSpawn, 90f);
					SC.Load(RcBandito);
				}
			}
			catch (NullReferenceException)
			{
				UI.Notify("~r~ Arena War Second Garage : Somthing went wrong while loading these vehicles, please retry, if it persists check the vehicle ini files for invald vehiclenames or contact HKH~w~");
			}
		}

		private void SetupSpecialMissions8()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0102: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(DemoltionMenMenu, "Demolition Men");
			UIMenuItem Race13 = new UIMenuItem("Demolition Men, 4x Opp (Dystopian 5)");
			uIMenu.AddItem(Race13);
			UIMenuItem Race14 = new UIMenuItem("Demolition Men, 4x Opp (Dystopian 10)");
			uIMenu.AddItem(Race14);
			UIMenuItem Race15 = new UIMenuItem("Demolition Men, 4x Opp (Scifi 5)");
			uIMenu.AddItem(Race15);
			UIMenuItem Race16 = new UIMenuItem("Demolition Men, 4x Opp (Scifi 10)");
			uIMenu.AddItem(Race16);
			UIMenuItem Race12 = new UIMenuItem("Demolition Men, 4x Opp (Wasteland 2)");
			uIMenu.AddItem(Race12);
			UIMenuItem Race11 = new UIMenuItem("Demolition Men, 4x Opp (Wasteland 5)");
			uIMenu.AddItem(Race11);
			UIMenuItem Race10 = new UIMenuItem("Demolition Men, 4x Opp (Random Track & Car)");
			uIMenu.AddItem(Race10);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race10)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Random random = new Random();
					int num = random.Next(1, 80);
					if (num < 10)
					{
						LoadDystopian_10();
					}
					if (num > 10 && num < 20)
					{
						LoadDystopian_5();
					}
					if (num > 20 && num < 30)
					{
						LoadScifi_2();
					}
					if (num > 30 && num < 40)
					{
						LoadScifi_5();
					}
					if (num > 40 && num < 50)
					{
						LoadScifi_10();
					}
					if (num > 50 && num < 60)
					{
						LoadWasteland_5();
					}
					if (num > 60 && num < 70)
					{
						LoadWasteland_5();
					}
					if (num > 70 && num < 80)
					{
						LoadDystopian_12();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					UI.Notify("Alan : ok boss, avoid the opponents to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 2;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race15)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_5();
					UI.Notify("Alan : ok boss, avoid the rc banditos to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race16)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_10();
					UI.Notify("Alan : ok boss, avoid the rc banditos to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle3 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle3, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race13)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_5();
					UI.Notify("Alan : ok boss, avoid the rc banditos to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle4 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle4, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race14)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_10();
					UI.Notify("Alan : ok boss, avoid the rc banditos to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle5 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle5, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race12)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_2();
					UI.Notify("Alan : ok boss, avoid the rc banditos to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle6 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle6, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race11)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_5();
					UI.Notify("Alan : ok boss, avoid the rc banditos to earn money, survive for aslong as possible");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle7 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle7, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 20;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		private void SetupSpecialMissions7()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(BeastWars, "Beast Wars");
			UIMenuItem Race4 = new UIMenuItem("Beast Wars  1, 4x Opp (Scifi 5)");
			uIMenu.AddItem(Race4);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race4)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (PLayerVehicle2 != null)
					{
						PLayerVehicle2.Delete();
					}
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					foreach (Ped ped in Peds)
					{
						if (ped != null && ped.CurrentVehicle == null)
						{
							ped.Delete();
						}
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Random random = new Random();
					int num = random.Next(1, 100);
					Model vehicle = getVehicle2();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, Game.Player.Character.Position);
					PLayerVehicle2 = World.CreateVehicle(VehicleHash.TrailerSmall2, Game.Player.Character.Position);
					PLayerVehicle2.AttachTo(PLayerVehicle, 0);
					PLayerVehicle2.CreateRandomPedOnSeat(VehicleSeat.Driver);
					Friendlyped = PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver);
					Friendlyped.IsInvincible = true;
					PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver).IsInvincible = true;
					PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver).CanBeTargetted = false;
					Peds.Add(PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver));
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					Ped pedOnSeat = PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver);
					int num2 = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { "RESPECT_PLAYER" });
					Function.Call(Hash._0xC80A74AC829DDD92, new InputArgument[2] { pedOnSeat, num2 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 0, 0 });
					Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
					SetupRivalCar(0, PLayerVehicle);
					PLayerVehicle2.PrimaryColor = PLayerVehicle.PrimaryColor;
					PLayerVehicle2.SecondaryColor = PLayerVehicle.SecondaryColor;
					Random random2 = new Random();
					int num3 = random2.Next(1, 300);
					PLayerVehicle2.SetMod(VehicleMod.Roof, -1, true);
					PLayerVehicle2.SetNoCollision(PLayerVehicle, true);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 16;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
					PLayerVehicle.BodyHealth = 2000f;
					PLayerVehicle2.BodyHealth = 2000f;
				}
			});
		}

		private void SetupSpecialMissions6()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			//IL_0071: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(SmashandGrab, "Smash And Grab");
			UIMenuItem Race4 = new UIMenuItem("Smash and Grab 1, 4x Opp (Wasteland 5)");
			uIMenu.AddItem(Race4);
			UIMenuItem Race5 = new UIMenuItem("Smash and Grab 1, 8x Opp (Wasteland 5)");
			uIMenu.AddItem(Race5);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race5)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					LoadWasteland_5();
					Game.Player.Character.Position = new Vector3(2773f, -3853.73f, 130f);
					UI.Notify("Alan : ok boss, ok boss grab the loot from the opposite goal and bring it back to ours for money");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					PLayerVehicle = World.CreateVehicle(getVehicle(), new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					FinishLineBLip = World.CreateBlip(RaceMarker);
					FinishLineBLip.Name = "Start Marker";
					FinishLineBLip.Sprite = BlipSprite.RaceFinish;
					FinishLineBLip.Color = BlipColor.White;
					FinishLineBLip.Name = "Start Marker";
					Race = 2;
					MissionId = 15;
					MissionSetup = true;
					StartedRace = false;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race4)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (FinishLineBLip != null)
					{
						FinishLineBLip.Remove();
					}
					LoadWasteland_5();
					Game.Player.Character.Position = new Vector3(2773f, -3853.73f, 130f);
					UI.Notify("Alan : ok boss, ok boss grab the loot from the opposite goal and bring it back to ours for money");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					FinishLineBLip = World.CreateBlip(RaceMarker);
					FinishLineBLip.Name = "Start Marker";
					FinishLineBLip.Sprite = BlipSprite.RaceFinish;
					FinishLineBLip.Color = BlipColor.White;
					FinishLineBLip.Name = "Start Marker";
					Race = 1;
					MissionId = 15;
					MissionSetup = true;
					StartedRace = false;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		private void SetupSpecialMissions5()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			//IL_0071: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(HotRing, "Hot Ring Circuits");
			UIMenuItem Race4 = new UIMenuItem("Hot Ring Circuit 1 (Wasteland 4)");
			uIMenu.AddItem(Race4);
			UIMenuItem Race5 = new UIMenuItem("Hot Ring Circuit 2 (Scifi 4)");
			uIMenu.AddItem(Race5);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race5)
				{
					MissionSetup = true;
					MissionId = 13;
					Race = 1;
					RaceMarker = new Vector3(2773f, -3853.73f, 130f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Hot Ring Circuit Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : Race around around the Circuit, all the while avoiding the ");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					Game.Player.Character.IsInvincible = true;
					LoadScifi_4();
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race4)
				{
					MissionSetup = true;
					MissionId = 13;
					Race = 1;
					RaceMarker = new Vector3(2773f, -3853.73f, 130f);
					StartedRace = false;
					RaceBlip = World.CreateBlip(RaceMarker);
					RaceBlip.Name = "Hot Ring Circuit Race";
					RaceBlip.Sprite = BlipSprite.Race;
					UI.Notify("Alan : Race around around the Circuit, all the while avoiding the ");
					Game.Player.Character.Position = RaceMarker;
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					Game.Player.Character.IsInvincible = true;
					LoadWasteland_4();
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		private void SetupSpecialMissions4()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0102: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(RCKing, "RC King");
			UIMenuItem Race11 = new UIMenuItem("RC King (Scifi 2)");
			uIMenu.AddItem(Race11);
			UIMenuItem Race12 = new UIMenuItem("RC King (Dystopian 3)");
			uIMenu.AddItem(Race12);
			UIMenuItem Race13 = new UIMenuItem("RC King (Wasteland 9)");
			uIMenu.AddItem(Race13);
			UIMenuItem Race14 = new UIMenuItem("RC King (Dystopian 7)");
			uIMenu.AddItem(Race14);
			UIMenuItem Race15 = new UIMenuItem("RC King (Scifi 9)");
			uIMenu.AddItem(Race15);
			UIMenuItem Race16 = new UIMenuItem("RC King (Wasteland 7)");
			uIMenu.AddItem(Race16);
			UIMenuItem Race10 = new UIMenuItem("RC King (BMX Park)");
			uIMenu.AddItem(Race10);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race10)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(-888f, -802f, 14f);
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(-888f, -802f, 14f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(-888f, -802f, 14f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 2;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race16)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_7();
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race15)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_9();
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race14)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_7();
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race13)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_9();
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race12)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_3();
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race11)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_2();
					UI.Notify("Alan : ok boss, drive this RC Bandito around, flipping it jumping over stuff to earn cash, in the given time limit");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle("rcbandito", new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					UI.Notify("test3");
					Race = 1;
					MissionId = 4;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 80;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					PLayerVehicle.FreezePosition = false;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		private void SetupSpecialMissions3()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Expected O, but got Unknown
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_011d: Expected O, but got Unknown
			//IL_0130: Unknown result type (might be due to invalid IL or missing references)
			//IL_013a: Expected O, but got Unknown
			//IL_014d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0157: Expected O, but got Unknown
			//IL_016a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0174: Expected O, but got Unknown
			//IL_0187: Unknown result type (might be due to invalid IL or missing references)
			//IL_0191: Expected O, but got Unknown
			//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ae: Expected O, but got Unknown
			//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01cb: Expected O, but got Unknown
			//IL_01de: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e8: Expected O, but got Unknown
			//IL_01fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0207: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(DeathMatch, "Vehicle Death Match");
			UIMenuItem Race20 = new UIMenuItem("Death Match (Scifi 2) 4x Opp");
			uIMenu.AddItem(Race20);
			UIMenuItem Race11 = new UIMenuItem("Death Match (Scifi 5) 4x Opp");
			uIMenu.AddItem(Race11);
			UIMenuItem Race12 = new UIMenuItem("Death Match (Scifi 10) 4x Opp");
			uIMenu.AddItem(Race12);
			UIMenuItem Race21 = new UIMenuItem("Death Match (Dystopian 5) 4x Opp");
			uIMenu.AddItem(Race21);
			UIMenuItem Race22 = new UIMenuItem("Death Match (Dystopian 10) 4x Opp");
			uIMenu.AddItem(Race22);
			UIMenuItem Race25 = new UIMenuItem("Death Match (Wasteland 5) 4x Opp");
			uIMenu.AddItem(Race25);
			UIMenuItem Race16 = new UIMenuItem("Death Match (Dystopian 7) 4x Opp");
			uIMenu.AddItem(Race16);
			UIMenuItem Race17 = new UIMenuItem("Death Match (Dystopian 12) 4x Opp");
			uIMenu.AddItem(Race17);
			UIMenuItem Race24 = new UIMenuItem("Death Match (Scifi 2) 8x Opp");
			uIMenu.AddItem(Race24);
			UIMenuItem Race14 = new UIMenuItem("Death Match (Scifi 5) 8x Opp");
			uIMenu.AddItem(Race14);
			UIMenuItem Race15 = new UIMenuItem("Death Match (Scifi 10) 8x Opp");
			uIMenu.AddItem(Race15);
			UIMenuItem Race13 = new UIMenuItem("Death Match (Dystopian 5) 8x Opp");
			uIMenu.AddItem(Race13);
			UIMenuItem Race23 = new UIMenuItem("Death Match (Dystopian 10) 8x Opp");
			uIMenu.AddItem(Race23);
			UIMenuItem Race10 = new UIMenuItem("Death Match (Wasteland 5) 8x Opp");
			uIMenu.AddItem(Race10);
			UIMenuItem Race18 = new UIMenuItem("Death Match (Dystopian 7) 8x Opp");
			uIMenu.AddItem(Race18);
			UIMenuItem Race19 = new UIMenuItem("Death Match (Dystopian 12) 8x Opp");
			uIMenu.AddItem(Race19);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race19)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_12();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race18)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_8();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race17)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_12();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle3 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle3, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race16)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_8();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle4 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle4, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race15)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_10();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle5 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle5, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race14)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle6 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle6, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race13)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle7 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle7, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race12)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_10();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle8 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle8, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race11)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle9 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle9, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race10)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle10 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle10, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race25)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle11 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle11, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race24)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_2();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle12 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle12, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race23)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_10();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle13 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle13, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 5;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race22)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_10();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle14 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle14, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race21)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_5();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle15 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle15, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race20)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_2();
					UI.Notify("Alan : ok boss, destroy each vehicle to progress to the next wave to earn money, each wave vehicles are harded to destroy");
					RaceMarker = new Vector3(2640f, -3801f, 140f);
					Script.Wait(200);
					Model vehicle16 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle16, new Vector3(2782.99f, -3898.15f, 140.001f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 1;
					MissionId = 2;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					vehicleHealth = 600;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		private void SetupSpecialMissions2()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00db: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e5: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(PointtoPointMenu, "Point to Point");
			UIMenuItem Race11 = new UIMenuItem("40 Second Start (Dystopian 2)");
			uIMenu.AddItem(Race11);
			UIMenuItem Race14 = new UIMenuItem("50 Second Start (Dystopian 3)");
			uIMenu.AddItem(Race14);
			UIMenuItem Race12 = new UIMenuItem("40 Second Start (Scifi 2)");
			uIMenu.AddItem(Race12);
			UIMenuItem Race15 = new UIMenuItem("50 Second Start (Scifi 9)");
			uIMenu.AddItem(Race15);
			UIMenuItem Race13 = new UIMenuItem("40 Second Start (Wasteland 2)");
			uIMenu.AddItem(Race13);
			UIMenuItem Race10 = new UIMenuItem("50 Second Start (Wasteland 9)");
			uIMenu.AddItem(Race10);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race11)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_2();
					UI.Notify("Alan : ok boss drive through the checkpoints to earn cash, while a timer counts to 0, good luck, oh and avoid the mines!");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					Script.Wait(200);
					Model vehicle = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 4;
					MissionId = 10;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race12)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_2();
					UI.Notify("Alan : ok boss drive through the checkpoints to earn cash, while a timer counts to 0, good luck, oh and avoid the mines!");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle2 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle2, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 6;
					MissionId = 10;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race13)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_2();
					UI.Notify("Alan : ok boss drive through the checkpoints to earn cash, while a timer counts to 0, good luck, oh and avoid the mines!");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle3 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle3, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 7;
					MissionId = 10;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 40;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race14)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadDystopian_3();
					UI.Notify("Alan : ok boss drive through the checkpoints to earn cash, while a timer counts to 0, good luck, oh and avoid the mines!");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle4 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle4, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 8;
					MissionId = 10;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 50;
					Game.Player.Character.IsInvincible = true;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race15)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadScifi_9();
					UI.Notify("Alan : ok boss drive through the checkpoints to earn cash, while a timer counts to 0, good luck, oh and avoid the mines!");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle5 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle5, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 9;
					MissionId = 10;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 50;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race10)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
					LoadWasteland_9();
					UI.Notify("Alan : ok boss drive through the checkpoints to earn cash, while a timer counts to 0, good luck, oh and avoid the mines!");
					RaceMarker = new Vector3(2731f, -3882f, 140f);
					UI.Notify("test1");
					Script.Wait(200);
					Model vehicle6 = getVehicle();
					if (PLayerVehicle != null)
					{
						PLayerVehicle.Delete();
					}
					PLayerVehicle = World.CreateVehicle(vehicle6, new Vector3(2782.99f, -3898.15f, 140f), 148f);
					Game.Player.Character.SetIntoVehicle(PLayerVehicle, VehicleSeat.Driver);
					SetupRivalCar(0, PLayerVehicle);
					VtoGetBlip = World.CreateBlip(RaceMarker);
					VtoGetBlip.Name = "Start Marker";
					VtoGetBlip.Sprite = BlipSprite.RaceFinish;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Start Marker";
					Race = 10;
					MissionId = 10;
					MissionSetup = true;
					StartedRace = false;
					TimeLeft = 50;
					Game.Player.Character.IsInvincible = true;
					checkpointReaced = 0;
					moneytobeawarded = 0f;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
			});
		}

		public void SetPedOutfit(Ped ped)
		{
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 0, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 1, 142, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 2, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 3, 19, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 4, 107, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 5, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 6, 84, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 7, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 8, 130, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 9, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 10, 3, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 11, 275, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 12, 0, 0, 1 });
		}

		public Ped CreatePed(Vector3 Loc)
		{
			Ped ped = World.CreatePed(PedHash.FreemodeMale01, Loc);
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 0, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 1, 142, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 2, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 3, 19, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 4, 107, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 5, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 6, 84, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 7, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 8, 130, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 9, 0, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 10, 3, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 11, 275, 0, 1 });
			Function.Call(Hash._0x262B14F48D29DE80, new InputArgument[5] { ped, 12, 0, 0, 1 });
			Peds.Add(ped);
			return ped;
		}

		private void SetupSpecialMissions()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00db: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e5: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(SupplyRunsmenu, "Special Missions");
			UIMenuItem Race3 = new UIMenuItem("Rogue Contestant");
			uIMenu.AddItem(Race3);
			UIMenuItem Race4 = new UIMenuItem("The Rookie");
			uIMenu.AddItem(Race4);
			UIMenuItem Race5 = new UIMenuItem("The Oil Fued");
			uIMenu.AddItem(Race5);
			UIMenuItem Race6 = new UIMenuItem("The Air Tanker");
			uIMenu.AddItem(Race6);
			UIMenuItem Race7 = new UIMenuItem("The Beast");
			uIMenu.AddItem(Race7);
			UIMenuItem Race8 = new UIMenuItem("Traning Day");
			uIMenu.AddItem(Race8);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Race8)
				{
					foreach (Ped ped4 in Peds)
					{
						if (ped4 != null)
						{
							ped4.Delete();
						}
					}
					foreach (Vehicle item in ExtraV)
					{
						if (item != null)
						{
							item.Delete();
						}
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					foreach (Prop prop in Props)
					{
						if (prop != null)
						{
							prop.Delete();
						}
					}
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGet1 != null)
					{
						VtoGet1.Delete();
					}
					TriggerEscape = false;
					try
					{
						Model vehicle = getVehicle2();
						VtoGet = World.CreateVehicle(vehicle, new Vector3(1891f, 2786f, 44f));
						VtoGet.Rotation = new Vector3(0f, 0f, 33f);
						Ped ped = CreatePed(VtoGet.Position);
						ped.Task.WarpIntoVehicle(VtoGet, VehicleSeat.Driver);
						vehicle = getVehicle2();
						VtoGet1 = World.CreateVehicle(vehicle, new Vector3(1895f, 2789f, 44f));
						VtoGet1.Rotation = new Vector3(0f, 0f, 33f);
						ped = CreatePed(VtoGet1.Position);
						ped.Task.WarpIntoVehicle(VtoGet1, VehicleSeat.Driver);
						UpgradeVehicle3(VtoGet);
						SetupModifications(VtoGet);
						Script.Wait(1);
						UpgradeVehicle3(VtoGet1);
						SetupModifications(VtoGet1);
					}
					catch (Exception)
					{
						VtoGet = World.CreateVehicle(VehicleHash.ZR3802, new Vector3(1895f, 2789f, 44f));
						VtoGet.Rotation = new Vector3(0f, 0f, 33f);
						Ped ped2 = CreatePed(VtoGet.Position);
						ped2.Task.WarpIntoVehicle(VtoGet, VehicleSeat.Driver);
						VtoGet1 = World.CreateVehicle(VehicleHash.Imperator2, new Vector3(1891f, 2786f, 44f));
						VtoGet1.Rotation = new Vector3(0f, 0f, 33f);
						ped2 = CreatePed(VtoGet1.Position);
						ped2.Task.WarpIntoVehicle(VtoGet1, VehicleSeat.Driver);
						UpgradeVehicle3(VtoGet);
						SetupModifications(VtoGet);
						Script.Wait(1);
						UpgradeVehicle3(VtoGet1);
						SetupModifications(VtoGet1);
					}
					VtoGetBlip = World.CreateBlip(new Vector3(1882f, 2801f, 43f));
					VtoGetBlip.Name = "Destroy Both Racing vehicles";
					VtoGetBlip.Sprite = BlipSprite.RaceArenaWar;
					VtoGetBlip.Color = BlipColor.Pink;
					VtoGetBlip.Name = "Destroy Both Racing vehicles";
					VtoGetBlip.ShowRoute = true;
					VtoGet1.Alpha = 255;
					VtoGet.Alpha = 255;
					SpawnProp("stt_prop_race_gantry_01", new Vector3(1886f, 2804f, 43f), new Vector3(0f, 0f, -66f), 1);
					MissionId = 25;
					MissionSetup = true;
					UI.Notify("Alan : boss we have got some wanabies doing laps, out side LS, go destroy their vehicles and any other around them");
					foreach (Vector3 item2 in new List<Vector3>
					{
						new Vector3(1841f, 2769.2f, 46f),
						new Vector3(1844f, 2751f, 46f),
						new Vector3(1830f, 2767f, 46f),
						new Vector3(1879f, 2831f, 46f),
						new Vector3(1897f, 2830f, 46f),
						new Vector3(1907f, 2812f, 46f),
						new Vector3(1959f, 2725f, 46f),
						new Vector3(1944f, 2739f, 46f),
						new Vector3(1727f, 2800f, 46f),
						new Vector3(1715f, 2793f, 46f),
						new Vector3(1692f, 2809f, 45f),
						new Vector3(1689f, 2822f, 45f)
					})
					{
						bool flag = true;
						Script.Wait(1);
						Model vehicle2 = getVehicle();
						Vehicle vehicle3 = World.CreateVehicle(vehicle2, item2, 0f);
						SetupRivalCar(0, vehicle3);
						vehicle3.EngineRunning = true;
						vehicle3.HighBeamsOn = true;
						Random random = new Random();
						int num = random.Next(0, 360);
						vehicle3.Rotation = new Vector3(0f, 0f, num);
						ExtraV.Add(vehicle3);
					}
				}
				if (item == Race7)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGet1 != null)
					{
						VtoGet1.Delete();
					}
					if (VtoGet2 != null)
					{
						VtoGet2.Delete();
					}
					if (VtoGet3 != null)
					{
						VtoGet3.Delete();
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					Vector3 position = Randomlocation();
					Model vehicle4 = getVehicle2();
					VtoGet = World.CreateVehicle(vehicle4, Randomlocation());
					VtoGet1 = World.CreateVehicle(VehicleHash.TrailerSmall2, position);
					VtoGet1.AttachTo(VtoGet, 0);
					VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
					VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
					Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
					Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
					Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
					Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
					Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
					SetupRivalCar(0, VtoGet);
					VtoGet1.PrimaryColor = VtoGet.PrimaryColor;
					VtoGet1.SecondaryColor = VtoGet.SecondaryColor;
					VtoGet.SetMod(VehicleMod.Roof, 0, true);
					UI.Notify("Alan : boss we have got some sort of custom vehicle, running wild with the cops, go destroy it, be carefull its heavily armed");
					VtoGetBlip = World.CreateBlip(VtoGet.Position);
					VtoGetBlip.Name = "Find Vehicle";
					VtoGetBlip.Sprite = BlipSprite.Tank;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Find Vehicle";
					UI.Notify("test3");
					MissionId = 18;
					MissionSetup = true;
					Piracymission = 1;
					VtoGet.Health = 1300;
					VtoGet.BodyHealth = 1300f;
					VtoGet1.Health = 1300;
					VtoGet1.BodyHealth = 1300f;
				}
				if (item == Race6)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGet3 != null)
					{
						VtoGet3.Delete();
					}
					if (VtoGet2 != null)
					{
						VtoGet2.Delete();
					}
					if (VtoGet6 != null)
					{
						VtoGet6.Delete();
					}
					if (VtoGet4 != null)
					{
						VtoGet4.Delete();
					}
					if (VtoGet5 != null)
					{
						VtoGet5.Delete();
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					if (VtoGetBlip2 != null)
					{
						VtoGetBlip2.Remove();
					}
					if (VtoGetBlip1 != null)
					{
						VtoGetBlip1.Remove();
					}
					EndPointPos = new Vector3(-382f, -1835f, 20f);
					Vector3 position2 = new Vector3(-2499f, 3155f, 33f);
					Vector3 position3 = new Vector3(2026f, 4748f, 41f);
					Vector3 position4 = new Vector3(1094f, 3044f, 40f);
					UI.Notify("test");
					VtoGet = World.CreateVehicle(VehicleHash.Skylift, position2);
					VtoGet.Rotation = new Vector3(0f, 0f, -169f);
					VtoGet4 = World.CreateVehicle("Scarab", position2);
					UpgradeVehicle3(VtoGet4);
					VtoGet.IsInvincible = true;
					VtoGet4.IsInvincible = true;
					VtoGet3 = World.CreateVehicle(VehicleHash.Skylift, position3);
					VtoGet3.Rotation = new Vector3(0f, 0f, 172f);
					VtoGet5 = World.CreateVehicle("Scarab", position3);
					VtoGet3.IsInvincible = true;
					VtoGet5.IsInvincible = true;
					UpgradeVehicle3(VtoGet5);
					VtoGet2 = World.CreateVehicle(VehicleHash.Skylift, position4);
					VtoGet2.Rotation = new Vector3(0f, 0f, 172f);
					VtoGet6 = World.CreateVehicle("Scarab", position4);
					VtoGet2.IsInvincible = true;
					VtoGet6.IsInvincible = true;
					UpgradeVehicle3(VtoGet6);
					SetupRivalCar(0, VtoGet4);
					SetupRivalCar(0, VtoGet5);
					SetupRivalCar(0, VtoGet6);
					Function.Call(Hash._0x6B9BBD38AB0796DF, new InputArgument[15]
					{
						VtoGet4, VtoGet, 0, 0.0, -3.0, -1.0, 0.0, 0.0, 0.0, true,
						true, true, true, 1, true
					});
					Function.Call(Hash._0x6B9BBD38AB0796DF, new InputArgument[15]
					{
						VtoGet5, VtoGet3, 0, 0.0, -3.0, -1.0, 0.0, 0.0, 0.0, true,
						true, true, true, 1, true
					});
					Function.Call(Hash._0x6B9BBD38AB0796DF, new InputArgument[15]
					{
						VtoGet6, VtoGet2, 0, 0.0, -3.0, -1.0, 0.0, 0.0, 0.0, true,
						true, true, true, 1, true
					});
					UI.Notify("test1");
					VtoGet.CreatePedOnSeat(VehicleSeat.Driver, PedHash.ArmGoon02GMY);
					VtoGet2.CreatePedOnSeat(VehicleSeat.Driver, PedHash.ArmGoon02GMY);
					VtoGet3.CreatePedOnSeat(VehicleSeat.Driver, PedHash.ArmGoon02GMY);
					DropedVehicleA = false;
					DropedVehicleB = false;
					DropedVehicleC = false;
					Ped ped3 = World.CreateRandomPed(EndPointPos);
					ped3.IsInvincible = true;
					ped3.IsVisible = false;
					ped3.FreezePosition = true;
					Peds.Add(ped3);
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(ped3);
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(ped3);
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(ped3);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(VtoGet.Position);
					VtoGetBlip.Sprite = BlipSprite.HelicopterAnimated;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Destroy Skylift A";
					VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
					VtoGetBlip3.Sprite = BlipSprite.HelicopterAnimated;
					VtoGetBlip3.Color = BlipColor.White;
					VtoGetBlip3.Name = "Destroy Skylift B";
					VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
					VtoGetBlip2.Sprite = BlipSprite.HelicopterAnimated;
					VtoGetBlip2.Color = BlipColor.White;
					VtoGetBlip2.Name = "Destroy Skylift C";
					UI.Notify("test3");
					EndPointBlip = World.CreateBlip(new Vector3(-382f, -1835f, 20f));
					EndPointBlip.Sprite = BlipSprite.Castle;
					EndPointBlip.Name = "Delivery Point";
					UI.Notify("test4");
					MissionId = 11;
					Race = 1;
					MissionSetup = true;
					UI.Notify("Alan: Boss I've spotted 3 vehicles on route to Stadium, Destroy All Three, Before they reach their destination for a reward, there carring some sort of luxury tank");
					UI.Notify("Alan: id on the vehicle says its a Skylift Helicopter, Carryng a Scarab");
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race5)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGet3 != null)
					{
						VtoGet3.Delete();
					}
					if (VtoGet2 != null)
					{
						VtoGet2.Delete();
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					if (VtoGetBlip2 != null)
					{
						VtoGetBlip2.Remove();
					}
					if (VtoGetBlip1 != null)
					{
						VtoGetBlip1.Remove();
					}
					EndPointPos = new Vector3(-382f, -1835f, 20f);
					Vector3 position5 = new Vector3(-2173f, -346f, 12f);
					Vector3 position6 = new Vector3(-217f, 260f, 91f);
					Vector3 position7 = new Vector3(1201f, -379f, 58f);
					UI.Notify("test");
					VtoGet = World.CreateVehicle("Cerberus", position5);
					VtoGet3 = World.CreateVehicle("Cerberus", position6);
					VtoGet2 = World.CreateVehicle("Cerberus", position7);
					UI.Notify("test1");
					VtoGet.CreatePedOnSeat(VehicleSeat.Driver, PedHash.ArmGoon02GMY);
					VtoGet2.CreatePedOnSeat(VehicleSeat.Driver, PedHash.ArmGoon02GMY);
					VtoGet3.CreatePedOnSeat(VehicleSeat.Driver, PedHash.ArmGoon02GMY);
					Ped pedOnSeat2 = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
					Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
					Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
					pedOnSeat2 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
					Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
					Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
					pedOnSeat2 = VtoGet3.GetPedOnSeat(VehicleSeat.Driver);
					Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
					Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
					Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
					Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet, EndPointPos, 20f, 120f, 1);
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet3, EndPointPos, 20f, 120f, 1);
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet2, EndPointPos, 20f, 120f, 1);
					UI.Notify("test2");
					VtoGetBlip = World.CreateBlip(VtoGet.Position);
					VtoGetBlip.Sprite = BlipSprite.GunCar;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Vehicle A";
					VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
					VtoGetBlip3.Sprite = BlipSprite.GunCar;
					VtoGetBlip3.Color = BlipColor.White;
					VtoGetBlip3.Name = "Vehicle B";
					VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
					VtoGetBlip2.Sprite = BlipSprite.GunCar;
					VtoGetBlip2.Color = BlipColor.White;
					VtoGetBlip2.Name = "Vehicle A";
					UI.Notify("test3");
					EndPointBlip = World.CreateBlip(EndPointPos);
					EndPointBlip.Sprite = BlipSprite.Castle;
					EndPointBlip.Name = "Delivery Point";
					UI.Notify("test4");
					MissionId = 7;
					Race = 1;
					MissionSetup = true;
					UI.Notify("Alan: Boss I've spotted 3 vehicles on route to Stadium, Destroy All Three, Before they reach their destination for a reward, there carring vital oil supplies for our rivals");
					UI.Notify("Alan: id on the vehicle says its a Cerberus Oil Tanker");
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race4)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGet1 != null)
					{
						VtoGet1.Delete();
					}
					if (VtoGet2 != null)
					{
						VtoGet2.Delete();
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					foreach (Ped ped5 in Peds)
					{
						if (ped5 != null)
						{
							ped5.Delete();
						}
					}
					VtoGet = World.CreateVehicle(VehicleHash.Glendale, new Vector3(-2037f, -466f, 11f), 11f);
					VtoGet1 = World.CreateVehicle(VehicleHash.Dominator, new Vector3(-2033f, -457f, 10f), 93f);
					VtoGet2 = World.CreateVehicle(VehicleHash.SlamVan, new Vector3(-2044f, -459f, 11f), 58f);
					Peds.Add(World.CreateRandomPed(new Vector3(-2042f, -464f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2033f, -454f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2034f, -462f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2024f, -463f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2034f, -447f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2044f, -445f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2053f, -453f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2035f, -460f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2021f, -455f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2027f, -448f, 11f)));
					Peds.Add(World.CreateRandomPed(new Vector3(-2013f, -460f, 11f)));
					UI.Notify("test1");
					VtoGetBlip = World.CreateBlip(new Vector3(-2040f, -456f, 11f));
					SetupRivalCar(0, VtoGet);
					UI.Notify("test2");
					VtoGetBlip.Name = "Destroy vehicles";
					VtoGetBlip.Sprite = BlipSprite.Bomb;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Destroy  Vehicle";
					UI.Notify("test3");
					SetupPed = false;
					PedsCounted = 0;
					MissionId = 6;
					Race = 1;
					MissionSetup = true;
					IsinInterior = false;
					IsInInterior = false;
					isInGarage = false;
					isinsecondVehicleBay = false;
				}
				if (item == Race3)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					Vector3 position8 = Randomlocation();
					VehicleHash vehicleHash = RandomVehicleFun();
					Model vehicle5 = getVehicle();
					VtoGet = World.CreateVehicle(vehicle5, position8, 45f);
					UI.Notify("Alan : boss we have got some lunatic playing with the cops!, go teach him a lesson, damage his vehicle, but dont destroy it!");
					VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
					VtoGet.CreateRandomPedOnSeat(VehicleSeat.Passenger);
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
					VtoGetBlip = World.CreateBlip(position8);
					SetupRivalCar(0, VtoGet);
					VtoGetBlip.Name = "Find Vehicle";
					VtoGetBlip.Sprite = BlipSprite.GunCar;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Find Vehicle";
					UI.Notify("test3");
					MissionId = 8;
					MissionSetup = true;
					Piracymission = 1;
					VtoGet.Health = 12000;
					VtoGet.BodyHealth = 12000f;
					vehiclehealth = VtoGet.Health;
				}
			});
		}

		public void RemoveCar()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Expected O, but got Unknown
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_011d: Expected O, but got Unknown
			//IL_0130: Unknown result type (might be due to invalid IL or missing references)
			//IL_013a: Expected O, but got Unknown
			//IL_014f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0159: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(RemoveMenu, "Remove Vehicle");
			UIMenuItem Slot1A = new UIMenuItem("Slot 1");
			uIMenu.AddItem(Slot1A);
			UIMenuItem Slot2A = new UIMenuItem("Slot 2");
			uIMenu.AddItem(Slot2A);
			UIMenuItem Slot3A = new UIMenuItem("Slot 3");
			uIMenu.AddItem(Slot3A);
			UIMenuItem Slot4A = new UIMenuItem("Slot 4");
			uIMenu.AddItem(Slot4A);
			UIMenuItem Slot5A = new UIMenuItem("Slot 5");
			uIMenu.AddItem(Slot5A);
			UIMenuItem Slot6A = new UIMenuItem("Slot 6");
			uIMenu.AddItem(Slot6A);
			UIMenuItem Slot7A = new UIMenuItem("Slot 7");
			uIMenu.AddItem(Slot7A);
			UIMenuItem Slot8A = new UIMenuItem("Slot 8");
			uIMenu.AddItem(Slot8A);
			UIMenuItem Slot9A = new UIMenuItem("Slot 9");
			uIMenu.AddItem(Slot9A);
			UIMenuItem Slot10A = new UIMenuItem("Slot 10");
			uIMenu.AddItem(Slot10A);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Slot1A && Vehicle1 != null)
				{
					DeleteCarinSlot("Slot1", Vehicle1);
				}
				if (item == Slot2A && Vehicle2 != null)
				{
					DeleteCarinSlot("Slot2", Vehicle2);
				}
				if (item == Slot3A && Vehicle3 != null)
				{
					DeleteCarinSlot("Slot3", Vehicle3);
				}
				if (item == Slot4A && Vehicle4 != null)
				{
					DeleteCarinSlot("Slot4", Vehicle4);
				}
				if (item == Slot5A && Vehicle5 != null)
				{
					DeleteCarinSlot("Slot5", Vehicle5);
				}
				if (item == Slot6A && Vehicle6 != null)
				{
					DeleteCarinSlot("Slot6", Vehicle6);
				}
				if (item == Slot7A && Vehicle7 != null)
				{
					DeleteCarinSlot("Slot7", Vehicle7);
				}
				if (item == Slot8A && Vehicle8 != null)
				{
					DeleteCarinSlot("Slot8", Vehicle8);
				}
				if (item == Slot9A && Vehicle9 != null)
				{
					DeleteCarinSlot("Slot9", Vehicle9);
				}
				if (item == Slot10A && Vehicle10 != null)
				{
					DeleteCarinSlot("Slot10", Vehicle10);
				}
			});
		}

		public void DeleteCarinSlot(string Slot, Vehicle V)
		{
			SC.LoadIniFile(path + GarageNum + "//" + Slot + ".ini");
			UI.Notify(path + GarageNum + "//" + Slot + ".ini");
			SC.SaveName();
			V.Delete();
		}

		public void LoadGarageVehicles()
		{
			DeleteVehicles();
			LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
			if (CurrentZR380 == 1 && ApocalypseZR380Bought == 1)
			{
				SC.LoadIniFile(Loadpath + "ZR380//1Apocalypse.ini");
				ZR380 = World.CreateVehicle("ZR380", ZR380Spawn, 90f);
				SC.Load(ZR380);
			}
			if (CurrentZR380 == 2 && NightmareZR380Bought == 1)
			{
				SC.LoadIniFile(Loadpath + "ZR380//2NIghtmare.ini");
				ZR380 = World.CreateVehicle("ZR3802", ZR380Spawn, 90f);
				SC.Load(ZR380);
			}
			if (CurrentZR380 == 3 && FutureShockZR380Bought == 1)
			{
				SC.LoadIniFile(Loadpath + "ZR380//3FutureShock.ini");
				ZR380 = World.CreateVehicle("ZR3803", ZR380Spawn, 90f);
				SC.Load(ZR380);
			}
			if (CurrentBruiser == 1 && ApocalypseBruiserBought == 1)
			{
				SC.LoadIniFile(Loadpath + "Bruiser//1Apocalypse.ini");
				Bruiser = World.CreateVehicle("Bruiser", BruiserSpawn, -90f);
				SC.Load(Bruiser);
			}
			if (CurrentBruiser == 2 && NightmareBruiserBought == 1)
			{
				SC.LoadIniFile(Loadpath + "Bruiser//2NIghtmare.ini");
				Bruiser = World.CreateVehicle("Bruiser2", BruiserSpawn, -90f);
				SC.Load(Bruiser);
			}
			if (CurrentBruiser == 3 && FutureShockBruiserBought == 1)
			{
				SC.LoadIniFile(Loadpath + "Bruiser//3FutureShock.ini");
				Bruiser = World.CreateVehicle("Bruiser3", BruiserSpawn, -90f);
				SC.Load(Bruiser);
			}
		}

		public void SaveLocalcarinGarageA(string G, Vehicle V, string Slot)
		{
			if (Game.Player.Character.CurrentVehicle != null)
			{
				if (Game.Player.Character.CurrentVehicle.DisplayName != "RHINO" || Game.Player.Character.CurrentVehicle.DisplayName != "KHANJALI" || Game.Player.Character.CurrentVehicle.DisplayName != "CHERNOBOG")
				{
					DeleteVehicles();
					DestoryCars();
					if (SaveVehicle != null)
					{
						SaveVehicle = null;
					}
					GarageNum = G;
					UI.Notify(path + G + "//" + Slot + ".ini");
					SC.LoadIniFile(path + G + "//" + Slot + ".ini");
					SC.VehicleName = "null";
					Script.Wait(50);
					SC.SaveWithoutDelete();
					Script.Wait(50);
					V = Game.Player.Character.CurrentVehicle;
					Script.Wait(50);
					UI.Notify("Alan : your " + V.FriendlyName + ", has been Saved into  " + G + ", " + Slot);
					Script.Wait(50);
					SC.Save();
					DestoryCars();
					Script.Wait(50);
					CreateCars(G);
					Script.Wait(50);
					Game.Player.Character.Position = ExitMarker;
					Script.Wait(100);
					IsinInterior = true;
				}
				else
				{
					DisplayHelpTextThisFrame("You cannot save this vehicle");
				}
			}
			else
			{
				DisplayHelpTextThisFrame("Bring a vehicle to save");
			}
		}

		public void DestoryCars()
		{
			if (Vehicle1 != null)
			{
				Vehicle1.Delete();
			}
			if (Vehicle2 != null)
			{
				Vehicle2.Delete();
			}
			if (Vehicle3 != null)
			{
				Vehicle3.Delete();
			}
			if (Vehicle4 != null)
			{
				Vehicle4.Delete();
			}
			if (Vehicle5 != null)
			{
				Vehicle5.Delete();
			}
			if (Vehicle5 != null)
			{
				Vehicle5.Delete();
			}
			if (Vehicle6 != null)
			{
				Vehicle6.Delete();
			}
			if (Vehicle7 != null)
			{
				Vehicle7.Delete();
			}
			if (Vehicle8 != null)
			{
				Vehicle8.Delete();
			}
			if (Vehicle9 != null)
			{
				Vehicle9.Delete();
			}
			if (Vehicle10 != null)
			{
				Vehicle10.Delete();
			}
		}

		public void CreateCars(string Garage)
		{
			try
			{
				Garage = "GarageA";
				SC.LoadIniFile(path + Garage + "//Slot1.ini");
				Model model = SC.CheckCar(path + Garage + "//Slot1.ini");
				SC.LoadIniFile(path + Garage + "//Slot2.ini");
				Model model2 = SC.CheckCar(path + Garage + "//Slot2.ini");
				SC.LoadIniFile(path + Garage + "//Slot3.ini");
				Model model3 = SC.CheckCar(path + Garage + "//Slot3.ini");
				SC.LoadIniFile(path + Garage + "//Slot4.ini");
				Model model4 = SC.CheckCar(path + Garage + "//Slot4.ini");
				SC.LoadIniFile(path + Garage + "//Slot5.ini");
				Model model5 = SC.CheckCar(path + Garage + "//Slot5.ini");
				SC.LoadIniFile(path + Garage + "//Slot6.ini");
				Model model6 = SC.CheckCar(path + Garage + "//Slot6.ini");
				SC.LoadIniFile(path + Garage + "//Slot7.ini");
				Model model7 = SC.CheckCar(path + Garage + "//Slot7.ini");
				SC.LoadIniFile(path + Garage + "//Slot8.ini");
				Model model8 = SC.CheckCar(path + Garage + "//Slot8.ini");
				SC.LoadIniFile(path + Garage + "//Slot9.ini");
				Model model9 = SC.CheckCar(path + Garage + "//Slot9.ini");
				SC.LoadIniFile(path + Garage + "//Slot10.ini");
				Model model10 = SC.CheckCar(path + Garage + "//Slot10.ini");
				if (model != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot1.ini");
					Model model11 = SC.CheckCar(path + Garage + "//Slot1.ini");
					Vehicle1 = World.CreateVehicle(model11, Vehicle1Loc, -90f);
					SC.Load(Vehicle1);
					Vehicle1.IsDriveable = false;
				}
				Script.Wait(50);
				if (model2 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot2.ini");
					Model model12 = SC.CheckCar(path + Garage + "//Slot2.ini");
					Vehicle2 = World.CreateVehicle(model12, Vehicle2Loc, -90f);
					SC.Load(Vehicle2);
					Vehicle2.IsDriveable = false;
				}
				Script.Wait(50);
				if (model3 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot3.ini");
					Model model13 = SC.CheckCar(path + Garage + "//Slot3.ini");
					Vehicle3 = World.CreateVehicle(model13, Vehicle3Loc, -90f);
					SC.Load(Vehicle3);
					Vehicle3.IsDriveable = false;
				}
				Script.Wait(50);
				if (model4 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot4.ini");
					Model model14 = SC.CheckCar(path + Garage + "//Slot4.ini");
					Vehicle4 = World.CreateVehicle(model14, Vehicle4Loc, -90f);
					SC.Load(Vehicle4);
					Vehicle4.IsDriveable = false;
				}
				Script.Wait(50);
				if (model5 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot5.ini");
					Model model15 = SC.CheckCar(path + Garage + "//Slot5.ini");
					Vehicle5 = World.CreateVehicle(model15, Vehicle5Loc, 90f);
					SC.Load(Vehicle5);
					Vehicle5.IsDriveable = false;
				}
				Script.Wait(50);
				if (model6 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot6.ini");
					Model model16 = SC.CheckCar(path + Garage + "//Slot6.ini");
					Vehicle6 = World.CreateVehicle(model16, Vehicle6Loc, 90f);
					SC.Load(Vehicle6);
					Vehicle6.IsDriveable = false;
				}
				Script.Wait(50);
				if (model7 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot7.ini");
					Model model17 = SC.CheckCar(path + Garage + "//Slot7.ini");
					Vehicle7 = World.CreateVehicle(model17, Vehicle7Loc, 100f);
					SC.Load(Vehicle7);
					Vehicle7.IsDriveable = false;
				}
				Script.Wait(50);
				if (model8 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot8.ini");
					Model model18 = SC.CheckCar(path + Garage + "//Slot8.ini");
					Vehicle8 = World.CreateVehicle(model18, Vehicle8Loc, 90f);
					SC.Load(Vehicle8);
					Vehicle8.IsDriveable = false;
				}
				Script.Wait(50);
				if (model9 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot9.ini");
					Model model19 = SC.CheckCar(path + Garage + "//Slot9.ini");
					Vehicle9 = World.CreateVehicle(model19, Vehicle9Loc, 90f);
					SC.Load(Vehicle9);
					Vehicle9.IsDriveable = false;
				}
				Script.Wait(50);
				if (model10 != "null")
				{
					SC.LoadIniFile(path + Garage + "//Slot10.ini");
					Model model20 = SC.CheckCar(path + Garage + "//Slot10.ini");
					Vehicle10 = World.CreateVehicle(model20, Vehicle10Loc, -90f);
					SC.Load(Vehicle10);
					Vehicle10.IsDriveable = false;
				}
				GarageNum = Garage;
			}
			catch (NullReferenceException)
			{
				UI.Notify("~r~ Arena War Player Garage : Somthing went wrong while loading these vehicles, please retry, if it persists check the vehicle ini files for invald vehiclenames or contact HKH~w~");
			}
		}

		private void SetupGarage()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Expected O, but got Unknown
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_011d: Expected O, but got Unknown
			//IL_0130: Unknown result type (might be due to invalid IL or missing references)
			//IL_013a: Expected O, but got Unknown
			//IL_014c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0152: Expected O, but got Unknown
			//IL_015f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0165: Expected O, but got Unknown
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_0179: Expected O, but got Unknown
			//IL_0187: Unknown result type (might be due to invalid IL or missing references)
			//IL_018e: Expected O, but got Unknown
			//IL_019c: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a3: Expected O, but got Unknown
			//IL_01b1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b8: Expected O, but got Unknown
			//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01cd: Expected O, but got Unknown
			//IL_01db: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e2: Expected O, but got Unknown
			//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Expected O, but got Unknown
			//IL_0205: Unknown result type (might be due to invalid IL or missing references)
			//IL_020c: Expected O, but got Unknown
			//IL_021d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0227: Expected O, but got Unknown
			UIMenu uIMenu = PlayerGaragemodMenuPool.AddSubMenu(PlayerGaragemainMenu, "Enter Garage A");
			UIMenuItem Slot1A = new UIMenuItem("Slot 1A");
			uIMenu.AddItem(Slot1A);
			UIMenuItem Slot2A = new UIMenuItem("Slot 2A");
			uIMenu.AddItem(Slot2A);
			UIMenuItem Slot3A = new UIMenuItem("Slot 3A");
			uIMenu.AddItem(Slot3A);
			UIMenuItem Slot4A = new UIMenuItem("Slot 4A");
			uIMenu.AddItem(Slot4A);
			UIMenuItem Slot5A = new UIMenuItem("Slot 5A");
			uIMenu.AddItem(Slot5A);
			UIMenuItem Slot6A = new UIMenuItem("Slot 6A");
			uIMenu.AddItem(Slot6A);
			UIMenuItem Slot7A = new UIMenuItem("Slot 7A");
			uIMenu.AddItem(Slot7A);
			UIMenuItem Slot8A = new UIMenuItem("Slot 8A");
			uIMenu.AddItem(Slot8A);
			UIMenuItem Slot9A = new UIMenuItem("Slot 9A");
			uIMenu.AddItem(Slot9A);
			UIMenuItem Slot10A = new UIMenuItem("Slot 10A");
			uIMenu.AddItem(Slot10A);
			UIMenuItem val = new UIMenuItem("Slot 11A");
			uIMenu.AddItem(val);
			UIMenuItem val2 = new UIMenuItem("Slot 12A");
			uIMenu.AddItem(val2);
			UIMenuItem val3 = new UIMenuItem("Slot 13A");
			uIMenu.AddItem(val3);
			UIMenuItem val4 = new UIMenuItem("Slot 14A");
			uIMenu.AddItem(val4);
			UIMenuItem val5 = new UIMenuItem("Slot 15A");
			uIMenu.AddItem(val5);
			UIMenuItem val6 = new UIMenuItem("Slot 16A");
			uIMenu.AddItem(val6);
			UIMenuItem val7 = new UIMenuItem("Slot 17A");
			uIMenu.AddItem(val7);
			UIMenuItem val8 = new UIMenuItem("Slot 18A");
			uIMenu.AddItem(val8);
			UIMenuItem val9 = new UIMenuItem("Slot 19A");
			uIMenu.AddItem(val9);
			UIMenuItem val10 = new UIMenuItem("Slot 20A");
			uIMenu.AddItem(val10);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Slot1A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle1, "Slot1");
				}
				if (item == Slot2A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle2, "Slot2");
				}
				if (item == Slot3A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle3, "Slot3");
				}
				if (item == Slot4A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle4, "Slot4");
				}
				if (item == Slot5A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle5, "Slot5");
				}
				if (item == Slot6A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle6, "Slot6");
				}
				if (item == Slot7A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle7, "Slot7");
				}
				if (item == Slot8A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle8, "Slot8");
				}
				if (item == Slot9A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle9, "Slot9");
				}
				if (item == Slot10A)
				{
					SaveLocalcarinGarageA("GarageA", Vehicle10, "Slot10");
				}
			});
		}

		public void DeleteVehicles()
		{
			if (RcBandito != null)
			{
				RcBandito.Delete();
			}
			if (Italigto != null)
			{
				Italigto.Delete();
			}
			if (Deveste != null)
			{
				Deveste.Delete();
			}
			if (Deviant != null)
			{
				Deviant.Delete();
			}
			if (Toros != null)
			{
				Toros.Delete();
			}
			if (Schlagen != null)
			{
				Schlagen.Delete();
			}
			if (Vamos != null)
			{
				Vamos.Delete();
			}
			if (Tulip != null)
			{
				Tulip.Delete();
			}
			if (Clique != null)
			{
				Clique.Delete();
			}
			if (ZR380 != null)
			{
				ZR380.Delete();
			}
			if (Bruiser != null)
			{
				Bruiser.Delete();
			}
			if (Cerberus != null)
			{
				Cerberus.Delete();
			}
			if (Scarab != null)
			{
				Scarab.Delete();
			}
			if (Dominator != null)
			{
				Dominator.Delete();
			}
			if (Imperator != null)
			{
				Imperator.Delete();
			}
			if (Deathbike != null)
			{
				Deathbike.Delete();
			}
			if (Issi != null)
			{
				Issi.Delete();
			}
			if (Monster != null)
			{
				Monster.Delete();
			}
			if (Bruitus != null)
			{
				Bruitus.Delete();
			}
			if (Impaler != null)
			{
				Impaler.Delete();
			}
			if (Slamvan != null)
			{
				Slamvan.Delete();
			}
			if (ZR380 != null)
			{
				ZR380.Delete();
			}
		}

		public void SetUpVehicles2()
		{
			//IL_007f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Expected O, but got Unknown
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Expected O, but got Unknown
			//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Expected O, but got Unknown
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Expected O, but got Unknown
			//IL_0136: Unknown result type (might be due to invalid IL or missing references)
			//IL_0140: Expected O, but got Unknown
			//IL_014a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0154: Expected O, but got Unknown
			//IL_0181: Unknown result type (might be due to invalid IL or missing references)
			//IL_018b: Expected O, but got Unknown
			//IL_019f: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a9: Expected O, but got Unknown
			//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c7: Expected O, but got Unknown
			//IL_01db: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e5: Expected O, but got Unknown
			//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0203: Expected O, but got Unknown
			//IL_0217: Unknown result type (might be due to invalid IL or missing references)
			//IL_0221: Expected O, but got Unknown
			//IL_0238: Unknown result type (might be due to invalid IL or missing references)
			//IL_0242: Expected O, but got Unknown
			//IL_024c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0256: Expected O, but got Unknown
			//IL_0270: Unknown result type (might be due to invalid IL or missing references)
			//IL_027a: Expected O, but got Unknown
			//IL_028e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0298: Expected O, but got Unknown
			//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b6: Expected O, but got Unknown
			//IL_02ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d4: Expected O, but got Unknown
			//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f2: Expected O, but got Unknown
			//IL_0306: Unknown result type (might be due to invalid IL or missing references)
			//IL_0310: Expected O, but got Unknown
			//IL_0324: Unknown result type (might be due to invalid IL or missing references)
			//IL_032e: Expected O, but got Unknown
			//IL_0342: Unknown result type (might be due to invalid IL or missing references)
			//IL_034c: Expected O, but got Unknown
			//IL_0360: Unknown result type (might be due to invalid IL or missing references)
			//IL_036a: Expected O, but got Unknown
			//IL_0381: Unknown result type (might be due to invalid IL or missing references)
			//IL_038b: Expected O, but got Unknown
			UIMenu uIMenu = GarageMenuPool2.AddSubMenu(VehicleMenu2, "ZR380");
			UIMenu uIMenu2 = GarageMenuPool2.AddSubMenu(VehicleMenu2, "Bruiser");
			UIMenu uIMenu3 = GarageMenuPool2.AddSubMenu(VehicleMenu2, "Secondary Vehicles");
			UIMenu uIMenu4 = GarageMenuPool.AddSubMenu(uIMenu, "Buy");
			UIMenu uIMenu5 = GarageMenuPool.AddSubMenu(uIMenu, "Use");
			UIMenuItem ApocalypseZR380Use = new UIMenuItem("Apocalypse ZR380");
			uIMenu5.AddItem(ApocalypseZR380Use);
			UIMenuItem NightmareZR380Use = new UIMenuItem("Nightmare ZR380");
			uIMenu5.AddItem(NightmareZR380Use);
			UIMenuItem FutureShockZR380Use = new UIMenuItem("Future Shock ZR380");
			uIMenu5.AddItem(FutureShockZR380Use);
			UIMenuItem ApocalypseZR380Buy = new UIMenuItem("Apocalypse ZR380 : $2,910,000");
			uIMenu4.AddItem(ApocalypseZR380Buy);
			UIMenuItem NightmareZR380Buy = new UIMenuItem("Nightmare ZR380 : $2,910,000 ");
			uIMenu4.AddItem(NightmareZR380Buy);
			UIMenuItem FutureShockZR380Buy = new UIMenuItem("Future Shock ZR380 : $2,910,000");
			uIMenu4.AddItem(FutureShockZR380Buy);
			uIMenu5.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseZR380Use)
				{
					if (ApocalypseZR380Bought == 1)
					{
						ZR380.Delete();
						SC.LoadIniFile(Loadpath + "ZR380//1Apocalypse.ini");
						ZR380 = World.CreateVehicle("ZR380", ZR380Spawn, 90f);
						SC.Load(ZR380);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + ZR380);
						CurrentZR380 = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentZR380", CurrentZR380);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareZR380Use)
				{
					if (NightmareZR380Bought == 1)
					{
						ZR380.Delete();
						SC.LoadIniFile(Loadpath + "ZR380//2NIghtmare.ini");
						ZR380 = World.CreateVehicle("ZR3803", ZR380Spawn, 90f);
						SC.Load(ZR380);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + ZR380);
						CurrentZR380 = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentZR380", CurrentZR380);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockZR380Use)
				{
					if (FutureShockZR380Bought == 1)
					{
						ZR380.Delete();
						SC.LoadIniFile(Loadpath + "ZR380//3FutureShock.ini");
						ZR380 = World.CreateVehicle("ZR3802", ZR380Spawn, 90f);
						SC.Load(ZR380);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + ZR380);
						CurrentZR380 = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentZR380", CurrentZR380);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu4.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseZR380Buy)
				{
					if (ApocalypseZR380Bought != 1)
					{
						if (Game.Player.Money >= 2910000)
						{
							ApocalypseZR380Bought = 1;
							Game.Player.Money -= 2910000;
							Config.SetValue("Vehicles", "ApocalypseZR380Bought", ApocalypseZR380Bought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareZR380Buy)
				{
					if (NightmareZR380Bought != 1)
					{
						if (Game.Player.Money >= 2910000)
						{
							NightmareZR380Bought = 1;
							Game.Player.Money -= 2910000;
							Config.SetValue("Vehicles", "NightmareZR380Bought", NightmareZR380Bought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockZR380Buy)
				{
					if (FutureShockZR380Bought != 1)
					{
						if (Game.Player.Money >= 2910000)
						{
							FutureShockZR380Bought = 1;
							Game.Player.Money -= 2910000;
							Config.SetValue("Vehicles", "FutureShockZR380Bought", FutureShockZR380Bought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu6 = GarageMenuPool.AddSubMenu(uIMenu2, "Buy");
			UIMenu uIMenu7 = GarageMenuPool.AddSubMenu(uIMenu2, "Use");
			UIMenuItem ApocalypseBruiserUse = new UIMenuItem("Apocalypse Bruiser");
			uIMenu7.AddItem(ApocalypseBruiserUse);
			UIMenuItem NightmareBruiserUse = new UIMenuItem("Nightmare Bruiser");
			uIMenu7.AddItem(NightmareBruiserUse);
			UIMenuItem FutureShockBruiserUse = new UIMenuItem("Future Shock Bruiser");
			uIMenu7.AddItem(FutureShockBruiserUse);
			UIMenuItem ApocalypseBruiserBuy = new UIMenuItem("Apocalypse Bruiser: $2,910,000");
			uIMenu6.AddItem(ApocalypseBruiserBuy);
			UIMenuItem NightmareBruiserBuy = new UIMenuItem("Nightmare Bruiser : $2,910,000 ");
			uIMenu6.AddItem(NightmareBruiserBuy);
			UIMenuItem FutureShockBruiserBuy = new UIMenuItem("Future Shock Bruiser : $2,910,000");
			uIMenu6.AddItem(FutureShockBruiserBuy);
			uIMenu7.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseBruiserUse)
				{
					if (ApocalypseBruiserBought == 1)
					{
						Bruiser.Delete();
						SC.LoadIniFile(Loadpath + "Bruiser/1Apocalypse.ini");
						Bruiser = World.CreateVehicle("Bruiser", BruiserSpawn, -90f);
						SC.Load(Bruiser);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Bruiser);
						CurrentBruiser = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareBruiserUse)
				{
					if (NightmareBruiserBought == 1)
					{
						Bruiser.Delete();
						SC.LoadIniFile(Loadpath + "Bruiser/2NIghtmare.ini");
						Bruiser = World.CreateVehicle("Bruiser3", BruiserSpawn, -90f);
						SC.Load(Bruiser);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Bruiser);
						CurrentBruiser = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockBruiserUse)
				{
					if (FutureShockBruiserBought == 1)
					{
						Bruiser.Delete();
						SC.LoadIniFile(Loadpath + "Bruiser/3FutureShock.ini");
						Bruiser = World.CreateVehicle("Bruiser2", BruiserSpawn, -90f);
						SC.Load(Bruiser);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Bruiser);
						CurrentBruiser = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu6.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseBruiserBuy)
				{
					if (ApocalypseBruiserBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							ApocalypseBruiserBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "ApocalypseBruiserBought", ApocalypseBruiserBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareBruiserBuy)
				{
					if (NightmareBruiserBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							NightmareBruiserBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "NightmareBruiserBought", NightmareBruiserBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockBruiserBuy)
				{
					if (FutureShockBruiserBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							FutureShockBruiserBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "FutureShockBruiserBought", FutureShockBruiserBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu8 = GarageMenuPool.AddSubMenu(uIMenu3, "Buy");
			UIMenuItem Clique = new UIMenuItem("Clique $909,000 ");
			uIMenu8.AddItem(Clique);
			UIMenuItem ItlaiGto = new UIMenuItem("Itali GTO $1,965,000 ");
			uIMenu8.AddItem(ItlaiGto);
			UIMenuItem Tulip = new UIMenuItem("Tulip $718,000");
			uIMenu8.AddItem(Tulip);
			UIMenuItem Vamos = new UIMenuItem("Vamos $596,000");
			uIMenu8.AddItem(Vamos);
			UIMenuItem Schalgen = new UIMenuItem("Schlagen $1,300,000");
			uIMenu8.AddItem(Schalgen);
			UIMenuItem Deviant = new UIMenuItem("Deviant $512,000");
			uIMenu8.AddItem(Deviant);
			UIMenuItem Toros = new UIMenuItem("Toros $498,000 ");
			uIMenu8.AddItem(Toros);
			UIMenuItem Deveste = new UIMenuItem("Deveste $1,795,000");
			uIMenu8.AddItem(Deveste);
			UIMenuItem Rcbandito = new UIMenuItem("RC Bandito $1,590,000");
			uIMenu8.AddItem(Rcbandito);
			uIMenu8.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Clique)
				{
					if (Game.Player.Money >= 909000 && CliqueBought != 1)
					{
						Game.Player.Money -= 909000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						CliqueBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == ItlaiGto)
				{
					if (Game.Player.Money >= 1965000 && ItaligtoBought != 1)
					{
						Game.Player.Money -= 1965000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						ItaligtoBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Tulip)
				{
					if (Game.Player.Money >= 718000 && TulipBought != 1)
					{
						Game.Player.Money -= 718000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						TulipBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Vamos)
				{
					if (Game.Player.Money >= 596000 && VamosBought != 1)
					{
						Game.Player.Money -= 596000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						VamosBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Schalgen)
				{
					if (Game.Player.Money >= 1300000 && SchlagenBought != 1)
					{
						Game.Player.Money -= 1300000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						SchlagenBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Deviant)
				{
					if (Game.Player.Money >= 512000 && DevesteBought != 1)
					{
						Game.Player.Money -= 512000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						DeviantBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Toros)
				{
					if (Game.Player.Money >= 498000 && TorosBought != 1)
					{
						Game.Player.Money -= 498000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						TorosBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Deveste)
				{
					if (Game.Player.Money >= 1795000 && DevesteBought != 1)
					{
						Game.Player.Money -= 1795000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						DevesteBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
				if (item == Rcbandito)
				{
					if (Game.Player.Money >= 1595000 && DevesteBought != 1)
					{
						Game.Player.Money -= 1595000;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						DevesteBought = 1;
						Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
						Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
						Config.SetValue("Vehicles", "TulipBought", TulipBought);
						Config.SetValue("Vehicles", "VamosBought", VamosBought);
						Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
						Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
						Config.SetValue("Vehicles", "TorosBought", TorosBought);
						Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
						Config.SetValue("Vehicles", "RcBanditoBought", RcBanditoBought);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : You dont have enought money for this vehicle, or you have already bought this vehicle ");
					}
				}
			});
		}

		public void SetUpVehicles()
		{
			//IL_013f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0149: Expected O, but got Unknown
			//IL_015d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0167: Expected O, but got Unknown
			//IL_017b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0185: Expected O, but got Unknown
			//IL_0199: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a3: Expected O, but got Unknown
			//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c1: Expected O, but got Unknown
			//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01df: Expected O, but got Unknown
			//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0200: Expected O, but got Unknown
			//IL_020a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0214: Expected O, but got Unknown
			//IL_0241: Unknown result type (might be due to invalid IL or missing references)
			//IL_024b: Expected O, but got Unknown
			//IL_025f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0269: Expected O, but got Unknown
			//IL_027d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0287: Expected O, but got Unknown
			//IL_029b: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a5: Expected O, but got Unknown
			//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
			//IL_02c3: Expected O, but got Unknown
			//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e1: Expected O, but got Unknown
			//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0302: Expected O, but got Unknown
			//IL_030c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0316: Expected O, but got Unknown
			//IL_0345: Unknown result type (might be due to invalid IL or missing references)
			//IL_034f: Expected O, but got Unknown
			//IL_0363: Unknown result type (might be due to invalid IL or missing references)
			//IL_036d: Expected O, but got Unknown
			//IL_0381: Unknown result type (might be due to invalid IL or missing references)
			//IL_038b: Expected O, but got Unknown
			//IL_039f: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a9: Expected O, but got Unknown
			//IL_03bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_03c7: Expected O, but got Unknown
			//IL_03db: Unknown result type (might be due to invalid IL or missing references)
			//IL_03e5: Expected O, but got Unknown
			//IL_03fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0406: Expected O, but got Unknown
			//IL_0410: Unknown result type (might be due to invalid IL or missing references)
			//IL_041a: Expected O, but got Unknown
			//IL_0449: Unknown result type (might be due to invalid IL or missing references)
			//IL_0453: Expected O, but got Unknown
			//IL_0467: Unknown result type (might be due to invalid IL or missing references)
			//IL_0471: Expected O, but got Unknown
			//IL_0485: Unknown result type (might be due to invalid IL or missing references)
			//IL_048f: Expected O, but got Unknown
			//IL_04a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_04ad: Expected O, but got Unknown
			//IL_04c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_04cb: Expected O, but got Unknown
			//IL_04df: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e9: Expected O, but got Unknown
			//IL_0500: Unknown result type (might be due to invalid IL or missing references)
			//IL_050a: Expected O, but got Unknown
			//IL_0514: Unknown result type (might be due to invalid IL or missing references)
			//IL_051e: Expected O, but got Unknown
			//IL_054d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0557: Expected O, but got Unknown
			//IL_056b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0575: Expected O, but got Unknown
			//IL_0589: Unknown result type (might be due to invalid IL or missing references)
			//IL_0593: Expected O, but got Unknown
			//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_05b1: Expected O, but got Unknown
			//IL_05c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_05cf: Expected O, but got Unknown
			//IL_05e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_05ed: Expected O, but got Unknown
			//IL_0604: Unknown result type (might be due to invalid IL or missing references)
			//IL_060e: Expected O, but got Unknown
			//IL_0618: Unknown result type (might be due to invalid IL or missing references)
			//IL_0622: Expected O, but got Unknown
			//IL_0651: Unknown result type (might be due to invalid IL or missing references)
			//IL_065b: Expected O, but got Unknown
			//IL_066f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0679: Expected O, but got Unknown
			//IL_068d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0697: Expected O, but got Unknown
			//IL_06ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_06b5: Expected O, but got Unknown
			//IL_06c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_06d3: Expected O, but got Unknown
			//IL_06e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_06f1: Expected O, but got Unknown
			//IL_0708: Unknown result type (might be due to invalid IL or missing references)
			//IL_0712: Expected O, but got Unknown
			//IL_071c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0726: Expected O, but got Unknown
			//IL_0755: Unknown result type (might be due to invalid IL or missing references)
			//IL_075f: Expected O, but got Unknown
			//IL_0773: Unknown result type (might be due to invalid IL or missing references)
			//IL_077d: Expected O, but got Unknown
			//IL_0791: Unknown result type (might be due to invalid IL or missing references)
			//IL_079b: Expected O, but got Unknown
			//IL_07af: Unknown result type (might be due to invalid IL or missing references)
			//IL_07b9: Expected O, but got Unknown
			//IL_07cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_07d7: Expected O, but got Unknown
			//IL_07eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_07f5: Expected O, but got Unknown
			//IL_080c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0816: Expected O, but got Unknown
			//IL_0820: Unknown result type (might be due to invalid IL or missing references)
			//IL_082a: Expected O, but got Unknown
			//IL_0859: Unknown result type (might be due to invalid IL or missing references)
			//IL_0863: Expected O, but got Unknown
			//IL_0877: Unknown result type (might be due to invalid IL or missing references)
			//IL_0881: Expected O, but got Unknown
			//IL_0895: Unknown result type (might be due to invalid IL or missing references)
			//IL_089f: Expected O, but got Unknown
			//IL_08b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_08bd: Expected O, but got Unknown
			//IL_08d1: Unknown result type (might be due to invalid IL or missing references)
			//IL_08db: Expected O, but got Unknown
			//IL_08ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_08f9: Expected O, but got Unknown
			//IL_0910: Unknown result type (might be due to invalid IL or missing references)
			//IL_091a: Expected O, but got Unknown
			//IL_0924: Unknown result type (might be due to invalid IL or missing references)
			//IL_092e: Expected O, but got Unknown
			//IL_095d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0967: Expected O, but got Unknown
			//IL_097b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0985: Expected O, but got Unknown
			//IL_0999: Unknown result type (might be due to invalid IL or missing references)
			//IL_09a3: Expected O, but got Unknown
			//IL_09b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_09c1: Expected O, but got Unknown
			//IL_09d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_09df: Expected O, but got Unknown
			//IL_09f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_09fd: Expected O, but got Unknown
			//IL_0a14: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a1e: Expected O, but got Unknown
			//IL_0a28: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a32: Expected O, but got Unknown
			//IL_0a61: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a6b: Expected O, but got Unknown
			//IL_0a7f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a89: Expected O, but got Unknown
			//IL_0a9d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0aa7: Expected O, but got Unknown
			//IL_0abb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ac5: Expected O, but got Unknown
			//IL_0ad9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ae3: Expected O, but got Unknown
			//IL_0af7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b01: Expected O, but got Unknown
			//IL_0b18: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b22: Expected O, but got Unknown
			//IL_0b2c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b36: Expected O, but got Unknown
			//IL_0b3d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b47: Expected O, but got Unknown
			//IL_0b5a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b64: Expected O, but got Unknown
			//IL_0b77: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b81: Expected O, but got Unknown
			//IL_0b96: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ba0: Expected O, but got Unknown
			UIMenu uIMenu = GarageMenuPool.AddSubMenu(VehicleLoadMenu, "Vehicle Load Menu");
			UIMenu uIMenu2 = GarageMenuPool.AddSubMenu(VehicleMenu, "Cerberus");
			UIMenu uIMenu3 = GarageMenuPool.AddSubMenu(VehicleMenu, "Scarab");
			UIMenu uIMenu4 = GarageMenuPool.AddSubMenu(VehicleMenu, "Impaler");
			UIMenu uIMenu5 = GarageMenuPool.AddSubMenu(VehicleMenu, "Deathbike");
			UIMenu uIMenu6 = GarageMenuPool.AddSubMenu(VehicleMenu, "Dominator");
			UIMenu uIMenu7 = GarageMenuPool.AddSubMenu(VehicleMenu, "Slamvan");
			UIMenu uIMenu8 = GarageMenuPool.AddSubMenu(VehicleMenu, "Issi");
			UIMenu uIMenu9 = GarageMenuPool.AddSubMenu(VehicleMenu, "Monster");
			UIMenu uIMenu10 = GarageMenuPool.AddSubMenu(VehicleMenu, "Imperator");
			UIMenu uIMenu11 = GarageMenuPool.AddSubMenu(VehicleMenu, "Bruitus");
			UIMenu uIMenu12 = GarageMenuPool.AddSubMenu(uIMenu2, "Buy");
			UIMenu uIMenu13 = GarageMenuPool.AddSubMenu(uIMenu2, "Use");
			UIMenuItem ApocalypseCerberusUse = new UIMenuItem("Apocalypse Cerberus");
			uIMenu13.AddItem(ApocalypseCerberusUse);
			UIMenuItem NightmareCerberusUse = new UIMenuItem("Nightmare Cerberus");
			uIMenu13.AddItem(NightmareCerberusUse);
			UIMenuItem FutureShockCerberusUse = new UIMenuItem("Future Shock Cerberus");
			uIMenu13.AddItem(FutureShockCerberusUse);
			UIMenuItem ApocalypseCerberusBuy = new UIMenuItem("Apocalypse Cerberus : $2,910,000");
			uIMenu12.AddItem(ApocalypseCerberusBuy);
			UIMenuItem NightmareCerberusBuy = new UIMenuItem("Nightmare Cerberus : $2,910,000 ");
			uIMenu12.AddItem(NightmareCerberusBuy);
			UIMenuItem FutureShockCerberusBuy = new UIMenuItem("Future Shock Cerberus : $2,910,000");
			uIMenu12.AddItem(FutureShockCerberusBuy);
			uIMenu13.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseCerberusUse)
				{
					if (ApocalypseCerberusBought == 1)
					{
						Cerberus.Delete();
						SC.LoadIniFile(Loadpath + "Cerberus//1Apocalypse.ini");
						Cerberus = World.CreateVehicle("Cerberus", CerberusSpawn, -90f);
						SC.Load(Cerberus);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Cerberus);
						CurrentCerberus = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareCerberusUse)
				{
					if (NightmareCerberusBought == 1)
					{
						Cerberus.Delete();
						SC.LoadIniFile(Loadpath + "Cerberus//2NIghtmare.ini");
						Cerberus = World.CreateVehicle("Cerberus3", CerberusSpawn, -90f);
						SC.Load(Cerberus);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Cerberus);
						CurrentCerberus = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockCerberusUse)
				{
					if (FutureShockCerberusBought == 1)
					{
						Cerberus.Delete();
						SC.LoadIniFile(Loadpath + "Cerberus//3FutureShock.ini");
						Cerberus = World.CreateVehicle("Cerberus2", CerberusSpawn, -90f);
						SC.Load(Cerberus);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Cerberus);
						CurrentCerberus = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu12.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseCerberusBuy)
				{
					if (ApocalypseCerberusBought != 1)
					{
						if (Game.Player.Money >= 2910000)
						{
							ApocalypseCerberusBought = 1;
							Game.Player.Money -= 2910000;
							Config.SetValue("Vehicles", "ApocalypseCerberusBought", ApocalypseCerberusBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareCerberusBuy)
				{
					if (NightmareCerberusBought != 1)
					{
						if (Game.Player.Money >= 2910000)
						{
							NightmareCerberusBought = 1;
							Game.Player.Money -= 2910000;
							Config.SetValue("Vehicles", "NightmareCerberusBought", NightmareCerberusBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockCerberusBuy)
				{
					if (FutureShockCerberusBought != 1)
					{
						if (Game.Player.Money >= 2910000)
						{
							FutureShockCerberusBought = 1;
							Game.Player.Money -= 2910000;
							Config.SetValue("Vehicles", "FutureShockCerberusBought", FutureShockCerberusBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu14 = GarageMenuPool.AddSubMenu(uIMenu3, "Buy");
			UIMenu uIMenu15 = GarageMenuPool.AddSubMenu(uIMenu3, "Use");
			UIMenuItem ApocalypseScarabUse = new UIMenuItem("Apocalypse Scarab");
			uIMenu15.AddItem(ApocalypseScarabUse);
			UIMenuItem NightmareScarabUse = new UIMenuItem("Nightmare Scarab");
			uIMenu15.AddItem(NightmareScarabUse);
			UIMenuItem FutureShockScarabUse = new UIMenuItem("Future Shock Scarab");
			uIMenu15.AddItem(FutureShockScarabUse);
			UIMenuItem ApocalypseScarabBuy = new UIMenuItem("Apocalypse Scarab: $2,910,000");
			uIMenu14.AddItem(ApocalypseScarabBuy);
			UIMenuItem NightmareScarabBuy = new UIMenuItem("Nightmare Scarab : $2,910,000 ");
			uIMenu14.AddItem(NightmareScarabBuy);
			UIMenuItem FutureShockScarabBuy = new UIMenuItem("Future Shock Scarab : $2,910,000");
			uIMenu14.AddItem(FutureShockScarabBuy);
			uIMenu15.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseScarabUse)
				{
					if (ApocalypseScarabBought == 1)
					{
						Scarab.Delete();
						SC.LoadIniFile(Loadpath + "Scarab/1Apocalypse.ini");
						Scarab = World.CreateVehicle("Scarab", ScarabSpawn, 90f);
						SC.Load(Scarab);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Scarab);
						CurrentScarab = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentScarab", CurrentScarab);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareScarabUse)
				{
					if (NightmareScarabBought == 1)
					{
						Scarab.Delete();
						SC.LoadIniFile(Loadpath + "Scarab/2NIghtmare.ini");
						Scarab = World.CreateVehicle("Scarab3", ScarabSpawn, 90f);
						SC.Load(Scarab);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Scarab);
						CurrentScarab = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentScarab", CurrentScarab);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockScarabUse)
				{
					if (FutureShockScarabBought == 1)
					{
						Scarab.Delete();
						SC.LoadIniFile(Loadpath + "Scarab/3FutureShock.ini");
						Scarab = World.CreateVehicle("Scarab2", ScarabSpawn, 90f);
						SC.Load(Scarab);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Scarab);
						CurrentScarab = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentScarab", CurrentScarab);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu14.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseScarabBuy)
				{
					if (ApocalypseScarabBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							ApocalypseScarabBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "ApocalypseScarabBought", ApocalypseScarabBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareScarabBuy)
				{
					if (NightmareScarabBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							NightmareScarabBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "NightmareScarabBought", NightmareScarabBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockScarabBuy)
				{
					if (FutureShockScarabBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							FutureShockScarabBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "FutureShockScarabBought", FutureShockScarabBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu16 = GarageMenuPool.AddSubMenu(uIMenu6, "Buy");
			UIMenu uIMenu17 = GarageMenuPool.AddSubMenu(uIMenu6, "Use");
			UIMenuItem ApocalypseDominatorUse = new UIMenuItem("Apocalypse Dominator");
			uIMenu17.AddItem(ApocalypseDominatorUse);
			UIMenuItem NightmareDominatorUse = new UIMenuItem("Nightmare Dominator");
			uIMenu17.AddItem(NightmareDominatorUse);
			UIMenuItem FutureShockDominatorUse = new UIMenuItem("Future Shock Dominator");
			uIMenu17.AddItem(FutureShockDominatorUse);
			UIMenuItem ApocalypseDominatorBuy = new UIMenuItem("Apocalypse Dominator: $1,075,400");
			uIMenu16.AddItem(ApocalypseDominatorBuy);
			UIMenuItem NightmareDominatorBuy = new UIMenuItem("Nightmare Dominator : $1,075,400 ");
			uIMenu16.AddItem(NightmareDominatorBuy);
			UIMenuItem FutureShockDominatorBuy = new UIMenuItem("Future Shock Dominator : $1,075,400");
			uIMenu16.AddItem(FutureShockDominatorBuy);
			uIMenu17.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseDominatorUse)
				{
					if (ApocalypseDominatorBought == 1)
					{
						Dominator.Delete();
						SC.LoadIniFile(Loadpath + "Dominator/1Apocalypse.ini");
						Dominator = World.CreateVehicle("Dominator4", DominatorSpawn, -90f);
						SC.Load(Dominator);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Dominator);
						CurrentDominator = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentDominator", CurrentDominator);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareDominatorUse)
				{
					if (NightmareDominatorBought == 1)
					{
						Dominator.Delete();
						SC.LoadIniFile(Loadpath + "Dominator/2NIghtmare.ini");
						Dominator = World.CreateVehicle("Dominator6", DominatorSpawn, -90f);
						SC.Load(Dominator);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Dominator);
						CurrentDominator = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentDominator", CurrentDominator);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockDominatorUse)
				{
					if (FutureShockDominatorBought == 1)
					{
						Dominator.Delete();
						SC.LoadIniFile(Loadpath + "Dominator/3FutureShock.ini");
						Dominator = World.CreateVehicle("Dominator5", DominatorSpawn, -90f);
						SC.Load(Dominator);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Dominator);
						CurrentDominator = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentDominator", CurrentDominator);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu16.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseDominatorBuy)
				{
					if (ApocalypseDominatorBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							ApocalypseDominatorBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "ApocalypseDominatorBought", ApocalypseDominatorBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareDominatorBuy)
				{
					if (NightmareDominatorBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							NightmareDominatorBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "NightmareDominatorBought", NightmareDominatorBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockDominatorBuy)
				{
					if (FutureShockDominatorBought != 1)
					{
						if (Game.Player.Money >= 2313000)
						{
							FutureShockDominatorBought = 1;
							Game.Player.Money -= 2313000;
							Config.SetValue("Vehicles", "FutureShockDominatorBought", FutureShockDominatorBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu18 = GarageMenuPool.AddSubMenu(uIMenu9, "Buy");
			UIMenu uIMenu19 = GarageMenuPool.AddSubMenu(uIMenu9, "Use");
			UIMenuItem ApocalypseMonsterUse = new UIMenuItem("Apocalypse Monster");
			uIMenu19.AddItem(ApocalypseMonsterUse);
			UIMenuItem NightmareMonsterUse = new UIMenuItem("Nightmare Monster");
			uIMenu19.AddItem(NightmareMonsterUse);
			UIMenuItem FutureShockMonsterUse = new UIMenuItem("Future Shock Monster");
			uIMenu19.AddItem(FutureShockMonsterUse);
			UIMenuItem ApocalypseMonsterBuy = new UIMenuItem("Apocalypse Monster: $1,530,875");
			uIMenu18.AddItem(ApocalypseMonsterBuy);
			UIMenuItem NightmareMonsterBuy = new UIMenuItem("Nightmare Monster : $1,530,875 ");
			uIMenu18.AddItem(NightmareMonsterBuy);
			UIMenuItem FutureShockMonsterBuy = new UIMenuItem("Future Shock Monster : $1,530,875");
			uIMenu18.AddItem(FutureShockMonsterBuy);
			uIMenu19.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseMonsterUse)
				{
					if (ApocalypseMonsterBought == 1)
					{
						Monster.Delete();
						SC.LoadIniFile(Loadpath + "Monster/1Apocalypse.ini");
						Monster = World.CreateVehicle("Monster3", MonsterSpawn, -90f);
						SC.Load(Monster);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Monster);
						CurrentMonster = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentMonster", CurrentMonster);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareMonsterUse)
				{
					if (NightmareMonsterBought == 1)
					{
						Monster.Delete();
						SC.LoadIniFile(Loadpath + "Monster/2NIghtmare.ini");
						Monster = World.CreateVehicle("Monster5", MonsterSpawn, -90f);
						SC.Load(Monster);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Monster);
						CurrentMonster = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentMonster", CurrentMonster);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockMonsterUse)
				{
					if (FutureShockMonsterBought == 1)
					{
						Monster.Delete();
						SC.LoadIniFile(Loadpath + "Monster/3FutureShock.ini");
						Monster = World.CreateVehicle("Monster4", MonsterSpawn, -90f);
						SC.Load(Monster);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Monster);
						CurrentMonster = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentMonster", CurrentMonster);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu18.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseMonsterBuy)
				{
					if (ApocalypseMonsterBought != 1)
					{
						if (Game.Player.Money >= 1530875)
						{
							ApocalypseMonsterBought = 1;
							Game.Player.Money -= 1530875;
							Config.SetValue("Vehicles", "ApocalypseMonsterBought", ApocalypseMonsterBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareMonsterBuy)
				{
					if (NightmareMonsterBought != 1)
					{
						if (Game.Player.Money >= 1530875)
						{
							NightmareMonsterBought = 1;
							Game.Player.Money -= 1530875;
							Config.SetValue("Vehicles", "NightmareMonsterBought", NightmareMonsterBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockMonsterBuy)
				{
					if (FutureShockMonsterBought != 1)
					{
						if (Game.Player.Money >= 1530875)
						{
							FutureShockMonsterBought = 1;
							Game.Player.Money -= 1530875;
							Config.SetValue("Vehicles", "FutureShockMonsterBought", FutureShockMonsterBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu20 = GarageMenuPool.AddSubMenu(uIMenu4, "Buy");
			UIMenu uIMenu21 = GarageMenuPool.AddSubMenu(uIMenu4, "Use");
			UIMenuItem ApocalypseImpalerUse = new UIMenuItem("Apocalypse Impaler");
			uIMenu21.AddItem(ApocalypseImpalerUse);
			UIMenuItem NightmareImpalerUse = new UIMenuItem("Nightmare Impaler");
			uIMenu21.AddItem(NightmareImpalerUse);
			UIMenuItem FutureShockImpalerUse = new UIMenuItem("Future Shock Impaler");
			uIMenu21.AddItem(FutureShockImpalerUse);
			UIMenuItem ApocalypseImpalerBuy = new UIMenuItem("Apocalypse Impaler: $331,835");
			uIMenu20.AddItem(ApocalypseImpalerBuy);
			UIMenuItem NightmareImpalerBuy = new UIMenuItem("Nightmare Impaler : $331,835");
			uIMenu20.AddItem(NightmareImpalerBuy);
			UIMenuItem FutureShockImpalerBuy = new UIMenuItem("Future Shock Impaler : $331,835");
			uIMenu20.AddItem(FutureShockImpalerBuy);
			uIMenu21.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseImpalerUse)
				{
					if (ApocalypseImpalerBought == 1)
					{
						Impaler.Delete();
						SC.LoadIniFile(Loadpath + "Impaler/1Apocalypse.ini");
						Impaler = World.CreateVehicle("Impaler2", ImpalerSpawn, 90f);
						SC.Load(Impaler);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Impaler);
						CurrentImpaler = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareImpalerUse)
				{
					if (NightmareImpalerBought == 1)
					{
						Impaler.Delete();
						SC.LoadIniFile(Loadpath + "Impaler/2NIghtmare.ini");
						Impaler = World.CreateVehicle("Impaler4", ImpalerSpawn, 90f);
						SC.Load(Impaler);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Impaler);
						CurrentImpaler = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockImpalerUse)
				{
					if (FutureShockImpalerBought == 1)
					{
						Impaler.Delete();
						SC.LoadIniFile(Loadpath + "Impaler/3FutureShock.ini");
						Impaler = World.CreateVehicle("Impaler3", ImpalerSpawn, 90f);
						SC.Load(Impaler);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Impaler);
						CurrentImpaler = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu20.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseImpalerBuy)
				{
					if (ApocalypseImpalerBought != 1)
					{
						if (Game.Player.Money >= 331835)
						{
							ApocalypseImpalerBought = 1;
							Game.Player.Money -= 331835;
							Config.SetValue("Vehicles", "ApocalypseImpalerBought", ApocalypseImpalerBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareImpalerBuy)
				{
					if (NightmareImpalerBought != 1)
					{
						if (Game.Player.Money >= 331835)
						{
							NightmareImpalerBought = 1;
							Game.Player.Money -= 331835;
							Config.SetValue("Vehicles", "NightmareImpalerBought", NightmareImpalerBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockImpalerBuy)
				{
					if (FutureShockImpalerBought != 1)
					{
						if (Game.Player.Money >= 1530875)
						{
							FutureShockImpalerBought = 1;
							Game.Player.Money -= 1530875;
							Config.SetValue("Vehicles", "FutureShockImpalerBought", FutureShockImpalerBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu22 = GarageMenuPool.AddSubMenu(uIMenu10, "Buy");
			UIMenu uIMenu23 = GarageMenuPool.AddSubMenu(uIMenu10, "Use");
			UIMenuItem ApocalypseImperatorUse = new UIMenuItem("Apocalypse Imperator");
			uIMenu23.AddItem(ApocalypseImperatorUse);
			UIMenuItem NightmareImperatorUse = new UIMenuItem("Nightmare Imperator");
			uIMenu23.AddItem(NightmareImperatorUse);
			UIMenuItem FutureShockImperatorUse = new UIMenuItem("Future Shock Imperator");
			uIMenu23.AddItem(FutureShockImperatorUse);
			UIMenuItem ApocalypseImperatorBuy = new UIMenuItem("Apocalypse Imperator: $1,718,000");
			uIMenu22.AddItem(ApocalypseImperatorBuy);
			UIMenuItem NightmareImperatorBuy = new UIMenuItem("Nightmare Imperator : $1,718,000");
			uIMenu22.AddItem(NightmareImperatorBuy);
			UIMenuItem FutureShockImperatorBuy = new UIMenuItem("Future Shock Imperator : $1,718,000");
			uIMenu22.AddItem(FutureShockImperatorBuy);
			uIMenu23.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseImperatorUse)
				{
					if (ApocalypseImperatorBought == 1)
					{
						Imperator.Delete();
						SC.LoadIniFile(Loadpath + "Imperator/1Apocalypse.ini");
						Imperator = World.CreateVehicle("Imperator", ImperatorSpawn, 90f);
						SC.Load(Imperator);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Imperator);
						CurrentImperator = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentImperator", CurrentImperator);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareImperatorUse)
				{
					if (NightmareImperatorBought == 1)
					{
						Imperator.Delete();
						SC.LoadIniFile(Loadpath + "Imperator/2NIghtmare.ini");
						Imperator = World.CreateVehicle("Imperator3", ImperatorSpawn, 90f);
						SC.Load(Imperator);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Imperator);
						CurrentImperator = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentImperator", CurrentImperator);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockImperatorUse)
				{
					if (FutureShockImperatorBought == 1)
					{
						Imperator.Delete();
						SC.LoadIniFile(Loadpath + "Imperator/3FutureShock.ini");
						Imperator = World.CreateVehicle("Imperator2", ImperatorSpawn, 90f);
						SC.Load(Imperator);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Imperator);
						CurrentImperator = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentImperator", CurrentImperator);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu22.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseImperatorBuy)
				{
					if (ApocalypseImperatorBought != 1)
					{
						if (Game.Player.Money >= 1718000)
						{
							ApocalypseImperatorBought = 1;
							Game.Player.Money -= 1718000;
							Config.SetValue("Vehicles", "ApocalypseImperatorBought", ApocalypseImperatorBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareImperatorBuy)
				{
					if (NightmareImperatorBought != 1)
					{
						if (Game.Player.Money >= 1718000)
						{
							NightmareImperatorBought = 1;
							Game.Player.Money -= 1718000;
							Config.SetValue("Vehicles", "NightmareImperatorBought", NightmareImperatorBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockImperatorBuy)
				{
					if (FutureShockImperatorBought != 1)
					{
						if (Game.Player.Money >= 1718000)
						{
							FutureShockImperatorBought = 1;
							Game.Player.Money -= 1718000;
							Config.SetValue("Vehicles", "FutureShockImperatorBought", FutureShockImperatorBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu24 = GarageMenuPool.AddSubMenu(uIMenu5, "Buy");
			UIMenu uIMenu25 = GarageMenuPool.AddSubMenu(uIMenu5, "Use");
			UIMenuItem ApocalypseDeathbikeUse = new UIMenuItem("Apocalypse Deathbike");
			uIMenu25.AddItem(ApocalypseDeathbikeUse);
			UIMenuItem NightmareDeathbikeUse = new UIMenuItem("Nightmare Deathbike");
			uIMenu25.AddItem(NightmareDeathbikeUse);
			UIMenuItem FutureShockDeathbikeUse = new UIMenuItem("Future Shock Deathbike");
			uIMenu25.AddItem(FutureShockDeathbikeUse);
			UIMenuItem ApocalypseDeathbikeBuy = new UIMenuItem("Apocalypse Deathbike: $1,269,000");
			uIMenu24.AddItem(ApocalypseDeathbikeBuy);
			UIMenuItem NightmareDeathbikeBuy = new UIMenuItem("Nightmare Deathbike : $1,269,000");
			uIMenu24.AddItem(NightmareDeathbikeBuy);
			UIMenuItem FutureShockDeathbikeBuy = new UIMenuItem("Future Shock Deathbike : $1,269,000");
			uIMenu24.AddItem(FutureShockDeathbikeBuy);
			uIMenu25.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseDeathbikeUse)
				{
					if (ApocalypseDeathbikeBought == 1)
					{
						Deathbike.Delete();
						SC.LoadIniFile(Loadpath + "Deathbike/1Apocalypse.ini");
						Deathbike = World.CreateVehicle("Deathbike", DeathbikeSpawn, -90f);
						SC.Load(Deathbike);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Deathbike);
						CurrentDeathbike = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareDeathbikeUse)
				{
					if (NightmareDeathbikeBought == 1)
					{
						Deathbike.Delete();
						SC.LoadIniFile(Loadpath + "Deathbike/2NIghtmare.ini");
						Deathbike = World.CreateVehicle("Deathbike3", DeathbikeSpawn, -90f);
						SC.Load(Deathbike);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Deathbike);
						CurrentDeathbike = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockDeathbikeUse)
				{
					if (FutureShockDeathbikeBought == 1)
					{
						Deathbike.Delete();
						SC.LoadIniFile(Loadpath + "Deathbike/3FutureShock.ini");
						Deathbike = World.CreateVehicle("Deathbike2", DeathbikeSpawn, -90f);
						SC.Load(Deathbike);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Deathbike);
						CurrentDeathbike = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu24.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseDeathbikeBuy)
				{
					if (ApocalypseDeathbikeBought != 1)
					{
						if (Game.Player.Money >= 1269000)
						{
							ApocalypseDeathbikeBought = 1;
							Game.Player.Money -= 1269000;
							Config.SetValue("Vehicles", "ApocalypseDeathbikeBought", ApocalypseDeathbikeBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareDeathbikeBuy)
				{
					if (NightmareDeathbikeBought != 1)
					{
						if (Game.Player.Money >= 1269000)
						{
							NightmareDeathbikeBought = 1;
							Game.Player.Money -= 1269000;
							Config.SetValue("Vehicles", "NightmareDeathbikeBought", NightmareDeathbikeBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockDeathbikeBuy)
				{
					if (FutureShockDeathbikeBought != 1)
					{
						if (Game.Player.Money >= 1269000)
						{
							FutureShockDeathbikeBought = 1;
							Game.Player.Money -= 1269000;
							Config.SetValue("Vehicles", "FutureShockDeathbikeBought", FutureShockDeathbikeBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu26 = GarageMenuPool.AddSubMenu(uIMenu7, "Buy");
			UIMenu uIMenu27 = GarageMenuPool.AddSubMenu(uIMenu7, "Use");
			UIMenuItem ApocalypseSlamvanUse = new UIMenuItem("Apocalypse Slamvan");
			uIMenu27.AddItem(ApocalypseSlamvanUse);
			UIMenuItem NightmareSlamvanUse = new UIMenuItem("Nightmare Slamvan");
			uIMenu27.AddItem(NightmareSlamvanUse);
			UIMenuItem FutureShockSlamvanUse = new UIMenuItem("Future Shock Slamvan");
			uIMenu27.AddItem(FutureShockSlamvanUse);
			UIMenuItem ApocalypseSlamvanBuy = new UIMenuItem("Apocalypse Slamvan: $1,255,781");
			uIMenu26.AddItem(ApocalypseSlamvanBuy);
			UIMenuItem NightmareSlamvanBuy = new UIMenuItem("Nightmare Slamvan : $1,255,781");
			uIMenu26.AddItem(NightmareSlamvanBuy);
			UIMenuItem FutureShockSlamvanBuy = new UIMenuItem("Future Shock Slamvan : $1,255,781");
			uIMenu26.AddItem(FutureShockSlamvanBuy);
			uIMenu27.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseSlamvanUse)
				{
					if (ApocalypseSlamvanBought == 1)
					{
						Slamvan.Delete();
						SC.LoadIniFile(Loadpath + "Slamvan/1Apocalypse.ini");
						Slamvan = World.CreateVehicle("Slamvan4", SlamvanSpawn, -90f);
						SC.Load(Slamvan);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Slamvan);
						CurrentSlamvan = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareSlamvanUse)
				{
					if (NightmareSlamvanBought == 1)
					{
						Slamvan.Delete();
						SC.LoadIniFile(Loadpath + "Slamvan/2NIghtmare.ini");
						Slamvan = World.CreateVehicle("Slamvan6", SlamvanSpawn, -90f);
						SC.Load(Slamvan);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Slamvan);
						CurrentSlamvan = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockSlamvanUse)
				{
					if (FutureShockSlamvanBought == 1)
					{
						Slamvan.Delete();
						SC.LoadIniFile(Loadpath + "Slamvan/3FutureShock.ini");
						Slamvan = World.CreateVehicle("Slamvan5", SlamvanSpawn, -90f);
						SC.Load(Slamvan);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Slamvan);
						CurrentSlamvan = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu26.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseSlamvanBuy)
				{
					if (ApocalypseSlamvanBought != 1)
					{
						if (Game.Player.Money >= 1255781)
						{
							ApocalypseSlamvanBought = 1;
							Game.Player.Money -= 1255781;
							Config.SetValue("Vehicles", "ApocalypseSlamvanBought", ApocalypseSlamvanBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareSlamvanBuy)
				{
					if (NightmareSlamvanBought != 1)
					{
						if (Game.Player.Money >= 1255781)
						{
							NightmareSlamvanBought = 1;
							Game.Player.Money -= 1255781;
							Config.SetValue("Vehicles", "NightmareSlamvanBought", NightmareSlamvanBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockSlamvanBuy)
				{
					if (FutureShockSlamvanBought != 1)
					{
						if (Game.Player.Money >= 1255781)
						{
							FutureShockSlamvanBought = 1;
							Game.Player.Money -= 1255781;
							Config.SetValue("Vehicles", "FutureShockSlamvanBought", FutureShockSlamvanBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu28 = GarageMenuPool.AddSubMenu(uIMenu8, "Buy");
			UIMenu uIMenu29 = GarageMenuPool.AddSubMenu(uIMenu8, "Use");
			UIMenuItem ApocalypseIssiUse = new UIMenuItem("Apocalypse Issi");
			uIMenu29.AddItem(ApocalypseIssiUse);
			UIMenuItem NightmareIssiUse = new UIMenuItem("Nightmare Issi");
			uIMenu29.AddItem(NightmareIssiUse);
			UIMenuItem FutureShockIssiUse = new UIMenuItem("Future Shock Issi");
			uIMenu29.AddItem(FutureShockIssiUse);
			UIMenuItem ApocalypseIssiBuy = new UIMenuItem("Apocalypse Issi : $1,034,550");
			uIMenu28.AddItem(ApocalypseIssiBuy);
			UIMenuItem NightmareIssiBuy = new UIMenuItem("Nightmare Issi : $1,034,550");
			uIMenu28.AddItem(NightmareIssiBuy);
			UIMenuItem FutureShockIssiBuy = new UIMenuItem("Future Shock Issi : $1,034,550");
			uIMenu28.AddItem(FutureShockIssiBuy);
			uIMenu29.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseIssiUse)
				{
					if (ApocalypseIssiBought == 1)
					{
						Issi.Delete();
						SC.LoadIniFile(Loadpath + "Issi/1Apocalypse.ini");
						Issi = World.CreateVehicle("Issi4", IssiSpawn, -90f);
						SC.Load(Issi);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Issi);
						CurrentIssi = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentIssi", CurrentIssi);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareIssiUse)
				{
					if (NightmareIssiBought == 1)
					{
						Issi.Delete();
						SC.LoadIniFile(Loadpath + "Issi/2NIghtmare.ini");
						Issi = World.CreateVehicle("Issi6", IssiSpawn, -90f);
						SC.Load(Issi);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Issi);
						CurrentIssi = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentIssi", CurrentIssi);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockIssiUse)
				{
					if (FutureShockIssiBought == 1)
					{
						Issi.Delete();
						SC.LoadIniFile(Loadpath + "Issi/3FutureShock.ini");
						Issi = World.CreateVehicle("Issi5", IssiSpawn, -90f);
						SC.Load(Issi);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Issi);
						CurrentIssi = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentIssi", CurrentIssi);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu28.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseIssiBuy)
				{
					if (ApocalypseSlamvanBought != 1)
					{
						if (Game.Player.Money >= 1034550)
						{
							ApocalypseIssiBought = 1;
							Game.Player.Money -= 1034550;
							Config.SetValue("Vehicles", "ApocalypseIssiBought", ApocalypseIssiBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareIssiBuy)
				{
					if (NightmareIssiBought != 1)
					{
						if (Game.Player.Money >= 1034550)
						{
							NightmareIssiBought = 1;
							Game.Player.Money -= 1034550;
							Config.SetValue("Vehicles", "NightmareIssiBought", NightmareIssiBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockIssiBuy)
				{
					if (FutureShockIssiBought != 1)
					{
						if (Game.Player.Money >= 1034550)
						{
							FutureShockIssiBought = 1;
							Game.Player.Money -= 1034550;
							Config.SetValue("Vehicles", "FutureShockIssiBought", FutureShockIssiBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenu uIMenu30 = GarageMenuPool.AddSubMenu(uIMenu11, "Buy");
			UIMenu uIMenu31 = GarageMenuPool.AddSubMenu(uIMenu11, "Use");
			UIMenuItem ApocalypseBruitusUse = new UIMenuItem("Apocalypse Brutus");
			uIMenu31.AddItem(ApocalypseBruitusUse);
			UIMenuItem NightmareBruitusUse = new UIMenuItem("Nightmare Brutus");
			uIMenu31.AddItem(NightmareBruitusUse);
			UIMenuItem FutureShockBruitusUse = new UIMenuItem("Future Shock  Brutus");
			uIMenu31.AddItem(FutureShockBruitusUse);
			UIMenuItem ApocalypseBruitusBuy = new UIMenuItem("Apocalypse Bruitus : $2,005,000");
			uIMenu30.AddItem(ApocalypseBruitusBuy);
			UIMenuItem NightmareBruitusBuy = new UIMenuItem("Nightmare Bruitus : $2,005,000");
			uIMenu30.AddItem(NightmareBruitusBuy);
			UIMenuItem FutureShockBruitusBuy = new UIMenuItem("Future Shock Bruitus : $2,005,000");
			uIMenu30.AddItem(FutureShockBruitusBuy);
			uIMenu31.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseBruitusUse)
				{
					if (ApocalypseBruitusBought == 1)
					{
						Bruitus.Delete();
						SC.LoadIniFile(Loadpath + "Bruitus/1Apocalypse.ini");
						Bruitus = World.CreateVehicle("Brutus", BruitusSpawn, 90f);
						SC.Load(Bruitus);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Bruitus);
						CurrentBruitus = 1;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentBruitus", CurrentBruitus);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == NightmareBruitusUse)
				{
					if (NightmareBruitusBought == 1)
					{
						Bruitus.Delete();
						SC.LoadIniFile(Loadpath + "Bruitus/2NIghtmare.ini");
						Bruitus = World.CreateVehicle("Brutus3", BruitusSpawn, 90f);
						SC.Load(Bruitus);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Bruitus);
						CurrentBruitus = 3;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentBruitus", CurrentBruitus);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
				if (item == FutureShockBruitusUse)
				{
					if (FutureShockBruitusBought == 1)
					{
						Bruitus.Delete();
						SC.LoadIniFile(Loadpath + "Bruitus/3FutureShock.ini");
						Bruitus = World.CreateVehicle("Brutus2", BruitusSpawn, 90f);
						SC.Load(Bruitus);
						SC.SaveWithoutDelete();
						UI.Notify("Alan : Loaded vehicle : " + Bruitus);
						CurrentBruitus = 2;
						LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
						Config.SetValue("Vehicles", "CurrentBruitus", CurrentBruitus);
						Config.Save();
					}
					else
					{
						UI.Notify("Alan : you dont own this vehicle");
					}
				}
			});
			uIMenu30.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == ApocalypseBruitusBuy)
				{
					if (ApocalypseBruitusBought != 1)
					{
						if (Game.Player.Money >= 2005000)
						{
							ApocalypseBruitusBought = 1;
							Game.Player.Money -= 2005000;
							Config.SetValue("Vehicles", "ApocalypseBrutusBought", ApocalypseBruitusBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == NightmareBruitusBuy)
				{
					if (NightmareBruitusBought != 1)
					{
						if (Game.Player.Money >= 2005000)
						{
							NightmareBruitusBought = 1;
							Game.Player.Money -= 2005000;
							Config.SetValue("Vehicles", "NightmareBrutusBought", NightmareBruitusBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
				if (item == FutureShockBruitusBuy)
				{
					if (FutureShockBruitusBought != 1)
					{
						if (Game.Player.Money >= 2005000)
						{
							FutureShockBruitusBought = 1;
							Game.Player.Money -= 2005000;
							Config.SetValue("Vehicles", "FutureShockBrutusBought", FutureShockBruitusBought);
							Config.Save();
						}
					}
					else
					{
						UI.Notify("Alan : you already own this vehicle ");
					}
				}
			});
			UIMenuItem Apocalypse = new UIMenuItem("Apocalypse");
			uIMenu.AddItem(Apocalypse);
			UIMenuItem Nightmare = new UIMenuItem("Nightmare");
			uIMenu.AddItem(Nightmare);
			UIMenuItem FutureShock = new UIMenuItem("Future Shock");
			uIMenu.AddItem(FutureShock);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Apocalypse)
				{
					CurrentCerberus = 1;
					Config.SetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
					CurrentScarab = 1;
					Config.SetValue("Vehicles", "CurrentScarab", CurrentScarab);
					CurrentDominator = 1;
					Config.SetValue("Vehicles", "CurrentDominator", CurrentDominator);
					CurrentImperator = 1;
					Config.SetValue("Vehicles", "CurrentImperator", CurrentImperator);
					CurrentDeathbike = 1;
					Config.SetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
					CurrentIssi = 1;
					Config.SetValue("Vehicles", "CurrentIssi", CurrentIssi);
					CurrentMonster = 1;
					Config.SetValue("Vehicles", "CurrentMonster", CurrentMonster);
					CurrentImpaler = 1;
					Config.SetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
					CurrentSlamvan = 1;
					Config.SetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
					CurrentBruitus = 1;
					Config.SetValue("Vehicles", "CurrentBrutus", CurrentBruitus);
					CurrentZR380 = 1;
					Config.SetValue("Vehicles", "CurrentZR380", CurrentZR380);
					CurrentBruiser = 1;
					Config.SetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
					Config.Save();
					DeleteVehicles();
					LoadVehicles();
				}
				if (item == Nightmare)
				{
					CurrentCerberus = 2;
					Config.SetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
					CurrentScarab = 2;
					Config.SetValue("Vehicles", "CurrentScarab", CurrentScarab);
					CurrentDominator = 2;
					Config.SetValue("Vehicles", "CurrentDominator", CurrentDominator);
					CurrentImperator = 2;
					Config.SetValue("Vehicles", "CurrentImperator", CurrentImperator);
					CurrentDeathbike = 2;
					Config.SetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
					CurrentIssi = 2;
					Config.SetValue("Vehicles", "CurrentIssi", CurrentIssi);
					CurrentMonster = 2;
					Config.SetValue("Vehicles", "CurrentMonster", CurrentMonster);
					CurrentImpaler = 2;
					Config.SetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
					CurrentSlamvan = 2;
					Config.SetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
					CurrentBruitus = 2;
					Config.SetValue("Vehicles", "CurrentBrutus", CurrentBruitus);
					CurrentZR380 = 2;
					Config.SetValue("Vehicles", "CurrentZR380", CurrentZR380);
					CurrentBruiser = 2;
					Config.SetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
					Config.Save();
					DeleteVehicles();
					LoadVehicles();
				}
				if (item == FutureShock)
				{
					CurrentCerberus = 3;
					Config.SetValue("Vehicles", "CurrentCerberus", CurrentCerberus);
					CurrentScarab = 3;
					Config.SetValue("Vehicles", "CurrentScarab", CurrentScarab);
					CurrentDominator = 3;
					Config.SetValue("Vehicles", "CurrentDominator", CurrentDominator);
					CurrentImperator = 3;
					Config.SetValue("Vehicles", "CurrentImperator", CurrentImperator);
					CurrentDeathbike = 3;
					Config.SetValue("Vehicles", "CurrentDeathbike", CurrentDeathbike);
					CurrentIssi = 3;
					Config.SetValue("Vehicles", "CurrentIssi", CurrentIssi);
					CurrentMonster = 3;
					Config.SetValue("Vehicles", "CurrentMonster", CurrentMonster);
					CurrentImpaler = 3;
					Config.SetValue("Vehicles", "CurrentImpaler", CurrentImpaler);
					CurrentSlamvan = 3;
					Config.SetValue("Vehicles", "CurrentSlamvan", CurrentSlamvan);
					CurrentBruitus = 3;
					Config.SetValue("Vehicles", "CurrentBrutus", CurrentBruitus);
					CurrentZR380 = 3;
					Config.SetValue("Vehicles", "CurrentZR380", CurrentZR380);
					CurrentBruiser = 3;
					Config.SetValue("Vehicles", "CurrentBruiser", CurrentBruiser);
					Config.Save();
					DeleteVehicles();
					LoadVehicles();
				}
			});
		}

		public Vector3 RandomLocationFun2()
		{
			Random random = new Random();
			int num = random.Next(1, 110);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2774f, -3779f, 140f);
			}
			if (num >= 10 && num <= 20)
			{
				RamdomLocationVar = new Vector3(2899f, -3749f, 140f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2962f, -3790f, 140f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2874f, -3866f, 138f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2850f, -3852f, 139f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2676f, -3795f, 143f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2670f, -3745f, 140f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2738f, -3784f, 140f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2820f, -3727f, 140f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2887f, -3811f, 140f);
			}
			if (num > 100 && num <= 110)
			{
				RamdomLocationVar = new Vector3(2684f, -3871f, 140f);
			}
			return RamdomLocationVar;
		}

		public Vector3 RandomLocationFun3()
		{
			Random random = new Random();
			int num = random.Next(1, 110);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2684f, -3853f, 140f);
			}
			if (num > 10 && num < 20)
			{
				RamdomLocationVar = new Vector3(2682f, -3796f, 140f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2728f, -3758f, 140f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2799f, -3799f, 140f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2870f, -3841f, 140f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2895f, -3825f, 140f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2918f, -3803f, 140f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2917f, -3749f, 140f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2800f, -3758f, 127f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2757f, -3800f, 127f);
			}
			if (num > 100 && num < 110)
			{
				RamdomLocationVar = new Vector3(2801f, -3836f, 127f);
			}
			return RamdomLocationVar;
		}

		public Vector3 RandomLocationFun4()
		{
			Random random = new Random();
			int num = random.Next(1, 110);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2733f, -3803f, 127f);
			}
			if (num > 10 && num < 20)
			{
				RamdomLocationVar = new Vector3(2790f, -3754f, 127f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2855f, -3790f, 127f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2886f, -3878f, 140f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2886f, -3826f, 140f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2909f, -3755f, 140f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2762f, -3779f, 141f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2643f, -3821f, 140f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2784f, -3728f, 140f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2906f, -3752f, 140f);
			}
			if (num > 100 && num < 110)
			{
				RamdomLocationVar = new Vector3(2941f, -3786f, 140f);
			}
			return RamdomLocationVar;
		}

		public Vector3 RandomLocationFun5()
		{
			Random random = new Random();
			int num = random.Next(1, 140);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2738f, -3853f, 140f);
			}
			if (num > 10 && num < 20)
			{
				RamdomLocationVar = new Vector3(2745f, -3808f, 140f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2752f, -3742f, 137f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2799f, -3825f, 147f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2799f, -3749f, 147f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2875f, -3761f, 140f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2892f, -3821f, 140f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2837f, -3795f, 157f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2652f, -3763f, 142f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2772f, -3797f, 157f);
			}
			if (num > 100 && num < 110)
			{
				RamdomLocationVar = new Vector3(2923f, -3727f, 139f);
			}
			if (num > 110 && num < 120)
			{
				RamdomLocationVar = new Vector3(2937f, -3837f, 141f);
			}
			if (num > 120 && num < 130)
			{
				RamdomLocationVar = new Vector3(2675f, -3796f, 144f);
			}
			if (num > 130 && num <= 140)
			{
				RamdomLocationVar = new Vector3(2926f, -3796f, 144f);
			}
			return RamdomLocationVar;
		}

		public Vector3 RandomLocationFun6()
		{
			Random random = new Random();
			int num = random.Next(1, 150);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2931f, -3828f, 139f);
			}
			if (num > 10 && num < 20)
			{
				RamdomLocationVar = new Vector3(2932f, -3771f, 139f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2901f, -3799f, 139f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2880f, -3800f, 139f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2842f, -3798f, 139f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2800f, -3800f, 139f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2761f, -3800f, 139f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2720f, -3799f, 139f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2668f, -3772f, 139f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2667f, -3828f, 139f);
			}
			if (num > 100 && num < 110)
			{
				RamdomLocationVar = new Vector3(2822f, -3854f, 147f);
			}
			if (num > 110 && num < 120)
			{
				RamdomLocationVar = new Vector3(2776f, -3854f, 147f);
			}
			if (num > 120 && num < 130)
			{
				RamdomLocationVar = new Vector3(2823f, -3745f, 147f);
			}
			if (num > 130 && num < 140)
			{
				RamdomLocationVar = new Vector3(2777f, -3745f, 147f);
			}
			if (num > 140 && num <= 150)
			{
				RamdomLocationVar = new Vector3(2757f, -3800f, 126f);
			}
			return RamdomLocationVar;
		}

		public Vector3 RandomLocationFun7()
		{
			Random random = new Random();
			int num = random.Next(1, 150);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2714f, -3871f, 139f);
			}
			if (num > 10 && num < 20)
			{
				RamdomLocationVar = new Vector3(2705f, -3803f, 137f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2759f, -3745f, 139f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2834f, -3782f, 146f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2879f, -3796f, 136f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2803f, -3800f, 150f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2841f, -3739f, 148f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2801f, -3847f, 149f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2747f, -3753f, 139f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2855f, -3744f, 139f);
			}
			if (num > 100 && num < 110)
			{
				RamdomLocationVar = new Vector3(2942f, -3835f, 139f);
			}
			if (num > 110 && num < 120)
			{
				RamdomLocationVar = new Vector3(2887f, -3849f, 139f);
			}
			if (num > 120 && num < 130)
			{
				RamdomLocationVar = new Vector3(2748f, -3862f, 139f);
			}
			if (num > 130 && num < 140)
			{
				RamdomLocationVar = new Vector3(2695f, -3744f, 147f);
			}
			if (num > 140 && num <= 150)
			{
				RamdomLocationVar = new Vector3(2757f, -3800f, 126f);
			}
			return RamdomLocationVar;
		}

		public Vector3 RandomLocationFun8()
		{
			Random random = new Random();
			int num = random.Next(1, 110);
			if (num < 10)
			{
				RamdomLocationVar = new Vector3(2748f, -3754f, 134f);
			}
			if (num >= 10 && num <= 20)
			{
				RamdomLocationVar = new Vector3(2797f, -3751f, 134f);
			}
			if (num > 20 && num < 30)
			{
				RamdomLocationVar = new Vector3(2845f, -3773f, 134f);
			}
			if (num > 30 && num < 40)
			{
				RamdomLocationVar = new Vector3(2840f, -3845f, 134f);
			}
			if (num > 40 && num < 50)
			{
				RamdomLocationVar = new Vector3(2850f, -3852f, 134f);
			}
			if (num > 50 && num < 60)
			{
				RamdomLocationVar = new Vector3(2779f, -3830f, 133f);
			}
			if (num > 60 && num < 70)
			{
				RamdomLocationVar = new Vector3(2722f, -3807f, 133f);
			}
			if (num > 70 && num < 80)
			{
				RamdomLocationVar = new Vector3(2759f, -3790f, 132f);
			}
			if (num > 80 && num < 90)
			{
				RamdomLocationVar = new Vector3(2777f, -3810f, 132f);
			}
			if (num > 90 && num < 100)
			{
				RamdomLocationVar = new Vector3(2816f, -3812f, 132f);
			}
			if (num > 100 && num <= 110)
			{
				RamdomLocationVar = new Vector3(2817f, -3785f, 132f);
			}
			return RamdomLocationVar;
		}

		public VehicleHash RandomVehicleFun()
		{
			Random random = new Random();
			if (random.Next(1, 13) == 1)
			{
				RandomVehicle = VehicleHash.Baller;
			}
			if (random.Next(1, 13) == 2)
			{
				RandomVehicle = VehicleHash.Dominator;
			}
			if (random.Next(1, 13) == 3)
			{
				RandomVehicle = VehicleHash.Dukes;
			}
			if (random.Next(1, 13) == 4)
			{
				RandomVehicle = VehicleHash.Comet2;
			}
			if (random.Next(1, 13) == 5)
			{
				RandomVehicle = VehicleHash.SabreGT;
			}
			if (random.Next(1, 13) == 6)
			{
				RandomVehicle = VehicleHash.Schafter2;
			}
			if (random.Next(1, 13) == 7)
			{
				RandomVehicle = VehicleHash.Stalion;
			}
			if (random.Next(1, 13) == 8)
			{
				RandomVehicle = VehicleHash.Taco;
			}
			if (random.Next(1, 13) == 9)
			{
				RandomVehicle = VehicleHash.Voltic;
			}
			if (random.Next(1, 13) == 10)
			{
				RandomVehicle = VehicleHash.XLS;
			}
			if (random.Next(1, 13) == 11)
			{
				RandomVehicle = VehicleHash.Vader;
			}
			if (random.Next(1, 13) == 12)
			{
				RandomVehicle = VehicleHash.Sultan;
			}
			if (random.Next(1, 13) == 13)
			{
				RandomVehicle = VehicleHash.Sanchez;
			}
			if (random.Next(1, 13) > 13)
			{
				RandomVehicle = VehicleHash.Chino;
			}
			return RandomVehicle;
		}

		public Vector3 Randomlocation()
		{
			Random random = new Random();
			int num = random.Next(1, 1400);
			if (num < 100)
			{
				VehicleSpawn = new Vector3(-1069.32f, -72.28f, 19f);
			}
			if (num >= 100 && num < 200)
			{
				VehicleSpawn = new Vector3(-1579.93f, -155.28f, 55f);
			}
			if (num >= 200 && num < 300)
			{
				VehicleSpawn = new Vector3(-711.74f, -28.28f, 37f);
			}
			if (num >= 300 && num < 400)
			{
				VehicleSpawn = new Vector3(6f, 253.58f, 109f);
			}
			if (num >= 400 && num < 500)
			{
				VehicleSpawn = new Vector3(703f, 32f, 84f);
			}
			if (num >= 500 && num < 600)
			{
				VehicleSpawn = new Vector3(1197f, -421.5f, 68f);
			}
			if (num >= 600 && num < 700)
			{
				VehicleSpawn = new Vector3(1257f, -1428f, 35f);
			}
			if (num >= 700 && num < 800)
			{
				VehicleSpawn = new Vector3(1264f, -2039f, 45f);
			}
			if (num >= 800 && num < 900)
			{
				VehicleSpawn = new Vector3(527f, -2052f, 28f);
			}
			if (num >= 900 && num < 1000)
			{
				VehicleSpawn = new Vector3(-161f, -2087.8f, 26f);
			}
			if (num >= 1000 && num < 1100)
			{
				VehicleSpawn = new Vector3(756f, -1723f, 30f);
			}
			if (num >= 1100 && num < 1200)
			{
				VehicleSpawn = new Vector3(-816f, -2300f, 11f);
			}
			if (num >= 1200 && num < 1300)
			{
				VehicleSpawn = new Vector3(-1839f, 136f, 78f);
			}
			if (num >= 1300 && num < 1400)
			{
				VehicleSpawn = new Vector3(756f, -1723f, 30f);
			}
			return VehicleSpawn;
		}

		public VehicleColor GetColor()
		{
			List<object> list = new List<object>();
			VehicleColor[] array = (VehicleColor[])Enum.GetValues(typeof(VehicleColor));
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(array[i]);
			}
			Random random = new Random();
			int index = random.Next(1, array.Length);
			return (dynamic)list[index];
		}

		private void SetupOrganization()
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Expected O, but got Unknown
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_011d: Expected O, but got Unknown
			//IL_0132: Unknown result type (might be due to invalid IL or missing references)
			//IL_013c: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(OrganizationOptions, "Change Design");
			UIMenuItem D1 = new UIMenuItem("Executive Rich : Free");
			uIMenu.AddItem(D1);
			UIMenuItem D2 = new UIMenuItem("Executive Cool: $415,000");
			uIMenu.AddItem(D2);
			UIMenuItem D3 = new UIMenuItem("Executive Contrast: $500,000");
			uIMenu.AddItem(D3);
			UIMenuItem D4 = new UIMenuItem("Old Spice Warms: $950,000");
			uIMenu.AddItem(D4);
			UIMenuItem D5 = new UIMenuItem("Old Spice Classical: $685,000");
			uIMenu.AddItem(D5);
			UIMenuItem D6 = new UIMenuItem("Old Spice Vintage: $760,000");
			uIMenu.AddItem(D6);
			UIMenuItem D7 = new UIMenuItem("Power Broker Ice $1,000,000\t");
			uIMenu.AddItem(D7);
			UIMenuItem D8 = new UIMenuItem("Power Broker Conservative: $835,000");
			uIMenu.AddItem(D8);
			UIMenuItem D9 = new UIMenuItem("Power Broker Polished: $910,000");
			uIMenu.AddItem(D9);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == D1 && Game.Player.Money >= 0)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Player player = Game.Player;
					player.Money = player.Money;
					int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_02b";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num2 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D2 && Game.Player.Money >= 415000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 415000;
					int num3 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_02c";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num4 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D3 && Game.Player.Money >= 500000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 500000;
					int num5 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_02a";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num6 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D4 && Game.Player.Money >= 950000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 950000;
					int num7 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_01a";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num8 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D5 && Game.Player.Money >= 685000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 685000;
					int num9 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_01b";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num10 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D6 && Game.Player.Money >= 760000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 760000;
					int num11 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_01c";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num12 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D7 && Game.Player.Money >= 1000000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 1000000;
					int num13 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_03a";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num14 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D8 && Game.Player.Money >= 835000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 835000;
					int num15 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_03b";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num16 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
				if (item == D9 && Game.Player.Money >= 910000)
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = MarkerEnter;
					Game.Player.Money -= 910000;
					int num17 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { Design });
					Design = "ex_dt1_11_office_03c";
					Config.SetValue<string>("Design", "InteriorDesign", Design);
					Config.Save();
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num18 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Script.Wait(300);
					Game.FadeScreenIn(300);
				}
			});
		}

		private void ChooseVehicle(int i)
		{
			if (i == 1)
			{
				carid = "Mogul";
				VehicleMissioncar = World.CreateVehicle(new Model(-749299473), VehicleLocation);
				VehicleMissioncar.PlaceOnGround();
			}
			if (i == 2)
			{
				carid = "Cuban 800";
				VehicleMissioncar = World.CreateVehicle(VehicleHash.Cuban800, VehicleLocation);
				VehicleMissioncar.PlaceOnGround();
			}
			if (i == 3)
			{
				carid = "Duster";
				VehicleMissioncar = World.CreateVehicle(VehicleHash.Duster, VehicleLocation);
				VehicleMissioncar.PlaceOnGround();
			}
			if (i == 4)
			{
				carid = "Mammatus";
				VehicleMissioncar = World.CreateVehicle(VehicleHash.Mammatus, VehicleLocation);
				VehicleMissioncar.PlaceOnGround();
			}
		}

		private void SetupProduct()
		{
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Expected O, but got Unknown
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Expected O, but got Unknown
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00aa: Expected O, but got Unknown
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c7: Expected O, but got Unknown
			//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e6: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(ProductStock, "Buy/Sell Product");
			UIMenuItem Buy2 = new UIMenuItem("Buy X10: -$" + 500000);
			uIMenu.AddItem(Buy2);
			UIMenuItem Buy = new UIMenuItem("Buy X1: -$" + 100000);
			uIMenu.AddItem(Buy);
			UIMenuItem Sell = new UIMenuItem("Sell - All Stocks (Low)");
			uIMenu.AddItem(Sell);
			UIMenuItem Sell2 = new UIMenuItem("Sell - All Stocks (High)");
			uIMenu.AddItem(Sell2);
			UIMenuItem Show = new UIMenuItem("Show Product Value/Count");
			uIMenu.AddItem(Show);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Show)
				{
					LoadIniFile("scripts//ExecutiveBusiness//MazeBank.ini");
					UI.Notify("Alan: Here is where we are at");
					UI.Notify("Level: " + purchaselvl + "/20");
					UI.Notify("Max Stocks: " + maxstocks);
					UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
					UI.Notify("Mission Gain: " + profitMargin + "%");
					UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
				}
				if (item == Buy2)
				{
					if (stockscount + 10 <= maxstocks)
					{
						if (Game.Player.Money > 500000)
						{
							Game.Player.Money = Game.Player.Money - 500000;
							stocksvalue += 250000f;
							stockscount += 10;
							Config.SetValue("Setup", "stockslevel", stockscount);
							Config.SetValue("Setup", "StocksValue", stocksvalue);
							Config.Save();
							UI.Notify("Alan: ok i can deal with that, one new container of product");
							UI.Notify("Stocks Avalable: " + stockscount);
						}
					}
					else
					{
						UI.Notify("Alan: Sorry Boss, were full, we canot store any more stocks, please sell stocks or upgrade ");
					}
				}
				if (item == Buy)
				{
					if (stockscount != maxstocks)
					{
						if (Game.Player.Money > 100000)
						{
							Game.Player.Money = Game.Player.Money - 100000;
							stocksvalue += 25000f;
							stockscount++;
							Config.SetValue("Setup", "stockslevel", stockscount);
							Config.SetValue("Setup", "StocksValue", stocksvalue);
							Config.Save();
							UI.Notify("Alan : ok i can deal with that, one new container of product");
							UI.Notify("Stocks Avalable: " + stockscount);
						}
					}
					else
					{
						UI.Notify("Alan : Sorry Boss, were full, we canot store any more stocks, please sell stocks or upgrade ");
					}
				}
				if (item == Sell)
				{
					UI.Notify("Alan : ok i can deal with that, selling all product avalable");
					Game.Player.Money = Game.Player.Money + (int)stocksvalue;
					stocksvalue = 0f;
					stockscount = 0;
					Config.SetValue("Setup", "stockslevel", stockscount);
					Config.SetValue("Setup", "StocksValue", stocksvalue);
					Config.Save();
				}
				if (item == Sell2)
				{
					if (VtoGet != null)
					{
						VtoGet.Delete();
					}
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Remove();
					}
					UI.Notify("Alan : ok get the mule from the warehouse and deliver it to the drop zone");
					Missionnum = 17;
					VtoGet = World.CreateVehicle(VehicleHash.Mule, new Vector3(269f, -3050f, 5.38f));
					VtoGet.Rotation = new Vector3(0f, 0f, 44f);
					VtoGetBlip = World.CreateBlip(VtoGet.Position);
					VtoGetBlip.Name = "Take Mule to drop point";
					VtoGetBlip.Sprite = BlipSprite.Trailer;
					VtoGetBlip.Color = BlipColor.White;
					VtoGetBlip.Name = "Take Mule to drop point";
					VehicleisDamaged = false;
					Vehiclehealth = VtoGet.Health;
					MissionSetup = true;
					VehicleSetup = true;
					GotCar = false;
					Race = 1;
				}
			});
		}

		private void SetupSourcing2()
		{
			//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01da: Expected O, but got Unknown
			//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Expected O, but got Unknown
			//IL_020c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0216: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(Sourcingmenu2, "Source a vehicle ");
			List<object> list2 = new List<object>();
			VehicleHash[] allvehiclehashes = (VehicleHash[])Enum.GetValues(typeof(VehicleHash));
			for (int i = 0; i < allvehiclehashes.Length; i++)
			{
				list2.Add(allvehiclehashes[i]);
			}
			list2.Add(VehicleHash.EntityXXR);
			list2.Add(VehicleHash.Rhino);
			list2.Add(VehicleHash.Stromberg);
			list2.Add(VehicleHash.ZType);
			list2.Add(VehicleHash.Deluxo);
			list2.Add(VehicleHash.Visione);
			list2.Add(VehicleHash.Vigilante);
			list2.Add(VehicleHash.Vagner);
			list2.Add(VehicleHash.Phantom2);
			list2.Add(VehicleHash.Dune4);
			list2.Add(VehicleHash.Dune5);
			list2.Add(VehicleHash.Dune5);
			list2.Add(VehicleHash.Wastelander);
			list2.Add(VehicleHash.Banshee2);
			list2.Add(VehicleHash.Voltic2);
			list2.Add(VehicleHash.Technical2);
			list2.Add(VehicleHash.Technical3);
			list2.Add(VehicleHash.Tezeract);
			list2.Add(VehicleHash.Taipan);
			list2.Add(VehicleHash.Tampa3);
			UIMenuListItem list = new UIMenuListItem("Vehicle: ", list2, 0);
			uIMenu.AddItem((UIMenuItem)(object)list);
			UIMenuItem getvehicle = new UIMenuItem("Source Vehicle");
			uIMenu.AddItem(getvehicle);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getvehicle)
				{
					int index2 = list.get_Index();
					VehicleHash vehicleHash = allvehiclehashes[index2];
					if (vehicleHash == VehicleHash.Insurgent || vehicleHash == VehicleHash.Insurgent2 || vehicleHash == VehicleHash.Insurgent3 || vehicleHash == VehicleHash.Kuruma2 || vehicleHash == VehicleHash.Oppressor || vehicleHash == VehicleHash.APC || vehicleHash == VehicleHash.HalfTrack || vehicleHash == VehicleHash.NightShark || vehicleHash == VehicleHash.Dune3 || vehicleHash == VehicleHash.Technical || vehicleHash == VehicleHash.Technical2 || vehicleHash == VehicleHash.Technical3 || vehicleHash == VehicleHash.Chernobog)
					{
						Random random = new Random();
						int num = random.Next(125000, 350000);
						SourcingPayout = (float)num + (float)num * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.EntityXXR || vehicleHash == VehicleHash.LE7B || vehicleHash == VehicleHash.Nero2 || vehicleHash == VehicleHash.Nero2 || vehicleHash == VehicleHash.T20 || vehicleHash == VehicleHash.Tyrant || vehicleHash == VehicleHash.Tezeract || vehicleHash == VehicleHash.NightShark || vehicleHash == VehicleHash.Tempesta || vehicleHash == VehicleHash.Technical || vehicleHash == VehicleHash.Osiris || vehicleHash == VehicleHash.GP1 || vehicleHash == VehicleHash.Autarch || vehicleHash == VehicleHash.SultanRS || vehicleHash == VehicleHash.Banshee2 || vehicleHash == VehicleHash.Taipan || vehicleHash == VehicleHash.Taipan || vehicleHash == VehicleHash.Vagner || vehicleHash == VehicleHash.Visione || vehicleHash == VehicleHash.Prototipo || vehicleHash == VehicleHash.Reaper || vehicleHash == VehicleHash.Pfister811 || vehicleHash == VehicleHash.FMJ || vehicleHash == VehicleHash.Zentorno || vehicleHash == VehicleHash.ItaliGTB2 || vehicleHash == VehicleHash.ItaliGTB || vehicleHash == VehicleHash.Voltic2)
					{
						Random random2 = new Random();
						int num2 = random2.Next(75000, 1000000);
						SourcingPayout = (float)num2 + (float)num2 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.ZType)
					{
						Random random3 = new Random();
						int num3 = random3.Next(195000, 2300000);
						SourcingPayout = (float)num3 + (float)num3 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.Deluxo || vehicleHash == VehicleHash.Stromberg || vehicleHash == VehicleHash.Vigilante || vehicleHash == VehicleHash.Dune2)
					{
						Random random4 = new Random();
						int num4 = random4.Next(135000, 550000);
						SourcingPayout = (float)num4 + (float)num4 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.Phantom2 || vehicleHash == VehicleHash.Dune4 || vehicleHash == VehicleHash.Dune5 || vehicleHash == VehicleHash.Wastelander || vehicleHash == VehicleHash.Tampa3 || vehicleHash == VehicleHash.Caracara || vehicleHash == VehicleHash.Monster)
					{
						Random random5 = new Random();
						int num5 = random5.Next(100000, 400000);
						SourcingPayout = (float)num5 + (float)num5 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.Rhino || vehicleHash == VehicleHash.Khanjali)
					{
						Random random6 = new Random();
						int num6 = random6.Next(290000, 2000000);
						SourcingPayout = (float)num6 + (float)num6 * profitMargin / 100f;
					}
					else
					{
						Random random7 = new Random();
						int num7 = random7.Next(100000, 200000);
						SourcingPayout = (float)num7 + (float)num7 * profitMargin / 100f;
					}
					VehicleIdentifier = vehicleHash;
					VehicleIdentiferfun2(vehicleHash);
					UI.Notify("Alan: Ok the car is a " + vehicleHash);
					UI.Notify("Alan: the pay is  $" + SourcingPayout);
				}
			});
		}

		private void SetupSourcing()
		{
			//IL_01d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01da: Expected O, but got Unknown
			//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Expected O, but got Unknown
			//IL_020c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0216: Expected O, but got Unknown
			UIMenu uIMenu = modMenuPool.AddSubMenu(Sourcingmenu, "Source a vehicle ");
			List<object> list2 = new List<object>();
			VehicleHash[] allvehiclehashes = (VehicleHash[])Enum.GetValues(typeof(VehicleHash));
			for (int i = 0; i < allvehiclehashes.Length; i++)
			{
				list2.Add(allvehiclehashes[i]);
			}
			list2.Add(VehicleHash.EntityXXR);
			list2.Add(VehicleHash.Rhino);
			list2.Add(VehicleHash.Stromberg);
			list2.Add(VehicleHash.ZType);
			list2.Add(VehicleHash.Deluxo);
			list2.Add(VehicleHash.Visione);
			list2.Add(VehicleHash.Vigilante);
			list2.Add(VehicleHash.Vagner);
			list2.Add(VehicleHash.Phantom2);
			list2.Add(VehicleHash.Dune4);
			list2.Add(VehicleHash.Dune5);
			list2.Add(VehicleHash.Dune5);
			list2.Add(VehicleHash.Wastelander);
			list2.Add(VehicleHash.Banshee2);
			list2.Add(VehicleHash.Voltic2);
			list2.Add(VehicleHash.Technical2);
			list2.Add(VehicleHash.Technical3);
			list2.Add(VehicleHash.Tezeract);
			list2.Add(VehicleHash.Taipan);
			list2.Add(VehicleHash.Tampa3);
			UIMenuListItem list = new UIMenuListItem("Vehicle: ", list2, 0);
			uIMenu.AddItem((UIMenuItem)(object)list);
			UIMenuItem getvehicle = new UIMenuItem("Source Vehicle");
			uIMenu.AddItem(getvehicle);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getvehicle)
				{
					int index2 = list.get_Index();
					VehicleHash vehicleHash = allvehiclehashes[index2];
					if (vehicleHash == VehicleHash.Insurgent || vehicleHash == VehicleHash.Insurgent2 || vehicleHash == VehicleHash.Insurgent3 || vehicleHash == VehicleHash.Kuruma2 || vehicleHash == VehicleHash.Oppressor || vehicleHash == VehicleHash.APC || vehicleHash == VehicleHash.HalfTrack || vehicleHash == VehicleHash.NightShark || vehicleHash == VehicleHash.Dune3 || vehicleHash == VehicleHash.Technical || vehicleHash == VehicleHash.Technical2 || vehicleHash == VehicleHash.Technical3 || vehicleHash == VehicleHash.Chernobog)
					{
						Random random = new Random();
						int num = random.Next(125000, 350000);
						SourcingPayout = (float)num + (float)num * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.EntityXXR || vehicleHash == VehicleHash.LE7B || vehicleHash == VehicleHash.Nero2 || vehicleHash == VehicleHash.Nero2 || vehicleHash == VehicleHash.T20 || vehicleHash == VehicleHash.Tyrant || vehicleHash == VehicleHash.Tezeract || vehicleHash == VehicleHash.NightShark || vehicleHash == VehicleHash.Tempesta || vehicleHash == VehicleHash.Technical || vehicleHash == VehicleHash.Osiris || vehicleHash == VehicleHash.GP1 || vehicleHash == VehicleHash.Autarch || vehicleHash == VehicleHash.SultanRS || vehicleHash == VehicleHash.Banshee2 || vehicleHash == VehicleHash.Taipan || vehicleHash == VehicleHash.Taipan || vehicleHash == VehicleHash.Vagner || vehicleHash == VehicleHash.Visione || vehicleHash == VehicleHash.Prototipo || vehicleHash == VehicleHash.Reaper || vehicleHash == VehicleHash.Pfister811 || vehicleHash == VehicleHash.FMJ || vehicleHash == VehicleHash.Zentorno || vehicleHash == VehicleHash.ItaliGTB2 || vehicleHash == VehicleHash.ItaliGTB || vehicleHash == VehicleHash.Voltic2)
					{
						Random random2 = new Random();
						int num2 = random2.Next(75000, 1000000);
						SourcingPayout = (float)num2 + (float)num2 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.ZType)
					{
						Random random3 = new Random();
						int num3 = random3.Next(195000, 2300000);
						SourcingPayout = (float)num3 + (float)num3 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.Deluxo || vehicleHash == VehicleHash.Stromberg || vehicleHash == VehicleHash.Vigilante || vehicleHash == VehicleHash.Dune2)
					{
						Random random4 = new Random();
						int num4 = random4.Next(135000, 550000);
						SourcingPayout = (float)num4 + (float)num4 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.Phantom2 || vehicleHash == VehicleHash.Dune4 || vehicleHash == VehicleHash.Dune5 || vehicleHash == VehicleHash.Wastelander || vehicleHash == VehicleHash.Tampa3 || vehicleHash == VehicleHash.Caracara || vehicleHash == VehicleHash.Monster)
					{
						Random random5 = new Random();
						int num5 = random5.Next(100000, 400000);
						SourcingPayout = (float)num5 + (float)num5 * profitMargin / 100f;
					}
					if (vehicleHash == VehicleHash.Rhino || vehicleHash == VehicleHash.Khanjali)
					{
						Random random6 = new Random();
						int num6 = random6.Next(290000, 2000000);
						SourcingPayout = (float)num6 + (float)num6 * profitMargin / 100f;
					}
					else
					{
						Random random7 = new Random();
						int num7 = random7.Next(100000, 200000);
						SourcingPayout = (float)num7 + (float)num7 * profitMargin / 100f;
					}
					VehicleIdentifier = vehicleHash;
					VehicleIdentiferfun(vehicleHash);
					UI.Notify("Alan: Ok the car is a " + vehicleHash);
					UI.Notify("Alan: the pay is  $" + SourcingPayout);
				}
			});
		}

		private void Setupbuisness()
		{
			//IL_0074: Unknown result type (might be due to invalid IL or missing references)
			//IL_007e: Expected O, but got Unknown
			//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Expected O, but got Unknown
			//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d2: Expected O, but got Unknown
			//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Expected O, but got Unknown
			//IL_0103: Unknown result type (might be due to invalid IL or missing references)
			//IL_010d: Expected O, but got Unknown
			//IL_0122: Unknown result type (might be due to invalid IL or missing references)
			//IL_012c: Expected O, but got Unknown
			//IL_013f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0149: Expected O, but got Unknown
			//IL_015c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0166: Expected O, but got Unknown
			//IL_0191: Unknown result type (might be due to invalid IL or missing references)
			//IL_019b: Expected O, but got Unknown
			//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_01bc: Expected O, but got Unknown
			//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d0: Expected O, but got Unknown
			//IL_01da: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e4: Expected O, but got Unknown
			//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Expected O, but got Unknown
			List<object> list3 = new List<object>();
			int num = 1;
			for (int i = 1; i < 100; i++)
			{
				list3.Add(num + i);
			}
			UIMenu uIMenu = modMenuPool.AddSubMenu(methgarage, "Expand Business ");
			UIMenu uIMenu2 = modMenuPool.AddSubMenu(methgarage, "Money Vault Options ");
			UIMenuItem BuyVW = new UIMenuItem("Buy : $450,000");
			uIMenu2.AddItem(BuyVW);
			UIMenu uIMenu3 = modMenuPool.AddSubMenu(methgarage, "Gun Locker Options ");
			UIMenuItem BuyGL = new UIMenuItem("Buy : $1,000,000");
			uIMenu3.AddItem(BuyGL);
			UIMenuItem SellGL = new UIMenuItem("Sell");
			uIMenu3.AddItem(SellGL);
			UIMenuItem Update = new UIMenuItem("Update Stats");
			uIMenu.AddItem(Update);
			UIMenuItem BuyNewLevel = new UIMenuItem(" Buy Level ");
			uIMenu.AddItem(BuyNewLevel);
			UIMenuListItem list2 = new UIMenuListItem("Select Level: ", list3, 1);
			uIMenu.AddItem((UIMenuItem)(object)list2);
			UIMenuItem Jump = new UIMenuItem("Jump Straight to Level");
			uIMenu.AddItem(Jump);
			UIMenuItem Show = new UIMenuItem("Show Level");
			uIMenu.AddItem(Show);
			UIMenu uIMenu4 = modMenuPool.AddSubMenu(methgarage, "Sell Business");
			UIMenuItem Sell = new UIMenuItem("Sell");
			uIMenu4.AddItem(Sell);
			uIMenu4.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Sell)
				{
					if (!bought)
					{
						UI.Notify("Alan: Get out of here!, you dont own any of these buisnesses ");
					}
					else
					{
						bought = false;
						purchaselvl = 0;
						stocksvalue = 0f;
						stockscount = 0;
						Config.SetValue("Setup", "BuisnessLevel", purchaselvl);
						Config.Save();
						UI.Notify("Alan: I just heard, you wanted to sell the buisness, i'm verry sorry, if i have upset you in any way");
					}
				}
			});
			uIMenu3.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (Config.GetValue("Setup", "GunLockerBought", GunLockerBought) == 0)
				{
					if (item == BuyGL)
					{
						if (Game.Player.Money > 1000000)
						{
							Game.Player.Money -= 1000000;
							GunLockerBought = 1;
							Config.SetValue("Setup", "GunLockerBought", GunLockerBought);
							Config.Save();
							UI.Notify("Alan: Ok good you can buy MK2 Weapons now from your gun locker");
						}
						else
						{
							UI.Notify("Alan: Sorry boss you don't have enought money to purchase a  gun locker");
						}
					}
				}
				else if (Config.GetValue("Setup", "GunLockerBought", GunLockerBought) == 1)
				{
					if (item == SellGL)
					{
						GunLockerBought = 0;
						Config.SetValue("Setup", "GunLockerBought", GunLockerBought);
						Config.Save();
						UI.Notify("Alan: Ok i can organize to sell the gun locker");
					}
					UI.Notify("Alan: Boss you have allready bought a gun locker");
				}
			});
			uIMenu2.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (Config.GetValue("Setup", "MoneyVaultBought", MoneyVaultBought) == 0 && item == BuyVW)
				{
					if (Game.Player.Money > 450000)
					{
						Game.Player.Money -= 450000;
						MoneyVaultBought = 1;
						Config.SetValue("Setup", "MoneyVaultBought", MoneyVaultBought);
						Config.Save();
						UI.Notify("Alan: Ok good you can store money now");
					}
					else
					{
						UI.Notify("Alan: Sorry boss you don't have enought money to purchase a vehicle Warehouse");
					}
				}
			});
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == Jump)
				{
					int num2 = list2.get_Index() + 1;
					if (num2 > purchaselvl)
					{
						int num3 = 0;
						int num4 = 0;
						purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
						for (int j = purchaselvl; j < num2; j++)
						{
							double num5 = 1.75;
							if (purchaselvl < 25)
							{
								num5 = 1.75;
							}
							if (purchaselvl > 25 && index < 50)
							{
								num5 = 2.25;
							}
							if (purchaselvl > 50 && purchaselvl < 70)
							{
								num5 = 3.5;
							}
							if (purchaselvl > 75 && purchaselvl < 100)
							{
								num5 = 4.75;
							}
							num3 += (int)(200000.0 * num5 * (double)num2);
							num4++;
						}
						UI.Notify("OK your new level will be " + (purchaselvl += num4 + 1) + ", at a price of $" + num3.ToString("N") + ", Do u want to continue Enter Y or N");
						Script.Wait(1000);
						try
						{
							string userInput = Game.GetUserInput(WindowTitle.CELL_EMAIL_BOD, 1);
							if (userInput.Equals("Y"))
							{
								if (Game.Player.Money >= num3)
								{
									Game.Player.Money -= num3;
									purchaselvl = num2;
									maxstocks = 10 * purchaselvl;
									float num6 = (float)(125000 * purchaselvl) / 0.75f;
									profitMargin = (float)(0.85 * (double)purchaselvl + 0.0);
									increaseGain = num6;
									Config.SetValue("Setup", "BuisnessLevel", purchaselvl);
									Config.Save();
								}
								else
								{
									purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
									UI.Notify("You dont have enough money to purchase this upgrade");
								}
							}
							else
							{
								purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
								UI.Notify(" You Entered the Wrong key or N");
							}
						}
						catch (NullReferenceException)
						{
							purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
							UI.Notify("You did not enter a key!");
						}
					}
				}
				if (item == Update)
				{
					int num7 = list2.get_Index() + 1;
					double num8 = 1.75;
					if (purchaselvl < 25)
					{
						num8 = 1.75;
					}
					if (purchaselvl > 25 && index < 50)
					{
						num8 = 2.25;
					}
					if (purchaselvl > 50 && purchaselvl < 70)
					{
						num8 = 3.5;
					}
					if (purchaselvl > 75 && purchaselvl < 100)
					{
						num8 = 4.75;
					}
					UI.Notify("Price " + (200000.0 * num8 * (double)num7).ToString("N"));
					UI.Notify("Level to Buy " + (num7 + 1));
					UI.Notify("Profit Margin  : $" + ((float)(125000 * num7) / 0.75f).ToString("N"));
					UI.Notify("increaseGain:" + (0.85 * (double)num7 + 0.0) + "%");
					UI.Notify("Max Stocks : " + 10 * num7);
				}
				if (item == BuyNewLevel)
				{
					int num9 = list2.get_Index() + 1;
					purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
					if (purchaselvl + 1 == num9)
					{
						double num10 = 1.75;
						if (purchaselvl < 25)
						{
							num10 = 1.75;
						}
						if (purchaselvl > 25 && index < 50)
						{
							num10 = 2.25;
						}
						if (purchaselvl > 50 && purchaselvl < 70)
						{
							num10 = 3.5;
						}
						if (purchaselvl > 75 && purchaselvl < 100)
						{
							num10 = 4.75;
						}
						if ((double)Game.Player.Money >= 200000.0 * num10 * (double)num9)
						{
							Game.Player.Money -= (int)(200000.0 * num10 * (double)num9);
							purchaselvl++;
							maxstocks = 10 * purchaselvl;
							float num11 = (float)(125000 * purchaselvl) / 0.75f;
							profitMargin = (float)(0.85 * (double)purchaselvl + 0.0);
							increaseGain = num11;
							Config.SetValue("Setup", "BuisnessLevel", purchaselvl);
							Config.Save();
						}
						else
						{
							UI.Notify("You dont have enough money to purchase this upgrade");
						}
					}
					else
					{
						UI.Notify("The level you are trying to purchase is either to high or to low!, please purchase the level before, to purchase this level");
					}
				}
				if (item == Show)
				{
					double num12 = 1.75;
					if (purchaselvl < 25)
					{
						num12 = 1.75;
					}
					if (purchaselvl > 25 && index < 50)
					{
						num12 = 3.75;
					}
					if (purchaselvl > 50 && purchaselvl < 70)
					{
						num12 = 6.75;
					}
					if (purchaselvl > 75 && purchaselvl < 100)
					{
						num12 = 9.75;
					}
					UI.Notify("Price for Next Level $" + (200000.0 * num12 * (double)purchaselvl).ToString("N"));
					UI.Notify("Next Level " + (purchaselvl + 1));
					UI.Notify("increaseGain : $" + (float)(125000 * purchaselvl) / 0.75f);
					UI.Notify("Profit Margin :" + (0.85 * (double)purchaselvl + 0.0) + "%");
					UI.Notify("Max Stocks : " + 10 * purchaselvl);
				}
			});
		}

		private void List2_OnListChanged(UIMenuListItem sender, int newIndex)
		{
			throw new NotImplementedException();
		}

		private void VehicleIdentiferfun2(VehicleHash v)
		{
			if (VehicleMarker != null)
			{
				VehicleMarker.Remove();
			}
			Vehicletoget = null;
			Random random = new Random();
			if (random.Next(1, 13) == 1)
			{
				VehicleSpawn = new Vector3(-1069.32f, -72.28f, 19f);
			}
			if (random.Next(1, 13) == 2)
			{
				VehicleSpawn = new Vector3(-1579.93f, -155.28f, 55f);
			}
			if (random.Next(1, 13) == 3)
			{
				VehicleSpawn = new Vector3(-711.74f, -28.28f, 37f);
			}
			if (random.Next(1, 13) == 4)
			{
				VehicleSpawn = new Vector3(6f, 253.58f, 109f);
			}
			if (random.Next(1, 13) == 5)
			{
				VehicleSpawn = new Vector3(703f, 32f, 84f);
			}
			if (random.Next(1, 13) == 6)
			{
				VehicleSpawn = new Vector3(1197f, -421.5f, 68f);
			}
			if (random.Next(1, 13) == 7)
			{
				VehicleSpawn = new Vector3(1257f, -1428f, 35f);
			}
			if (random.Next(1, 13) == 8)
			{
				VehicleSpawn = new Vector3(1264f, -2039f, 45f);
			}
			if (random.Next(1, 13) == 9)
			{
				VehicleSpawn = new Vector3(527f, -2052f, 28f);
			}
			if (random.Next(1, 13) == 10)
			{
				VehicleSpawn = new Vector3(-161f, -2087.8f, 26f);
			}
			if (random.Next(1, 13) == 11)
			{
				VehicleSpawn = new Vector3(756f, -1723f, 30f);
			}
			if (random.Next(1, 13) == 12)
			{
				VehicleSpawn = new Vector3(-816f, -2300f, 11f);
			}
			if (random.Next(1, 13) == 13)
			{
				VehicleSpawn = new Vector3(-1839f, 136f, 78f);
			}
			Vehicletoget = World.CreateVehicle(v, VehicleSpawn);
			SourcedVehicle = Vehicletoget.DisplayName;
			Vehicletoget.Delete();
			NewVehicleSourcing = true;
			foundvehicleyet = true;
			SourcingCheckingforDamage = true;
		}

		private void VehicleIdentiferfun(VehicleHash v)
		{
			if (VehicleMarker != null)
			{
				VehicleMarker.Remove();
			}
			Vehicletoget = null;
			Random random = new Random();
			if (random.Next(1, 13) == 1)
			{
				VehicleSpawn = new Vector3(-1069.32f, -72.28f, 19f);
			}
			if (random.Next(1, 13) == 2)
			{
				VehicleSpawn = new Vector3(-1579.93f, -155.28f, 55f);
			}
			if (random.Next(1, 13) == 3)
			{
				VehicleSpawn = new Vector3(-711.74f, -28.28f, 37f);
			}
			if (random.Next(1, 13) == 4)
			{
				VehicleSpawn = new Vector3(6f, 253.58f, 109f);
			}
			if (random.Next(1, 13) == 5)
			{
				VehicleSpawn = new Vector3(703f, 32f, 84f);
			}
			if (random.Next(1, 13) == 6)
			{
				VehicleSpawn = new Vector3(1197f, -421.5f, 68f);
			}
			if (random.Next(1, 13) == 7)
			{
				VehicleSpawn = new Vector3(1257f, -1428f, 35f);
			}
			if (random.Next(1, 13) == 8)
			{
				VehicleSpawn = new Vector3(1264f, -2039f, 45f);
			}
			if (random.Next(1, 13) == 9)
			{
				VehicleSpawn = new Vector3(527f, -2052f, 28f);
			}
			if (random.Next(1, 13) == 10)
			{
				VehicleSpawn = new Vector3(-161f, -2087.8f, 26f);
			}
			if (random.Next(1, 13) == 11)
			{
				VehicleSpawn = new Vector3(756f, -1723f, 30f);
			}
			if (random.Next(1, 13) == 12)
			{
				VehicleSpawn = new Vector3(-816f, -2300f, 11f);
			}
			if (random.Next(1, 13) == 13)
			{
				VehicleSpawn = new Vector3(-1839f, 136f, 78f);
			}
			Vehicletoget = World.CreateVehicle(v, VehicleSpawn);
			Vehicletoget.CreatePedOnSeat(VehicleSeat.Driver, PedHash.Busker01SMO);
			Vehicletoget.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
			Vehicleloc = Vehicletoget.Position;
			VehicleMarker = World.CreateBlip(Vehicleloc);
			VehicleMarker.Sprite = BlipSprite.Cab;
			VehicleMarker.Color = BlipColor.Red;
			VehicleMarker.Name = "Target Car";
			foundvehicleyet = true;
			SourcingCheckingforDamage = true;
		}

		public void UpgradeVehicle2(Vehicle Car)
		{
			Car.SetMod(VehicleMod.Brakes, 3, true);
			Car.SetMod(VehicleMod.Suspension, 3, true);
			Car.SetMod(VehicleMod.Transmission, 3, true);
			Car.SetMod(VehicleMod.Engine, 3, true);
		}

		public void UpgradeVehicle3(Vehicle Car)
		{
			Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { Car.Handle, 0 });
			Car.SetMod(VehicleMod.Brakes, 3, true);
			Car.SetMod(VehicleMod.Suspension, 3, true);
			Car.SetMod(VehicleMod.Transmission, 3, true);
			Car.SetMod(VehicleMod.Engine, 3, true);
			Car.PrimaryColor = GetColor();
			Car.SecondaryColor = GetColor();
		}

		public void ChecktoSeeifinthelead()
		{
			if (!CircuitRace)
			{
				if (World.GetDistance(Game.Player.Character.Position, FinishLine) < World.GetDistance(VehicleA.Position, FinishLine) && World.GetDistance(Game.Player.Character.Position, FinishLine) < World.GetDistance(VehicleB.Position, FinishLine) && World.GetDistance(Game.Player.Character.Position, FinishLine) < World.GetDistance(VehicleC.Position, FinishLine))
				{
					IsLeading = true;
				}
				else
				{
					IsLeading = false;
				}
				return;
			}
			if (World.GetDistance(Game.Player.Character.Position, VehicleA.Position) < 20f)
			{
				VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			}
			else
			{
				if (ACheck == 0)
				{
					VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1165f, 24f, 81f), 20f, 420f);
				}
				if (ACheck == 1)
				{
					VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1253f, 267f, 82f), 20f, 420f);
				}
				if (ACheck == 2)
				{
					VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1101f, 166f, 81f), 20f, 420f);
				}
				if (ACheck == 3)
				{
					VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1005f, -72f, 81f), 20f, 420f);
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, VehicleB.Position) < 20f)
			{
				VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			}
			else
			{
				if (BCheck == 0)
				{
					VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1165f, 24f, 81f), 20f, 420f);
				}
				if (BCheck == 1)
				{
					VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1253f, 267f, 82f), 20f, 420f);
				}
				if (BCheck == 2)
				{
					VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1101f, 166f, 81f), 20f, 420f);
				}
				if (BCheck == 3)
				{
					VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1005f, -72f, 81f), 20f, 420f);
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, VehicleC.Position) < 20f)
			{
				VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			}
			else
			{
				if (CCheck == 0)
				{
					VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1165f, 24f, 81f), 20f, 420f);
				}
				if (CCheck == 1)
				{
					VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1253f, 267f, 82f), 20f, 420f);
				}
				if (CCheck == 2)
				{
					VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1101f, 166f, 81f), 20f, 420f);
				}
				if (CCheck == 3)
				{
					VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1005f, -72f, 81f), 20f, 420f);
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, FinishLine) < World.GetDistance(VehicleA.Position, FinishLine) && World.GetDistance(Game.Player.Character.Position, FinishLine) < World.GetDistance(VehicleB.Position, FinishLine) && World.GetDistance(Game.Player.Character.Position, FinishLine) < World.GetDistance(VehicleC.Position, FinishLine))
			{
				IsLeading = true;
			}
			else
			{
				IsLeading = false;
			}
		}

		public Model getVehicle()
		{
			Random random = new Random();
			int num = random.Next(1, 310);
			if (num < 10)
			{
				VehicleChoosen = VehicleHash.Dominator4;
			}
			else if (num >= 10 && num < 20)
			{
				VehicleChoosen = VehicleHash.Dominator5;
			}
			else if (num >= 20 && num < 30)
			{
				VehicleChoosen = VehicleHash.ZR380;
			}
			else if (num >= 30 && num < 40)
			{
				VehicleChoosen = VehicleHash.ZR3802;
			}
			else if (num >= 40 && num < 50)
			{
				VehicleChoosen = VehicleHash.ZR3803;
			}
			else if (num >= 50 && num < 60)
			{
				VehicleChoosen = VehicleHash.ZR3802;
			}
			else if (num >= 60 && num < 80)
			{
				VehicleChoosen = VehicleHash.Imperator;
			}
			else if (num >= 80 && num < 90)
			{
				VehicleChoosen = VehicleHash.Imperator3;
			}
			else if (num >= 90 && num < 100)
			{
				VehicleChoosen = VehicleHash.Imperator2;
			}
			else if (num >= 100 && num < 110)
			{
				VehicleChoosen = VehicleHash.Impaler2;
			}
			else if (num >= 110 && num < 120)
			{
				VehicleChoosen = VehicleHash.Impaler3;
			}
			else if (num >= 120 && num < 130)
			{
				VehicleChoosen = VehicleHash.Impaler4;
			}
			else if (num >= 130 && num < 140)
			{
				VehicleChoosen = VehicleHash.Monster3;
			}
			else if (num > 140 && num < 150)
			{
				VehicleChoosen = VehicleHash.Monster4;
			}
			else if (num >= 150 && num < 160)
			{
				VehicleChoosen = VehicleHash.Monster5;
			}
			else if (num >= 160 && num < 170)
			{
				VehicleChoosen = VehicleHash.Brutus;
			}
			else if (num >= 170 && num < 180)
			{
				VehicleChoosen = VehicleHash.Issi4;
			}
			else if (num >= 180 && num < 190)
			{
				VehicleChoosen = VehicleHash.Deathbike;
			}
			else if (num >= 190 && num < 200)
			{
				VehicleChoosen = VehicleHash.Scarab;
			}
			else if (num >= 200 && num < 210)
			{
				VehicleChoosen = VehicleHash.RCBandito;
			}
			else if (num >= 210 && num < 220)
			{
				VehicleChoosen = VehicleHash.Cerberus2;
			}
			else if (num >= 220 && num < 230)
			{
				VehicleChoosen = VehicleHash.Cerberus;
			}
			else if (num >= 230 && num < 240)
			{
				VehicleChoosen = VehicleHash.Cerberus3;
			}
			else if (num >= 240 && num < 250)
			{
				VehicleChoosen = VehicleHash.Bruiser;
			}
			else if (num >= 250 && num < 260)
			{
				VehicleChoosen = VehicleHash.Bruiser2;
			}
			else if (num >= 260 && num < 270)
			{
				VehicleChoosen = VehicleHash.Bruiser3;
			}
			else if (num >= 270 && num < 280)
			{
				VehicleChoosen = VehicleHash.Brutus2;
			}
			else if (num >= 280 && num < 290)
			{
				VehicleChoosen = VehicleHash.Brutus3;
			}
			else if (num >= 290 && num < 300)
			{
				VehicleChoosen = VehicleHash.Deathbike2;
			}
			else if (num >= 300 && num <= 310)
			{
				VehicleChoosen = VehicleHash.Deathbike3;
			}
			return RequestModel(VehicleChoosen);
		}

		public Model getVehicle2()
		{
			Random random = new Random();
			int num = random.Next(1, 150);
			if (num < 10)
			{
				VehicleChoosen = VehicleHash.Dominator4;
			}
			else if (num >= 10 && num < 20)
			{
				VehicleChoosen = VehicleHash.Dominator5;
			}
			else if (num >= 20 && num < 30)
			{
				VehicleChoosen = VehicleHash.ZR380;
			}
			else if (num >= 30 && num < 40)
			{
				VehicleChoosen = VehicleHash.ZR3802;
			}
			else if (num >= 40 && num < 50)
			{
				VehicleChoosen = VehicleHash.ZR3803;
			}
			else if (num >= 50 && num < 60)
			{
				VehicleChoosen = VehicleHash.ZR380;
			}
			else if (num >= 60 && num < 70)
			{
				VehicleChoosen = VehicleHash.Imperator;
			}
			else if (num >= 70 && num < 80)
			{
				VehicleChoosen = VehicleHash.Imperator2;
			}
			else if (num >= 80 && num < 90)
			{
				VehicleChoosen = VehicleHash.Imperator3;
			}
			else if (num >= 90 && num < 100)
			{
				VehicleChoosen = VehicleHash.Impaler;
			}
			else if (num >= 110 && num < 110)
			{
				VehicleChoosen = VehicleHash.Impaler2;
			}
			else if (num >= 110 && num < 120)
			{
				VehicleChoosen = VehicleHash.Impaler3;
			}
			else if (num >= 120 && num < 130)
			{
				VehicleChoosen = VehicleHash.Imperator3;
			}
			else if (num >= 130 && num < 140)
			{
				VehicleChoosen = VehicleHash.Dominator4;
			}
			if (num >= 140 && num < 150)
			{
				VehicleChoosen = VehicleHash.Dominator6;
			}
			return RequestModel(VehicleChoosen);
		}

		public void SetupModifications(Vehicle V)
		{
			Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
			Random random = new Random();
			V.SetMod(VehicleMod.Exhaust, random.Next(0, 4), true);
			V.SetMod(VehicleMod.Grille, random.Next(0, 3), true);
			V.SetMod(VehicleMod.Frame, random.Next(0, 3), true);
			V.SetMod(VehicleMod.EngineBlock, random.Next(0, 4), true);
			V.SetMod(VehicleMod.ArchCover, random.Next(0, 3), true);
			V.SetMod(VehicleMod.Tank, random.Next(0, 2), true);
			V.SetMod(VehicleMod.Struts, random.Next(0, 3), true);
			V.SetMod(VehicleMod.AirFilter, random.Next(0, 3), true);
			V.SetMod(VehicleMod.Livery, random.Next(0, 17), true);
			Function.Call(Hash._0x6AF0636DDEDCB6DD, new InputArgument[4]
			{
				V,
				44,
				random.Next(0, 1),
				true
			});
			V.PrimaryColor = GetColor();
			V.SecondaryColor = GetColor();
			V.ToggleMod(VehicleToggleMod.XenonHeadlights, true);
			V.LightsOn = true;
			V.HighBeamsOn = true;
			Random random2 = new Random();
			int num = random2.Next(1, 13);
			if (num == 1)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 1 });
			}
			if (num == 2)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 2 });
			}
			if (num == 3)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 3 });
			}
			if (num == 4)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 4 });
			}
			if (num == 5)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 5 });
			}
			if (num == 6)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 6 });
			}
			if (num == 7)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 7 });
			}
			if (num == 8)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 8 });
			}
			if (num == 9)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 9 });
			}
			if (num == 10)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 10 });
			}
			if (num == 11)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 11 });
			}
			if (num == 12)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 12 });
			}
			if (num == 13)
			{
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { V, 255 });
			}
		}

		public void SetupRivalCar(int i, Vehicle V)
		{
			Script.Wait(3);
			if (i == 0)
			{
				Random random = new Random();
				Random random2 = new Random();
				V.MaxSpeed = 400f;
				V.EngineTorqueMultiplier = random.Next(15, 100) / 10;
				V.EnginePowerMultiplier = random2.Next(15, 100) / 10;
				SetupModifications(V);
			}
			if (i == 1)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
				V.SetMod(VehicleMod.Spoilers, 0, true);
				V.SetMod(VehicleMod.FrontWheels, 4, true);
				V.PrimaryColor = VehicleColor.MetallicPurple;
				V.SecondaryColor = VehicleColor.MetallicPurple;
				V.PearlescentColor = VehicleColor.MetallicUltraBlue;
				V.SetMod(VehicleMod.Livery, 4, true);
				V.MaxSpeed = 400f;
				V.EngineTorqueMultiplier = 1.4f;
				V.EnginePowerMultiplier = 1.4f;
			}
			if (i == 2)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
				V.SetMod(VehicleMod.Aerials, 10, true);
				V.SetMod(VehicleMod.AirFilter, 7, true);
				V.SetMod(VehicleMod.ArchCover, 5, true);
				V.SetMod(VehicleMod.Spoilers, 12, true);
				V.PrimaryColor = VehicleColor.BrushedAluminium;
				V.SecondaryColor = VehicleColor.BrushedAluminium;
				V.PearlescentColor = VehicleColor.MatteBlack;
				V.SetMod(VehicleMod.Livery, 3, true);
				V.MaxSpeed = 400f;
				V.EngineTorqueMultiplier = 2.2f;
				V.EnginePowerMultiplier = 2.4f;
			}
			if (i == 3)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
				V.SetMod(VehicleMod.Hood, 4, true);
				V.PrimaryColor = VehicleColor.MetallicBlack;
				V.SecondaryColor = VehicleColor.Chrome;
				V.PearlescentColor = VehicleColor.MetallicBlack;
				V.MaxSpeed = 400f;
				V.EngineTorqueMultiplier = 5f;
				V.EnginePowerMultiplier = 5f;
			}
			if (i == 4)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
				V.PrimaryColor = VehicleColor.MetallicTorinoRed;
				V.SecondaryColor = VehicleColor.MetallicTorinoRed;
				V.PearlescentColor = VehicleColor.MetallicBlack;
				V.MaxSpeed = 420f;
				V.EngineTorqueMultiplier = 2f;
				V.EnginePowerMultiplier = 2f;
			}
			if (i == 5)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
				V.PrimaryColor = VehicleColor.MatteBlack;
				V.SecondaryColor = VehicleColor.MatteBlack;
				V.PearlescentColor = VehicleColor.MetallicBlack;
				V.SetMod(VehicleMod.Livery, 1, true);
				V.MaxSpeed = 420f;
				V.EngineTorqueMultiplier = 2.4f;
				V.EnginePowerMultiplier = 1.3f;
			}
			if (i == 6)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
				V.PrimaryColor = VehicleColor.MatteBlack;
				V.SecondaryColor = VehicleColor.MatteBlack;
				V.PearlescentColor = VehicleColor.MetallicBlack;
				V.SetMod(VehicleMod.Livery, 2, true);
				V.MaxSpeed = 420f;
				V.EngineTorqueMultiplier = 4f;
				V.EnginePowerMultiplier = 2.2f;
			}
		}

		public void DeleteVehicleinPointtoPoint()
		{
			Game.Player.Money += (int)moneytobeawarded;
			Game.Player.Character.CurrentVehicle.Explode();
			Script.Wait(500);
			StartedRace = false;
			MissionSetup = false;
			Race = 0;
			if (VtoGetBlip != null)
			{
				VtoGetBlip.Remove();
			}
			Script.Wait(200);
			UI.Notify("Alan : wow you just hit a mine, congrats on surviving for that long");
			Game.Player.Character.CurrentVehicle.Delete();
		}

		public void SetupDeathMatchCars()
		{
			if (VtoGetBlip != null)
			{
				VtoGetBlip.Remove();
			}
			if (VtoGetBlip1 != null)
			{
				VtoGetBlip1.Remove();
			}
			if (VtoGetBlip2 != null)
			{
				VtoGetBlip2.Remove();
			}
			if (VtoGetBlip3 != null)
			{
				VtoGetBlip3.Remove();
			}
			if (VtoGet != null)
			{
				VtoGet.Delete();
			}
			if (VtoGet1 != null)
			{
				VtoGet1.Delete();
			}
			if (VtoGet2 != null)
			{
				VtoGet2.Delete();
			}
			if (VtoGet3 != null)
			{
				VtoGet3.Delete();
			}
			Vector3 position = new Vector3(2736f, -3892f, 140f);
			Vector3 position2 = new Vector3(2866f, -3892f, 140f);
			Vector3 position3 = new Vector3(2865f, -3707f, 140f);
			Vector3 position4 = new Vector3(2732f, -3707f, 140f);
			Script.Wait(100);
			VtoGet = World.CreateVehicle(getVehicle(), position, 10f);
			VtoGet.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet1 = World.CreateVehicle(getVehicle(), position2, 10f);
			VtoGet1.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet2 = World.CreateVehicle(getVehicle(), position3, 10f);
			VtoGet2.Rotation = new Vector3(0f, 0f, 180f);
			Script.Wait(100);
			VtoGet3 = World.CreateVehicle(getVehicle(), position4, 10f);
			VtoGet3.Rotation = new Vector3(0f, 0f, 180f);
			SetupRivalCar(0, VtoGet);
			SetupRivalCar(0, VtoGet1);
			SetupRivalCar(0, VtoGet2);
			SetupRivalCar(0, VtoGet3);
			Script.Wait(50);
			Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet1.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet3.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Script.Wait(50);
			VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet2.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet3.CreateRandomPedOnSeat(VehicleSeat.Driver);
			Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet2.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet3.GetPedOnSeat(VehicleSeat.Driver));
			Script.Wait(100);
			VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			Script.Wait(100);
			VtoGetBlip = World.CreateBlip(VtoGet.Position);
			VtoGetBlip.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip, 8 });
			VtoGetBlip1 = World.CreateBlip(VtoGet1.Position);
			VtoGetBlip1.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip1, 8 });
			VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
			VtoGetBlip2.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip2, 8 });
			VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
			VtoGetBlip3.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip3, 8 });
		}

		public void SetupSkyWarsCars()
		{
			if (VtoGetBlip != null)
			{
				VtoGetBlip.Remove();
			}
			if (VtoGetBlip1 != null)
			{
				VtoGetBlip1.Remove();
			}
			if (VtoGetBlip2 != null)
			{
				VtoGetBlip2.Remove();
			}
			if (VtoGetBlip3 != null)
			{
				VtoGetBlip3.Remove();
			}
			if (VtoGet != null)
			{
				VtoGet.Delete();
			}
			if (VtoGet1 != null)
			{
				VtoGet1.Delete();
			}
			if (VtoGet2 != null)
			{
				VtoGet2.Delete();
			}
			if (VtoGet3 != null)
			{
				VtoGet3.Delete();
			}
			Vector3 position = new Vector3(-132f, -774f, 1005f);
			Vector3 position2 = new Vector3(-148f, -945f, 1005f);
			Vector3 position3 = new Vector3(14f, -944f, 1005f);
			Vector3 position4 = new Vector3(21f, -775f, 1005f);
			Script.Wait(100);
			VtoGet = World.CreateVehicle(getVehicle(), position, 10f);
			VtoGet.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			VtoGet1 = World.CreateVehicle(getVehicle(), position2, 10f);
			VtoGet1.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			VtoGet2 = World.CreateVehicle(getVehicle(), position3, 10f);
			VtoGet2.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			VtoGet3 = World.CreateVehicle(getVehicle(), position4, 10f);
			VtoGet3.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			SetupRivalCar(0, VtoGet);
			SetupRivalCar(0, VtoGet1);
			SetupRivalCar(0, VtoGet2);
			SetupRivalCar(0, VtoGet3);
			Script.Wait(50);
			Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet1.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet3.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Script.Wait(50);
			VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet2.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet3.CreateRandomPedOnSeat(VehicleSeat.Driver);
			Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet2.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet3.GetPedOnSeat(VehicleSeat.Driver));
			Script.Wait(100);
			VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			Script.Wait(100);
			VtoGetBlip = World.CreateBlip(VtoGet.Position);
			VtoGetBlip.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip, 8 });
			VtoGetBlip1 = World.CreateBlip(VtoGet1.Position);
			VtoGetBlip1.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip1, 8 });
			VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
			VtoGetBlip2.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip2, 8 });
			VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
			VtoGetBlip3.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip3, 8 });
		}

		public void SetupSkyWarsCars2()
		{
			if (VtoGetBlip4 != null)
			{
				VtoGetBlip4.Remove();
			}
			if (VtoGetBlip5 != null)
			{
				VtoGetBlip5.Remove();
			}
			if (VtoGetBlip6 != null)
			{
				VtoGetBlip6.Remove();
			}
			if (VtoGetBlip7 != null)
			{
				VtoGetBlip7.Remove();
			}
			if (VtoGet4 != null)
			{
				VtoGet4.Delete();
			}
			if (VtoGet5 != null)
			{
				VtoGet5.Delete();
			}
			if (VtoGet6 != null)
			{
				VtoGet6.Delete();
			}
			if (VtoGet7 != null)
			{
				VtoGet7.Delete();
			}
			Vector3 position = new Vector3(-122f, -774f, 1005f);
			Vector3 position2 = new Vector3(-138f, -945f, 1005f);
			Vector3 position3 = new Vector3(24f, -944f, 1005f);
			Vector3 position4 = new Vector3(31f, -775f, 1005f);
			Script.Wait(100);
			VtoGet4 = World.CreateVehicle(getVehicle(), position, 10f);
			VtoGet4.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			VtoGet5 = World.CreateVehicle(getVehicle(), position2, 10f);
			VtoGet5.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			VtoGet6 = World.CreateVehicle(getVehicle(), position3, 10f);
			VtoGet6.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			VtoGet7 = World.CreateVehicle(getVehicle(), position4, 10f);
			VtoGet7.Rotation = new Vector3(0f, 0f, -180f);
			Script.Wait(100);
			SetupRivalCar(0, VtoGet4);
			SetupRivalCar(0, VtoGet5);
			SetupRivalCar(0, VtoGet6);
			SetupRivalCar(0, VtoGet7);
			Script.Wait(100);
			VtoGet4.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet5.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet6.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet7.CreateRandomPedOnSeat(VehicleSeat.Driver);
			Peds.Add(VtoGet4.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet5.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet6.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet7.GetPedOnSeat(VehicleSeat.Driver));
			Script.Wait(50);
			Ped pedOnSeat = VtoGet4.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet5.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet6.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet7.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Script.Wait(50);
			VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet5.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet7.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			Script.Wait(100);
			VtoGetBlip4 = World.CreateBlip(VtoGet4.Position);
			VtoGetBlip4.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip4, 8 });
			VtoGetBlip5 = World.CreateBlip(VtoGet5.Position);
			VtoGetBlip5.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip5, 8 });
			VtoGetBlip6 = World.CreateBlip(VtoGet6.Position);
			VtoGetBlip6.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip6, 8 });
			VtoGetBlip7 = World.CreateBlip(VtoGet7.Position);
			VtoGetBlip7.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip7, 8 });
		}

		public void SetupChampionchipCars(int I)
		{
			Vector3 position = new Vector3(2736f, -3892f, 140f);
			Vector3 position2 = new Vector3(2866f, -3892f, 140f);
			Vector3 position3 = new Vector3(2865f, -3707f, 140f);
			Vector3 vector = new Vector3(2732f, -3707f, 140f);
			if (I == 1)
			{
				if (VtoGet != null)
				{
					VtoGet.Delete();
				}
				if (VtoGetBlip != null)
				{
					VtoGetBlip.Remove();
				}
				VtoGet = World.CreateVehicle(getVehicle(), position, 10f);
				VtoGet.Rotation = new Vector3(0f, 0f, 0f);
				SetupRivalCar(0, VtoGet);
				VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
				Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip = World.CreateBlip(VtoGet.Position);
				VtoGetBlip.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip, 8 });
				if (VtoGet.Model == VehicleHash.Deathbike)
				{
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet.Model == VehicleHash.Deathbike2)
				{
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet.Model == VehicleHash.Deathbike3)
				{
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 2)
			{
				if (VtoGet1 != null)
				{
					VtoGet1.Delete();
				}
				if (VtoGetBlip1 != null)
				{
					VtoGetBlip1.Remove();
				}
				VtoGet1 = World.CreateVehicle(getVehicle(), position2, 10f);
				VtoGet1.Rotation = new Vector3(0f, 0f, 0f);
				SetupRivalCar(0, VtoGet1);
				VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat2 = VtoGet1.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
				Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip1 = World.CreateBlip(VtoGet1.Position);
				VtoGetBlip1.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip1, 8 });
				if (VtoGet1.Model == VehicleHash.Deathbike)
				{
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet1.Model == VehicleHash.Deathbike2)
				{
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet1.Model == VehicleHash.Deathbike3)
				{
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 3)
			{
				if (VtoGet2 != null)
				{
					VtoGet2.Delete();
				}
				if (VtoGetBlip2 != null)
				{
					VtoGetBlip2.Remove();
				}
				VtoGet2 = World.CreateVehicle(getVehicle(), position3, 10f);
				VtoGet2.Rotation = new Vector3(0f, 0f, 180f);
				SetupRivalCar(0, VtoGet2);
				VtoGet2.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat3 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
				Peds.Add(VtoGet2.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
				VtoGetBlip2.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip2, 8 });
				if (VtoGet2.Model == VehicleHash.Deathbike)
				{
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet2.Model == VehicleHash.Deathbike2)
				{
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet2.Model == VehicleHash.Deathbike3)
				{
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			moneytobeawarded += 75000f;
			checkpointReaced++;
		}

		public void RespawnSkywarsCar(int I)
		{
			Vector3 position = new Vector3(-132f, -774f, 1005f);
			Vector3 position2 = new Vector3(-148f, -945f, 1005f);
			Vector3 position3 = new Vector3(14f, -944f, 1005f);
			Vector3 position4 = new Vector3(21f, -775f, 1005f);
			Vector3 position5 = new Vector3(-122f, -774f, 1005f);
			Vector3 position6 = new Vector3(-138f, -945f, 1005f);
			Vector3 position7 = new Vector3(24f, -944f, 1005f);
			Vector3 position8 = new Vector3(31f, -775f, 1005f);
			if (I == 1)
			{
				if (VtoGet != null)
				{
					VtoGet.Delete();
				}
				if (VtoGetBlip != null)
				{
					VtoGetBlip.Remove();
				}
				VtoGet = World.CreateVehicle(getVehicle(), position, 10f);
				VtoGet.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet);
				VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
				Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip = World.CreateBlip(VtoGet.Position);
				VtoGetBlip.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip, 8 });
				if (VtoGet.Model == VehicleHash.Deathbike)
				{
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet.Model == VehicleHash.Deathbike2)
				{
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet.Model == VehicleHash.Deathbike3)
				{
					VtoGet.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 2)
			{
				if (VtoGet1 != null)
				{
					VtoGet1.Delete();
				}
				if (VtoGetBlip1 != null)
				{
					VtoGetBlip1.Remove();
				}
				VtoGet1 = World.CreateVehicle(getVehicle(), position2, 10f);
				VtoGet1.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet1);
				VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat2 = VtoGet1.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
				Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip1 = World.CreateBlip(VtoGet1.Position);
				VtoGetBlip1.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip1, 8 });
				if (VtoGet1.Model == VehicleHash.Deathbike)
				{
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet1.Model == VehicleHash.Deathbike2)
				{
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet1.Model == VehicleHash.Deathbike3)
				{
					VtoGet1.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 3)
			{
				if (VtoGet2 != null)
				{
					VtoGet2.Delete();
				}
				if (VtoGetBlip2 != null)
				{
					VtoGetBlip2.Remove();
				}
				VtoGet2 = World.CreateVehicle(getVehicle(), position3, 10f);
				VtoGet2.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet2);
				VtoGet2.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat3 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
				Peds.Add(VtoGet2.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
				VtoGetBlip2.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip2, 8 });
				if (VtoGet2.Model == VehicleHash.Deathbike)
				{
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet2.Model == VehicleHash.Deathbike2)
				{
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet2.Model == VehicleHash.Deathbike3)
				{
					VtoGet2.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 4)
			{
				if (VtoGet3 != null)
				{
					VtoGet3.Delete();
				}
				if (VtoGetBlip3 != null)
				{
					VtoGetBlip3.Remove();
				}
				VtoGet3 = World.CreateVehicle(getVehicle(), position4, 10f);
				VtoGet3.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet3);
				VtoGet3.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat4 = VtoGet3.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
				Peds.Add(VtoGet3.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
				VtoGetBlip3.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip3, 8 });
				if (VtoGet3.Model == VehicleHash.Deathbike)
				{
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet3.Model == VehicleHash.Deathbike2)
				{
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet3.Model == VehicleHash.Deathbike3)
				{
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 4)
			{
				if (VtoGet3 != null)
				{
					VtoGet3.Delete();
				}
				if (VtoGetBlip3 != null)
				{
					VtoGetBlip3.Remove();
				}
				VtoGet3 = World.CreateVehicle(getVehicle(), position4, 10f);
				VtoGet3.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet3);
				VtoGet3.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat5 = VtoGet3.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat5, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat5, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat5, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat5, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat5, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat5, 17, 1 });
				Peds.Add(VtoGet3.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
				VtoGetBlip3.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip3, 8 });
				if (VtoGet3.Model == VehicleHash.Deathbike)
				{
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet3.Model == VehicleHash.Deathbike2)
				{
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet3.Model == VehicleHash.Deathbike3)
				{
					VtoGet3.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 5)
			{
				if (VtoGet4 != null)
				{
					VtoGet4.Delete();
				}
				if (VtoGetBlip4 != null)
				{
					VtoGetBlip4.Remove();
				}
				VtoGet4 = World.CreateVehicle(getVehicle(), position5, 10f);
				VtoGet4.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet4);
				VtoGet4.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat6 = VtoGet4.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat6, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat6, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat6, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat6, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat6, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat6, 17, 1 });
				Peds.Add(VtoGet4.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip4 = World.CreateBlip(VtoGet4.Position);
				VtoGetBlip4.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip4, 8 });
				if (VtoGet4.Model == VehicleHash.Deathbike)
				{
					VtoGet4.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet4.Model == VehicleHash.Deathbike2)
				{
					VtoGet4.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet4.Model == VehicleHash.Deathbike3)
				{
					VtoGet4.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 6)
			{
				if (VtoGet5 != null)
				{
					VtoGet5.Delete();
				}
				if (VtoGetBlip5 != null)
				{
					VtoGetBlip5.Remove();
				}
				VtoGet5 = World.CreateVehicle(getVehicle(), position6, 10f);
				VtoGet5.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet5);
				VtoGet5.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat7 = VtoGet5.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat7, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat7, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat7, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat7, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat7, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat7, 17, 1 });
				Peds.Add(VtoGet5.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip5 = World.CreateBlip(VtoGet5.Position);
				VtoGetBlip5.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip4, 8 });
				if (VtoGet5.Model == VehicleHash.Deathbike)
				{
					VtoGet5.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet5.Model == VehicleHash.Deathbike2)
				{
					VtoGet5.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet5.Model == VehicleHash.Deathbike3)
				{
					VtoGet5.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet5.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 7)
			{
				if (VtoGet6 != null)
				{
					VtoGet6.Delete();
				}
				if (VtoGetBlip6 != null)
				{
					VtoGetBlip6.Remove();
				}
				VtoGet6 = World.CreateVehicle(getVehicle(), position7, 10f);
				VtoGet6.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet6);
				VtoGet6.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat8 = VtoGet6.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat8, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat8, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat8, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat8, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat8, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat8, 17, 1 });
				Peds.Add(VtoGet6.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip6 = World.CreateBlip(VtoGet6.Position);
				VtoGetBlip6.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip6, 8 });
				if (VtoGet6.Model == VehicleHash.Deathbike)
				{
					VtoGet6.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet6.Model == VehicleHash.Deathbike2)
				{
					VtoGet6.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet6.Model == VehicleHash.Deathbike3)
				{
					VtoGet6.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			if (I == 8)
			{
				if (VtoGet7 != null)
				{
					VtoGet7.Delete();
				}
				if (VtoGetBlip7 != null)
				{
					VtoGetBlip7.Remove();
				}
				VtoGet7 = World.CreateVehicle(getVehicle(), position8, 10f);
				VtoGet7.Rotation = new Vector3(0f, 0f, -180f);
				SetupRivalCar(0, VtoGet7);
				VtoGet7.CreateRandomPedOnSeat(VehicleSeat.Driver);
				Ped pedOnSeat9 = VtoGet7.GetPedOnSeat(VehicleSeat.Driver);
				Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat9, true });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat9, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat9, 17, 1 });
				Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat9, 1 });
				Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat9, 0, 0 });
				Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat9, 17, 1 });
				Peds.Add(VtoGet7.GetPedOnSeat(VehicleSeat.Driver));
				VtoGetBlip7 = World.CreateBlip(VtoGet7.Position);
				VtoGetBlip7.Sprite = BlipSprite.GunCar;
				Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip7, 8 });
				if (VtoGet7.Model == VehicleHash.Deathbike)
				{
					VtoGet7.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet7.Model == VehicleHash.Deathbike2)
				{
					VtoGet7.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				if (VtoGet7.Model == VehicleHash.Deathbike3)
				{
					VtoGet7.GetPedOnSeat(VehicleSeat.Driver).CanBeKnockedOffBike = false;
				}
				VtoGet7.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			}
			moneytobeawarded += 25000f;
			checkpointReaced++;
		}

		public void SetupDeathMatchCars2()
		{
			if (VtoGetBlip4 != null)
			{
				VtoGetBlip4.Remove();
			}
			if (VtoGetBlip5 != null)
			{
				VtoGetBlip5.Remove();
			}
			if (VtoGetBlip6 != null)
			{
				VtoGetBlip6.Remove();
			}
			if (VtoGetBlip7 != null)
			{
				VtoGetBlip7.Remove();
			}
			if (VtoGet4 != null)
			{
				VtoGet4.Delete();
			}
			if (VtoGet5 != null)
			{
				VtoGet5.Delete();
			}
			if (VtoGet6 != null)
			{
				VtoGet6.Delete();
			}
			if (VtoGet7 != null)
			{
				VtoGet7.Delete();
			}
			Vector3 position = new Vector3(2736f, -3892f, 140f);
			Vector3 position2 = new Vector3(2866f, -3892f, 140f);
			Vector3 position3 = new Vector3(2865f, -3707f, 140f);
			Vector3 position4 = new Vector3(2732f, -3707f, 140f);
			Script.Wait(100);
			VtoGet4 = World.CreateVehicle(getVehicle(), position, 10f);
			VtoGet4.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet5 = World.CreateVehicle(getVehicle(), position2, 10f);
			VtoGet5.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet6 = World.CreateVehicle(getVehicle(), position3, 10f);
			VtoGet6.Rotation = new Vector3(0f, 0f, 180f);
			Script.Wait(100);
			VtoGet7 = World.CreateVehicle(getVehicle(), position4, 10f);
			VtoGet7.Rotation = new Vector3(0f, 0f, 180f);
			SetupRivalCar(0, VtoGet4);
			SetupRivalCar(0, VtoGet5);
			SetupRivalCar(0, VtoGet6);
			SetupRivalCar(0, VtoGet7);
			Script.Wait(100);
			VtoGet4.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet5.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet6.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet7.CreateRandomPedOnSeat(VehicleSeat.Driver);
			Peds.Add(VtoGet4.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet5.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet6.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet7.GetPedOnSeat(VehicleSeat.Driver));
			Script.Wait(50);
			Ped pedOnSeat = VtoGet4.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet5.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet6.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet7.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Script.Wait(50);
			VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet5.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet7.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			Script.Wait(100);
			VtoGetBlip4 = World.CreateBlip(VtoGet4.Position);
			VtoGetBlip4.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip4, 8 });
			VtoGetBlip5 = World.CreateBlip(VtoGet5.Position);
			VtoGetBlip5.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip5, 8 });
			VtoGetBlip6 = World.CreateBlip(VtoGet6.Position);
			VtoGetBlip6.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip6, 8 });
			VtoGetBlip7 = World.CreateBlip(VtoGet7.Position);
			VtoGetBlip7.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip7, 8 });
		}

		public void SetRoof(Vehicle V)
		{
			Random random = new Random();
			int num = random.Next(1, 300);
			Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { V.Handle, 0 });
			if (num < 100)
			{
				V.SetMod(VehicleMod.Roof, -1, true);
			}
			if (num > 100 && num < 200)
			{
				V.SetMod(VehicleMod.Roof, -1, true);
			}
			if (num > 200 && num < 300)
			{
				V.SetMod(VehicleMod.Roof, -1, true);
			}
		}

		public void SetupBeastWarsCars()
		{
			if (VtoGetBlip != null)
			{
				VtoGetBlip.Remove();
			}
			if (VtoGetBlip1 != null)
			{
				VtoGetBlip1.Remove();
			}
			if (VtoGetBlip2 != null)
			{
				VtoGetBlip2.Remove();
			}
			if (VtoGetBlip3 != null)
			{
				VtoGetBlip3.Remove();
			}
			if (VtoGet != null)
			{
				VtoGet.Delete();
			}
			if (VtoGet1 != null)
			{
				VtoGet1.Delete();
			}
			if (VtoGet2 != null)
			{
				VtoGet2.Delete();
			}
			if (VtoGet3 != null)
			{
				VtoGet3.Delete();
			}
			if (VtoGetBlip4 != null)
			{
				VtoGetBlip4.Remove();
			}
			if (VtoGetBlip5 != null)
			{
				VtoGetBlip5.Remove();
			}
			if (VtoGetBlip6 != null)
			{
				VtoGetBlip6.Remove();
			}
			if (VtoGetBlip7 != null)
			{
				VtoGetBlip7.Remove();
			}
			if (VtoGet4 != null)
			{
				VtoGet4.Delete();
			}
			if (VtoGet5 != null)
			{
				VtoGet5.Delete();
			}
			if (VtoGet6 != null)
			{
				VtoGet6.Delete();
			}
			if (VtoGet7 != null)
			{
				VtoGet7.Delete();
			}
			Vector3 position = new Vector3(2736f, -3892f, 140f);
			Vector3 position2 = new Vector3(2866f, -3892f, 140f);
			Vector3 position3 = new Vector3(2865f, -3707f, 140f);
			Vector3 position4 = new Vector3(2732f, -3707f, 140f);
			Model vehicle = getVehicle2();
			VtoGet = World.CreateVehicle(vehicle, position);
			VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
			SetupRivalCar(0, VtoGet);
			VtoGet.Rotation = new Vector3(0f, 0f, 0f);
			VtoGet1 = World.CreateVehicle(VehicleHash.TrailerSmall2, position);
			VtoGet1.AttachTo(VtoGet, 0);
			VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet1.PrimaryColor = VtoGet.PrimaryColor;
			VtoGet1.SecondaryColor = VtoGet.SecondaryColor;
			VtoGet1.SetMod(VehicleMod.Roof, 0, true);
			vehicle = getVehicle2();
			VtoGet2 = World.CreateVehicle(vehicle, position2);
			VtoGet2.CreateRandomPedOnSeat(VehicleSeat.Driver);
			SetupRivalCar(0, VtoGet2);
			VtoGet2.Rotation = new Vector3(0f, 0f, 0f);
			VtoGet3 = World.CreateVehicle(VehicleHash.TrailerSmall2, position2);
			VtoGet3.AttachTo(VtoGet2, 0);
			VtoGet3.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet3.PrimaryColor = VtoGet2.PrimaryColor;
			VtoGet3.SecondaryColor = VtoGet2.SecondaryColor;
			VtoGet3.SetMod(VehicleMod.Roof, 0, true);
			vehicle = getVehicle2();
			VtoGet4 = World.CreateVehicle(vehicle, position3);
			VtoGet4.CreateRandomPedOnSeat(VehicleSeat.Driver);
			SetupRivalCar(0, VtoGet4);
			VtoGet4.Rotation = new Vector3(0f, 0f, 180f);
			VtoGet5 = World.CreateVehicle(VehicleHash.TrailerSmall2, position3);
			VtoGet5.AttachTo(VtoGet4, 0);
			VtoGet5.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet5.PrimaryColor = VtoGet4.PrimaryColor;
			VtoGet5.SecondaryColor = VtoGet4.SecondaryColor;
			VtoGet5.SetMod(VehicleMod.Roof, 0, true);
			vehicle = getVehicle2();
			VtoGet6 = World.CreateVehicle(vehicle, position4);
			VtoGet6.CreateRandomPedOnSeat(VehicleSeat.Driver);
			SetupRivalCar(0, VtoGet6);
			VtoGet6.Rotation = new Vector3(0f, 0f, 180f);
			VtoGet7 = World.CreateVehicle(VehicleHash.TrailerSmall2, position4);
			VtoGet7.AttachTo(VtoGet6, 0);
			VtoGet7.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet7.PrimaryColor = VtoGet6.PrimaryColor;
			VtoGet7.SecondaryColor = VtoGet6.SecondaryColor;
			VtoGet7.SetMod(VehicleMod.Roof, 0, true);
			VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet2.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet3.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet4.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet5.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet6.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet7.GetPedOnSeat(VehicleSeat.Driver));
			Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet4.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet6.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			SetRoof(VtoGet1);
			VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			SetRoof(VtoGet3);
			VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet5.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			SetRoof(VtoGet5);
			VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.VehicleChase(Game.Player.Character);
			VtoGet7.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			SetRoof(VtoGet7);
			VtoGet1.GetPedOnSeat(VehicleSeat.Driver).IsInvincible = true;
			VtoGet3.GetPedOnSeat(VehicleSeat.Driver).IsInvincible = true;
			VtoGet5.GetPedOnSeat(VehicleSeat.Driver).IsInvincible = true;
			VtoGet7.GetPedOnSeat(VehicleSeat.Driver).IsInvincible = true;
			Script.Wait(100);
			VtoGetBlip4 = World.CreateBlip(VtoGet.Position);
			VtoGetBlip4.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip4, 8 });
			VtoGetBlip5 = World.CreateBlip(VtoGet2.Position);
			VtoGetBlip5.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip5, 8 });
			VtoGetBlip6 = World.CreateBlip(VtoGet4.Position);
			VtoGetBlip6.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip6, 8 });
			VtoGetBlip7 = World.CreateBlip(VtoGet6.Position);
			VtoGetBlip7.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip7, 8 });
		}

		public void SetupDeathMatchCars3()
		{
			if (VtoGetBlip4 != null)
			{
				VtoGetBlip4.Remove();
			}
			if (VtoGetBlip5 != null)
			{
				VtoGetBlip5.Remove();
			}
			if (VtoGetBlip6 != null)
			{
				VtoGetBlip6.Remove();
			}
			if (VtoGetBlip7 != null)
			{
				VtoGetBlip7.Remove();
			}
			if (VtoGet4 != null)
			{
				VtoGet4.Delete();
			}
			if (VtoGet5 != null)
			{
				VtoGet5.Delete();
			}
			if (VtoGet6 != null)
			{
				VtoGet6.Delete();
			}
			if (VtoGet7 != null)
			{
				VtoGet7.Delete();
			}
			Vector3 position = new Vector3(2736f, -3892f, 140f);
			Vector3 position2 = new Vector3(2866f, -3892f, 140f);
			Vector3 position3 = new Vector3(2865f, -3707f, 140f);
			Vector3 position4 = new Vector3(2732f, -3707f, 140f);
			Script.Wait(100);
			VtoGet4 = World.CreateVehicle(VehicleHash.Panto, position, 10f);
			VtoGet4.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet5 = World.CreateVehicle(VehicleHash.Panto, position2, 10f);
			VtoGet5.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet6 = World.CreateVehicle(VehicleHash.Panto, position3, 10f);
			VtoGet6.Rotation = new Vector3(0f, 0f, 180f);
			Script.Wait(100);
			VtoGet7 = World.CreateVehicle(VehicleHash.Panto, position4, 10f);
			VtoGet7.Rotation = new Vector3(0f, 0f, 180f);
			SetupRivalCar(0, VtoGet4);
			SetupRivalCar(0, VtoGet5);
			SetupRivalCar(0, VtoGet6);
			SetupRivalCar(0, VtoGet7);
			Script.Wait(100);
			VtoGet4.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet5.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet6.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet7.CreateRandomPedOnSeat(VehicleSeat.Driver);
			Script.Wait(50);
			Ped pedOnSeat = VtoGet4.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet5.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet6.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet7.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Script.Wait(50);
			VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
			VtoGet5.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
			VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
			VtoGet7.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
			Script.Wait(100);
			VtoGetBlip4 = World.CreateBlip(VtoGet4.Position);
			VtoGetBlip4.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip4, 8 });
			VtoGetBlip5 = World.CreateBlip(VtoGet5.Position);
			VtoGetBlip5.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip5, 8 });
			VtoGetBlip6 = World.CreateBlip(VtoGet6.Position);
			VtoGetBlip6.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip6, 8 });
			VtoGetBlip7 = World.CreateBlip(VtoGet7.Position);
			VtoGetBlip7.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip7, 8 });
			Peds.Add(VtoGet4.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet5.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet6.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet7.GetPedOnSeat(VehicleSeat.Driver));
		}

		public void SetupDeathMatchCars4()
		{
			if (VtoGetBlip != null)
			{
				VtoGetBlip.Remove();
			}
			if (VtoGetBlip1 != null)
			{
				VtoGetBlip1.Remove();
			}
			if (VtoGetBlip2 != null)
			{
				VtoGetBlip2.Remove();
			}
			if (VtoGetBlip3 != null)
			{
				VtoGetBlip3.Remove();
			}
			if (VtoGet != null)
			{
				VtoGet.Delete();
			}
			if (VtoGet1 != null)
			{
				VtoGet1.Delete();
			}
			if (VtoGet2 != null)
			{
				VtoGet2.Delete();
			}
			if (VtoGet3 != null)
			{
				VtoGet3.Delete();
			}
			Vector3 position = new Vector3(2736f, -3892f, 140f);
			Vector3 position2 = new Vector3(2866f, -3892f, 140f);
			Vector3 position3 = new Vector3(2865f, -3707f, 140f);
			Vector3 position4 = new Vector3(2732f, -3707f, 140f);
			Script.Wait(100);
			VtoGet = World.CreateVehicle("RCBandito", position, 10f);
			VtoGet.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet1 = World.CreateVehicle("RCBandito", position2, 10f);
			VtoGet1.Rotation = new Vector3(0f, 0f, 0f);
			Script.Wait(100);
			VtoGet2 = World.CreateVehicle("RCBandito", position3, 10f);
			VtoGet2.Rotation = new Vector3(0f, 0f, 180f);
			Script.Wait(100);
			VtoGet3 = World.CreateVehicle("RCBandito", position4, 10f);
			VtoGet3.Rotation = new Vector3(0f, 0f, 180f);
			SetupRivalCar(0, VtoGet);
			SetupRivalCar(0, VtoGet1);
			SetupRivalCar(0, VtoGet2);
			SetupRivalCar(0, VtoGet3);
			Script.Wait(50);
			Ped pedOnSeat = VtoGet.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
			Ped pedOnSeat2 = VtoGet1.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
			Ped pedOnSeat3 = VtoGet2.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
			Ped pedOnSeat4 = VtoGet3.GetPedOnSeat(VehicleSeat.Driver);
			Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
			Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
			Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
			Script.Wait(50);
			VtoGet.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet1.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet2.CreateRandomPedOnSeat(VehicleSeat.Driver);
			VtoGet3.CreateRandomPedOnSeat(VehicleSeat.Driver);
			Peds.Add(VtoGet.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet1.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet2.GetPedOnSeat(VehicleSeat.Driver));
			Peds.Add(VtoGet3.GetPedOnSeat(VehicleSeat.Driver));
			Script.Wait(100);
			VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			VtoGet3.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			VtoGet2.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(Game.Player.Character);
			Script.Wait(100);
			VtoGetBlip = World.CreateBlip(VtoGet.Position);
			VtoGetBlip.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip, 8 });
			VtoGetBlip1 = World.CreateBlip(VtoGet1.Position);
			VtoGetBlip1.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip1, 8 });
			VtoGetBlip2 = World.CreateBlip(VtoGet2.Position);
			VtoGetBlip2.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip2, 8 });
			VtoGetBlip3 = World.CreateBlip(VtoGet3.Position);
			VtoGetBlip3.Sprite = BlipSprite.GunCar;
			Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { VtoGetBlip3, 8 });
			VtoGet.EngineTorqueMultiplier = 3f;
			VtoGet.EnginePowerMultiplier = 3f;
			VtoGet1.EngineTorqueMultiplier = 3f;
			VtoGet1.EnginePowerMultiplier = 3f;
			VtoGet2.EngineTorqueMultiplier = 3f;
			VtoGet2.EnginePowerMultiplier = 3f;
			VtoGet3.EngineTorqueMultiplier = 3f;
			VtoGet3.EnginePowerMultiplier = 3f;
		}

		public void ChangeMIneLoc(Vector3 CheckPoint)
		{
			Script.Wait(1);
			if (MissionId == 1)
			{
				if (Race == 4)
				{
					Vector3 vector = RandomLocationFun2();
					Script.Wait(10);
					Vector3 vector2 = RandomLocationFun2();
					Script.Wait(10);
					Vector3 vector3 = RandomLocationFun2();
					Script.Wait(10);
					Vector3 vector4 = RandomLocationFun2();
					Script.Wait(10);
					Vector3 vector5 = RandomLocationFun2();
					Script.Wait(10);
					Vector3 vector6 = RandomLocationFun2();
					if (World.GetDistance(vector, CheckPoint) < 10f)
					{
						MineLoc1 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector, CheckPoint) > 10f)
					{
						MineLoc1 = vector;
					}
					if (World.GetDistance(vector2, CheckPoint) < 10f)
					{
						MineLoc2 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector2, CheckPoint) > 10f)
					{
						MineLoc2 = vector2;
					}
					if (World.GetDistance(vector3, CheckPoint) < 10f)
					{
						MineLoc3 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector3, CheckPoint) > 10f)
					{
						MineLoc3 = vector3;
					}
					if (World.GetDistance(vector4, CheckPoint) < 10f)
					{
						MineLoc4 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector4, CheckPoint) > 10f)
					{
						MineLoc4 = vector4;
					}
					if (World.GetDistance(vector5, CheckPoint) < 10f)
					{
						MineLoc5 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector5, CheckPoint) > 10f)
					{
						MineLoc5 = vector5;
					}
					if (World.GetDistance(vector6, CheckPoint) < 10f)
					{
						MineLoc6 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector6, CheckPoint) > 10f)
					{
						MineLoc6 = vector6;
					}
				}
				else if (Race == 6)
				{
					Vector3 vector7 = RandomLocationFun3();
					Script.Wait(10);
					Vector3 vector8 = RandomLocationFun3();
					Script.Wait(10);
					Vector3 vector9 = RandomLocationFun3();
					Script.Wait(10);
					Vector3 vector10 = RandomLocationFun3();
					Script.Wait(10);
					Vector3 vector11 = RandomLocationFun3();
					Script.Wait(10);
					Vector3 vector12 = RandomLocationFun3();
					if (World.GetDistance(vector7, CheckPoint) < 10f)
					{
						MineLoc1 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector7, CheckPoint) > 10f)
					{
						MineLoc1 = vector7;
					}
					if (World.GetDistance(vector8, CheckPoint) < 10f)
					{
						MineLoc2 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector8, CheckPoint) > 10f)
					{
						MineLoc2 = vector8;
					}
					if (World.GetDistance(vector9, CheckPoint) < 10f)
					{
						MineLoc3 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector9, CheckPoint) > 10f)
					{
						MineLoc3 = vector9;
					}
					if (World.GetDistance(vector10, CheckPoint) < 10f)
					{
						MineLoc4 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector10, CheckPoint) > 10f)
					{
						MineLoc4 = vector10;
					}
					if (World.GetDistance(vector11, CheckPoint) < 10f)
					{
						MineLoc5 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector11, CheckPoint) > 10f)
					{
						MineLoc5 = vector11;
					}
					if (World.GetDistance(vector12, CheckPoint) < 10f)
					{
						MineLoc6 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector12, CheckPoint) > 10f)
					{
						MineLoc6 = vector12;
					}
				}
				if (Race == 7)
				{
					Vector3 vector13 = RandomLocationFun4();
					Script.Wait(10);
					Vector3 vector14 = RandomLocationFun4();
					Script.Wait(10);
					Vector3 vector15 = RandomLocationFun4();
					Script.Wait(10);
					Vector3 vector16 = RandomLocationFun4();
					Script.Wait(10);
					Vector3 vector17 = RandomLocationFun4();
					Script.Wait(10);
					Vector3 vector18 = RandomLocationFun4();
					if (World.GetDistance(vector13, CheckPoint) < 10f)
					{
						MineLoc1 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector13, CheckPoint) > 10f)
					{
						MineLoc1 = vector13;
					}
					if (World.GetDistance(vector14, CheckPoint) < 10f)
					{
						MineLoc2 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector14, CheckPoint) > 10f)
					{
						MineLoc2 = vector14;
					}
					if (World.GetDistance(vector15, CheckPoint) < 10f)
					{
						MineLoc3 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector15, CheckPoint) > 10f)
					{
						MineLoc3 = vector15;
					}
					if (World.GetDistance(vector16, CheckPoint) < 10f)
					{
						MineLoc4 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector16, CheckPoint) > 10f)
					{
						MineLoc4 = vector16;
					}
					if (World.GetDistance(vector17, CheckPoint) < 10f)
					{
						MineLoc5 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector17, CheckPoint) > 10f)
					{
						MineLoc5 = vector17;
					}
					if (World.GetDistance(vector18, CheckPoint) < 10f)
					{
						MineLoc6 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector18, CheckPoint) > 10f)
					{
						MineLoc6 = vector18;
					}
				}
				if (Race == 8)
				{
					Vector3 vector19 = RandomLocationFun5();
					Script.Wait(10);
					Vector3 vector20 = RandomLocationFun5();
					Script.Wait(10);
					Vector3 vector21 = RandomLocationFun5();
					Script.Wait(10);
					Vector3 vector22 = RandomLocationFun5();
					Script.Wait(10);
					Vector3 vector23 = RandomLocationFun5();
					Script.Wait(10);
					Vector3 vector24 = RandomLocationFun5();
					if (World.GetDistance(vector19, CheckPoint) < 10f)
					{
						MineLoc1 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector19, CheckPoint) > 10f)
					{
						MineLoc1 = vector19;
					}
					if (World.GetDistance(vector20, CheckPoint) < 10f)
					{
						MineLoc2 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector20, CheckPoint) > 10f)
					{
						MineLoc2 = vector20;
					}
					if (World.GetDistance(vector21, CheckPoint) < 10f)
					{
						MineLoc3 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector21, CheckPoint) > 10f)
					{
						MineLoc3 = vector21;
					}
					if (World.GetDistance(vector22, CheckPoint) < 10f)
					{
						MineLoc4 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector22, CheckPoint) > 10f)
					{
						MineLoc4 = vector22;
					}
					if (World.GetDistance(vector23, CheckPoint) < 10f)
					{
						MineLoc5 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector23, CheckPoint) > 10f)
					{
						MineLoc5 = vector23;
					}
					if (World.GetDistance(vector24, CheckPoint) < 10f)
					{
						MineLoc6 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector24, CheckPoint) > 10f)
					{
						MineLoc6 = vector24;
					}
				}
				if (Race == 9)
				{
					Vector3 vector25 = RandomLocationFun6();
					Script.Wait(10);
					Vector3 vector26 = RandomLocationFun6();
					Script.Wait(10);
					Vector3 vector27 = RandomLocationFun6();
					Script.Wait(10);
					Vector3 vector28 = RandomLocationFun6();
					Script.Wait(10);
					Vector3 vector29 = RandomLocationFun6();
					Script.Wait(10);
					Vector3 vector30 = RandomLocationFun6();
					if (World.GetDistance(vector25, CheckPoint) < 10f)
					{
						MineLoc1 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector25, CheckPoint) > 10f)
					{
						MineLoc1 = vector25;
					}
					if (World.GetDistance(vector26, CheckPoint) < 10f)
					{
						MineLoc2 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector26, CheckPoint) > 10f)
					{
						MineLoc2 = vector26;
					}
					if (World.GetDistance(vector27, CheckPoint) < 10f)
					{
						MineLoc3 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector27, CheckPoint) > 10f)
					{
						MineLoc3 = vector27;
					}
					if (World.GetDistance(vector28, CheckPoint) < 10f)
					{
						MineLoc4 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector28, CheckPoint) > 10f)
					{
						MineLoc4 = vector28;
					}
					if (World.GetDistance(vector29, CheckPoint) < 10f)
					{
						MineLoc5 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector29, CheckPoint) > 10f)
					{
						MineLoc5 = vector29;
					}
					if (World.GetDistance(vector30, CheckPoint) < 10f)
					{
						MineLoc6 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector30, CheckPoint) > 10f)
					{
						MineLoc6 = vector30;
					}
				}
				if (Race == 10)
				{
					Vector3 vector31 = RandomLocationFun7();
					Script.Wait(10);
					Vector3 vector32 = RandomLocationFun7();
					Script.Wait(10);
					Vector3 vector33 = RandomLocationFun7();
					Script.Wait(10);
					Vector3 vector34 = RandomLocationFun7();
					Script.Wait(10);
					Vector3 vector35 = RandomLocationFun7();
					Script.Wait(10);
					Vector3 vector36 = RandomLocationFun7();
					if (World.GetDistance(vector31, CheckPoint) < 10f)
					{
						MineLoc1 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector31, CheckPoint) > 10f)
					{
						MineLoc1 = vector31;
					}
					if (World.GetDistance(vector32, CheckPoint) < 10f)
					{
						MineLoc2 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector32, CheckPoint) > 10f)
					{
						MineLoc2 = vector32;
					}
					if (World.GetDistance(vector33, CheckPoint) < 10f)
					{
						MineLoc3 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector33, CheckPoint) > 10f)
					{
						MineLoc3 = vector33;
					}
					if (World.GetDistance(vector34, CheckPoint) < 10f)
					{
						MineLoc4 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector34, CheckPoint) > 10f)
					{
						MineLoc4 = vector34;
					}
					if (World.GetDistance(vector35, CheckPoint) < 10f)
					{
						MineLoc5 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector35, CheckPoint) > 10f)
					{
						MineLoc5 = vector35;
					}
					if (World.GetDistance(vector36, CheckPoint) < 10f)
					{
						MineLoc6 = new Vector3(0f, 0f, 0f);
					}
					else if (World.GetDistance(vector36, CheckPoint) > 10f)
					{
						MineLoc6 = vector36;
					}
				}
			}
			if (MissionId != 2)
			{
				return;
			}
			if (Race == 2)
			{
				Vector3 vector37 = RandomLocationFun2();
				Script.Wait(10);
				Vector3 vector38 = RandomLocationFun2();
				Script.Wait(10);
				Vector3 vector39 = RandomLocationFun2();
				Script.Wait(10);
				Vector3 vector40 = RandomLocationFun2();
				Script.Wait(10);
				Vector3 vector41 = RandomLocationFun2();
				Script.Wait(10);
				Vector3 vector42 = RandomLocationFun2();
				if (World.GetDistance(vector37, CheckPoint) < 10f)
				{
					MineLoc1 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector37, CheckPoint) > 10f)
				{
					MineLoc1 = vector37;
				}
				if (World.GetDistance(vector38, CheckPoint) < 10f)
				{
					MineLoc2 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector38, CheckPoint) > 10f)
				{
					MineLoc2 = vector38;
				}
				if (World.GetDistance(vector39, CheckPoint) < 10f)
				{
					MineLoc3 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector39, CheckPoint) > 10f)
				{
					MineLoc3 = vector39;
				}
				if (World.GetDistance(vector40, CheckPoint) < 10f)
				{
					MineLoc4 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector40, CheckPoint) > 10f)
				{
					MineLoc4 = vector40;
				}
				if (World.GetDistance(vector41, CheckPoint) < 10f)
				{
					MineLoc5 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector41, CheckPoint) > 10f)
				{
					MineLoc5 = vector41;
				}
				if (World.GetDistance(vector42, CheckPoint) < 10f)
				{
					MineLoc6 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector42, CheckPoint) > 10f)
				{
					MineLoc6 = vector42;
				}
			}
			else if (Race == 1)
			{
				Vector3 vector43 = RandomLocationFun3();
				Script.Wait(10);
				Vector3 vector44 = RandomLocationFun3();
				Script.Wait(10);
				Vector3 vector45 = RandomLocationFun3();
				Script.Wait(10);
				Vector3 vector46 = RandomLocationFun3();
				Script.Wait(10);
				Vector3 vector47 = RandomLocationFun3();
				Script.Wait(10);
				Vector3 vector48 = RandomLocationFun3();
				if (World.GetDistance(vector43, CheckPoint) < 10f)
				{
					MineLoc1 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector43, CheckPoint) > 10f)
				{
					MineLoc1 = vector43;
				}
				if (World.GetDistance(vector44, CheckPoint) < 10f)
				{
					MineLoc2 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector44, CheckPoint) > 10f)
				{
					MineLoc2 = vector44;
				}
				if (World.GetDistance(vector45, CheckPoint) < 10f)
				{
					MineLoc3 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector45, CheckPoint) > 10f)
				{
					MineLoc3 = vector45;
				}
				if (World.GetDistance(vector46, CheckPoint) < 10f)
				{
					MineLoc4 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector46, CheckPoint) > 10f)
				{
					MineLoc4 = vector46;
				}
				if (World.GetDistance(vector47, CheckPoint) < 10f)
				{
					MineLoc5 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector47, CheckPoint) > 10f)
				{
					MineLoc5 = vector47;
				}
				if (World.GetDistance(vector48, CheckPoint) < 10f)
				{
					MineLoc6 = new Vector3(0f, 0f, 0f);
				}
				else if (World.GetDistance(vector48, CheckPoint) > 10f)
				{
					MineLoc6 = vector48;
				}
			}
		}

		public Ped ChooseTarget()
		{
			Ped closestPed = World.GetClosestPed(Game.Player.Character.Position, 1000f);
			if (closestPed != Game.Player.Character && closestPed != Friendlyped)
			{
				closestPed = World.GetClosestPed(Game.Player.Character.Position, 1000f);
			}
			return closestPed;
		}

		public void OnTick(object sender, EventArgs e)
		{
			if (World.GetDistance(Game.Player.Character.Position, SecondEntry) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, SecondEntry, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, SecondEntry) < 2f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to enter the Garage A");
			}
			if (Clique != null && Clique.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Italigto != null && Italigto.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Tulip != null && Tulip.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Vamos != null && Vamos.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Schlagen != null && Schlagen.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Deviant != null && Deviant.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Toros != null && Toros.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Italigto != null && Italigto.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Deveste != null && Deveste.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Cerberus != null && Cerberus.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (RcBandito != null && RcBandito.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Impaler != null && Impaler.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Issi != null && Issi.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Slamvan != null && Slamvan.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Dominator != null && Dominator.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Deathbike != null && Deathbike.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Imperator != null && Imperator.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Monster != null && Monster.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Scarab != null && Scarab.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Bruitus != null && Bruitus.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (ZR380 != null && ZR380.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			if (Bruiser != null && Bruiser.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
			}
			OnKeyDown();
			if (isInGarage || isinsecondVehicleBay || IsInInterior)
			{
				if (Game.Player.Character.CurrentVehicle != null)
				{
					LastVehicle = Game.Player.Character.CurrentVehicle;
					LastVehicle.IsDriveable = true;
					LastVehicle.FreezePosition = true;
					LastVehicle.HighBeamsOn = true;
				}
				if (Game.Player.Character.CurrentVehicle == null && LastVehicle != null)
				{
					LastVehicle.HighBeamsOn = false;
					LastVehicle.IsDriveable = false;
					LastVehicle.FreezePosition = false;
					LastVehicle = null;
				}
			}
			if (isinsecondVehicleBay && RcBandito != null)
			{
				if (RcBandito.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
				{
					RcBandito.FreezePosition = true;
				}
				else
				{
					RcBandito.FreezePosition = false;
				}
			}
			if (isInGarage && Game.Player.Character.CurrentVehicle != null)
			{
				Vehicle currentVehicle = Game.Player.Character.CurrentVehicle;
				if (Vehicle1 != null && currentVehicle == Vehicle1)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle2 != null && currentVehicle == Vehicle2)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle3 != null && currentVehicle == Vehicle3)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle4 != null && currentVehicle == Vehicle4)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle5 != null && currentVehicle == Vehicle5)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle6 != null && currentVehicle == Vehicle6)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle7 != null && currentVehicle == Vehicle7)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle8 != null && currentVehicle == Vehicle8)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle9 != null && currentVehicle == Vehicle9)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
				if (Vehicle10 != null && currentVehicle == Vehicle10)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to exit the garage, Press ~INPUT_COVER~  to save the vehicle");
				}
			}
			if (MissionSetup)
			{
				if (MissionId == 3)
				{
					if (CircuitRace)
					{
						if (World.GetDistance(VehicleA.Position, new Vector3(1005f, -72f, 81f)) < 60f && ACheck == 0)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1165f, 24f, 81f), 20f, 420f);
							ACheck = 1;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(1165f, 24f, 81f)) < 60f && ACheck == 1)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1253f, 267f, 82f), 20f, 420f);
							ACheck = 2;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(1253f, 267f, 82f)) < 60f && ACheck == 2)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1101f, 166f, 81f), 20f, 420f);
							ACheck = 3;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(1101f, 166f, 81f)) < 60f && ACheck == 3)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1005f, -72f, 81f), 20f, 420f);
							ACheck = 0;
							Alap++;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(1005f, -72f, 81f)) < 60f && BCheck == 0)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1165f, 24f, 81f), 20f, 420f);
							BCheck = 1;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(1165f, 24f, 81f)) < 60f && BCheck == 1)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1253f, 267f, 82f), 20f, 420f);
							BCheck = 2;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(1253f, 267f, 82f)) < 60f && BCheck == 2)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1101f, 166f, 81f), 20f, 420f);
							BCheck = 3;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(1101f, 166f, 81f)) < 60f && BCheck == 3)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1005f, -72f, 81f), 20f, 420f);
							BCheck = 0;
							Blap++;
						}
						if (World.GetDistance(VehicleC.Position, new Vector3(1005f, -72f, 81f)) < 60f && CCheck == 0)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1165f, 24f, 81f), 20f, 420f);
							CCheck = 1;
						}
						if (World.GetDistance(VehicleC.Position, new Vector3(1165f, 24f, 81f)) < 60f && CCheck == 1)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1253f, 267f, 82f), 20f, 420f);
							CCheck = 2;
						}
						if (World.GetDistance(VehicleC.Position, new Vector3(1253f, 267f, 82f)) < 60f && CCheck == 2)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1101f, 166f, 81f), 20f, 420f);
							CCheck = 3;
						}
						if (World.GetDistance(VehicleC.Position, new Vector3(1101f, 166f, 81f)) < 60f && CCheck == 3)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1005f, -72f, 81f), 20f, 420f);
							CCheck = 0;
							Clap++;
						}
					}
					if (CircuitRace2)
					{
						if (World.GetDistance(VehicleA.Position, new Vector3(2882f, -3877f, 140f)) < 60f && ACheck == 0)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(2883f, -3723f, 140f), 20f, 420f);
							ACheck = 1;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(2883f, -3723f, 140f)) < 60f && ACheck == 1)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(2721f, -3722f, 140f), 20f, 420f);
							ACheck = 2;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(2721f, -3722f, 140f)) < 60f && ACheck == 2)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(2800f, -3880f, 140f), 20f, 420f);
							ACheck = 3;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(2800f, -3880f, 140f)) < 60f && ACheck == 3)
						{
							VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(2882f, -3877f, 140f), 20f, 420f);
							ACheck = 0;
							Alap++;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(2882f, -3877f, 140f)) < 60f && ACheck == 0)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(2883f, -3723f, 140f), 20f, 420f);
							BCheck = 1;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(2883f, -3723f, 140f)) < 60f && ACheck == 1)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(2721f, -3722f, 140f), 20f, 420f);
							BCheck = 2;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(2721f, -3722f, 140f)) < 60f && ACheck == 2)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(2800f, -3880f, 140f), 20f, 420f);
							BCheck = 3;
						}
						if (World.GetDistance(VehicleB.Position, new Vector3(2800f, -3880f, 140f)) < 60f && ACheck == 3)
						{
							VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(2882f, -3877f, 140f), 20f, 420f);
							ACheck = 0;
							Blap++;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(2882f, -3877f, 140f)) < 60f && ACheck == 0)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(2883f, -3723f, 140f), 20f, 420f);
							CCheck = 1;
						}
						if (World.GetDistance(VehicleC.Position, new Vector3(2883f, -3723f, 140f)) < 60f && ACheck == 1)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(2721f, -3722f, 140f), 20f, 420f);
							CCheck = 2;
						}
						if (World.GetDistance(VehicleA.Position, new Vector3(2721f, -3722f, 140f)) < 60f && ACheck == 2)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(2800f, -3880f, 140f), 20f, 420f);
							CCheck = 3;
						}
						if (World.GetDistance(VehicleC.Position, new Vector3(2800f, -3880f, 140f)) < 60f && ACheck == 3)
						{
							VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(2882f, -3877f, 140f), 20f, 420f);
							ACheck = 0;
							Clap++;
						}
					}
					if (Race == 1)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, Racemarker2, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), MarkerColor);
						}
						if (StartedRace)
						{
						}
						if (World.GetDistance(Game.Player.Character.Position, Racemarker2) < 7f && !StartedRace)
						{
							if (RaceBlip != null)
							{
								RaceBlip.Remove();
							}
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								SetupRivalCar(0, Game.Player.Character.CurrentVehicle);
								if (VehicleA != null)
								{
									VehicleA.Delete();
								}
								if (VehicleB != null)
								{
									VehicleB.Delete();
								}
								if (VehicleC != null)
								{
									VehicleC.Delete();
								}
								Model vehicle = getVehicle();
								Script.Wait(100);
								Model vehicle2 = getVehicle();
								Script.Wait(100);
								Model vehicle3 = getVehicle();
								inRace = true;
								FinishedRace = false;
								UI.Notify("test1");
								Game.Player.Character.CurrentVehicle.Rotation = new Vector3(0f, 0f, -90f);
								Game.Player.Character.CurrentVehicle.FreezePosition = true;
								Vector3 position = new Vector3(2780f, -3886f, 140f);
								VehicleA = World.CreateVehicle(vehicle, new Vector3(2795f, -3886f, 140f), -90f);
								VehicleA.CreateRandomPedOnSeat(VehicleSeat.Driver);
								VehicleA.IsInvincible = true;
								Vector3 position2 = new Vector3(2796f, -3876f, 140f);
								VehicleB = World.CreateVehicle(vehicle2, new Vector3(2795f, -3886f, 140f), -90f);
								VehicleB.CreateRandomPedOnSeat(VehicleSeat.Driver);
								VehicleB.IsInvincible = true;
								Vector3 position3 = new Vector3(2780f, -3876f, 140f);
								VehicleC = World.CreateVehicle(vehicle3, new Vector3(2795f, -3886f, 140f), -90f);
								VehicleC.CreateRandomPedOnSeat(VehicleSeat.Driver);
								VehicleC.IsInvincible = true;
								UI.Notify("test2");
								Script.Wait(200);
								VehicleA.Position = position;
								VehicleB.Position = position2;
								VehicleC.Position = position3;
								VehicleA.IsInvincible = false;
								VehicleB.IsInvincible = false;
								VehicleC.IsInvincible = false;
								VehicleA.IsVisible = true;
								VehicleB.IsVisible = true;
								VehicleC.IsVisible = true;
								int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
								Function.Call(Hash._0x52923C4710DD9907, new InputArgument[2] { VehicleA, num });
								Function.Call(Hash._0x52923C4710DD9907, new InputArgument[2] { VehicleB, num });
								Function.Call(Hash._0x52923C4710DD9907, new InputArgument[2] { VehicleC, num });
								UpgradeVehicle2(VehicleA);
								UpgradeVehicle2(VehicleB);
								UpgradeVehicle2(VehicleC);
								Random random = new Random();
								Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { VehicleA.Handle, 0 });
								Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { VehicleB.Handle, 0 });
								Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { VehicleC.Handle, 0 });
								SetupRivalCar(0, VehicleA);
								SetupRivalCar(0, VehicleB);
								SetupRivalCar(0, VehicleC);
								UI.Notify("test3");
								Script.Wait(1000);
								UI.Notify("Ready!");
								Script.Wait(1000);
								UI.Notify("Set! ");
								Script.Wait(1000);
								UI.Notify("Go!");
								CircuitRace2 = true;
								VehicleA.Rotation = new Vector3(0f, 0f, 143f);
								VehicleB.Rotation = new Vector3(0f, 0f, 143f);
								VehicleC.Rotation = new Vector3(0f, 0f, 143f);
								Ped pedOnSeat = VehicleA.GetPedOnSeat(VehicleSeat.Driver);
								Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat, true });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
								Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat, 1 });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat, 17, 1 });
								Ped pedOnSeat2 = VehicleB.GetPedOnSeat(VehicleSeat.Driver);
								Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat2, true });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
								Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat2, 1 });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat2, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat2, 17, 1 });
								Ped pedOnSeat3 = VehicleC.GetPedOnSeat(VehicleSeat.Driver);
								Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat3, true });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
								Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat3, 1 });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat3, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat3, 17, 1 });
								VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1005f, -72f, 81f), 20f, 420f);
								VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1005f, -72f, 81f), 20f, 420f);
								VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1005f, -72f, 81f), 20f, 420f);
								UI.Notify("test4");
								ACheck = 0;
								BCheck = 0;
								CCheck = 0;
								Alap = 0;
								Blap = 0;
								Clap = 0;
								Game.Player.Character.CurrentVehicle.FreezePosition = false;
								UI.Notify("test5");
							}
						}
						if (inRace)
						{
							if (IsLeading)
							{
							}
							World.DrawMarker(MarkerType.VerticalCylinder, FinishLine, Vector3.Zero, Vector3.Zero, new Vector3(4f, 4f, 1f), MarkerColor);
							DisplayHelpTextThisFrame("Get to the finish line in first,  Lap " + lap + "/3");
							ChecktoSeeifinthelead();
							if (!FinishedRace)
							{
								if (checkpoint == 0)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2882f, -3877f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(2882f, -3877f, 140f)) < 20f)
									{
										checkpoint = 1;
									}
								}
								if (checkpoint == 1)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2883f, -3723f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(2883f, -3723f, 140f)) < 20f)
									{
										checkpoint = 2;
									}
								}
								if (checkpoint == 2)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2721f, -3722f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(2721f, -3722f, 140f)) < 20f)
									{
										checkpoint = 3;
									}
								}
								if (checkpoint == 3)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2800f, -3880f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(2800f, -3880f, 140f)) < 20f)
									{
										checkpoint = 0;
										lap++;
									}
								}
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2800f, -3880f, 140f)) < 10f && lap == 3)
								{
									if (IsLeading)
									{
										if (FinishLineBLip != null)
										{
											FinishLineBLip.Remove();
										}
										inRace = false;
										VehicleA.GetPedOnSeat(VehicleSeat.Driver).Delete();
										VehicleA.Delete();
										VehicleB.GetPedOnSeat(VehicleSeat.Driver).Delete();
										VehicleB.Delete();
										VehicleC.GetPedOnSeat(VehicleSeat.Driver).Delete();
										VehicleC.Delete();
										StartedRace = false;
										FinishedRace = true;
										Race = 0;
										MissionId = 0;
										Game.Player.Money += 450000;
										UI.Notify("Alan, I just head you smoked those fools!");
									}
									else if (!IsLeading)
									{
										if (Alap == 3 || Blap == 3 || Clap == 3)
										{
											if (FinishLineBLip != null)
											{
												FinishLineBLip.Remove();
											}
											inRace = false;
											VehicleA.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleA.Delete();
											VehicleB.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleB.Delete();
											VehicleC.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleC.Delete();
											StartedRace = false;
											FinishedRace = true;
											Race = 0;
											MissionId = 0;
											CircuitRace = false;
											UI.Notify("Alan : Dam!, we will have to replan our strategy!");
										}
										else
										{
											if (FinishLineBLip != null)
											{
												FinishLineBLip.Remove();
											}
											inRace = false;
											VehicleA.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleA.Delete();
											VehicleB.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleB.Delete();
											VehicleC.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleC.Delete();
											StartedRace = false;
											FinishedRace = true;
											Race = 0;
											MissionId = 0;
											CircuitRace = false;
											Game.Player.Money += 4500000;
											UI.Notify("Alan : Haha! that is what i am talking about, good job");
										}
									}
								}
							}
						}
					}
					if (Race == 5)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), MarkerColor);
						}
						if (StartedRace)
						{
						}
						if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
						{
							if (RaceBlip != null)
							{
								RaceBlip.Remove();
							}
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								SetupRivalCar(0, Game.Player.Character.CurrentVehicle);
								if (VehicleA != null)
								{
									VehicleA.Delete();
								}
								if (VehicleB != null)
								{
									VehicleB.Delete();
								}
								if (VehicleC != null)
								{
									VehicleC.Delete();
								}
								Model vehicle4 = getVehicle();
								Script.Wait(100);
								Model vehicle5 = getVehicle();
								Script.Wait(100);
								Model vehicle6 = getVehicle();
								inRace = true;
								FinishedRace = false;
								UI.Notify("test1");
								Game.Player.Character.CurrentVehicle.Rotation = new Vector3(0f, 0f, 148f);
								Game.Player.Character.CurrentVehicle.Position = new Vector3(1108f, 188f, 81f);
								Game.Player.Character.CurrentVehicle.FreezePosition = true;
								Vector3 position4 = new Vector3(1117f, 184f, 81f);
								VehicleA = World.CreateVehicle(vehicle4, position4, 148f);
								VehicleA.CreateRandomPedOnSeat(VehicleSeat.Driver);
								Vector3 position5 = new Vector3(1114f, 198f, 81f);
								VehicleB = World.CreateVehicle(vehicle5, position5, 148f);
								VehicleB.CreateRandomPedOnSeat(VehicleSeat.Driver);
								Vector3 position6 = new Vector3(1123f, 194f, 81f);
								VehicleC = World.CreateVehicle(vehicle6, position6, 148f);
								VehicleC.CreateRandomPedOnSeat(VehicleSeat.Driver);
								UI.Notify("test2");
								UpgradeVehicle2(VehicleA);
								UpgradeVehicle2(VehicleB);
								UpgradeVehicle2(VehicleC);
								Random random2 = new Random();
								Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { VehicleA.Handle, 0 });
								Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { VehicleB.Handle, 0 });
								Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { VehicleC.Handle, 0 });
								SetupRivalCar(0, VehicleA);
								SetupRivalCar(0, VehicleB);
								SetupRivalCar(0, VehicleC);
								UI.Notify("test3");
								Script.Wait(1000);
								UI.Notify("Ready!");
								Script.Wait(1000);
								UI.Notify("Set! ");
								Script.Wait(1000);
								UI.Notify("Go!");
								CircuitRace = true;
								VehicleA.Rotation = new Vector3(0f, 0f, 143f);
								VehicleB.Rotation = new Vector3(0f, 0f, 143f);
								VehicleC.Rotation = new Vector3(0f, 0f, 143f);
								Ped pedOnSeat4 = VehicleA.GetPedOnSeat(VehicleSeat.Driver);
								Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat4, true });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
								Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat4, 1 });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat4, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat4, 17, 1 });
								Ped pedOnSeat5 = VehicleB.GetPedOnSeat(VehicleSeat.Driver);
								Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat5, true });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat5, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat5, 17, 1 });
								Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat5, 1 });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat5, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat5, 17, 1 });
								Ped pedOnSeat6 = VehicleC.GetPedOnSeat(VehicleSeat.Driver);
								Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat6, true });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat6, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat6, 17, 1 });
								Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat6, 1 });
								Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat6, 0, 0 });
								Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat6, 17, 1 });
								VehicleA.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleA, new Vector3(1005f, -72f, 81f), 20f, 420f);
								VehicleB.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleB, new Vector3(1005f, -72f, 81f), 20f, 420f);
								VehicleC.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VehicleC, new Vector3(1005f, -72f, 81f), 20f, 420f);
								UI.Notify("test4");
								ACheck = 0;
								BCheck = 0;
								CCheck = 0;
								Alap = 0;
								Blap = 0;
								Clap = 0;
								Game.Player.Character.CurrentVehicle.FreezePosition = false;
								UI.Notify("test5");
							}
						}
						if (inRace)
						{
							if (IsLeading)
							{
							}
							World.DrawMarker(MarkerType.VerticalCylinder, FinishLine, Vector3.Zero, Vector3.Zero, new Vector3(4f, 4f, 1f), MarkerColor);
							DisplayHelpTextThisFrame("Get to the finish line in first,  Lap " + lap + "/3");
							ChecktoSeeifinthelead();
							if (!FinishedRace)
							{
								if (checkpoint == 0)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(1005f, -72f, 80f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(1005f, -72f, 80f)) < 20f)
									{
										checkpoint = 1;
									}
								}
								if (checkpoint == 1)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(1165f, 24f, 80f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(1165f, 24f, 80f)) < 20f)
									{
										checkpoint = 2;
									}
								}
								if (checkpoint == 2)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(1253f, 267f, 80f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(1253f, 267f, 80f)) < 20f)
									{
										checkpoint = 3;
									}
								}
								if (checkpoint == 3)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(1138f, 236f, 81f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
									if (World.GetDistance(Game.Player.Character.Position, new Vector3(1138f, 236f, 81f)) < 20f)
									{
										checkpoint = 0;
										lap++;
									}
								}
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(1138f, 236f, 81f)) < 10f && lap == 3)
								{
									if (IsLeading)
									{
										if (FinishLineBLip != null)
										{
											FinishLineBLip.Remove();
										}
										inRace = false;
										VehicleA.GetPedOnSeat(VehicleSeat.Driver).Delete();
										VehicleA.Delete();
										VehicleB.GetPedOnSeat(VehicleSeat.Driver).Delete();
										VehicleB.Delete();
										VehicleC.GetPedOnSeat(VehicleSeat.Driver).Delete();
										VehicleC.Delete();
										StartedRace = false;
										FinishedRace = true;
										Race = 0;
										MissionId = 0;
										Game.Player.Money += 450000;
										UI.Notify("Alan : Haha that is what i am talking about, good job");
									}
									else if (!IsLeading)
									{
										if (Alap == 3 || Blap == 3 || Clap == 3)
										{
											if (FinishLineBLip != null)
											{
												FinishLineBLip.Remove();
											}
											inRace = false;
											VehicleA.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleA.Delete();
											VehicleB.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleB.Delete();
											VehicleC.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleC.Delete();
											StartedRace = false;
											FinishedRace = true;
											Race = 0;
											MissionId = 0;
											CircuitRace = false;
											UI.Notify("Alan : Dam! we will have to replan out stratergy");
										}
										else
										{
											if (FinishLineBLip != null)
											{
												FinishLineBLip.Remove();
											}
											inRace = false;
											VehicleA.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleA.Delete();
											VehicleB.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleB.Delete();
											VehicleC.GetPedOnSeat(VehicleSeat.Driver).Delete();
											VehicleC.Delete();
											StartedRace = false;
											FinishedRace = true;
											Race = 0;
											MissionId = 0;
											CircuitRace = false;
											Game.Player.Money += 4500000;
											UI.Notify("Alan Haha that is what i am talking about ,good job");
										}
									}
								}
							}
						}
					}
				}
				if (MissionId == 10)
				{
					if (Race == 4)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle == null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle2 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle2);
									Game.Player.Character.CurrentVehicle.Explode();
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle2.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
								}
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded + ", Checkpoints reached : " + checkpointReaced);
							if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 10f)
							{
								Vector3 vector = (CheckPointPosition = RandomLocationFun2());
								ChangeMIneLoc(CheckPointPosition);
								UI.Notify("Alan : Check point reached!");
								moneytobeawarded += 12500f;
								checkpointReaced++;
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
								Random random3 = new Random();
								int num2 = random3.Next(3, 12);
								TimeLeft += num2;
							}
							if (TimeLeft != 0)
							{
								if (missiletimer != 45)
								{
									missiletimer++;
								}
								else if (missiletimer == 45)
								{
									missiletimer = 0;
									Firemissile();
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
								Vehicle currentVehicle3 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle3);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle3.Delete();
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								Vector3 vector2 = (CheckPointPosition = RandomLocationFun2());
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
							}
						}
					}
					if (Race == 6)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle4 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle4);
									Game.Player.Character.CurrentVehicle.Explode();
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle4.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
								UI.Notify("testaa2");
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded + ", Checkpoints reached : " + checkpointReaced);
							if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 10f)
							{
								Vector3 vector3 = (CheckPointPosition = RandomLocationFun3());
								UI.Notify("Alan : Check point reached!");
								moneytobeawarded += 15000f;
								checkpointReaced++;
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
								Random random4 = new Random();
								int num3 = random4.Next(3, 8);
								TimeLeft += num3;
								ChangeMIneLoc(CheckPointPosition);
							}
							if (TimeLeft != 0)
							{
								if (missiletimer != 45)
								{
									missiletimer++;
								}
								else if (missiletimer == 45)
								{
									missiletimer = 0;
									Firemissile();
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
								Vehicle currentVehicle5 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle5);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle5.Delete();
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								Vector3 vector4 = (CheckPointPosition = RandomLocationFun3());
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
							}
						}
					}
					if (Race == 7)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle6 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle6);
									Game.Player.Character.CurrentVehicle.Explode();
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle6.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded + ", Checkpoints reached : " + checkpointReaced);
							if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 10f)
							{
								Vector3 vector5 = (CheckPointPosition = RandomLocationFun4());
								UI.Notify("Alan : Check point reached!");
								moneytobeawarded += 18000f;
								checkpointReaced++;
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
								Random random5 = new Random();
								int num4 = random5.Next(3, 12);
								TimeLeft += num4;
								ChangeMIneLoc(CheckPointPosition);
							}
							if (TimeLeft != 0)
							{
								if (missiletimer != 45)
								{
									missiletimer++;
								}
								else if (missiletimer == 45)
								{
									missiletimer = 0;
									Firemissile();
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
								Vehicle currentVehicle7 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle7);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle7.Delete();
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Game.Player.Character.CurrentVehicle.Explode();
									Script.Wait(500);
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle8 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle8);
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle8.Delete();
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								Vector3 vector6 = (CheckPointPosition = RandomLocationFun4());
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
							}
						}
					}
					if (Race == 8)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle9 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle9);
									Game.Player.Character.CurrentVehicle.Explode();
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle9.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded + ", Checkpoints reached : " + checkpointReaced);
							if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 10f)
							{
								Vector3 vector7 = (CheckPointPosition = RandomLocationFun5());
								UI.Notify("Alan : Check point reached!");
								moneytobeawarded += 16500f;
								checkpointReaced++;
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
								Random random6 = new Random();
								int num5 = random6.Next(5, 14);
								TimeLeft += num5;
								ChangeMIneLoc(CheckPointPosition);
							}
							if (TimeLeft != 0)
							{
								if (missiletimer != 45)
								{
									missiletimer++;
								}
								else if (missiletimer == 45)
								{
									missiletimer = 0;
									Firemissile();
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
								Vehicle currentVehicle10 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle10);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle10.Delete();
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Game.Player.Character.CurrentVehicle.Explode();
									Script.Wait(500);
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle11 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle11);
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle11.Delete();
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								Vector3 vector8 = (CheckPointPosition = RandomLocationFun4());
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
							}
						}
					}
					if (Race == 9)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle12 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle12);
									Game.Player.Character.CurrentVehicle.Explode();
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle12.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded + ", Checkpoints reached : " + checkpointReaced);
							if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 10f)
							{
								Vector3 vector9 = (CheckPointPosition = RandomLocationFun6());
								UI.Notify("Alan : Check point reached!");
								moneytobeawarded += 18500f;
								checkpointReaced++;
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
								Random random7 = new Random();
								int num6 = random7.Next(4, 10);
								TimeLeft += num6;
								ChangeMIneLoc(CheckPointPosition);
							}
							if (TimeLeft != 0)
							{
								if (missiletimer != 45)
								{
									missiletimer++;
								}
								else if (missiletimer == 45)
								{
									missiletimer = 0;
									Firemissile();
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
								Vehicle currentVehicle13 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle13);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle13.Delete();
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Game.Player.Character.CurrentVehicle.Explode();
									Script.Wait(500);
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle14 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle14);
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle14.Delete();
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								Vector3 vector10 = (CheckPointPosition = RandomLocationFun4());
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
							}
						}
					}
					if (Race == 10)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle15 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle15);
									currentVehicle15.Explode();
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle15.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded + ", Checkpoints reached : " + checkpointReaced);
							if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 10f)
							{
								Vector3 vector11 = (CheckPointPosition = RandomLocationFun7());
								UI.Notify("Alan : Check point reached!");
								moneytobeawarded += 20500f;
								checkpointReaced++;
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
								Random random8 = new Random();
								int num7 = random8.Next(4, 8);
								TimeLeft += num7;
								ChangeMIneLoc(CheckPointPosition);
							}
							if (TimeLeft != 0)
							{
								if (missiletimer != 45)
								{
									missiletimer++;
								}
								else if (missiletimer == 45)
								{
									missiletimer = 0;
									Firemissile();
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
								Vehicle currentVehicle16 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle16);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle16.Delete();
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Game.Player.Character.CurrentVehicle.Explode();
									Script.Wait(500);
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									UI.Notify("Alan : Good Job , you passed through " + checkpointReaced + " checkpoints and earned : $" + moneytobeawarded);
									Vehicle currentVehicle17 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle17);
									Game.Player.Character.IsInvincible = false;
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle17.Delete();
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								Vector3 vector12 = (CheckPointPosition = RandomLocationFun4());
								VtoGetBlip.Name = "Checkpoint";
								VtoGetBlip.Sprite = BlipSprite.RaceFinish;
								VtoGetBlip.Color = BlipColor.White;
								VtoGetBlip.Position = CheckPointPosition;
								VtoGetBlip.Name = "Checkpoint";
							}
						}
					}
				}
				if (MissionId == 2)
				{
					foreach (Ped ped4 in Peds)
					{
						if (ped4 != null && ped4.CurrentVehicle == null)
						{
							Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped4, 1198256469, 999999, true, true });
							if (!ped4.IsShooting)
							{
								ped4.Task.FightAgainst(Game.Player.Character);
							}
						}
					}
					if (Race == 1)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (VtoGet != null && VtoGetBlip != null)
							{
								VtoGetBlip.Position = VtoGet.Position;
							}
							if (VtoGet1 != null && VtoGetBlip1 != null)
							{
								VtoGetBlip1.Position = VtoGet1.Position;
							}
							if (VtoGet2 != null && VtoGetBlip2 != null)
							{
								VtoGetBlip2.Position = VtoGet2.Position;
							}
							if (VtoGet3 != null && VtoGetBlip3 != null)
							{
								VtoGetBlip3.Position = VtoGet3.Position;
							}
							if (VtoGet != null && VtoGet != null && VtoGet2 != null && VtoGet3 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive)
							{
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								vehicleHealth += 100;
								SetupDeathMatchCars();
								checkpointReaced++;
								moneytobeawarded += 100000f;
								foreach (Ped ped5 in Peds)
								{
									if (ped5 != null && ped5.CurrentVehicle == null)
									{
										ped5.Delete();
									}
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (VtoGetBlip1 != null)
									{
										VtoGetBlip1.Remove();
									}
									if (VtoGetBlip2 != null)
									{
										VtoGetBlip2.Remove();
									}
									if (VtoGetBlip3 != null)
									{
										VtoGetBlip3.Remove();
									}
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGet1 != null)
									{
										VtoGet1.Delete();
									}
									if (VtoGet2 != null)
									{
										VtoGet2.Delete();
									}
									if (VtoGet3 != null)
									{
										VtoGet3.Delete();
									}
									UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
									Vehicle currentVehicle18 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle18);
									currentVehicle18.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle18.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
									foreach (Ped ped6 in Peds)
									{
										if (ped6 != null && ped6.CurrentVehicle == null)
										{
											ped6.Delete();
										}
									}
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								UI.Notify("Mission Complete");
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped7 in Peds)
								{
									if (ped7 != null && ped7.CurrentVehicle == null)
									{
										ped7.Delete();
									}
								}
							}
							DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
							if (UseMIssilesInVDM)
							{
								if (missiletimer != 150)
								{
									missiletimer++;
								}
								else if (missiletimer == 150)
								{
									missiletimer = 0;
									Firemissile4_1();
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								SetupDeathMatchCars();
								checkpointReaced = 1;
							}
						}
					}
				}
				if (MissionId == 4)
				{
					if (Race == 1)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2731f, -3882f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								MissionId = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 7f), Color.Red);
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded);
							if (TimeLeft != 0)
							{
								if (Game.Player.Character.CurrentVehicle.IsInAir)
								{
									moneytobeawarded += 1000f;
								}
								if (Game.Player.Character.CurrentVehicle.IsUpsideDown)
								{
									moneytobeawarded += 1000f;
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								MissionId = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job ,you earned : $" + moneytobeawarded);
								Vehicle currentVehicle19 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle19);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle19.Delete();
							}
							if (!(Game.Player.Character.CurrentVehicle != null))
							{
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(2731f, -3882f, 140f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (!(Game.Player.Character.CurrentVehicle != null))
							{
							}
						}
					}
					if (Race == 2)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(-888f, -802f, 14f), Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								MissionId = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job , you earned : $" + moneytobeawarded + ", you abandoned your vehicle ");
								Game.Player.Character.IsInvincible = false;
							}
							DisplayHelpTextThisFrame("Time Left : " + TimeLeft + ", Money Earned $" + moneytobeawarded);
							if (TimeLeft != 0)
							{
								if (Game.Player.Character.CurrentVehicle.IsInAir)
								{
									moneytobeawarded += 1000f;
								}
								if (Game.Player.Character.CurrentVehicle.IsUpsideDown)
								{
									moneytobeawarded += 1000f;
								}
								if (timer != 24)
								{
									timer++;
								}
								else if (timer == 24)
								{
									timer = 0;
									TimeLeft--;
								}
							}
							else if (TimeLeft <= 0 && Game.Player.Character.CurrentVehicle != null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								MissionId = 0;
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								UI.Notify("Alan : Good Job ,you earned : $" + moneytobeawarded);
								Vehicle currentVehicle20 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle20);
								Game.Player.Character.CurrentVehicle.Explode();
								Game.Player.Character.IsInvincible = false;
								Game.Player.Character.Position = new Vector3(-888f, -802f, 14f);
								currentVehicle20.Delete();
							}
							if (!(Game.Player.Character.CurrentVehicle != null))
							{
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, new Vector3(-888f, -802f, 14f)) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (!(Game.Player.Character.CurrentVehicle != null))
							{
							}
						}
					}
				}
				if (MissionId == 5)
				{
					if (VtoGet != null && VtoGet.GetPedOnSeat(VehicleSeat.Driver) == null)
					{
						VtoGet.Explode();
						UI.Notify("Vehilce A has been Eliminated for no driver");
					}
					if (VtoGet1 != null && VtoGet1.GetPedOnSeat(VehicleSeat.Driver) == null)
					{
						VtoGet1.Explode();
						UI.Notify("Vehilce B has been Eliminated for no driver");
					}
					if (VtoGet2 != null && VtoGet2.GetPedOnSeat(VehicleSeat.Driver) == null)
					{
						VtoGet2.Explode();
						UI.Notify("Vehilce B has been Eliminated for no driver");
					}
					if (VtoGet3 != null && VtoGet3.GetPedOnSeat(VehicleSeat.Driver) == null)
					{
						VtoGet3.Explode();
						UI.Notify("Vehilce B has been Eliminated for no driver");
					}
					foreach (Ped ped8 in Peds)
					{
						if (ped8 != null && ped8.CurrentVehicle == null)
						{
							Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped8, 1198256469, 999999, true, true });
							ped8.Task.FightAgainst(Game.Player.Character);
						}
					}
					if (Race == 1)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (VtoGet != null && VtoGetBlip != null)
							{
								VtoGetBlip.Position = VtoGet.Position;
							}
							if (VtoGet1 != null && VtoGetBlip1 != null)
							{
								VtoGetBlip1.Position = VtoGet1.Position;
							}
							if (VtoGet2 != null && VtoGetBlip2 != null)
							{
								VtoGetBlip2.Position = VtoGet2.Position;
							}
							if (VtoGet3 != null && VtoGetBlip3 != null)
							{
								VtoGetBlip3.Position = VtoGet3.Position;
							}
							if (VtoGet4 != null && VtoGetBlip4 != null)
							{
								VtoGetBlip4.Position = VtoGet4.Position;
							}
							if (VtoGet5 != null && VtoGetBlip5 != null)
							{
								VtoGetBlip5.Position = VtoGet5.Position;
							}
							if (VtoGet6 != null && VtoGetBlip6 != null)
							{
								VtoGetBlip6.Position = VtoGet6.Position;
							}
							if (VtoGet7 != null && VtoGetBlip7 != null)
							{
								VtoGetBlip7.Position = VtoGet7.Position;
							}
							if (VtoGet != null && VtoGet1 != null && VtoGet2 != null && VtoGet3 != null && VtoGet4 != null && VtoGet5 != null && VtoGet6 != null && VtoGet7 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive && !VtoGet4.IsAlive && !VtoGet5.IsAlive && !VtoGet6.IsAlive && !VtoGet7.IsAlive)
							{
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								vehicleHealth += 100;
								SetupDeathMatchCars();
								Script.Wait(3000);
								SetupDeathMatchCars2();
								checkpointReaced++;
								moneytobeawarded += 200000f;
								foreach (Ped ped9 in Peds)
								{
									if (ped9 != null && ped9.CurrentVehicle == null)
									{
										ped9.Delete();
									}
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGet1 != null)
									{
										VtoGet1.Delete();
									}
									if (VtoGet2 != null)
									{
										VtoGet2.Delete();
									}
									if (VtoGet3 != null)
									{
										VtoGet3.Delete();
									}
									if (VtoGet4 != null)
									{
										VtoGet4.Delete();
									}
									if (VtoGet5 != null)
									{
										VtoGet5.Delete();
									}
									if (VtoGet6 != null)
									{
										VtoGet6.Delete();
									}
									if (VtoGet7 != null)
									{
										VtoGet7.Delete();
									}
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (VtoGetBlip1 != null)
									{
										VtoGetBlip1.Remove();
									}
									if (VtoGetBlip2 != null)
									{
										VtoGetBlip2.Remove();
									}
									if (VtoGetBlip3 != null)
									{
										VtoGetBlip3.Remove();
									}
									if (VtoGetBlip4 != null)
									{
										VtoGetBlip4.Remove();
									}
									if (VtoGetBlip5 != null)
									{
										VtoGetBlip5.Remove();
									}
									if (VtoGetBlip6 != null)
									{
										VtoGetBlip6.Remove();
									}
									if (VtoGetBlip7 != null)
									{
										VtoGetBlip7.Remove();
									}
									UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
									Vehicle currentVehicle21 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle21);
									currentVehicle21.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle21.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
									foreach (Ped ped10 in Peds)
									{
										if (ped10 != null && ped10.CurrentVehicle == null)
										{
											ped10.Delete();
										}
									}
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								UI.Notify("Mission Complete");
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped11 in Peds)
								{
									if (ped11 != null && ped11.CurrentVehicle == null)
									{
										ped11.Delete();
									}
								}
							}
							DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
							if (UseMIssilesInVDM)
							{
								if (missiletimer != 190)
								{
									missiletimer++;
								}
								else if (missiletimer == 190)
								{
									missiletimer = 0;
									Firemissile4_1();
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								SetupDeathMatchCars();
								Script.Wait(3000);
								SetupDeathMatchCars2();
								checkpointReaced = 1;
							}
						}
					}
				}
				if (MissionId == 6 && Race == 1 && VtoGet != null && VtoGet1 != null && VtoGet2 != null)
				{
					if (World.GetDistance(Game.Player.Character.Position, new Vector3(-2040f, -456f, 11f)) < 40f && !SetupPed)
					{
						foreach (Ped ped12 in Peds)
						{
							if (!(ped12 != null))
							{
								continue;
							}
							Ped ped = ped12;
							Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { ped, true });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { ped, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { ped, 17, 1 });
							Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { ped, 1 });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { ped, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { ped, 17, 1 });
							ped12.Weapons.Give(WeaponHash.SMG, 999, true, true);
							ped12.Task.FightAgainst(Game.Player.Character);
							if (!SetupPed)
							{
								if (PedsCounted <= 11)
								{
									SetupPed = true;
								}
								else
								{
									PedsCounted++;
								}
							}
						}
						if (SetupPed)
						{
							foreach (Ped ped13 in Peds)
							{
								if (ped13 != null)
								{
									ped13.Weapons.Give(WeaponHash.SMG, 9999, true, true);
									ped13.Task.FightAgainst(Game.Player.Character);
								}
							}
						}
					}
					if (!VtoGet.IsAlive && !VtoGet1.IsAlive && !VtoGet2.IsAlive)
					{
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet1 != null)
						{
							VtoGet1.Delete();
						}
						if (VtoGet2 != null)
						{
							VtoGet2.Delete();
						}
						if (VtoGet3 != null)
						{
							VtoGet3.Delete();
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						if (VtoGetBlip1 != null)
						{
							VtoGetBlip1.Remove();
						}
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
						UI.Notify("Alan : ok good enemy vehicle Destroyed ");
						UI.Notify("Alan : Stocks just Increased");
						UI.Notify("Max Stocks: " + maxstocks);
						UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
						UI.Notify("Mission Gain: " + profitMargin + "%");
						UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
						MissionSetup = false;
						Missionnum = 0;
						Race = 0;
						MissionScreen missionScreen = new MissionScreen();
						missionScreen.SetPass("The Rookie", 540000, "The Player has died");
						stocksvalue = stocksvalue + 150000f + 100000f * profitMargin / 100f;
						foreach (Ped ped14 in Peds)
						{
							if (ped14 != null && ped14.CurrentVehicle == null)
							{
								ped14.Delete();
							}
						}
					}
					else if (!Game.Player.Character.IsAlive)
					{
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet1 != null)
						{
							VtoGet1.Delete();
						}
						if (VtoGet2 != null)
						{
							VtoGet2.Delete();
						}
						if (VtoGet3 != null)
						{
							VtoGet3.Delete();
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						if (VtoGetBlip1 != null)
						{
							VtoGetBlip1.Remove();
						}
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
						MissionScreen missionScreen2 = new MissionScreen();
						missionScreen2.SetFail("The Rookie", 1400000, "The Player has died");
						UI.Notify("Alan :you died, the contestants have escaped ");
						MissionSetup = false;
						Missionnum = 0;
						Race = 0;
						foreach (Ped ped15 in Peds)
						{
							if (ped15 != null && ped15.CurrentVehicle == null)
							{
								ped15.Delete();
							}
						}
					}
				}
				if (MissionId == 7 && Race == 1)
				{
					if (!VtoGet.IsAlive)
					{
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
					}
					else
					{
						VtoGetBlip.Position = VtoGet.Position;
					}
					if (!VtoGet3.IsAlive)
					{
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
					}
					else
					{
						VtoGetBlip3.Position = VtoGet3.Position;
					}
					if (!VtoGet2.IsAlive)
					{
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
					}
					else
					{
						VtoGetBlip2.Position = VtoGet2.Position;
					}
					if (!VtoGet.IsAlive && !VtoGet3.IsAlive && !VtoGet2.IsAlive)
					{
						Game.FadeScreenOut(500);
						Script.Wait(500);
						EndPointBlip.Remove();
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet2 != null)
						{
							VtoGet2.Delete();
						}
						if (VtoGet3 != null)
						{
							VtoGet3.Delete();
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
						Script.Wait(500);
						Game.FadeScreenIn(500);
						UI.Notify("Alan : ok good enemy vehicle Destroyed ");
						UI.Notify("Alan : Stocks just Increased");
						UI.Notify("Max Stocks: " + maxstocks);
						UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
						UI.Notify("Mission Gain: " + profitMargin + "%");
						UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
						MissionSetup = false;
						Missionnum = 0;
						MissionScreen missionScreen3 = new MissionScreen();
						missionScreen3.SetPass("The Oil Fued Mission", 1450000, "");
						stocksvalue = stocksvalue + 1500000f + 1000000f * profitMargin / 100f;
						Config.SetValue("Setup", "StocksValue", stocksvalue);
						Config.Save();
					}
					if (World.GetDistance(VtoGet.Position, EndPointPos) < 20f || World.GetDistance(VtoGet3.Position, EndPointPos) < 20f || World.GetDistance(VtoGet2.Position, EndPointPos) < 20f)
					{
						Game.FadeScreenOut(500);
						Script.Wait(500);
						EndPointBlip.Remove();
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet2 != null)
						{
							VtoGet2.Delete();
						}
						if (VtoGet3 != null)
						{
							VtoGet3.Delete();
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
						Script.Wait(500);
						Game.FadeScreenIn(500);
						UI.Notify("Alan : Boss a vehicle Reached the destination!, We cannot afford to have other contestants with fuel!");
						MissionScreen missionScreen4 = new MissionScreen();
						missionScreen4.SetFail("The Oil Fued Mission", 1450000, "A vehicle Reached the destination!");
						MissionSetup = false;
						Missionnum = 0;
						Config.SetValue("Setup", "StocksValue", stocksvalue);
						Config.Save();
					}
				}
				if (MissionId == 11 && Race == 1)
				{
					if (VtoGet4 != null && VtoGetBlip4 != null)
					{
						if (!VtoGet4.IsAlive)
						{
							VtoGetBlip4.Remove();
						}
						else
						{
							VtoGetBlip4.Position = VtoGet4.Position;
						}
					}
					if (VtoGet5 != null && VtoGetBlip5 != null)
					{
						if (!VtoGet5.IsAlive)
						{
							VtoGetBlip5.Remove();
						}
						else
						{
							VtoGetBlip5.Position = VtoGet5.Position;
						}
					}
					if (VtoGet6 != null && VtoGetBlip6 != null)
					{
						if (!VtoGet6.IsAlive)
						{
							VtoGetBlip6.Remove();
						}
						else
						{
							VtoGetBlip6.Position = VtoGet6.Position;
						}
					}
					if (VtoGet != null && VtoGet4 != null)
					{
						if (World.GetDistance(Game.Player.Character.Position, VtoGet.Position) < 1300f)
						{
							VtoGet.IsInvincible = false;
							VtoGet4.IsInvincible = false;
							VtoGet.IsVisible = true;
							VtoGet4.IsVisible = true;
						}
						if (World.GetDistance(Game.Player.Character.Position, VtoGet4.Position) < 300f && !DropedVehicleA)
						{
							DropedVehicleA = true;
							VtoGet4.Detach();
							Peds.Add(VtoGet4.CreateRandomPedOnSeat(VehicleSeat.Driver));
							Ped pedOnSeat7 = VtoGet4.GetPedOnSeat(VehicleSeat.Driver);
							Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat7, true });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat7, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat7, 17, 1 });
							Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat7, 1 });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat7, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat7, 17, 1 });
							VtoGet4.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet4, EndPointPos, 20f, 120f, 1);
							VtoGetBlip4 = World.CreateBlip(VtoGet5.Position);
							VtoGetBlip4.Sprite = BlipSprite.GunCar;
							VtoGetBlip4.Name = "Destroy Scarab";
							UI.Notify("A Scarab has been dropped! Destroy it before it gets to the Drop Point ");
						}
					}
					if (VtoGet3 != null && VtoGet5 != null)
					{
						if (World.GetDistance(Game.Player.Character.Position, VtoGet3.Position) < 1300f)
						{
							VtoGet3.IsInvincible = false;
							VtoGet5.IsInvincible = false;
							VtoGet3.IsVisible = true;
							VtoGet5.IsVisible = true;
						}
						if (World.GetDistance(Game.Player.Character.Position, VtoGet5.Position) < 300f && !DropedVehicleB)
						{
							DropedVehicleB = true;
							VtoGet5.Detach();
							Peds.Add(VtoGet5.CreateRandomPedOnSeat(VehicleSeat.Driver));
							Ped pedOnSeat8 = VtoGet5.GetPedOnSeat(VehicleSeat.Driver);
							Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat8, true });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat8, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat8, 17, 1 });
							Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat8, 1 });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat8, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat8, 17, 1 });
							VtoGet5.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet5, EndPointPos, 20f, 120f, 1);
							VtoGetBlip5 = World.CreateBlip(VtoGet5.Position);
							VtoGetBlip5.Sprite = BlipSprite.GunCar;
							VtoGetBlip5.Name = "Destroy Scarab";
							UI.Notify("A Scarab has been dropped! Destroy it before it gets to the Drop Point ");
						}
					}
					if (VtoGet2 != null && VtoGet6 != null)
					{
						if (World.GetDistance(Game.Player.Character.Position, VtoGet2.Position) < 1300f)
						{
							VtoGet2.IsInvincible = false;
							VtoGet6.IsInvincible = false;
							VtoGet2.IsVisible = true;
							VtoGet6.IsVisible = true;
						}
						if (World.GetDistance(Game.Player.Character.Position, VtoGet6.Position) < 300f && !DropedVehicleC)
						{
							DropedVehicleC = true;
							VtoGet6.Detach();
							Peds.Add(VtoGet6.CreateRandomPedOnSeat(VehicleSeat.Driver));
							Ped pedOnSeat9 = VtoGet6.GetPedOnSeat(VehicleSeat.Driver);
							Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat9, true });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat9, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat9, 17, 1 });
							Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat9, 1 });
							Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat9, 0, 0 });
							Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat9, 17, 1 });
							VtoGet6.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet6, EndPointPos, 20f, 120f, 1);
							VtoGetBlip6 = World.CreateBlip(VtoGet6.Position);
							VtoGetBlip6.Sprite = BlipSprite.GunCar;
							VtoGetBlip6.Name = "Destroy Scarab";
							UI.Notify("A Scarab has been dropped! Destroy it before it gets to the Drop Point ");
						}
					}
					if (Timer2 != 60)
					{
						Timer2++;
					}
					if (Timer2 == 60)
					{
						Timer2 = 0;
					}
					if (!VtoGet.IsAlive)
					{
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
					}
					else if (Timer2 >= 30)
					{
						VtoGetBlip.Position = VtoGet.Position;
					}
					if (!VtoGet3.IsAlive)
					{
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
					}
					else if (Timer2 >= 30)
					{
						VtoGetBlip3.Position = VtoGet3.Position;
					}
					if (!VtoGet2.IsAlive)
					{
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
					}
					else if (Timer2 >= 30)
					{
						VtoGetBlip2.Position = VtoGet2.Position;
					}
					if (!VtoGet.IsAlive && !VtoGet3.IsAlive && !VtoGet2.IsAlive && !VtoGet4.IsAlive && !VtoGet5.IsAlive && !VtoGet6.IsAlive)
					{
						Game.FadeScreenOut(500);
						Script.Wait(500);
						EndPointBlip.Remove();
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet2 != null)
						{
							VtoGet2.Delete();
						}
						if (VtoGet3 != null)
						{
							VtoGet3.Delete();
						}
						if (VtoGet4 != null)
						{
							VtoGet4.Delete();
						}
						if (VtoGet5 != null)
						{
							VtoGet5.Delete();
						}
						if (VtoGet6 != null)
						{
							VtoGet6.Delete();
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
						foreach (Ped ped16 in Peds)
						{
							if (ped16 != null)
							{
								ped16.Delete();
							}
						}
						Script.Wait(500);
						Game.FadeScreenIn(500);
						UI.Notify("Alan : ok good enemy vehicle Destroyed ");
						UI.Notify("Alan : Stocks just Increased");
						UI.Notify("Max Stocks: " + maxstocks);
						UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
						UI.Notify("Mission Gain: " + profitMargin + "%");
						UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
						MissionSetup = false;
						Missionnum = 0;
						MissionScreen missionScreen5 = new MissionScreen();
						missionScreen5.SetPass("The Air Tanker Mission", 1450000, "");
						stocksvalue = stocksvalue + 1500000f + 1000000f * profitMargin / 100f;
						Config.SetValue("Setup", "StocksValue", stocksvalue);
						Config.Save();
					}
					if (World.GetDistance(VtoGet.Position, EndPointPos) < 20f || World.GetDistance(VtoGet3.Position, EndPointPos) < 20f || World.GetDistance(VtoGet2.Position, EndPointPos) < 20f || World.GetDistance(VtoGet4.Position, EndPointPos) < 20f || World.GetDistance(VtoGet5.Position, EndPointPos) < 20f || World.GetDistance(VtoGet6.Position, EndPointPos) < 20f)
					{
						Game.FadeScreenOut(500);
						Script.Wait(500);
						EndPointBlip.Remove();
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet2 != null)
						{
							VtoGet2.Delete();
						}
						if (VtoGet3 != null)
						{
							VtoGet3.Delete();
						}
						if (VtoGet4 != null)
						{
							VtoGet4.Delete();
						}
						if (VtoGet5 != null)
						{
							VtoGet5.Delete();
						}
						if (VtoGet6 != null)
						{
							VtoGet6.Delete();
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						if (VtoGetBlip2 != null)
						{
							VtoGetBlip2.Remove();
						}
						if (VtoGetBlip3 != null)
						{
							VtoGetBlip3.Remove();
						}
						foreach (Ped ped17 in Peds)
						{
							if (ped17 != null)
							{
								ped17.Delete();
							}
						}
						Script.Wait(500);
						Game.FadeScreenIn(500);
						UI.Notify("Alan : Boss a vehicle Reached the destination!, We cannot afford to have other contestants with fuel!");
						MissionScreen missionScreen6 = new MissionScreen();
						missionScreen6.SetFail("The Air Tanker Mission", 1450000, "A vehicle Reached the destination!");
						MissionSetup = false;
						Missionnum = 0;
						Config.SetValue("Setup", "StocksValue", stocksvalue);
						Config.Save();
					}
				}
				if (MissionId == 13 && Race == 1)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), MarkerColor);
					}
					if (StartedRace)
					{
						if (VtoGet != null && VtoGetBlip != null)
						{
							VtoGetBlip.Position = VtoGet.Position;
						}
						if (VtoGet1 != null && VtoGetBlip1 != null)
						{
							VtoGetBlip1.Position = VtoGet1.Position;
						}
						if (VtoGet2 != null && VtoGetBlip2 != null)
						{
							VtoGetBlip2.Position = VtoGet2.Position;
						}
						if (VtoGet3 != null && VtoGetBlip3 != null)
						{
							VtoGetBlip3.Position = VtoGet3.Position;
						}
						if (VtoGet != null && VtoGet != null && VtoGet2 != null && VtoGet3 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive)
						{
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							vehicleHealth += 100;
							SetupDeathMatchCars();
							VtoGet.HasCollision = false;
							VtoGet1.HasCollision = false;
							VtoGet2.HasCollision = false;
							VtoGet3.HasCollision = false;
							Script.Wait(500);
							VtoGet.HasCollision = true;
							VtoGet1.HasCollision = true;
							VtoGet2.HasCollision = true;
							VtoGet3.HasCollision = true;
							foreach (Ped ped18 in Peds)
							{
								if (ped18 != null && ped18.CurrentVehicle == null)
								{
									ped18.Delete();
								}
							}
						}
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						if (RaceBlip != null)
						{
							RaceBlip.Remove();
						}
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							Model vehicle7 = getVehicle();
							Script.Wait(100);
							Model vehicle8 = getVehicle();
							Script.Wait(100);
							Model vehicle9 = getVehicle();
							inRace = true;
							FinishedRace = false;
							UI.Notify("test1");
							Game.Player.Character.CurrentVehicle.FreezePosition = true;
							Random random9 = new Random();
							UI.Notify("test3");
							Script.Wait(1000);
							UI.Notify("Ready!");
							Script.Wait(1000);
							UI.Notify("Set! ");
							Script.Wait(1000);
							UI.Notify("Go!");
							UI.Notify("test4");
							ACheck = 0;
							BCheck = 0;
							CCheck = 0;
							Alap = 0;
							Blap = 0;
							Clap = 0;
							Game.Player.Character.CurrentVehicle.FreezePosition = false;
							UI.Notify("test5");
							SetupDeathMatchCars();
							VtoGet.HasCollision = false;
							VtoGet1.HasCollision = false;
							VtoGet2.HasCollision = false;
							VtoGet3.HasCollision = false;
							Script.Wait(500);
							VtoGet.HasCollision = true;
							VtoGet1.HasCollision = true;
							VtoGet2.HasCollision = true;
							VtoGet3.HasCollision = true;
							Game.Player.Character.IsInvincible = true;
						}
					}
					if (inRace)
					{
						if (Timer2 != 35)
						{
							Timer2++;
						}
						if (Timer2 == 35)
						{
							Timer2 = 0;
							Firemissile();
						}
						Random random10 = new Random();
						int num8 = random10.Next(1, 1000);
						if (num8 <= 10)
						{
							UI.Notify("C" + num8);
							foreach (Vector3 trapsPo in TrapsPos)
							{
								bool flag = true;
								if (World.GetDistance(Game.Player.Character.Position, trapsPo) < 10f && Game.Player.Character.CurrentVehicle != null)
								{
									UI.Notify("Alan You have been hit by an EMP mine");
									Game.Player.Character.CurrentVehicle.IsInvincible = true;
									Game.Player.Character.CurrentVehicle.IsDriveable = false;
									Game.Player.Character.CurrentVehicle.Health = 10;
									Script.Wait(100);
									Game.Player.Character.CurrentVehicle.Health = 100;
									Game.Player.Character.CurrentVehicle.IsDriveable = true;
									Game.Player.Character.CurrentVehicle.IsInvincible = false;
								}
							}
						}
						if (IsLeading)
						{
						}
						World.DrawMarker(MarkerType.VerticalCylinder, FinishLine, Vector3.Zero, Vector3.Zero, new Vector3(4f, 4f, 1f), MarkerColor);
						DisplayHelpTextThisFrame("Surive for as long as possible,  Lap " + lap + " 100k for each lap");
						if (!FinishedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									if (FinishLineBLip != null)
									{
										FinishLineBLip.Remove();
									}
									inRace = false;
									StartedRace = false;
									FinishedRace = true;
									Race = 0;
									MissionId = 0;
									Game.Player.Money += 100000 * lap;
									UI.Notify("Alan : Haha that is what i am talking about, good job, you earned : $" + 100000 * lap + " for " + lap + " Laps");
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (VtoGetBlip1 != null)
									{
										VtoGetBlip1.Remove();
									}
									if (VtoGetBlip2 != null)
									{
										VtoGetBlip2.Remove();
									}
									if (VtoGetBlip3 != null)
									{
										VtoGetBlip3.Remove();
									}
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGet1 != null)
									{
										VtoGet1.Delete();
									}
									if (VtoGet2 != null)
									{
										VtoGet2.Delete();
									}
									if (VtoGet3 != null)
									{
										VtoGet3.Delete();
									}
									Vehicle currentVehicle22 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle22);
									currentVehicle22.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle22.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
								}
							}
							else
							{
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Remove();
								}
								inRace = false;
								StartedRace = false;
								FinishedRace = true;
								Race = 0;
								MissionId = 0;
								Game.Player.Money += 100000 * lap;
								UI.Notify("Alan : Haha that is what i am talking about, good job, you earned : $" + 100000 * lap + " for " + lap + " Laps");
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
							}
							if (checkpoint == 0)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2927f, -3840f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2927f, -3840f, 130f)) < 20f)
								{
									checkpoint = 1;
								}
							}
							if (checkpoint == 1)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2869f, -3747f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2869f, -3747f, 130f)) < 20f)
								{
									checkpoint = 2;
								}
							}
							if (checkpoint == 2)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2684f, -3754f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2684f, -3754f, 130f)) < 20f)
								{
									checkpoint = 3;
								}
							}
							if (checkpoint == 3)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2773f, -3853.73f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2773f, -3853.73f, 130f)) < 20f)
								{
									checkpoint = 0;
									lap++;
								}
							}
							if (!(World.GetDistance(Game.Player.Character.Position, new Vector3(2752f, -3879f, 140f)) < 10f))
							{
							}
						}
					}
				}
				if (MissionId == 14 && Race == 1)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
					}
					if (StartedRace)
					{
						if (VtoGet != null && VtoGet != null && VtoGet2 != null && VtoGet3 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive)
						{
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							vehicleHealth += 100;
							SetupDeathMatchCars3();
							checkpointReaced++;
							moneytobeawarded += 100000f;
							foreach (Ped ped19 in Peds)
							{
								if (ped19 != null && ped19.CurrentVehicle == null)
								{
									ped19.Delete();
								}
							}
						}
						if (VtoGet != null && VtoGet.IsAlive)
						{
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Position = VtoGet.Position;
							}
							if (World.GetDistance(VtoGet.Position, Goal1) < 40f)
							{
								VtoGet.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
							else if (World.GetDistance(VtoGet.Position, Goal2) < 40f)
							{
								VtoGet.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
						}
						if (VtoGet1 != null && VtoGet1.IsAlive)
						{
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Position = VtoGet1.Position;
							}
							if (World.GetDistance(VtoGet1.Position, Goal1) < 40f)
							{
								VtoGet1.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
							else if (World.GetDistance(VtoGet1.Position, Goal2) < 40f)
							{
								VtoGet1.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
						}
						if (VtoGet2 != null && VtoGet2.IsAlive)
						{
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Position = VtoGet2.Position;
							}
							if (World.GetDistance(VtoGet2.Position, Goal1) < 40f)
							{
								VtoGet2.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
							else if (World.GetDistance(VtoGet2.Position, Goal2) < 40f)
							{
								VtoGet2.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
						}
						if (VtoGet3 != null && VtoGet3.IsAlive)
						{
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Position = VtoGet3.Position;
							}
							if (World.GetDistance(VtoGet3.Position, Goal1) < 40f)
							{
								VtoGet3.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
							else if (World.GetDistance(VtoGet3.Position, Goal2) < 40f)
							{
								VtoGet3.Explode();
								moneytobeawarded += 100000f;
								UI.Notify("A Panto went into a goal");
							}
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (!Game.Player.Character.CurrentVehicle.IsAlive)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								Vehicle currentVehicle23 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle23);
								currentVehicle23.Explode();
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle23.Delete();
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped20 in Peds)
								{
									if (ped20 != null && ped20.CurrentVehicle == null)
									{
										ped20.Delete();
									}
								}
							}
						}
						else if (Game.Player.Character.CurrentVehicle == null)
						{
							Game.Player.Money += (int)moneytobeawarded;
							Script.Wait(500);
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
							StartedRace = false;
							MissionSetup = false;
							Race = 0;
							UI.Notify("Mission Complete");
							Script.Wait(400);
							Game.Player.Character.IsInvincible = false;
							foreach (Ped ped21 in Peds)
							{
								if (ped21 != null && ped21.CurrentVehicle == null)
								{
									ped21.Delete();
								}
							}
						}
						DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
							{
								FireMine(MineLoc1, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
							{
								FireMine(MineLoc2, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
							{
								FireMine(MineLoc3, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
							{
								FireMine(MineLoc4, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
							{
								FireMine(MineLoc5, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
							{
								FireMine(MineLoc6, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
						}
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							SetupDeathMatchCars3();
							checkpointReaced = 1;
						}
					}
				}
				if (MissionId == 15)
				{
					foreach (Ped ped22 in Peds)
					{
						if (ped22 != null && ped22.CurrentVehicle == null)
						{
							Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped22, 1198256469, 999999, true, true });
							if (!ped22.IsShooting)
							{
								ped22.Task.FightAgainst(Game.Player.Character);
							}
						}
					}
					if (Race == 1)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (GotCargo)
							{
								if (CheckPointstoProceed == 6)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, Goal1, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
									FinishLineBLip.Position = Goal1;
									FinishLineBLip.Name = "Drop Loot";
									UI.Notify("Got Loot, head to goal to drop it off");
								}
								else if (CheckPointstoProceed != 6)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 5f), Color.Red);
									if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 12f)
									{
										Vector3 vector13 = (CheckPointPosition = RandomLocationFun8());
										CheckPointstoProceed++;
										FinishLineBLip.Position = CheckPointPosition;
										FinishLineBLip.Name = "More Loot";
									}
								}
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Position = CheckPointPosition;
									FinishLineBLip.Name = "More Loot";
								}
								if (World.GetDistance(Game.Player.Character.Position, Goal1) < 12f && CheckPointstoProceed == 6)
								{
									GotCargo = false;
									moneytobeawarded += 250000f;
									CheckPointstoProceed = 0;
									checkpointReaced++;
									UI.Notify("Loot Captured, more at Opposite Goal");
								}
							}
							if (!GotCargo)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, Goal2, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Position = Goal2;
									FinishLineBLip.Name = "Retrieve Loot";
								}
								if (World.GetDistance(Game.Player.Character.Position, Goal2) < 12f)
								{
									GotCargo = true;
									UI.Notify("Got Loot, now drive through checkpoints to progress");
									Vector3 vector14 = (CheckPointPosition = RandomLocationFun8());
									FinishLineBLip.Position = CheckPointPosition;
									FinishLineBLip.Name = "More Loot";
								}
							}
							if (VtoGet != null && VtoGetBlip != null)
							{
								VtoGetBlip.Position = VtoGet.Position;
							}
							if (VtoGet1 != null && VtoGetBlip1 != null)
							{
								VtoGetBlip1.Position = VtoGet1.Position;
							}
							if (VtoGet2 != null && VtoGetBlip2 != null)
							{
								VtoGetBlip2.Position = VtoGet2.Position;
							}
							if (VtoGet3 != null && VtoGetBlip3 != null)
							{
								VtoGetBlip3.Position = VtoGet3.Position;
							}
							if (VtoGet != null && VtoGet != null && VtoGet2 != null && VtoGet3 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive)
							{
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								vehicleHealth += 100;
								SetupDeathMatchCars();
								foreach (Ped ped23 in Peds)
								{
									if (ped23 != null && ped23.CurrentVehicle == null)
									{
										ped23.Delete();
									}
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (VtoGetBlip1 != null)
									{
										VtoGetBlip1.Remove();
									}
									if (VtoGetBlip2 != null)
									{
										VtoGetBlip2.Remove();
									}
									if (VtoGetBlip3 != null)
									{
										VtoGetBlip3.Remove();
									}
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGet1 != null)
									{
										VtoGet1.Delete();
									}
									if (VtoGet2 != null)
									{
										VtoGet2.Delete();
									}
									if (VtoGet3 != null)
									{
										VtoGet3.Delete();
									}
									UI.Notify("Alan : Good Job , you got retrieved " + checkpointReaced + "loot, and  you earned $" + moneytobeawarded);
									Vehicle currentVehicle24 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle24);
									currentVehicle24.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle24.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
									foreach (Ped ped24 in Peds)
									{
										if (ped24 != null && ped24.CurrentVehicle == null)
										{
											ped24.Delete();
										}
									}
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you got retrieved " + checkpointReaced + "loot, and  you earned $" + moneytobeawarded);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								UI.Notify("Mission Complete");
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped25 in Peds)
								{
									if (ped25 != null && ped25.CurrentVehicle == null)
									{
										ped25.Delete();
									}
								}
							}
							DisplayHelpTextThisFrame("Amount of Loot Retreived :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
							if (UseMIssilesInVDM)
							{
								if (missiletimer != 60)
								{
									missiletimer++;
								}
								else if (missiletimer == 60)
								{
									missiletimer = 0;
									Firemissile4_1();
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								GotCargo = false;
								SetupDeathMatchCars();
								checkpointReaced = 0;
								GotCargo = false;
							}
						}
					}
					foreach (Ped ped26 in Peds)
					{
						if (ped26 != null && ped26.CurrentVehicle == null)
						{
							Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped26, 1198256469, 999999, true, true });
							ped26.Task.FightAgainst(Game.Player.Character);
						}
					}
					if (Race == 2)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (GotCargo)
							{
								if (CheckPointstoProceed == 6)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, Goal1, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
									FinishLineBLip.Position = Goal1;
									FinishLineBLip.Name = "Drop Loot";
									UI.Notify("Got Loot, head to goal to drop it off");
								}
								else if (CheckPointstoProceed != 6)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, CheckPointPosition, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 5f), Color.Red);
									if (World.GetDistance(Game.Player.Character.Position, CheckPointPosition) < 12f)
									{
										Vector3 vector15 = (CheckPointPosition = RandomLocationFun8());
										CheckPointstoProceed++;
										FinishLineBLip.Position = CheckPointPosition;
										FinishLineBLip.Name = "More Loot";
									}
								}
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Position = CheckPointPosition;
									FinishLineBLip.Name = "More Loot";
								}
								if (World.GetDistance(Game.Player.Character.Position, Goal1) < 12f && CheckPointstoProceed == 6)
								{
									GotCargo = false;
									moneytobeawarded += 250000f;
									CheckPointstoProceed = 0;
									checkpointReaced++;
									UI.Notify("Loot Captured, more at Opposite Goal");
								}
							}
							if (!GotCargo)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, Goal2, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Position = Goal2;
									FinishLineBLip.Name = "Retrieve Loot";
								}
								if (World.GetDistance(Game.Player.Character.Position, Goal2) < 12f)
								{
									GotCargo = true;
									UI.Notify("Got Loot, now drive through checkpoints to progress");
									Vector3 vector16 = (CheckPointPosition = RandomLocationFun8());
									FinishLineBLip.Position = CheckPointPosition;
									FinishLineBLip.Name = "More Loot";
								}
							}
							if (VtoGet != null && VtoGetBlip != null)
							{
								VtoGetBlip.Position = VtoGet.Position;
							}
							if (VtoGet1 != null && VtoGetBlip1 != null)
							{
								VtoGetBlip1.Position = VtoGet1.Position;
							}
							if (VtoGet2 != null && VtoGetBlip2 != null)
							{
								VtoGetBlip2.Position = VtoGet2.Position;
							}
							if (VtoGet3 != null && VtoGetBlip3 != null)
							{
								VtoGetBlip3.Position = VtoGet3.Position;
							}
							if (VtoGet4 != null && VtoGetBlip4 != null)
							{
								VtoGetBlip4.Position = VtoGet4.Position;
							}
							if (VtoGet5 != null && VtoGetBlip5 != null)
							{
								VtoGetBlip5.Position = VtoGet5.Position;
							}
							if (VtoGet6 != null && VtoGetBlip6 != null)
							{
								VtoGetBlip6.Position = VtoGet6.Position;
							}
							if (VtoGet7 != null && VtoGetBlip7 != null)
							{
								VtoGetBlip7.Position = VtoGet7.Position;
							}
							if (VtoGet != null && VtoGet1 != null && VtoGet2 != null && VtoGet3 != null && VtoGet4 != null && VtoGet5 != null && VtoGet6 != null && VtoGet7 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive && !VtoGet4.IsAlive && !VtoGet5.IsAlive && !VtoGet6.IsAlive && !VtoGet7.IsAlive)
							{
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								vehicleHealth += 100;
								SetupDeathMatchCars();
								Script.Wait(3000);
								SetupDeathMatchCars2();
								foreach (Ped ped27 in Peds)
								{
									if (ped27 != null && ped27.CurrentVehicle == null)
									{
										ped27.Delete();
									}
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGet1 != null)
									{
										VtoGet1.Delete();
									}
									if (VtoGet2 != null)
									{
										VtoGet2.Delete();
									}
									if (VtoGet3 != null)
									{
										VtoGet3.Delete();
									}
									if (VtoGet4 != null)
									{
										VtoGet4.Delete();
									}
									if (VtoGet5 != null)
									{
										VtoGet5.Delete();
									}
									if (VtoGet6 != null)
									{
										VtoGet6.Delete();
									}
									if (VtoGet7 != null)
									{
										VtoGet7.Delete();
									}
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (VtoGetBlip1 != null)
									{
										VtoGetBlip1.Remove();
									}
									if (VtoGetBlip2 != null)
									{
										VtoGetBlip2.Remove();
									}
									if (VtoGetBlip3 != null)
									{
										VtoGetBlip3.Remove();
									}
									if (VtoGetBlip4 != null)
									{
										VtoGetBlip4.Remove();
									}
									if (VtoGetBlip5 != null)
									{
										VtoGetBlip5.Remove();
									}
									if (VtoGetBlip6 != null)
									{
										VtoGetBlip6.Remove();
									}
									if (VtoGetBlip7 != null)
									{
										VtoGetBlip7.Remove();
									}
									UI.Notify("Alan : Good Job , you got retrieved " + checkpointReaced + "loot, and  you earned $" + moneytobeawarded);
									Vehicle currentVehicle25 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle25);
									currentVehicle25.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle25.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
									foreach (Ped ped28 in Peds)
									{
										if (ped28 != null && ped28.CurrentVehicle == null)
										{
											ped28.Delete();
										}
									}
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								UI.Notify("Alan : Good Job , you got retrieved " + checkpointReaced + "loot, and  you earned $" + moneytobeawarded);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								UI.Notify("Mission Complete");
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped29 in Peds)
								{
									if (ped29 != null && ped29.CurrentVehicle == null)
									{
										ped29.Delete();
									}
								}
							}
							DisplayHelpTextThisFrame("Loot Retrieved :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
							if (UseMIssilesInVDM)
							{
								if (missiletimer != 90)
								{
									missiletimer++;
								}
								else if (missiletimer == 90)
								{
									missiletimer = 0;
									Firemissile4_1();
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								SetupDeathMatchCars();
								Script.Wait(3000);
								SetupDeathMatchCars2();
								checkpointReaced = 0;
								GotCargo = false;
							}
						}
					}
				}
				if (MissionId == 16)
				{
					if (VtoGet != null && VtoGet1 != null)
					{
						if (!VtoGet.IsAlive)
						{
							if (VtoGet1.IsAlive)
							{
								VtoGet1.Explode();
							}
						}
						else
						{
							VtoGetBlip4.Position = VtoGet.Position;
						}
					}
					if (VtoGet2 != null && VtoGet3 != null)
					{
						if (!VtoGet2.IsAlive)
						{
							if (VtoGet3.IsAlive)
							{
								VtoGet3.Explode();
							}
						}
						else
						{
							VtoGetBlip5.Position = VtoGet2.Position;
						}
					}
					if (VtoGet4 != null && VtoGet5 != null)
					{
						if (!VtoGet4.IsAlive)
						{
							if (VtoGet5.IsAlive)
							{
								VtoGet5.Explode();
							}
						}
						else
						{
							VtoGetBlip6.Position = VtoGet4.Position;
						}
					}
					if (VtoGet6 != null && VtoGet7 != null)
					{
						if (!VtoGet6.IsAlive)
						{
							if (VtoGet7.IsAlive)
							{
								VtoGet7.Explode();
							}
						}
						else
						{
							VtoGetBlip7.Position = VtoGet6.Position;
						}
					}
					if (PLayerVehicle != null && PLayerVehicle2 != null)
					{
						if (!PLayerVehicle.IsAlive)
						{
							if (PLayerVehicle2.IsAlive)
							{
								PLayerVehicle2.Explode();
							}
						}
						else
						{
							if (PLayerVehicle2 != null && Friendlyped != null && Friendlyped.CurrentVehicle == null)
							{
								Friendlyped.SetIntoVehicle(PLayerVehicle2, VehicleSeat.Driver);
								Ped ped2 = ChooseTarget();
								if (ped2 != null)
								{
									Ped target = ped2;
									Ped pedOnSeat10 = PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver);
									Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat10, true });
									Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat10, 0, 0 });
									Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat10, 17, 1 });
									Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat10, 1 });
									Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat10, 0, 0 });
									Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat10, 17, 1 });
									UI.Notify("Ped :" + ped2.Model);
									PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(target);
									UI.Notify("Ped is on Seat");
								}
							}
							if (PLayerVehicle.IsAlive && PLayerVehicle2.IsAlive)
							{
								if (timer == 120)
								{
									Ped ped3 = ChooseTarget();
									if (ped3 != null)
									{
										Ped target2 = ped3;
										Ped pedOnSeat11 = PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver);
										Function.Call(Hash._0x90D2156198831D69, new InputArgument[2] { pedOnSeat11, true });
										Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat11, 0, 0 });
										Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat11, 17, 1 });
										Function.Call(Hash._0x9F8AA94D6D97DBF4, new InputArgument[2] { pedOnSeat11, 1 });
										Function.Call(Hash._0x70A2D1137C8ED7C9, new InputArgument[3] { pedOnSeat11, 0, 0 });
										Function.Call(Hash._0x9F7794730795E019, new InputArgument[3] { pedOnSeat11, 17, 1 });
										UI.Notify("Ped :" + ped3.Model);
										PLayerVehicle2.GetPedOnSeat(VehicleSeat.Driver).Task.FightAgainst(target2);
										UI.Notify("Ped is on Seat");
									}
									timer = 0;
									UI.Notify("AI changed Target");
								}
								else if (timer != 120)
								{
									timer++;
									if (!Friendlyped.IsAlive)
									{
										UI.Notify("Ped is Dead");
									}
								}
							}
						}
					}
					foreach (Ped ped30 in Peds)
					{
						if (ped30 != null && ped30.CurrentVehicle == null)
						{
							Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped30, 1198256469, 999999, true, true });
							ped30.Task.FightAgainst(Game.Player.Character);
						}
					}
					if (Race == 1)
					{
						if (!StartedRace)
						{
							World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
						}
						if (StartedRace)
						{
							if (VtoGet != null && VtoGet1 != null && VtoGet2 != null && VtoGet3 != null && VtoGet4 != null && VtoGet5 != null && VtoGet6 != null && VtoGet7 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive && !VtoGet4.IsAlive && !VtoGet5.IsAlive && !VtoGet6.IsAlive && !VtoGet7.IsAlive)
							{
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								vehicleHealth += 100;
								SetupBeastWarsCars();
								checkpointReaced++;
								moneytobeawarded += 500000f;
								foreach (Ped ped31 in Peds)
								{
									if (ped31 != null && ped31.CurrentVehicle == null)
									{
										ped31.Delete();
									}
								}
							}
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									Game.Player.Money += (int)moneytobeawarded;
									Script.Wait(500);
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGet1 != null)
									{
										VtoGet1.Delete();
									}
									if (VtoGet2 != null)
									{
										VtoGet2.Delete();
									}
									if (VtoGet3 != null)
									{
										VtoGet3.Delete();
									}
									if (VtoGet4 != null)
									{
										VtoGet4.Delete();
									}
									if (VtoGet5 != null)
									{
										VtoGet5.Delete();
									}
									if (VtoGet6 != null)
									{
										VtoGet6.Delete();
									}
									if (VtoGet7 != null)
									{
										VtoGet7.Delete();
									}
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (VtoGetBlip1 != null)
									{
										VtoGetBlip1.Remove();
									}
									if (VtoGetBlip2 != null)
									{
										VtoGetBlip2.Remove();
									}
									if (VtoGetBlip3 != null)
									{
										VtoGetBlip3.Remove();
									}
									if (VtoGetBlip4 != null)
									{
										VtoGetBlip4.Remove();
									}
									if (VtoGetBlip5 != null)
									{
										VtoGetBlip5.Remove();
									}
									if (VtoGetBlip6 != null)
									{
										VtoGetBlip6.Remove();
									}
									if (VtoGetBlip7 != null)
									{
										VtoGetBlip7.Remove();
									}
									UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
									Vehicle currentVehicle26 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle26);
									currentVehicle26.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle26.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
									foreach (Ped ped32 in Peds)
									{
										if (ped32 != null && ped32.CurrentVehicle == null)
										{
											ped32.Delete();
										}
									}
								}
							}
							else if (Game.Player.Character.CurrentVehicle == null)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								UI.Notify("Mission Complete");
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped33 in Peds)
								{
									if (ped33 != null && ped33.CurrentVehicle == null)
									{
										ped33.Delete();
									}
								}
							}
							DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
								{
									FireMine(MineLoc1, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
								{
									FireMine(MineLoc2, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
								{
									FireMine(MineLoc3, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
								{
									FireMine(MineLoc4, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
								{
									FireMine(MineLoc5, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
								if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
								{
									FireMine(MineLoc6, Game.Player.Character);
									ChangeMIneLoc(CheckPointPosition);
								}
							}
						}
						if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
						{
							StartedRace = true;
							if (Game.Player.Character.CurrentVehicle != null)
							{
								SetupBeastWarsCars();
								checkpointReaced = 1;
							}
						}
					}
				}
				if (Missionnum == 17)
				{
					UI.Notify("test1");
					if (Race == 1)
					{
						UI.Notify("test2");
						if (!GotCar && VtoGet.IsAlive)
						{
							UI.Notify("test3");
							if (VtoGet.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
							{
								UI.Notify("test4");
								GotCar = true;
								Random random11 = new Random();
								if (random11.Next(1, 100) < 20)
								{
									Dropzone = new Vector3(1737f, 3291f, 41f);
									DropzoneBlip = World.CreateBlip(Dropzone);
									DropzoneBlip.Name = "Drop Zone";
									DropzoneBlip.Sprite = BlipSprite.SpecialCargo;
									DropzoneBlip.Color = BlipColor.White;
									DropzoneBlip.Name = "Drop Zone";
								}
								if (random11.Next(1, 100) > 20 && random11.Next(1, 100) < 40)
								{
									Dropzone = new Vector3(141f, 6619f, 31f);
									DropzoneBlip = World.CreateBlip(Dropzone);
									DropzoneBlip.Name = "Drop Zone";
									DropzoneBlip.Sprite = BlipSprite.SpecialCargo;
									DropzoneBlip.Color = BlipColor.White;
									DropzoneBlip.Name = "Drop Zone";
								}
								if (random11.Next(1, 100) > 40 && random11.Next(1, 100) < 60)
								{
									Dropzone = new Vector3(2143f, 4801f, 41f);
									DropzoneBlip = World.CreateBlip(Dropzone);
									DropzoneBlip.Name = "Drop Zone";
									DropzoneBlip.Sprite = BlipSprite.SpecialCargo;
									DropzoneBlip.Color = BlipColor.White;
									DropzoneBlip.Name = "Drop Zone";
								}
								if (random11.Next(1, 100) > 60 && random11.Next(1, 100) < 80)
								{
									Dropzone = new Vector3(2817f, 1695f, 24f);
									DropzoneBlip = World.CreateBlip(Dropzone);
									DropzoneBlip.Name = "Drop Zone";
									DropzoneBlip.Sprite = BlipSprite.SpecialCargo;
									DropzoneBlip.Color = BlipColor.White;
									DropzoneBlip.Name = "Drop Zone";
								}
								if (random11.Next(1, 100) > 80 && random11.Next(1, 100) < 100)
								{
									Dropzone = new Vector3(-1154f, 2674f, 18f);
									DropzoneBlip = World.CreateBlip(Dropzone);
									DropzoneBlip.Name = "Drop Zone";
									DropzoneBlip.Sprite = BlipSprite.SpecialCargo;
									DropzoneBlip.Color = BlipColor.White;
									DropzoneBlip.Name = "Drop Zone";
								}
							}
						}
						if (VtoGet.IsAlive)
						{
							if (VtoGet.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
							{
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Position = VtoGet.Position;
								}
								if (VtoGet.IsDamaged)
								{
									VehicleisDamaged = true;
								}
								if (Vehiclehealth != VtoGet.Health)
								{
									Vehiclehealth = VtoGet.Health;
									stocksvalue = (int)stocksvalue - (int)stocksvalue / 100;
									UI.Notify("Alan : damaging the Mule, will decrease stock value, value : " + stocksvalue);
								}
								if (World.GetDistance(Game.Player.Character.Position, Dropzone) < 5f)
								{
									if (VtoGet != null)
									{
										VtoGet.Delete();
									}
									if (VtoGetBlip != null)
									{
										VtoGetBlip.Remove();
									}
									if (DropzoneBlip != null)
									{
										DropzoneBlip.Remove();
									}
									VehicleSetup = false;
									Missionnum = 0;
									Random random12 = new Random();
									stocksvalue = (int)stocksvalue + (int)stocksvalue / random12.Next(5, 10);
									Script.Wait(200);
									Game.Player.Money = Game.Player.Money + (int)stocksvalue;
									stocksvalue = 0f;
									stockscount = 0;
									Config.SetValue("Setup", "stockslevel", stockscount);
									Config.SetValue("Setup", "StocksValue", stocksvalue);
									Config.Save();
									UI.Notify("Office Assistant : ok we got the delivery to the location, there is a little boost in there");
								}
								if (World.GetDistance(Game.Player.Character.Position, Dropzone) < 5f)
								{
									World.DrawMarker(MarkerType.VerticalCylinder, Dropzone, Vector3.Zero, Vector3.Zero, new Vector3(3f, 3f, 2f), Color.White);
								}
							}
						}
						else
						{
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (DropzoneBlip != null)
							{
								DropzoneBlip.Remove();
							}
							VehicleSetup = false;
							Missionnum = 0;
							stocksvalue = (int)stocksvalue - (int)stocksvalue / 2;
							Script.Wait(200);
							UI.Notify("Office Assistant : What were you doing out there we just lost 50% of out stock!");
						}
					}
				}
			}
			if (MissionId == 18 && MissionSetup && MissionId == 18 && VtoGet != null)
			{
				if (VtoGetBlip != null)
				{
					VtoGetBlip.Position = VtoGet.Position;
				}
				if (!VtoGet.IsAlive)
				{
					if (VtoGet1.IsAlive)
					{
						VtoGet1.Explode();
					}
					Script.Wait(1000);
					MissionId = 0;
					MissionSetup = false;
					VtoGet.Delete();
					VtoGetBlip.Remove();
					VtoGet1.Delete();
					MissionScreen missionScreen7 = new MissionScreen();
					missionScreen7.SetPass("The Beast", 450000, "");
					Game.Player.Money += 450000;
					UI.Notify("Alan : good job, getting that menace off the streets");
					foreach (Ped ped34 in Peds)
					{
						if (ped34 != null)
						{
							ped34.Delete();
						}
					}
				}
			}
			if (MissionId == 20)
			{
				if (Race == 1)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
					}
					if (StartedRace)
					{
						if (VtoGet != null && VtoGet.IsAlive && World.GetDistance(VtoGet.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet1 != null && VtoGet1.IsAlive && World.GetDistance(VtoGet1.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet1.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet3 != null && VtoGet3.IsAlive && World.GetDistance(VtoGet3.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet3.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet2 != null && VtoGet2.IsAlive && World.GetDistance(VtoGet2.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet2.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet != null && VtoGetBlip != null)
						{
							VtoGetBlip.Position = VtoGet.Position;
						}
						if (VtoGet1 != null && VtoGetBlip1 != null)
						{
							VtoGetBlip1.Position = VtoGet1.Position;
						}
						if (VtoGet2 != null && VtoGetBlip2 != null)
						{
							VtoGetBlip2.Position = VtoGet2.Position;
						}
						if (VtoGet3 != null && VtoGetBlip3 != null)
						{
							VtoGetBlip3.Position = VtoGet3.Position;
						}
						if (VtoGet != null && VtoGet != null && VtoGet2 != null && VtoGet3 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive)
						{
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							vehicleHealth += 100;
							SetupDeathMatchCars4();
							moneytobeawarded += 100000f;
							foreach (Ped ped35 in Peds)
							{
								if (ped35 != null && ped35.CurrentVehicle == null)
								{
									ped35.Delete();
								}
							}
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (!Game.Player.Character.CurrentVehicle.IsAlive)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you suvived for " + checkpointReaced + " you earned $" + moneytobeawarded);
								Vehicle currentVehicle27 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle27);
								currentVehicle27.Explode();
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle27.Delete();
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped36 in Peds)
								{
									if (ped36 != null && ped36.CurrentVehicle == null)
									{
										ped36.Delete();
									}
								}
							}
						}
						else if (Game.Player.Character.CurrentVehicle == null)
						{
							Game.Player.Money += (int)moneytobeawarded;
							Script.Wait(500);
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							UI.Notify("Alan : Good Job , you suvived for " + checkpointReaced + " you earned $" + moneytobeawarded);
							StartedRace = false;
							MissionSetup = false;
							Race = 0;
							UI.Notify("Mission Complete");
							Script.Wait(400);
							Game.Player.Character.IsInvincible = false;
							foreach (Ped ped37 in Peds)
							{
								if (ped37 != null && ped37.CurrentVehicle == null)
								{
									ped37.Delete();
								}
							}
						}
						DisplayHelpTextThisFrame("Survived for :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
						if (timer != 36)
						{
							timer++;
						}
						if (timer == 36)
						{
							checkpointReaced++;
							moneytobeawarded += 5000f;
							timer = 0;
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							UI.Notify("Health : " + Game.Player.Character.CurrentVehicle.BodyHealth);
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
							{
								FireMine(MineLoc1, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
							{
								FireMine(MineLoc2, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
							{
								FireMine(MineLoc3, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
							{
								FireMine(MineLoc4, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
							{
								FireMine(MineLoc5, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
							{
								FireMine(MineLoc6, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
						}
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							SetupDeathMatchCars4();
							Game.Player.Character.CurrentVehicle.BodyHealth = 100f;
						}
					}
				}
				if (Race == 2)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
					}
					if (StartedRace)
					{
						if (VtoGet != null && VtoGet.IsAlive && World.GetDistance(VtoGet.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet1 != null && VtoGet1.IsAlive && World.GetDistance(VtoGet1.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet1.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet3 != null && VtoGet3.IsAlive && World.GetDistance(VtoGet3.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet3.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet2 != null && VtoGet2.IsAlive && World.GetDistance(VtoGet2.Position, Game.Player.Character.Position) < 5f)
						{
							VtoGet2.Explode();
							moneytobeawarded += 75000f;
						}
						if (VtoGet != null && VtoGetBlip != null)
						{
							VtoGetBlip.Position = VtoGet.Position;
						}
						if (VtoGet1 != null && VtoGetBlip1 != null)
						{
							VtoGetBlip1.Position = VtoGet1.Position;
						}
						if (VtoGet2 != null && VtoGetBlip2 != null)
						{
							VtoGetBlip2.Position = VtoGet2.Position;
						}
						if (VtoGet3 != null && VtoGetBlip3 != null)
						{
							VtoGetBlip3.Position = VtoGet3.Position;
						}
						if (VtoGet != null && VtoGet != null && VtoGet2 != null && VtoGet3 != null && !VtoGet1.IsAlive && !VtoGet2.IsAlive && !VtoGet3.IsAlive && !VtoGet.IsAlive)
						{
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							vehicleHealth += 100;
							SetupDeathMatchCars();
							moneytobeawarded += 100000f;
							foreach (Ped ped38 in Peds)
							{
								if (ped38 != null && ped38.CurrentVehicle == null)
								{
									ped38.Delete();
								}
							}
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (!Game.Player.Character.CurrentVehicle.IsAlive)
							{
								Game.Player.Money += (int)moneytobeawarded;
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you suvived for " + checkpointReaced + " you earned $" + moneytobeawarded);
								Vehicle currentVehicle28 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle28);
								currentVehicle28.Explode();
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle28.Delete();
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped39 in Peds)
								{
									if (ped39 != null && ped39.CurrentVehicle == null)
									{
										ped39.Delete();
									}
								}
							}
						}
						else if (Game.Player.Character.CurrentVehicle == null)
						{
							Game.Player.Money += (int)moneytobeawarded;
							Script.Wait(500);
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							UI.Notify("Alan : Good Job , you suvived for " + checkpointReaced + " you earned $" + moneytobeawarded);
							StartedRace = false;
							MissionSetup = false;
							Race = 0;
							UI.Notify("Mission Complete");
							Script.Wait(400);
							Game.Player.Character.IsInvincible = false;
							foreach (Ped ped40 in Peds)
							{
								if (ped40 != null && ped40.CurrentVehicle == null)
								{
									ped40.Delete();
								}
							}
						}
						DisplayHelpTextThisFrame("Survived for :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
						if (timer != 36)
						{
							timer++;
						}
						if (timer == 36)
						{
							checkpointReaced++;
							moneytobeawarded += 5000f;
							timer = 0;
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							UI.Notify("Health : " + Game.Player.Character.CurrentVehicle.BodyHealth);
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
							{
								FireMine(MineLoc1, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
							{
								FireMine(MineLoc2, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
							{
								FireMine(MineLoc3, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
							{
								FireMine(MineLoc4, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
							{
								FireMine(MineLoc5, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
							{
								FireMine(MineLoc6, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
						}
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							SetupDeathMatchCars();
							Game.Player.Character.CurrentVehicle.BodyHealth = 100f;
						}
					}
				}
			}
			if (MissionId == 25)
			{
				Vector3 vector17 = new Vector3(1882f, 2801f, 43f);
				Vector3 vector18 = new Vector3(1802f, 2873f, 45f);
				Vector3 vector19 = new Vector3(1719f, 2821f, 45f);
				Vector3 vector20 = new Vector3(1825f, 2823f, 45f);
				Vector3 vector21 = new Vector3(1951f, 2674f, 45f);
				if (VtoGet != null && VtoGet1 != null)
				{
					if (VtoGet.IsAlive || VtoGet1.IsAlive)
					{
						if (!TriggerEscape)
						{
							if (VtoGet.IsAlive && World.GetDistance(Game.Player.Character.Position, VtoGet.Position) < 2000f && !TriggerEscape)
							{
								if (World.GetDistance(VtoGet.Position, vector17) < 30f && VtoGet.Alpha == 255)
								{
									VtoGet.Alpha = 254;
									VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet, vector18, 30f, 100f, 2883621);
								}
								if (World.GetDistance(VtoGet.Position, vector18) < 30f && VtoGet.Alpha == 254)
								{
									VtoGet.Alpha = 253;
									VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet, vector19, 30f, 100f, 2883621);
								}
								if (World.GetDistance(VtoGet.Position, vector19) < 30f && VtoGet.Alpha == 253)
								{
									VtoGet.Alpha = 252;
									VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet, vector20, 30f, 100f, 2883621);
								}
								if (World.GetDistance(VtoGet.Position, vector20) < 30f && VtoGet.Alpha == 252)
								{
									VtoGet.Alpha = 251;
									VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet, vector21, 30f, 100f, 2883621);
								}
								if (World.GetDistance(VtoGet.Position, vector21) < 30f && VtoGet.Alpha == 251)
								{
									VtoGet.Alpha = 255;
									VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet, vector17, 30f, 100f, 2883621);
								}
							}
							if (VtoGet1.IsAlive)
							{
								if (World.GetDistance(Game.Player.Character.Position, VtoGet1.Position) < 2000f && !TriggerEscape)
								{
									if (World.GetDistance(VtoGet1.Position, vector17) < 30f && VtoGet1.Alpha == 255)
									{
										VtoGet1.Alpha = 254;
										VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet1, vector18, 30f, 100f, 2883621);
									}
									if (World.GetDistance(VtoGet1.Position, vector18) < 30f && VtoGet1.Alpha == 254)
									{
										VtoGet1.Alpha = 253;
										VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet1, vector19, 30f, 100f, 2883621);
									}
									if (World.GetDistance(VtoGet1.Position, vector19) < 30f && VtoGet1.Alpha == 253)
									{
										VtoGet1.Alpha = 252;
										VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet1, vector20, 30f, 100f, 2883621);
									}
									if (World.GetDistance(VtoGet1.Position, vector20) < 30f && VtoGet1.Alpha == 252)
									{
										VtoGet1.Alpha = 251;
										VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet1, vector21, 30f, 100f, 2883621);
									}
									if (World.GetDistance(VtoGet1.Position, vector21) < 30f && VtoGet1.Alpha == 251)
									{
										VtoGet1.Alpha = 255;
										VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.DriveTo(VtoGet1, vector17, 30f, 100f, 2883621);
									}
								}
								if (Game.Player.Character.IsShooting)
								{
									if (World.GetDistance(Game.Player.Character.Position, VtoGet.Position) < 500f)
									{
										TriggerEscape = true;
										VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
									}
									if (World.GetDistance(Game.Player.Character.Position, VtoGet1.Position) < 500f)
									{
										TriggerEscape = true;
										VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
									}
								}
							}
						}
						if (TriggerEscape)
						{
							if (World.GetDistance(Game.Player.Character.Position, VtoGet.Position) < 750f)
							{
								TriggerEscape = true;
								VtoGet.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
							}
							if (World.GetDistance(Game.Player.Character.Position, VtoGet1.Position) < 750f)
							{
								TriggerEscape = true;
								VtoGet1.GetPedOnSeat(VehicleSeat.Driver).Task.FleeFrom(Game.Player.Character);
							}
							if (World.GetDistance(Game.Player.Character.Position, VtoGet.Position) > 750f && VtoGet.IsAlive)
							{
								foreach (Ped ped41 in Peds)
								{
									if (ped41 != null)
									{
										ped41.Delete();
									}
								}
								foreach (Vehicle item in ExtraV)
								{
									if (item != null)
									{
										item.Delete();
									}
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								foreach (Prop prop in Props)
								{
									if (prop != null)
									{
										prop.Delete();
									}
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								TriggerEscape = false;
								MissionSetup = false;
								Missionnum = 0;
								MissionScreen missionScreen8 = new MissionScreen();
								missionScreen8.SetFail("The Traning Day", 2200000, "One of the racers has escaped!");
								return;
							}
							if (World.GetDistance(Game.Player.Character.Position, VtoGet1.Position) > 750f && VtoGet1.IsAlive)
							{
								foreach (Ped ped42 in Peds)
								{
									if (ped42 != null)
									{
										ped42.Delete();
									}
								}
								foreach (Vehicle item2 in ExtraV)
								{
									if (item2 != null)
									{
										item2.Delete();
									}
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								foreach (Prop prop2 in Props)
								{
									if (prop2 != null)
									{
										prop2.Delete();
									}
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								TriggerEscape = false;
								MissionSetup = false;
								Missionnum = 0;
								MissionScreen missionScreen9 = new MissionScreen();
								missionScreen9.SetFail("The Traning Day", 2200000, "One of the racers has escaped!");
								return;
							}
						}
					}
					else if (!VtoGet.IsAlive && !VtoGet1.IsAlive)
					{
						int num9 = 0;
						foreach (Vehicle item3 in ExtraV)
						{
							if (item3 != null && !item3.IsAlive)
							{
								num9 += 100000;
							}
						}
						foreach (Ped ped43 in Peds)
						{
							if (ped43 != null)
							{
								ped43.Delete();
							}
						}
						foreach (Vehicle item4 in ExtraV)
						{
							if (item4 != null)
							{
								item4.Delete();
							}
						}
						if (VtoGetBlip != null)
						{
							VtoGetBlip.Remove();
						}
						foreach (Prop prop3 in Props)
						{
							if (prop3 != null)
							{
								prop3.Delete();
							}
						}
						if (VtoGet != null)
						{
							VtoGet.Delete();
						}
						if (VtoGet1 != null)
						{
							VtoGet1.Delete();
						}
						TriggerEscape = false;
						UI.Notify("Alan : ok good enemy vehicles Destroyed ");
						UI.Notify("Alan : Stocks just Increased");
						UI.Notify("Max Stocks: " + maxstocks);
						UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
						UI.Notify("Mission Gain: " + profitMargin + "%");
						UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
						MissionSetup = false;
						MissionId = 0;
						MissionScreen missionScreen10 = new MissionScreen();
						missionScreen10.SetPass("The Traning Day", num9 + 2200000, "");
						stocksvalue += (float)num9 + 2200000f + 1000000f * profitMargin / 100f;
						Config.SetValue("Setup", "StocksValue", stocksvalue);
						Config.Save();
						return;
					}
				}
			}
			if (MissionId == 26)
			{
				foreach (Prop prop4 in Props)
				{
					if (prop4 != null)
					{
						prop4.IsVisible = true;
					}
				}
				foreach (Ped ped44 in Peds)
				{
					if (ped44 != null && ped44.CurrentVehicle == null)
					{
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped44, 1198256469, 999999, true, true });
						if (!ped44.IsShooting)
						{
							ped44.Task.FightAgainst(Game.Player.Character);
						}
					}
				}
				if (Race == 1)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
					}
					if (StartedRace)
					{
						if (VtoGet != null && VtoGetBlip != null)
						{
							VtoGetBlip.Position = VtoGet.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet1 != null && VtoGetBlip1 != null)
						{
							VtoGetBlip1.Position = VtoGet1.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet1.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet1,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet2 != null && VtoGetBlip2 != null)
						{
							VtoGetBlip2.Position = VtoGet2.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet2.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet2,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet3 != null && VtoGetBlip3 != null)
						{
							VtoGetBlip3.Position = VtoGet3.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet3.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet3,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet != null && !VtoGet.IsAlive)
						{
							SetupChampionchipCars(1);
						}
						if (VtoGet1 != null && !VtoGet1.IsAlive)
						{
							SetupChampionchipCars(2);
						}
						if (VtoGet2 != null && !VtoGet2.IsAlive)
						{
							SetupChampionchipCars(3);
						}
						if (VtoGet3 != null && !VtoGet3.IsAlive)
						{
							SetupChampionchipCars(4);
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (!Game.Player.Character.CurrentVehicle.IsAlive)
							{
								Game.Player.Money += (int)moneytobeawarded;
								foreach (Prop prop5 in Props)
								{
									if (prop5 != null)
									{
										prop5.Delete();
									}
								}
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								Vehicle currentVehicle29 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle29);
								currentVehicle29.Explode();
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								currentVehicle29.Delete();
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped45 in Peds)
								{
									if (ped45 != null && ped45.CurrentVehicle == null)
									{
										ped45.Delete();
									}
								}
							}
						}
						else if (Game.Player.Character.CurrentVehicle == null)
						{
							foreach (Prop prop6 in Props)
							{
								if (prop6 != null)
								{
									prop6.Delete();
								}
							}
							Game.Player.Money += (int)moneytobeawarded;
							Script.Wait(500);
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
							StartedRace = false;
							MissionSetup = false;
							Race = 0;
							UI.Notify("Mission Complete");
							Script.Wait(400);
							Game.Player.Character.IsInvincible = false;
							foreach (Ped ped46 in Peds)
							{
								if (ped46 != null && ped46.CurrentVehicle == null)
								{
									ped46.Delete();
								}
							}
						}
						DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
						if (UseMIssilesInVDM)
						{
							if (missiletimer != 150)
							{
								missiletimer++;
							}
							else if (missiletimer == 150)
							{
								missiletimer = 0;
								Firemissile4_4();
							}
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (World.GetDistance(Game.Player.Character.Position, MineLoc1) < 12f)
							{
								FireMine(MineLoc1, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc2) < 12f)
							{
								FireMine(MineLoc2, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc3) < 12f)
							{
								FireMine(MineLoc3, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc4) < 12f)
							{
								FireMine(MineLoc4, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc5) < 12f)
							{
								FireMine(MineLoc5, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
							if (World.GetDistance(Game.Player.Character.Position, MineLoc6) < 12f)
							{
								FireMine(MineLoc6, Game.Player.Character);
								ChangeMIneLoc(CheckPointPosition);
							}
						}
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							SetupDeathMatchCars();
							checkpointReaced = 1;
						}
					}
				}
			}
			if (MissionId == 27)
			{
				foreach (Prop prop7 in Props)
				{
					if (prop7 != null)
					{
						prop7.IsVisible = true;
					}
				}
				foreach (Ped ped47 in Peds)
				{
					if (ped47 != null && ped47.CurrentVehicle == null)
					{
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped47, 1198256469, 999999, true, true });
						if (!ped47.IsShooting)
						{
							ped47.Task.FightAgainst(Game.Player.Character);
						}
					}
				}
				if (Race == 1)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
					}
					if (StartedRace)
					{
						foreach (Prop item5 in Trap_GunTower)
						{
							if (item5 != null)
							{
								Vehicle[] nearbyVehicles = World.GetNearbyVehicles(item5.Position, 30f);
								if (nearbyVehicles.Length != 0)
								{
									Random random13 = new Random();
									int num10 = random13.Next(0, nearbyVehicles.Length - 1);
									Vector3 position7 = item5.Position;
									Firemissile4_12(FirePos: new Vector3(position7.X, position7.Y, position7.Z + 5f), Pos: nearbyVehicles[num10].Position);
								}
							}
						}
						foreach (Prop item6 in Trap_Flame)
						{
							if (!(item6 != null))
							{
								continue;
							}
							Vehicle[] nearbyVehicles2 = World.GetNearbyVehicles(item6.Position, 3f);
							if (nearbyVehicles2.Length == 0)
							{
								continue;
							}
							Vehicle[] array = nearbyVehicles2;
							foreach (Vehicle vehicle10 in array)
							{
								if (vehicle10 != null)
								{
									try
									{
										World.AddExplosion(vehicle10.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle10.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle10.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle10.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle10.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										vehicle10.EngineHealth -= 0.5f;
										vehicle10.BodyHealth -= 0.5f;
									}
									catch (Exception)
									{
										UI.Notify("Failed");
									}
								}
							}
						}
						foreach (Prop item7 in Trap_Flipper)
						{
							if (!(item7 != null))
							{
								continue;
							}
							item7.Rotation = new Vector3(item7.Rotation.X, item7.Rotation.Y, item7.Rotation.Z + 2f);
							Vehicle[] nearbyVehicles3 = World.GetNearbyVehicles(item7.Position, 3f);
							if (nearbyVehicles3.Length == 0)
							{
								continue;
							}
							Vehicle[] array2 = nearbyVehicles3;
							foreach (Vehicle vehicle11 in array2)
							{
								if (vehicle11 != null)
								{
									vehicle11.Rotation = item7.Rotation;
									vehicle11.Speed += 75f;
									item7.Rotation = new Vector3(item7.Rotation.X, item7.Rotation.Y, item7.Rotation.Z + 2f);
								}
							}
						}
						foreach (Prop trap_Mine in Trap_Mines)
						{
							if (!(trap_Mine != null))
							{
								continue;
							}
							Vehicle[] nearbyVehicles4 = World.GetNearbyVehicles(trap_Mine.Position, 4f);
							if (nearbyVehicles4.Length == 0)
							{
								continue;
							}
							Vehicle[] array3 = nearbyVehicles4;
							foreach (Vehicle vehicle12 in array3)
							{
								if (vehicle12 != null)
								{
									vehicle12.Explode();
									vehicle12.ApplyForce(Vector3.WorldUp, new Vector3(0f, 0f, 0f));
									vehicle12.Speed += 20f;
								}
							}
						}
						foreach (Prop item8 in Trap_Spike)
						{
							if (!(item8 != null))
							{
								continue;
							}
							Vehicle[] nearbyVehicles5 = World.GetNearbyVehicles(item8.Position, 5f);
							if (nearbyVehicles5.Length == 0)
							{
								continue;
							}
							Vehicle[] array4 = nearbyVehicles5;
							foreach (Vehicle vehicle13 in array4)
							{
								if (vehicle13 != null)
								{
									Random random14 = new Random();
									vehicle13.BurstTire(random14.Next(0, 5));
								}
							}
						}
						foreach (Prop item9 in Trap_Turning)
						{
							if (item9 != null)
							{
								item9.Rotation = new Vector3(item9.Rotation.X, item9.Rotation.Y, item9.Rotation.Z + 2f);
							}
						}
						if (VtoGet != null && VtoGetBlip != null)
						{
							VtoGetBlip.Position = VtoGet.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet1 != null && VtoGetBlip1 != null)
						{
							VtoGetBlip1.Position = VtoGet1.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet1.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet1,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet2 != null && VtoGetBlip2 != null)
						{
							VtoGetBlip2.Position = VtoGet2.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet2.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet2,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet3 != null && VtoGetBlip3 != null)
						{
							VtoGetBlip3.Position = VtoGet3.Position;
							Function.Call(Hash._0x659427E0EF36BCDE, new InputArgument[7]
							{
								VtoGet3.GetPedOnSeat(VehicleSeat.Driver),
								VtoGet3,
								Game.Player.Character,
								7,
								Game.Player.Character.CurrentVehicle.Speed * 4f + 30f,
								2883621,
								200
							});
						}
						if (VtoGet != null && (!VtoGet.IsAlive || VtoGet.Position.Z < 990f))
						{
							if (VtoGet.Position.Z < 990f)
							{
								VtoGet.Explode();
							}
							RespawnSkywarsCar(1);
						}
						if (VtoGet1 != null && (!VtoGet1.IsAlive || VtoGet1.Position.Z < 990f))
						{
							if (VtoGet1.Position.Z < 990f)
							{
								VtoGet1.Explode();
							}
							RespawnSkywarsCar(2);
						}
						if (VtoGet2 != null && (!VtoGet2.IsAlive || VtoGet2.Position.Z < 990f))
						{
							if (VtoGet2.Position.Z < 990f)
							{
								VtoGet2.Explode();
							}
							RespawnSkywarsCar(3);
						}
						if (VtoGet3 != null && (!VtoGet3.IsAlive || VtoGet3.Position.Z < 990f))
						{
							if (VtoGet3.Position.Z < 990f)
							{
								VtoGet3.Explode();
							}
							RespawnSkywarsCar(4);
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (!Game.Player.Character.CurrentVehicle.IsAlive || Game.Player.Character.CurrentVehicle.Position.Z < 990f)
							{
								Game.Player.Money += (int)moneytobeawarded;
								foreach (Prop prop8 in Props)
								{
									if (prop8 != null)
									{
										prop8.Delete();
									}
								}
								Script.Wait(500);
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								Vehicle currentVehicle30 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle30);
								currentVehicle30.Explode();
								currentVehicle30.Delete();
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped48 in Peds)
								{
									if (ped48 != null && ped48.CurrentVehicle == null)
									{
										ped48.Delete();
									}
								}
								Game.Player.Character.Position = MenuMarker;
							}
						}
						else if (Game.Player.Character.CurrentVehicle == null)
						{
							foreach (Prop prop9 in Props)
							{
								if (prop9 != null)
								{
									prop9.Delete();
								}
							}
							Game.Player.Money += (int)moneytobeawarded;
							Script.Wait(500);
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
							StartedRace = false;
							MissionSetup = false;
							Race = 0;
							UI.Notify("Mission Complete");
							Script.Wait(400);
							Game.Player.Character.IsInvincible = false;
							foreach (Ped ped49 in Peds)
							{
								if (ped49 != null && ped49.CurrentVehicle == null)
								{
									ped49.Delete();
								}
							}
							Game.Player.Character.Position = MenuMarker;
						}
						DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
						if (UseMIssilesInVDM)
						{
							if (missiletimer != 150)
							{
								missiletimer++;
							}
							else if (missiletimer == 150)
							{
								missiletimer = 0;
								Firemissile4_8();
							}
						}
					}
					if (!StartedRace)
					{
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							SetupSkyWarsCars();
							checkpointReaced = 1;
						}
					}
				}
				foreach (Ped ped50 in Peds)
				{
					if (ped50 != null && ped50.CurrentVehicle == null)
					{
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5] { ped50, 1198256469, 999999, true, true });
						if (!ped50.IsShooting)
						{
							ped50.Task.FightAgainst(Game.Player.Character);
						}
					}
				}
				if (Race == 2)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), Color.Red);
					}
					if (StartedRace)
					{
						foreach (Prop item10 in Trap_GunTower)
						{
							if (item10 != null)
							{
								Vehicle[] nearbyVehicles6 = World.GetNearbyVehicles(item10.Position, 30f);
								if (nearbyVehicles6.Length != 0)
								{
									Random random15 = new Random();
									int num11 = random15.Next(0, nearbyVehicles6.Length - 1);
									Vector3 position8 = item10.Position;
									Firemissile4_12(FirePos: new Vector3(position8.X, position8.Y, position8.Z + 5f), Pos: nearbyVehicles6[num11].Position);
								}
							}
						}
						foreach (Prop item11 in Trap_Flame)
						{
							if (!(item11 != null))
							{
								continue;
							}
							Vehicle[] nearbyVehicles7 = World.GetNearbyVehicles(item11.Position, 3f);
							if (nearbyVehicles7.Length == 0)
							{
								continue;
							}
							Vehicle[] array5 = nearbyVehicles7;
							foreach (Vehicle vehicle14 in array5)
							{
								if (vehicle14 != null)
								{
									try
									{
										World.AddExplosion(vehicle14.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle14.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle14.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle14.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										World.AddExplosion(vehicle14.Position.Around(3f), ExplosionType.Molotov1, 10f, 1f);
										vehicle14.EngineHealth -= 0.5f;
										vehicle14.BodyHealth -= 0.5f;
									}
									catch (Exception)
									{
										UI.Notify("Failed");
									}
								}
							}
						}
						foreach (Prop item12 in Trap_Flipper)
						{
							if (!(item12 != null))
							{
								continue;
							}
							item12.Rotation = new Vector3(item12.Rotation.X, item12.Rotation.Y, item12.Rotation.Z + 2f);
							Vehicle[] nearbyVehicles8 = World.GetNearbyVehicles(item12.Position, 3f);
							if (nearbyVehicles8.Length == 0)
							{
								continue;
							}
							Vehicle[] array6 = nearbyVehicles8;
							foreach (Vehicle vehicle15 in array6)
							{
								if (vehicle15 != null)
								{
									vehicle15.Rotation = item12.Rotation;
									vehicle15.Speed += 75f;
									item12.Rotation = new Vector3(item12.Rotation.X, item12.Rotation.Y, item12.Rotation.Z + 2f);
								}
							}
						}
						foreach (Prop trap_Mine2 in Trap_Mines)
						{
							if (!(trap_Mine2 != null))
							{
								continue;
							}
							Vehicle[] nearbyVehicles9 = World.GetNearbyVehicles(trap_Mine2.Position, 4f);
							if (nearbyVehicles9.Length == 0)
							{
								continue;
							}
							Vehicle[] array7 = nearbyVehicles9;
							foreach (Vehicle vehicle16 in array7)
							{
								if (vehicle16 != null)
								{
									vehicle16.Explode();
									vehicle16.ApplyForce(Vector3.WorldUp, new Vector3(0f, 0f, 0f));
									vehicle16.Speed += 20f;
								}
							}
						}
						foreach (Prop item13 in Trap_Spike)
						{
							if (!(item13 != null))
							{
								continue;
							}
							Vehicle[] nearbyVehicles10 = World.GetNearbyVehicles(item13.Position, 5f);
							if (nearbyVehicles10.Length == 0)
							{
								continue;
							}
							Vehicle[] array8 = nearbyVehicles10;
							foreach (Vehicle vehicle17 in array8)
							{
								if (vehicle17 != null)
								{
									Random random16 = new Random();
									vehicle17.BurstTire(random16.Next(0, 5));
								}
							}
						}
						foreach (Prop item14 in Trap_Turning)
						{
							if (item14 != null)
							{
								item14.Rotation = new Vector3(item14.Rotation.X, item14.Rotation.Y, item14.Rotation.Z + 2f);
							}
						}
						if (VtoGet != null && VtoGetBlip != null)
						{
							VtoGetBlip.Position = VtoGet.Position;
						}
						if (VtoGet1 != null && VtoGetBlip1 != null)
						{
							VtoGetBlip1.Position = VtoGet1.Position;
						}
						if (VtoGet2 != null && VtoGetBlip2 != null)
						{
							VtoGetBlip2.Position = VtoGet2.Position;
						}
						if (VtoGet3 != null && VtoGetBlip3 != null)
						{
							VtoGetBlip3.Position = VtoGet3.Position;
						}
						if (VtoGet4 != null && VtoGetBlip4 != null)
						{
							VtoGetBlip4.Position = VtoGet4.Position;
						}
						if (VtoGet5 != null && VtoGetBlip5 != null)
						{
							VtoGetBlip5.Position = VtoGet5.Position;
						}
						if (VtoGet6 != null && VtoGetBlip6 != null)
						{
							VtoGetBlip6.Position = VtoGet6.Position;
						}
						if (VtoGet7 != null && VtoGetBlip7 != null)
						{
							VtoGetBlip7.Position = VtoGet7.Position;
						}
						if (VtoGet != null && (!VtoGet.IsAlive || VtoGet.Position.Z < 990f))
						{
							if (VtoGet.Position.Z < 990f)
							{
								VtoGet.Explode();
							}
							RespawnSkywarsCar(1);
						}
						if (VtoGet1 != null && (!VtoGet1.IsAlive || VtoGet1.Position.Z < 990f))
						{
							if (VtoGet1.Position.Z < 990f)
							{
								VtoGet1.Explode();
							}
							RespawnSkywarsCar(2);
						}
						if (VtoGet2 != null && (!VtoGet2.IsAlive || VtoGet2.Position.Z < 990f))
						{
							if (VtoGet2.Position.Z < 990f)
							{
								VtoGet2.Explode();
							}
							RespawnSkywarsCar(3);
						}
						if (VtoGet3 != null && (!VtoGet3.IsAlive || VtoGet3.Position.Z < 990f))
						{
							if (VtoGet3.Position.Z < 990f)
							{
								VtoGet3.Explode();
							}
							RespawnSkywarsCar(4);
						}
						if (VtoGet4 != null && (!VtoGet4.IsAlive || VtoGet4.Position.Z < 990f))
						{
							if (VtoGet4.Position.Z < 990f)
							{
								VtoGet4.Explode();
							}
							RespawnSkywarsCar(5);
						}
						if (VtoGet5 != null && (!VtoGet5.IsAlive || VtoGet5.Position.Z < 990f))
						{
							if (VtoGet5.Position.Z < 990f)
							{
								VtoGet5.Explode();
							}
							RespawnSkywarsCar(6);
						}
						if (VtoGet6 != null && (!VtoGet6.IsAlive || VtoGet6.Position.Z < 990f))
						{
							if (VtoGet6.Position.Z < 990f)
							{
								VtoGet6.Explode();
							}
							RespawnSkywarsCar(7);
						}
						if (VtoGet7 != null && (!VtoGet7.IsAlive || VtoGet7.Position.Z < 990f))
						{
							if (VtoGet7.Position.Z < 990f)
							{
								VtoGet7.Explode();
							}
							RespawnSkywarsCar(8);
						}
						if (Game.Player.Character.CurrentVehicle != null)
						{
							if (!Game.Player.Character.CurrentVehicle.IsAlive || Game.Player.Character.CurrentVehicle.Position.Z < 990f)
							{
								Game.Player.Money += (int)moneytobeawarded;
								foreach (Prop prop10 in Props)
								{
									if (prop10 != null)
									{
										prop10.Delete();
									}
								}
								Script.Wait(500);
								if (VtoGet != null)
								{
									VtoGet.Delete();
								}
								if (VtoGet1 != null)
								{
									VtoGet1.Delete();
								}
								if (VtoGet2 != null)
								{
									VtoGet2.Delete();
								}
								if (VtoGet3 != null)
								{
									VtoGet3.Delete();
								}
								if (VtoGet4 != null)
								{
									VtoGet4.Delete();
								}
								if (VtoGet5 != null)
								{
									VtoGet5.Delete();
								}
								if (VtoGet6 != null)
								{
									VtoGet6.Delete();
								}
								if (VtoGet7 != null)
								{
									VtoGet7.Delete();
								}
								if (VtoGetBlip != null)
								{
									VtoGetBlip.Remove();
								}
								if (VtoGetBlip1 != null)
								{
									VtoGetBlip1.Remove();
								}
								if (VtoGetBlip2 != null)
								{
									VtoGetBlip2.Remove();
								}
								if (VtoGetBlip3 != null)
								{
									VtoGetBlip3.Remove();
								}
								if (VtoGetBlip4 != null)
								{
									VtoGetBlip4.Remove();
								}
								if (VtoGetBlip5 != null)
								{
									VtoGetBlip5.Remove();
								}
								if (VtoGetBlip6 != null)
								{
									VtoGetBlip6.Remove();
								}
								if (VtoGetBlip7 != null)
								{
									VtoGetBlip7.Remove();
								}
								UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
								Vehicle currentVehicle31 = Game.Player.Character.CurrentVehicle;
								Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle31);
								currentVehicle31.Explode();
								currentVehicle31.Delete();
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
								foreach (Ped ped51 in Peds)
								{
									if (ped51 != null && ped51.CurrentVehicle == null)
									{
										ped51.Delete();
									}
								}
								Game.Player.Character.Position = MenuMarker;
							}
						}
						else if (Game.Player.Character.CurrentVehicle == null)
						{
							foreach (Prop prop11 in Props)
							{
								if (prop11 != null)
								{
									prop11.Delete();
								}
							}
							Game.Player.Money += (int)moneytobeawarded;
							Script.Wait(500);
							if (VtoGet != null)
							{
								VtoGet.Delete();
							}
							if (VtoGet1 != null)
							{
								VtoGet1.Delete();
							}
							if (VtoGet2 != null)
							{
								VtoGet2.Delete();
							}
							if (VtoGet3 != null)
							{
								VtoGet3.Delete();
							}
							if (VtoGet4 != null)
							{
								VtoGet4.Delete();
							}
							if (VtoGet5 != null)
							{
								VtoGet5.Delete();
							}
							if (VtoGet6 != null)
							{
								VtoGet6.Delete();
							}
							if (VtoGet7 != null)
							{
								VtoGet7.Delete();
							}
							if (VtoGetBlip != null)
							{
								VtoGetBlip.Remove();
							}
							if (VtoGetBlip1 != null)
							{
								VtoGetBlip1.Remove();
							}
							if (VtoGetBlip2 != null)
							{
								VtoGetBlip2.Remove();
							}
							if (VtoGetBlip3 != null)
							{
								VtoGetBlip3.Remove();
							}
							if (VtoGetBlip4 != null)
							{
								VtoGetBlip4.Remove();
							}
							if (VtoGetBlip5 != null)
							{
								VtoGetBlip5.Remove();
							}
							if (VtoGetBlip6 != null)
							{
								VtoGetBlip6.Remove();
							}
							if (VtoGetBlip7 != null)
							{
								VtoGetBlip7.Remove();
							}
							UI.Notify("Alan : Good Job , you got to Wave " + checkpointReaced + " you earned $" + moneytobeawarded);
							StartedRace = false;
							MissionSetup = false;
							Race = 0;
							UI.Notify("Mission Complete");
							Script.Wait(400);
							Game.Player.Character.IsInvincible = false;
							foreach (Ped ped52 in Peds)
							{
								if (ped52 != null && ped52.CurrentVehicle == null)
								{
									ped52.Delete();
								}
							}
							Game.Player.Character.Position = MenuMarker;
						}
						DisplayHelpTextThisFrame("Current Wave :" + checkpointReaced + " Cash Earned : $" + moneytobeawarded);
						if (UseMIssilesInVDM)
						{
							if (missiletimer != 150)
							{
								missiletimer++;
							}
							else if (missiletimer == 150)
							{
								missiletimer = 0;
								Firemissile4_8();
							}
						}
					}
					if (!StartedRace)
					{
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							SetupSkyWarsCars2();
							SetupSkyWarsCars();
							checkpointReaced = 1;
						}
					}
				}
			}
			if (MissionId == 28)
			{
				if (Race == 1)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), MarkerColor);
					}
					if (StartedRace)
					{
						Firemissile4_16();
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						if (RaceBlip != null)
						{
							RaceBlip.Remove();
						}
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							inRace = true;
							FinishedRace = false;
							UI.Notify("test1");
							Game.Player.Character.CurrentVehicle.FreezePosition = true;
							Random random17 = new Random();
							UI.Notify("test3");
							Script.Wait(1000);
							UI.Notify("Ready!");
							Script.Wait(1000);
							UI.Notify("Set! ");
							Script.Wait(1000);
							UI.Notify("Go!");
							UI.Notify("test4");
							Game.Player.Character.CurrentVehicle.FreezePosition = false;
							UI.Notify("Alan : Do as many laps as possible, without being killed");
							Game.Player.Character.IsInvincible = true;
						}
					}
					if (inRace)
					{
						if (IsLeading)
						{
						}
						World.DrawMarker(MarkerType.VerticalCylinder, FinishLine, Vector3.Zero, Vector3.Zero, new Vector3(4f, 4f, 1f), MarkerColor);
						DisplayHelpTextThisFrame("Surive for as long as possible,  Lap " + lap + " 100k for each lap");
						if (!FinishedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									if (FinishLineBLip != null)
									{
										FinishLineBLip.Remove();
									}
									inRace = false;
									StartedRace = false;
									FinishedRace = true;
									Race = 0;
									MissionId = 0;
									Game.Player.Money += 100000 * lap;
									UI.Notify("Alan : Haha that is what i am talking about, good job, you earned : $" + 100000 * lap + " for " + lap + " Laps");
									Vehicle currentVehicle32 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle32);
									currentVehicle32.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle32.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
								}
							}
							else
							{
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Remove();
								}
								inRace = false;
								StartedRace = false;
								FinishedRace = true;
								Race = 0;
								MissionId = 0;
								Game.Player.Money += 100000 * lap;
								UI.Notify("Alan : Haha that is what i am talking about, good job, you earned : $" + 100000 * lap + " for " + lap + " Laps");
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
							}
							if (checkpoint == 0)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2927f, -3840f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2927f, -3840f, 130f)) < 20f)
								{
									checkpoint = 1;
								}
							}
							if (checkpoint == 1)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2869f, -3747f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2869f, -3747f, 130f)) < 20f)
								{
									checkpoint = 2;
								}
							}
							if (checkpoint == 2)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2684f, -3754f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2684f, -3754f, 130f)) < 20f)
								{
									checkpoint = 3;
								}
							}
							if (checkpoint == 3)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2773f, -3853.73f, 130f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2773f, -3853.73f, 130f)) < 20f)
								{
									checkpoint = 0;
									lap++;
								}
							}
							if (!(World.GetDistance(Game.Player.Character.Position, new Vector3(2752f, -3879f, 140f)) < 10f))
							{
							}
						}
					}
				}
				if (Race == 2)
				{
					if (!StartedRace)
					{
						World.DrawMarker(MarkerType.VerticalCylinder, RaceMarker, Vector3.Zero, Vector3.Zero, new Vector3(7f, 7f, 1f), MarkerColor);
					}
					if (StartedRace)
					{
						Firemissile4_16();
					}
					if (World.GetDistance(Game.Player.Character.Position, RaceMarker) < 7f && !StartedRace)
					{
						if (RaceBlip != null)
						{
							RaceBlip.Remove();
						}
						StartedRace = true;
						if (Game.Player.Character.CurrentVehicle != null)
						{
							inRace = true;
							FinishedRace = false;
							UI.Notify("test1");
							Game.Player.Character.CurrentVehicle.FreezePosition = true;
							Random random18 = new Random();
							UI.Notify("test3");
							Script.Wait(1000);
							UI.Notify("Ready!");
							Script.Wait(1000);
							UI.Notify("Set! ");
							Script.Wait(1000);
							UI.Notify("Go!");
							Game.Player.Character.CurrentVehicle.FreezePosition = false;
							UI.Notify("Alan : Do as many laps as possible, without being killed");
							Game.Player.Character.IsInvincible = true;
						}
					}
					if (inRace)
					{
						if (IsLeading)
						{
						}
						World.DrawMarker(MarkerType.VerticalCylinder, FinishLine, Vector3.Zero, Vector3.Zero, new Vector3(4f, 4f, 1f), MarkerColor);
						DisplayHelpTextThisFrame("Surive for as long as possible,  Lap " + lap + " 100k for each lap");
						if (!FinishedRace)
						{
							if (Game.Player.Character.CurrentVehicle != null)
							{
								if (!Game.Player.Character.CurrentVehicle.IsAlive)
								{
									if (FinishLineBLip != null)
									{
										FinishLineBLip.Remove();
									}
									inRace = false;
									StartedRace = false;
									FinishedRace = true;
									Race = 0;
									MissionId = 0;
									Game.Player.Money += 100000 * lap;
									UI.Notify("Alan : Haha that is what i am talking about, good job, you earned : $" + 100000 * lap + " for " + lap + " Laps");
									Vehicle currentVehicle33 = Game.Player.Character.CurrentVehicle;
									Game.Player.Character.Task.WarpOutOfVehicle(currentVehicle33);
									currentVehicle33.Explode();
									Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
									currentVehicle33.Delete();
									StartedRace = false;
									MissionSetup = false;
									Race = 0;
									Script.Wait(400);
									Game.Player.Character.IsInvincible = false;
								}
							}
							else
							{
								if (FinishLineBLip != null)
								{
									FinishLineBLip.Remove();
								}
								inRace = false;
								StartedRace = false;
								FinishedRace = true;
								Race = 0;
								MissionId = 0;
								Game.Player.Money += 100000 * lap;
								UI.Notify("Alan : Haha that is what i am talking about, good job, you earned : $" + 100000 * lap + " for " + lap + " Laps");
								Game.Player.Character.Position = new Vector3(2782.99f, -3898.15f, 140.001f);
								StartedRace = false;
								MissionSetup = false;
								Race = 0;
								Script.Wait(400);
								Game.Player.Character.IsInvincible = false;
							}
							if (checkpoint == 0)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2950.9f, -3842.17f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2950.9f, -3842.17f, 140f)) < 20f)
								{
									checkpoint = 1;
								}
							}
							if (checkpoint == 1)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2884f, -3724f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2884f, -3724f, 140f)) < 20f)
								{
									checkpoint = 2;
								}
							}
							if (checkpoint == 2)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2634f, -3795f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2634f, -3795f, 140f)) < 20f)
								{
									checkpoint = 3;
								}
							}
							if (checkpoint == 3)
							{
								World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(2790f, -3879.2f, 140f), Vector3.Zero, Vector3.Zero, new Vector3(8f, 8f, 3f), MarkerColor);
								if (World.GetDistance(Game.Player.Character.Position, new Vector3(2790f, -3879.2f, 140f)) < 20f)
								{
									checkpoint = 0;
									lap++;
								}
							}
							if (!(World.GetDistance(Game.Player.Character.Position, new Vector3(2752f, -3879f, 140f)) < 10f))
							{
							}
						}
					}
				}
			}
			if (Game.Player.Character.IsShooting && (Game.Player.Character.Weapons.Current.Hash == WeaponHash.UnholyHellbringer || Game.Player.Character.Weapons.Current.Hash == WeaponHash.Widowmaker))
			{
				UI.Notify(Game.Player.Character.Weapons.Current.Name.ToString());
				UI.Notify("fire");
				if (PedsDieinPufofSmoke)
				{
					UI.Notify("fire");
					Vector3 position9 = Game.Player.Character.Position;
					Vector3 vector22 = Function.Call<Vector3>(Hash._0x837765A25378F0BB, new InputArgument[0]);
					float num14 = vector22.Z * (MathF.PI / 180f);
					float num15 = vector22.X * (MathF.PI / 180f);
					float num16 = (float)Math.Abs(Math.Cos(num15));
					Vector3 vector23 = new Vector3((float)Math.Sin(num14) * num16 * -1f, (float)Math.Cos(num14) * num16, (float)Math.Sin(num15));
					RaycastResult raycastResult = World.Raycast(position9, position9 + vector23 * 25000f, IntersectOptions.Everything);
					World.AddOwnedExplosion(Game.Player.Character, raycastResult.HitCoords, ExplosionType.BZGas, 0.5f, 0f);
					Game.Player.Character.Position = raycastResult.HitCoords;
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, VipEntry) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Teleport to Vip Area");
			}
			if (World.GetDistance(Game.Player.Character.Position, VipEntry) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, VipEntry, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, VipExit) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Teleport to Workship");
			}
			if (World.GetDistance(Game.Player.Character.Position, VipExit) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, VipExit, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, CharacterSwitchPos) < 2f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to change characters");
			}
			if (World.GetDistance(Game.Player.Character.Position, CharacterSwitchPos) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, CharacterSwitchPos, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, SleepPos) < 2f)
			{
				DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~  to sleep");
			}
			if (World.GetDistance(Game.Player.Character.Position, DrinkPos) < 2f)
			{
				DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~  to Drink");
			}
			if (World.GetDistance(Game.Player.Character.Position, Sitpos) < 2f)
			{
				if (!IsSitting)
				{
					DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~  to sit");
				}
				if (IsSitting)
				{
					DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~  to get up");
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, JackpotTable) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Get a Prize - $250,000");
			}
			if (World.GetDistance(Game.Player.Character.Position, JackpotTable) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, JackpotTable, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaExit) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Teleport to Workshop");
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaExit) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, ArenaExit, Vector3.Zero, Vector3.Zero, new Vector3(3f, 3f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaEntry) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Teleport to Arena");
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaEntry) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, ArenaEntry, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, StadiumUpperEntry) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Enter ARB");
			}
			if (World.GetDistance(Game.Player.Character.Position, StadiumUpperEntry) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, StadiumUpperEntry, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, StadiumUpperExit) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ Exit ARB");
			}
			if (World.GetDistance(Game.Player.Character.Position, StadiumUpperExit) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, StadiumUpperExit, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, EnterGarageMarker) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to save a vehicle into Garage A");
			}
			if (World.GetDistance(Game.Player.Character.Position, EnterGarageMarker) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, EnterGarageMarker, Vector3.Zero, Vector3.Zero, new Vector3(3f, 3f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaVehicleMenuMarker) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ To Teleport to Arena with Vehicle");
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaVehicleMenuMarker) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, ArenaVehicleMenuMarker, Vector3.Zero, Vector3.Zero, new Vector3(3f, 3f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageEntry) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to enter Garage A");
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageEntry) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GarageEntry, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageBMarkerInside) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GarageBMarkerInside, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaMenuMarker) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ To open the menu to get a vehicle");
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaMenuMarker) < 80f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, ArenaMenuMarker, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (isInGarage)
			{
				if (World.GetDistance(Game.Player.Character.Position, RemoveMarker) < 80f)
				{
					World.DrawMarker(MarkerType.VerticalCylinder, RemoveMarker, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
				}
				if (World.GetDistance(Game.Player.Character.Position, RemoveMarker) < 2f)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ remove a vehicle");
				}
			}
			if (firstTime)
			{
				UI.Notify("~m~Arena War Business~w~ Loaded, by ~g~HKH191~w~");
				firstTime = false;
				EI.ReloadInterior();
			}
			if (ArenaMenuPool != null && ArenaMenuPool.IsAnyMenuOpen())
			{
				ArenaMenuPool.ProcessMenus();
			}
			if (modMenuPool != null && modMenuPool.IsAnyMenuOpen())
			{
				modMenuPool.ProcessMenus();
			}
			if (GarageMenuPool != null && GarageMenuPool.IsAnyMenuOpen())
			{
				GarageMenuPool.ProcessMenus();
			}
			if (GarageMenuPool2 != null && GarageMenuPool2.IsAnyMenuOpen())
			{
				GarageMenuPool2.ProcessMenus();
			}
			if (RemoveMenuPool2 != null && RemoveMenuPool2.IsAnyMenuOpen())
			{
				RemoveMenuPool2.ProcessMenus();
			}
			if (PlayerGaragemodMenuPool != null && PlayerGaragemodMenuPool.IsAnyMenuOpen())
			{
				PlayerGaragemodMenuPool.ProcessMenus();
			}
			if (ArenaGarageMenuPool != null && ArenaGarageMenuPool.IsAnyMenuOpen())
			{
				ArenaGarageMenuPool.ProcessMenus();
			}
			if (MissionSetup && MissionId == 8 && VtoGet != null)
			{
				if (VtoGet.IsAlive)
				{
					if (VtoGetBlip != null)
					{
						VtoGetBlip.Position = VtoGet.Position;
					}
					if ((float)VtoGet.Health != vehiclehealth)
					{
						vehiclehealth = VtoGet.Health;
						DisplayHelpTextThisFrame("Vehicle Health " + vehiclehealth + " /1500");
					}
					if (VtoGet.Health <= 1500)
					{
						MissionId = 0;
						MissionSetup = false;
						VtoGet.Delete();
						VtoGetBlip.Remove();
						Game.Player.Money += 250000;
						MissionScreen missionScreen11 = new MissionScreen();
						missionScreen11.SetPass("Rogue Contestant", 250000, "");
						UI.Notify("Alan : good job boss you have tought that racer a lesson");
					}
				}
				else if (!VtoGet.IsAlive)
				{
					MissionId = 0;
					MissionSetup = false;
					VtoGet.Delete();
					VtoGetBlip.Remove();
					MissionScreen missionScreen12 = new MissionScreen();
					missionScreen12.SetFail("Rogue Contestant", 250000, "The Vehicle was destroyed");
					UI.Notify("Alan : what did i say dont destory the vehicle");
				}
			}
			if (RentedVehicle != null && startedRent)
			{
				if (RentalvehicleHealth != RentedVehicle.Health)
				{
					RentalvehicleHealth = RentedVehicle.Health;
					UI.Notify("Alan : That is a rental!, be more carefull, we get billed each time you damage it! ");
					if (Game.Player.Money >= 300)
					{
						Game.Player.Money -= 300;
					}
				}
				if (RentTimer != 0)
				{
					RentTimer--;
				}
				else
				{
					startedRent = false;
					UI.Notify("Alan : ok Boss, the Rent for that vehicle has expired");
					RentedVehicle.GetPedOnSeat(VehicleSeat.Driver).Task.LeaveVehicle(LeaveVehicleFlags.BailOut);
					RentedVehicle.LockStatus = VehicleLockStatus.Locked;
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, MarkerEnter) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, MarkerEnter, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMenuMarker2) < 2f && isinsecondVehicleBay)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to open menu");
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageBMarkerOuside) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GarageBMarkerOuside, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageBMarkerOuside) < 2f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~  to enter the Second Vehicle Bay");
			}
			if (World.GetDistance(Game.Player.Character.Position, ExitMarker3) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, ExitMarker3, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, ExitMarker3) < 2f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_COVER~  to Enter the Workshop");
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageAMarkerInside) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GarageAMarkerInside, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageAMarkerInside) < 2f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_COVER~ to exit Second Vehicle Bay/Garage A");
			}
			if (World.GetDistance(Game.Player.Character.Position, MarkerExit) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, MarkerExit, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, MenuMarker) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, MenuMarker, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMarker) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GarageMarker, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, VehicleBayMarker) < 60f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, VehicleBayMarker, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, MarkerEnter) < 3f)
			{
				if (Config.GetValue("Setup", "BuisnessLevel", purchaselvl) == 0)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to Purchase Arena War Business ; $1,000,000");
				}
				else
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to Enter Arena War Business");
				}
			}
			if (Vehicletoget != null && World.GetDistance(Game.Player.Character.Position, WherehouseMarker) < 10f && hasgotvehicle && !NewVehicleSourcing && !Vehicletoget.IsDead)
			{
				if (SourcingCheckingforDamage)
				{
					stocksvalue += SourcingPayout * 2f;
					UI.Notify("Congradulations the vehicle is undamaged");
				}
				else
				{
					stocksvalue += SourcingPayout;
				}
				Missionnum = 0;
				Game.FadeScreenOut(300);
				Script.Wait(300);
				Game.Player.Character.Position = WherehouseMarker;
				VehicleMarker.Remove();
				Vehicletoget.Delete();
				Vehicletoget = null;
				hasgotvehicle = false;
				Script.Wait(300);
				Game.FadeScreenIn(300);
				UI.Notify("Alan: Ok we will store that away and sell it later");
				UI.Notify("Alan: Stocks just Increased");
				UI.Notify("Max Stocks: " + maxstocks);
				UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
				UI.Notify("Mission Gain: " + profitMargin + "%");
				UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
			}
			if (SourcedVehicle != null && World.GetDistance(Game.Player.Character.Position, WherehouseMarker) < 10f && hasgotvehicle && NewVehicleSourcing)
			{
				if (Game.Player.Character.CurrentVehicle != null && Game.Player.Character.CurrentVehicle.DisplayName == SourcedVehicle)
				{
					Vehicletoget = Game.Player.Character.CurrentVehicle;
				}
				if (Vehicletoget != null && !Vehicletoget.IsDead)
				{
					if (SourcingCheckingforDamage)
					{
						stocksvalue += SourcingPayout * 2f;
						UI.Notify("Congradulations the vehicle is undamaged");
					}
					else
					{
						stocksvalue += SourcingPayout;
					}
					Missionnum = 0;
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Game.Player.Character.Position = WherehouseMarker;
					Vehicletoget.Delete();
					Vehicletoget = null;
					hasgotvehicle = false;
					SourcedVehicle = null;
					NewVehicleSourcing = false;
					Script.Wait(300);
					Game.FadeScreenIn(300);
					UI.Notify("Alan: Ok we will store that away and sell it later");
					UI.Notify("Alan: Stocks just Increased");
					UI.Notify("Max Stocks: " + maxstocks);
					UI.Notify("Annual Gain: $" + increaseGain.ToString("N"));
					UI.Notify("Mission Gain: " + profitMargin + "%");
					UI.Notify("Stock Value: $" + stocksvalue.ToString("N"));
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, MarkerExit) < 3f)
			{
				DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~ to Exit ARB");
			}
			if (World.GetDistance(Game.Player.Character.Position, VehicleBayMarker) < 3f)
			{
				DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~ to Enter Second Vehicle Bay");
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMenuSpawn) < 2f)
			{
				DisplayHelpTextThisFrame("Press  ~INPUT_CONTEXT~ to Open Menu");
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMenuSpawn) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GarageMenuSpawn, Vector3.Zero, Vector3.Zero, new Vector3(3f, 3f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, new Vector3(-92f, 6589f, 28f)) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, new Vector3(-92f, 6589f, 28f), Vector3.Zero, Vector3.Zero, new Vector3(3f, 3f, 1f), MarkerColor);
			}
			if (World.GetDistance(Game.Player.Character.Position, MenuMarker) < 2f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to Open Menu");
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaExit) < 200f && Game.Player.Character.Position.Z > 120f && Game.Player.Character.Position.Z < 175f)
			{
				if (TowerBlip3 == null)
				{
					TowerBlip3 = World.CreateBlip(ArenaExit);
					Function.Call(Hash._0xDF735600A4696DAF, new InputArgument[2] { TowerBlip3, 269 });
					Function.Call(Hash._0x03D7FB09E75D6B7E, new InputArgument[2] { TowerBlip3, 8 });
					TowerBlip3.Name = "Arena War Business (Workshop Teleport)";
				}
				else
				{
					TowerBlip3.Alpha = 255;
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaExit) > 200f && TowerBlip3 != null)
			{
				TowerBlip3.Alpha = 0;
			}
		}

		private void DisplayHelpTextThisFrame(string text)
		{
			InputArgument[] arguments = new InputArgument[1] { "STRING" };
			Function.Call(Hash._0x8509B634FBE7DA11, arguments);
			InputArgument[] arguments2 = new InputArgument[1] { text };
			Function.Call(Hash._0x6C188BE134E074AA, arguments2);
			InputArgument[] arguments3 = new InputArgument[4] { 0, 0, 1, -1 };
			Function.Call(Hash._0x238FFE5C7B0498A6, arguments3);
		}

		public void LoadDystopian_4()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_02" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena ");
		}

		public void LoadDystopian_5()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_02" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena ");
		}

		public void LoadDystopian_3()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_03" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadDystopian_2()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_02" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadDystopian_10()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_10" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadDystopian_7()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_07" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadDystopian_8()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_08" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadDystopian_12()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Dystopian_04" });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_12" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Dystopian_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_dystopian_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadScifi_2()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_02" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_scifi_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_scifi" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadScifi_4()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_04" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_scifi_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_scifi" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadScifi_5()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_scifi_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_scifi" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadScifi_10()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_10" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_scifi_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_scifi" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadWasteland_2()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_02" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_CentreLine_Wasteland_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_wasteland" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadScifi_9()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_09" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Scifi_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_centreline_scifi_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_scifi" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadWasteland_9()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_09" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_CentreLine_Wasteland_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_wasteland" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadWasteland_4()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_04" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_CentreLine_Wasteland_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_wasteland" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadWasteland_5()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_CentreLine_Wasteland_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_wasteland" });
			UI.Notify("Loaded Arena 2");
		}

		public void LoadWasteland_7()
		{
			UI.Notify("test");
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			UI.Notify("test1");
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
			Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num });
			for (int i = 0; i < NStadium.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					NStadium[i]
				});
			}
			UI.Notify("test2");
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Crowd_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_a" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_b" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_c" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Team_band_d" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_07" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Pit_Fence_Oval" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Wasteland_Scene" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_CentreLine_Wasteland_05" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Turrets_wasteland" });
			UI.Notify("Loaded Arena 2");
		}

		private void FireGun(Vector3 Source, Ped Owner, Vector3 Target)
		{
			Model model = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { "VEHICLE_WEAPON_TURRET_TECHNICAL" });
			if (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
			{
				Function.Call(Hash._0x5443438F033E29C3, new InputArgument[1] { model });
				while (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
				{
					Script.Wait(0);
				}
			}
			World.ShootBullet(Source, Target, Owner, model, 3);
			World.ShootBullet(Source, Target, Owner, model, 3);
			World.ShootBullet(Source, Target, Owner, model, 3);
		}

		private void FireMissile(Vector3 Source, Ped Owner, Vector3 Target)
		{
			Model model = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { "WEAPON_AIRSTRIKE_ROCKET" });
			if (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
			{
				Function.Call(Hash._0x5443438F033E29C3, new InputArgument[1] { model });
				while (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
				{
					Script.Wait(0);
				}
			}
			World.ShootBullet(Source, Target, Game.Player.Character, model, 15000);
			World.ShootBullet(Source, Target, Game.Player.Character, model, 15000);
			World.ShootBullet(Source, Target, Game.Player.Character, model, 15000);
			UI.Notify("Firing missile");
		}

		private void FireMine(Vector3 Source, Ped Owner)
		{
			UI.Notify("player hit mine");
			Model model = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { "VEHICLE_WEAPON_NOSE_TURRET_VALKYRIE" });
			if (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
			{
				Function.Call(Hash._0x5443438F033E29C3, new InputArgument[1] { model });
				while (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
				{
					Script.Wait(0);
				}
			}
			Vector3 targetPosition = Source;
			targetPosition.Z -= 5f;
			World.ShootBullet(Source, targetPosition, Owner, model, 25000);
		}

		private void FireTrap(Vector3 Source, Ped Owner)
		{
			UI.Notify("player hit Trap");
			Model model = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { "DIR_FLAME_EXPLODE" });
			if (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
			{
				Function.Call(Hash._0x5443438F033E29C3, new InputArgument[1] { model });
				while (!Function.Call<bool>(Hash._0x36E353271F0E90EE, new InputArgument[1] { model }))
				{
					Script.Wait(0);
				}
			}
			Vector3 targetPosition = Source;
			targetPosition.Z -= 5f;
			World.ShootBullet(Source, targetPosition, Owner, model, 15000);
			World.ShootBullet(Source, targetPosition, Owner, model, 15000);
			World.ShootBullet(Source, targetPosition, Owner, model, 15000);
			World.ShootBullet(Source, targetPosition, Owner, model, 25000);
			World.ShootBullet(Source, targetPosition, Owner, model, 25000);
			World.ShootBullet(Source, targetPosition, Owner, model, 25000);
		}

		public void Firemissile()
		{
			Random random = new Random();
			int num = random.Next(1, 60);
			Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
			if (num < 10)
			{
				FireMissile(new Vector3(2718f, -3870f, 154f), ped, Game.Player.Character.Position);
			}
			if (num > 10 && num < 20)
			{
				FireMissile(new Vector3(2629f, -3805f, 154f), ped, Game.Player.Character.Position);
			}
			if (num > 20 && num < 30)
			{
				FireMissile(new Vector3(2712f, -3717f, 154f), ped, Game.Player.Character.Position);
			}
			if (num > 30 && num < 40)
			{
				FireMissile(new Vector3(2884f, -3722f, 154f), ped, Game.Player.Character.Position);
			}
			if (num > 40 && num < 50)
			{
				FireMissile(new Vector3(2970f, -3799f, 154f), ped, Game.Player.Character.Position);
			}
			if (num > 50 && num <= 60)
			{
				FireMissile(new Vector3(2886f, -3883f, 154f), ped, Game.Player.Character.Position);
			}
			ped.Delete();
		}

		public void Firemissile4_1()
		{
			Random random = new Random();
			int num = random.Next(1, 5);
			if (num == 1)
			{
				TargettoFireAt = Game.Player.Character.Position;
			}
			if (num == 2 && VtoGet != null)
			{
				TargettoFireAt = VtoGet.Position;
			}
			if (num == 3 && VtoGet1 != null)
			{
				TargettoFireAt = VtoGet1.Position;
			}
			if (num == 4 && VtoGet2 != null)
			{
				TargettoFireAt = VtoGet2.Position;
			}
			if (num == 5 && VtoGet3 != null)
			{
				TargettoFireAt = VtoGet3.Position;
			}
			Vector3 targettoFireAt = TargettoFireAt;
			if (true)
			{
				Random random2 = new Random();
				int num2 = random2.Next(1, 60);
				Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
				if (num2 < 10)
				{
					FireMissile(new Vector3(2718f, -3870f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 10 && num2 < 20)
				{
					FireMissile(new Vector3(2629f, -3805f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 20 && num2 < 30)
				{
					FireMissile(new Vector3(2712f, -3717f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 30 && num2 < 40)
				{
					FireMissile(new Vector3(2884f, -3722f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 40 && num2 < 50)
				{
					FireMissile(new Vector3(2970f, -3799f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 50 && num2 <= 60)
				{
					FireMissile(new Vector3(2886f, -3883f, 154f), ped, TargettoFireAt);
				}
				ped.Delete();
			}
		}

		public void Firemissile4_4()
		{
			Random random = new Random();
			int num = random.Next(1, 5);
			float distance = random.Next(5, 20);
			if (num == 1)
			{
				TargettoFireAt = Game.Player.Character.Position;
			}
			if (num == 2 && VtoGet != null)
			{
				TargettoFireAt = VtoGet.Position;
			}
			if (num == 3 && VtoGet1 != null)
			{
				TargettoFireAt = VtoGet1.Position;
			}
			if (num == 4 && VtoGet2 != null)
			{
				TargettoFireAt = VtoGet2.Position;
			}
			if (num == 5 && VtoGet3 != null)
			{
				TargettoFireAt = VtoGet3.Position;
			}
			Vector3 targettoFireAt7 = TargettoFireAt;
			if (true)
			{
				Random random2 = new Random();
				int num2 = random2.Next(1, 60);
				Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
				if (num2 < 10)
				{
					Vector3 source = new Vector3(2718f, -3870f, 154f);
					Vector3 targettoFireAt = TargettoFireAt;
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
				}
				if (num2 > 10 && num2 < 20)
				{
					Vector3 source2 = new Vector3(2629f, -3805f, 154f);
					Vector3 targettoFireAt2 = TargettoFireAt;
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
				}
				if (num2 > 20 && num2 < 30)
				{
					Vector3 source3 = new Vector3(2712f, -3717f, 154f);
					Vector3 targettoFireAt3 = TargettoFireAt;
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
				}
				if (num2 > 30 && num2 < 40)
				{
					Vector3 source4 = new Vector3(2884f, -3722f, 154f);
					Vector3 targettoFireAt4 = TargettoFireAt;
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
				}
				if (num2 > 40 && num2 < 50)
				{
					Vector3 source5 = new Vector3(2970f, -3799f, 154f);
					Vector3 targettoFireAt5 = TargettoFireAt;
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
				}
				if (num2 > 50 && num2 <= 60)
				{
					Vector3 source6 = new Vector3(2886f, -3883f, 154f);
					Vector3 targettoFireAt6 = TargettoFireAt;
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
				}
				ped.Delete();
			}
		}

		public void Firemissile4_8()
		{
			Random random = new Random();
			int num = random.Next(1, 5);
			float distance = random.Next(5, 20);
			if (num == 1)
			{
				TargettoFireAt = Game.Player.Character.Position;
			}
			if (num == 2 && VtoGet != null)
			{
				TargettoFireAt = VtoGet.Position;
			}
			if (num == 3 && VtoGet1 != null)
			{
				TargettoFireAt = VtoGet1.Position;
			}
			if (num == 4 && VtoGet2 != null)
			{
				TargettoFireAt = VtoGet2.Position;
			}
			if (num == 5 && VtoGet3 != null)
			{
				TargettoFireAt = VtoGet3.Position;
			}
			Vector3 targettoFireAt7 = TargettoFireAt;
			if (true)
			{
				Random random2 = new Random();
				int num2 = random2.Next(1, 60);
				Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
				if (num2 < 10)
				{
					Vector3 source = new Vector3(-42f, -871f, 1014f);
					Vector3 targettoFireAt = TargettoFireAt;
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt.Around(distance);
					FireMissile(source, ped, TargettoFireAt);
				}
				if (num2 > 10 && num2 < 20)
				{
					Vector3 source2 = new Vector3(-42f, -871f, 1014f);
					Vector3 targettoFireAt2 = TargettoFireAt;
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt2.Around(distance);
					FireMissile(source2, ped, TargettoFireAt);
				}
				if (num2 > 20 && num2 < 30)
				{
					Vector3 source3 = new Vector3(-42f, -871f, 1014f);
					Vector3 targettoFireAt3 = TargettoFireAt;
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt3.Around(distance);
					FireMissile(source3, ped, TargettoFireAt);
				}
				if (num2 > 30 && num2 < 40)
				{
					Vector3 source4 = new Vector3(-42f, -871f, 1014f);
					Vector3 targettoFireAt4 = TargettoFireAt;
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt4.Around(distance);
					FireMissile(source4, ped, TargettoFireAt);
				}
				if (num2 > 40 && num2 < 50)
				{
					Vector3 source5 = new Vector3(-42f, -871f, 1014f);
					Vector3 targettoFireAt5 = TargettoFireAt;
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt5.Around(distance);
					FireMissile(source5, ped, TargettoFireAt);
				}
				if (num2 > 50 && num2 <= 60)
				{
					Vector3 source6 = new Vector3(-42f, -871f, 1014f);
					Vector3 targettoFireAt6 = TargettoFireAt;
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
					Script.Wait(5);
					TargettoFireAt = targettoFireAt6.Around(distance);
					FireMissile(source6, ped, TargettoFireAt);
				}
				ped.Delete();
			}
		}

		public void Firemissile4_12(Vector3 Pos, Vector3 FirePos)
		{
			Random random = new Random();
			int num = random.Next(1, 5);
			float distance = random.Next(2, 7);
			TargettoFireAt = Pos;
			Vector3 targettoFireAt2 = TargettoFireAt;
			if (true)
			{
				Random random2 = new Random();
				int num2 = random2.Next(1, 60);
				Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
				Vector3 targettoFireAt = TargettoFireAt;
				TargettoFireAt = targettoFireAt.Around(distance);
				FireGun(FirePos, ped, TargettoFireAt);
				TargettoFireAt = targettoFireAt.Around(distance);
				FireGun(FirePos, ped, TargettoFireAt);
				TargettoFireAt = targettoFireAt.Around(distance);
				FireGun(FirePos, ped, TargettoFireAt);
				TargettoFireAt = targettoFireAt.Around(distance);
				FireGun(FirePos, ped, TargettoFireAt);
				ped.Delete();
			}
		}

		public void Firemissile4_16()
		{
			Random random = new Random();
			int num = random.Next(1, 5);
			float distance = random.Next(1, 5);
			TargettoFireAt = Game.Player.Character.Position;
			Vector3 targettoFireAt7 = TargettoFireAt;
			if (1 == 0)
			{
				return;
			}
			Random random2 = new Random();
			int num2 = random2.Next(1, 60);
			Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
			Vector3 vector = new Vector3(2718f, -3870f, 154f);
			Vector3 vector2 = new Vector3(2629f, -3805f, 154f);
			Vector3 vector3 = new Vector3(2718f, -3870f, 154f);
			Vector3 vector4 = new Vector3(2884f, -3722f, 154f);
			Vector3 position = new Vector3(2970f, -3799f, 154f);
			Vector3 vector5 = new Vector3(2886f, -3883f, 154f);
			Vehicle[] nearbyVehicles = World.GetNearbyVehicles(vector, 100f);
			Vehicle[] nearbyVehicles2 = World.GetNearbyVehicles(vector2, 100f);
			Vehicle[] nearbyVehicles3 = World.GetNearbyVehicles(vector3, 100f);
			Vehicle[] nearbyVehicles4 = World.GetNearbyVehicles(vector4, 100f);
			Vehicle[] nearbyVehicles5 = World.GetNearbyVehicles(position, 100f);
			Vehicle[] nearbyVehicles6 = World.GetNearbyVehicles(vector5, 100f);
			if (nearbyVehicles.Length != 0)
			{
				Vehicle[] array = nearbyVehicles;
				foreach (Vehicle vehicle in array)
				{
					if (vehicle != null)
					{
						Vector3 targettoFireAt = TargettoFireAt;
						TargettoFireAt = targettoFireAt.Around(distance);
						Random random3 = new Random();
						int num3 = random3.Next(0, nearbyVehicles.Length - 1);
						Vector3 vector6 = vector;
						vector6 = new Vector3(vector6.X, vector6.Y, vector6.Z + 5f);
						FireGun(vector, ped, TargettoFireAt);
					}
				}
			}
			if (nearbyVehicles2.Length != 0)
			{
				Vehicle[] array2 = nearbyVehicles2;
				foreach (Vehicle vehicle2 in array2)
				{
					if (vehicle2 != null)
					{
						Vector3 targettoFireAt2 = TargettoFireAt;
						TargettoFireAt = targettoFireAt2.Around(distance);
						Random random4 = new Random();
						int num4 = random4.Next(0, nearbyVehicles2.Length - 1);
						Vector3 vector7 = vector2;
						vector7 = new Vector3(vector7.X, vector7.Y, vector7.Z + 5f);
						FireGun(vector2, ped, TargettoFireAt);
					}
				}
			}
			if (nearbyVehicles3.Length != 0)
			{
				Vehicle[] array3 = nearbyVehicles3;
				foreach (Vehicle vehicle3 in array3)
				{
					if (vehicle3 != null)
					{
						Vector3 targettoFireAt3 = TargettoFireAt;
						TargettoFireAt = targettoFireAt3.Around(distance);
						Random random5 = new Random();
						int num5 = random5.Next(0, nearbyVehicles3.Length - 1);
						Vector3 vector8 = vector3;
						vector8 = new Vector3(vector8.X, vector8.Y, vector8.Z + 5f);
						FireGun(vector3, ped, TargettoFireAt);
					}
				}
			}
			if (nearbyVehicles4.Length != 0)
			{
				Vehicle[] array4 = nearbyVehicles4;
				foreach (Vehicle vehicle4 in array4)
				{
					if (vehicle4 != null)
					{
						Vector3 targettoFireAt4 = TargettoFireAt;
						TargettoFireAt = targettoFireAt4.Around(distance);
						Random random6 = new Random();
						int num6 = random6.Next(0, nearbyVehicles4.Length - 1);
						Vector3 vector9 = vector4;
						vector9 = new Vector3(vector9.X, vector9.Y, vector9.Z + 5f);
						FireGun(vector4, ped, TargettoFireAt);
					}
				}
			}
			if (nearbyVehicles4.Length != 0)
			{
				Vehicle[] array5 = nearbyVehicles4;
				foreach (Vehicle vehicle5 in array5)
				{
					if (vehicle5 != null)
					{
						Vector3 targettoFireAt5 = TargettoFireAt;
						TargettoFireAt = targettoFireAt5.Around(distance);
						Random random7 = new Random();
						int num7 = random7.Next(0, nearbyVehicles4.Length - 1);
						Vector3 vector10 = vector4;
						vector10 = new Vector3(vector10.X, vector10.Y, vector10.Z + 5f);
						FireGun(vector4, ped, TargettoFireAt);
					}
				}
			}
			if (nearbyVehicles6.Length != 0)
			{
				Vehicle[] array6 = nearbyVehicles4;
				foreach (Vehicle vehicle6 in array6)
				{
					if (vehicle6 != null)
					{
						Vector3 targettoFireAt6 = TargettoFireAt;
						TargettoFireAt = targettoFireAt6.Around(distance);
						Random random8 = new Random();
						int num8 = random8.Next(0, nearbyVehicles6.Length - 1);
						Vector3 vector11 = vector5;
						vector11 = new Vector3(vector11.X, vector11.Y, vector11.Z + 5f);
						FireGun(vector5, ped, TargettoFireAt);
					}
				}
			}
			ped.Delete();
		}

		public void Firemissile8_1()
		{
			Random random = new Random();
			int num = random.Next(1, 9);
			if (num == 1)
			{
				TargettoFireAt = Game.Player.Character.Position;
			}
			if (num == 2 && VtoGet != null)
			{
				TargettoFireAt = VtoGet.Position;
			}
			if (num == 3 && VtoGet1 != null)
			{
				TargettoFireAt = VtoGet1.Position;
			}
			if (num == 4 && VtoGet2 != null)
			{
				TargettoFireAt = VtoGet2.Position;
			}
			if (num == 5 && VtoGet3 != null)
			{
				TargettoFireAt = VtoGet3.Position;
			}
			if (num == 6 && VtoGet4 != null)
			{
				TargettoFireAt = VtoGet4.Position;
			}
			if (num == 7 && VtoGet5 != null)
			{
				TargettoFireAt = VtoGet5.Position;
			}
			if (num == 8 && VtoGet6 != null)
			{
				TargettoFireAt = VtoGet6.Position;
			}
			if (num == 9 && VtoGet7 != null)
			{
				TargettoFireAt = VtoGet7.Position;
			}
			Vector3 targettoFireAt = TargettoFireAt;
			if (true)
			{
				Random random2 = new Random();
				int num2 = random2.Next(1, 60);
				Ped ped = World.CreatePed(PedHash.Fabien, new Vector3(0f, 0f, 0f), 90f);
				if (num2 < 10)
				{
					FireMissile(new Vector3(2718f, -3870f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 10 && num2 < 20)
				{
					FireMissile(new Vector3(2629f, -3805f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 20 && num2 < 30)
				{
					FireMissile(new Vector3(2712f, -3717f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 30 && num2 < 40)
				{
					FireMissile(new Vector3(2884f, -3722f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 40 && num2 < 50)
				{
					FireMissile(new Vector3(2970f, -3799f, 154f), ped, TargettoFireAt);
				}
				if (num2 > 50 && num2 <= 60)
				{
					FireMissile(new Vector3(2886f, -3883f, 154f), ped, TargettoFireAt);
				}
				ped.Delete();
			}
		}

		public void GetAJackPot()
		{
			Random random = new Random();
			int num = random.Next(1, 1500);
			if (num < 50)
			{
				Game.Player.Money += 1000000;
				UI.Notify("Alan : You won $1M Dollas!");
			}
			if (num > 50 && num <= 80)
			{
				CliqueBought = 1;
				Config.SetValue("Vehicles", "CliqueBought", CliqueBought);
				UI.Notify("Alan : You won a Clique!");
			}
			if (num > 80 && num <= 120)
			{
				ItaligtoBought = 1;
				Config.SetValue("Vehicles", "ItaligtoBought", ItaligtoBought);
				UI.Notify("Alan : You won a Itali GTO!");
			}
			if (num > 120 && num <= 170)
			{
				TulipBought = 1;
				Config.SetValue("Vehicles", "TulipBought", TulipBought);
				UI.Notify("Alan : You won a Tulip");
			}
			if (num > 170 && num <= 220)
			{
				VamosBought = 1;
				Config.SetValue("Vehicles", "VamosBought", VamosBought);
				UI.Notify("Alan : You won a Vamos");
			}
			if (num > 220 && num <= 240)
			{
				SchlagenBought = 1;
				Config.SetValue("Vehicles", "SchlagenBought", SchlagenBought);
				UI.Notify("Alan : You won a Schlagen");
			}
			if (num > 240 && num <= 250)
			{
				DeviantBought = 1;
				Config.SetValue("Vehicles", "DeviantBought", DeviantBought);
				UI.Notify("Alan : You won a Deviant!");
			}
			if (num > 250 && num <= 290)
			{
				TorosBought = 1;
				Config.SetValue("Vehicles", "TorosBought", TorosBought);
				UI.Notify("Alan : You won a Toros!");
			}
			if (num > 290 && num <= 295)
			{
				DevesteBought = 1;
				Config.SetValue("Vehicles", "DevesteBought", DevesteBought);
				UI.Notify("Alan : You won a Deveste!");
			}
			if (num > 295 && num <= 330)
			{
				stockscount *= 2;
				UI.Notify("Alan : You won Double current Stocks!");
			}
			if (num > 330 && num <= 350)
			{
				stockscount *= 3;
				UI.Notify("Alan : You won Tripple current Stocks!");
			}
			if (num > 350 && num <= 355)
			{
				stockscount *= 10;
				UI.Notify("Alan : You won 10x current Stocks!");
			}
			if (num > 355 && num <= 375)
			{
				Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
				{
					Game.Player.Character,
					2939590305u,
					999999,
					true,
					true
				});
				UI.Notify("Alan : You won an Up-An-Atomizer!");
			}
			if (num > 375 && num <= 390)
			{
				Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
				{
					Game.Player.Character,
					1198256469,
					999999,
					true,
					true
				});
				UI.Notify("Alan : You won an Unholy Hellbringer!");
			}
			if (num > 390 && num <= 400)
			{
				Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
				{
					Game.Player.Character,
					3056410471u,
					999999,
					true,
					true
				});
				UI.Notify("Alan : You won an Widow Maker!");
			}
			if (num > 390 && num <= 400)
			{
				FutureShockDominatorBought = 1;
				Config.SetValue("Vehicles", "FutureShockDominatorBought", FutureShockDominatorBought);
				UI.Notify("Alan : You won a Future Shock Dominator!");
			}
			if (num > 400 && num <= 420)
			{
				ApocalypseZR380Bought = 1;
				Config.SetValue("Vehicles", "ApocalypseZR380Bought", ApocalypseZR380Bought);
				UI.Notify("Alan : You won a Appocalypse ZR380!");
			}
			if (num > 420 && num <= 450)
			{
				NightmareImpalerBought = 1;
				Config.SetValue("Vehicles", "NightmareImpalerBought", NightmareImpalerBought);
				UI.Notify("Alan : You won a Apocalypse ZR380!");
			}
			if (num > 450 && num <= 480)
			{
				NightmareImperatorBought = 1;
				Config.SetValue("Vehicles", "NightmareImperatorBought", NightmareImperatorBought);
				UI.Notify("Alan : You won a Nightmare Imperator!");
			}
			if (num > 480 && num <= 500)
			{
				FutureShockMonsterBought = 1;
				Config.SetValue("Vehicles", "FutureShockMonsterBought", FutureShockMonsterBought);
				UI.Notify("Alan : You won a Future Shock Sasquatch!");
			}
			if (num > 480 && num <= 540)
			{
				NightmareBruiserBought = 1;
				Config.SetValue("Vehicles", "NightmareBruiserBought", NightmareBruiserBought);
				UI.Notify("Alan : You won a Nightmare Bruiser!");
			}
			if (num > 540 && num <= 580)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.AssaultrifleMk2, 9999, true, true);
				UI.Notify("Alan : You won a Assault Rifle MK2!");
			}
			if (num > 580 && num <= 600)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.CarbineRifleMk2, 9999, true, true);
				UI.Notify("Alan : You won a Carbine Rifle MK2!");
			}
			if (num > 600 && num <= 630)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.CombatMGMk2, 9999, true, true);
				UI.Notify("Alan : You won a Combat MG MK2!");
			}
			if (num > 630 && num <= 660)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.HeavySniperMk2, 9999, true, true);
				UI.Notify("Alan : You won a Heavy Sniper MK2!");
			}
			if (num > 630 && num <= 660)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.MarksmanRifleMk2, 9999, true, true);
				UI.Notify("Alan : You won a Marksman Rifle MK2!");
			}
			if (num > 660 && num <= 680)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.PumpShotgunMk2, 9999, true, true);
				UI.Notify("Alan : You won a Pump Shotgun MK2!");
			}
			if (num > 680 && num <= 710)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.RevolverMk2, 9999, true, true);
				UI.Notify("Alan : You won a Revolver MK2!");
			}
			if (num > 710 && num <= 740)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.SMGMk2, 9999, true, true);
				UI.Notify("Alan : You won a SMG MK2!");
			}
			if (num > 740 && num <= 760)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.SpecialCarbineMk2, 9999, true, true);
				UI.Notify("Alan : You won a Special Carbine MK2!");
			}
			if (num > 760 && num <= 790)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.SNSPistolMk2, 9999, true, true);
				UI.Notify("Alan : You won a SNS Pistol MK2!");
			}
			if (num > 790 && num <= 820)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.PistolMk2, 9999, true, true);
				UI.Notify("Alan : You won a Pistol MK2!");
			}
			if (num > 820 && num <= 830)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.Minigun, 9999, true, true);
				UI.Notify("Alan : You won a Minigun!");
			}
			if (num > 830 && num <= 850)
			{
				Game.Player.Character.Weapons.Give(WeaponHash.GrenadeLauncher, 9999, true, true);
				UI.Notify("Alan : You won a Grenade Launcher!");
			}
			if (num > 850 && num <= 870)
			{
				Game.Player.Character.Armor = Game.Player.MaxArmor;
				Game.Player.Character.Health = Game.Player.Character.MaxHealth;
				UI.Notify("Alan : You won a full health and armour!");
			}
			if (num > 870 && num <= 900)
			{
				Game.Player.Character.Health = Game.Player.Character.MaxHealth;
				UI.Notify("Alan : You won a full health!");
			}
			if (num > 900 && num <= 940)
			{
				Game.Player.Character.Armor = Game.Player.MaxArmor;
				UI.Notify("Alan : You won a full armour!");
			}
			if (num > 940 && num <= 960)
			{
				Game.Player.WantedLevel = 0;
				UI.Notify("Alan : You won a Police Bribe, Wanted level is now 0!");
			}
			if (num > 960 && num <= 1000)
			{
				FutureShockDeathbikeBought = 1;
				Config.SetValue("Vehicles", "FutureShockDeathbikeBought", FutureShockDeathbikeBought);
				UI.Notify("Alan : You won a Future Shock Deathbike!");
			}
			else if (num > 1000)
			{
				UI.Notify("Alan : You won a nothing...");
			}
			UI.Notify("Prize : " + num);
			Config.Save();
		}

		private void OnKeyDown()
		{
			if (Game.IsControlJustPressed(2, GTA.Control.ThrowGrenade))
			{
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && World.GetDistance(Game.Player.Character.Position, EnterGarageMarker) < 2f)
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				PlayerGaragemainMenu.set_Visible(!PlayerGarageMenu.get_Visible());
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && isInGarage && World.GetDistance(Game.Player.Character.Position, RemoveMarker) < 2f)
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				RemoveMenu.set_Visible(!RemoveMenu.get_Visible());
			}
			if (isInGarage)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Cover) && Game.Player.Character.CurrentVehicle != null)
				{
					Vehicle currentVehicle = Game.Player.Character.CurrentVehicle;
					if (Vehicle1 != null && currentVehicle == Vehicle1)
					{
						SC.LoadIniFile(path + "GarageA//Slot1.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle2 != null && currentVehicle == Vehicle2)
					{
						SC.LoadIniFile(path + "GarageA//Slot2.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle3 != null && currentVehicle == Vehicle3)
					{
						SC.LoadIniFile(path + "GarageA//Slot3.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle4 != null && currentVehicle == Vehicle4)
					{
						SC.LoadIniFile(path + "GarageA//Slot4.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle5 != null && currentVehicle == Vehicle5)
					{
						SC.LoadIniFile(path + "GarageA//Slot5.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle6 != null && currentVehicle == Vehicle6)
					{
						SC.LoadIniFile(path + "GarageA//Slot6.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle7 != null && currentVehicle == Vehicle7)
					{
						SC.LoadIniFile(path + "GarageA//Slot7.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle8 != null && currentVehicle == Vehicle8)
					{
						SC.LoadIniFile(path + "GarageA//Slot8.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle9 != null && currentVehicle == Vehicle9)
					{
						SC.LoadIniFile(path + "GarageA//Slot9.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
					if (Vehicle10 != null && currentVehicle == Vehicle10)
					{
						SC.LoadIniFile(path + "GarageA//Slot10.ini");
						SC.SaveWithoutDelete();
						UI.Notify("Alan Vehice Saved");
					}
				}
				if (Game.IsControlJustPressed(2, GTA.Control.Context) && Game.Player.Character.CurrentVehicle != null)
				{
					Vehicle currentVehicle2 = Game.Player.Character.CurrentVehicle;
					if (Vehicle1 != null && currentVehicle2 == Vehicle1)
					{
						Vehicle1 = null;
						LoadCarinToRealWorld2(Vehicle1);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle2 != null && currentVehicle2 == Vehicle2)
					{
						Vehicle2 = null;
						LoadCarinToRealWorld2(Vehicle2);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle3 != null && currentVehicle2 == Vehicle3)
					{
						Vehicle3 = null;
						LoadCarinToRealWorld2(Vehicle3);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle4 != null && currentVehicle2 == Vehicle4)
					{
						Vehicle4 = null;
						LoadCarinToRealWorld2(Vehicle4);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle5 != null && currentVehicle2 == Vehicle5)
					{
						Vehicle5 = null;
						LoadCarinToRealWorld2(Vehicle5);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle6 != null && currentVehicle2 == Vehicle6)
					{
						Vehicle6 = null;
						LoadCarinToRealWorld2(Vehicle6);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle7 != null && currentVehicle2 == Vehicle7)
					{
						Vehicle7 = null;
						LoadCarinToRealWorld2(Vehicle7);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle8 != null && currentVehicle2 == Vehicle8)
					{
						Vehicle8 = null;
						LoadCarinToRealWorld2(Vehicle8);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle9 != null && currentVehicle2 == Vehicle9)
					{
						Vehicle9 = null;
						LoadCarinToRealWorld2(Vehicle9);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
					if (Vehicle10 != null && currentVehicle2 == Vehicle10)
					{
						Vehicle10 = null;
						LoadCarinToRealWorld2(Vehicle10);
						DisplayHelpTextThisFrame("Press E to use this vehicle");
					}
				}
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && World.GetDistance(Game.Player.Character.Position, EnterMarkerA) < 2f)
			{
				GarageNum = "GarageA";
				DestoryCars();
				Game.Player.Character.Position = ExitMarker;
				CreateCars("GarageA");
				Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "imp_dt1_11_cargarage_b" });
				Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "imp_dt1_11_cargarage_c" });
			}
			if (Clique != null && Clique.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle3 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle3);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Clique, "Clique");
				}
			}
			if (Italigto != null && Italigto.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle4 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle4);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Italigto, "Italigto");
				}
			}
			if (RcBandito != null && RcBandito.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle5 = Game.Player.Character.CurrentVehicle;
						RcBandito.FreezePosition = false;
						isinsecondVehicleBay = false;
						LoadCarinToRealWorld(currentVehicle5);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", RcBandito, "RcBandito");
				}
			}
			if (Tulip != null && Tulip.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle6 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle6);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Tulip, "Tulip");
				}
			}
			if (Vamos != null && Vamos.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle7 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle7);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Vamos, "Vamos");
				}
			}
			if (Schlagen != null && Schlagen.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle8 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle8);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Schlagen, "Schlagen");
				}
			}
			if (Deviant != null && Deviant.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle9 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle9);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Deviant, "Deviant");
				}
			}
			if (Toros != null && Toros.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle10 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle10);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Toros, "Toros");
				}
			}
			if (Deveste != null && Deveste.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle11 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle11);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					SaveLocalcar("Car", Deveste, "Deveste");
				}
			}
			if (Cerberus != null && Cerberus.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle12 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle12);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Cerberus.DisplayName == "cerberus")
					{
						SaveLocalcar("1Apocalypse", Cerberus, "Cerberus");
					}
					if (Cerberus.DisplayName == "cerberus3")
					{
						SaveLocalcar("2NIghtmare", Cerberus, "Cerberus");
					}
					if (Cerberus.DisplayName == "cerberus2")
					{
						SaveLocalcar("3FutureShock", Cerberus, "Cerberus");
					}
					UI.Notify(Cerberus.DisplayName);
				}
			}
			if (Impaler != null && Impaler.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle13 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle13);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Impaler.DisplayName == "IMPALER2")
					{
						SaveLocalcar("1Apocalypse", Impaler, "Impaler");
					}
					if (Impaler.DisplayName == "IMPALER4")
					{
						SaveLocalcar("2NIghtmare", Impaler, "Impaler");
					}
					if (Impaler.DisplayName == "IMPALER3")
					{
						SaveLocalcar("3FutureShock", Impaler, "Impaler");
					}
				}
			}
			if (Issi != null && Issi.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle14 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle14);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Issi.DisplayName == "ISSI4")
					{
						SaveLocalcar("1Apocalypse", Issi, "Issi");
					}
					if (Issi.DisplayName == "ISSI6")
					{
						SaveLocalcar("2NIghtmare", Issi, "Issi");
					}
					if (Issi.DisplayName == "ISSI5")
					{
						SaveLocalcar("3FutureShock", Issi, "Issi");
					}
				}
			}
			if (Slamvan != null && Slamvan.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle15 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle15);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Slamvan.DisplayName == "SLAMVAN4")
					{
						SaveLocalcar("1Apocalypse", Slamvan, "Slamvan");
					}
					if (Slamvan.DisplayName == "SLAMVAN6")
					{
						SaveLocalcar("2NIghtmare", Slamvan, "Slamvan");
					}
					if (Slamvan.DisplayName == "SLAMVAN5")
					{
						SaveLocalcar("3FutureShock", Slamvan, "Slamvan");
					}
				}
			}
			if (Dominator != null && Dominator.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle16 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle16);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Dominator.DisplayName == "DOMINATOR4")
					{
						SaveLocalcar("1Apocalypse", Dominator, "Dominator");
					}
					if (Dominator.DisplayName == "DOMINATOR6")
					{
						SaveLocalcar("2NIghtmare", Dominator, "Dominator");
					}
					if (Dominator.DisplayName == "DOMINATOR5")
					{
						SaveLocalcar("3FutureShock", Dominator, "Dominator");
					}
				}
			}
			if (Deathbike != null && Deathbike.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle17 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle17);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Deathbike.DisplayName == "DEATHBIKE")
					{
						SaveLocalcar("1Apocalypse", Deathbike, "Deathbike");
					}
					if (Deathbike.DisplayName == "DEATHBIKE3")
					{
						SaveLocalcar("2NIghtmare", Deathbike, "Deathbike");
					}
					if (Deathbike.DisplayName == "DEATHBIKE2")
					{
						SaveLocalcar("3FutureShock", Deathbike, "Deathbike");
					}
				}
			}
			if (Imperator != null && Imperator.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle18 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle18);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Imperator.DisplayName == "IMPERATOR")
					{
						SaveLocalcar("1Apocalypse", Imperator, "Imperator");
					}
					if (Imperator.DisplayName == "IMPERATOR3")
					{
						SaveLocalcar("2NIghtmare", Imperator, "Imperator");
					}
					if (Imperator.DisplayName == "IMPERATOR2")
					{
						SaveLocalcar("3FutureShock", Imperator, "Imperator");
					}
				}
			}
			if (Monster != null && Monster.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle19 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle19);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Monster.DisplayName == "MONSTER3")
					{
						SaveLocalcar("1Apocalypse", Monster, "Monster");
					}
					if (Monster.DisplayName == "MONSTER5")
					{
						SaveLocalcar("2NIghtmare", Monster, "Monster");
					}
					if (Monster.DisplayName == "MONSTER4")
					{
						SaveLocalcar("3FutureShock", Monster, "Monster");
					}
					UI.Notify(Monster.DisplayName);
				}
			}
			if (Scarab != null && Scarab.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle20 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle20);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Scarab.DisplayName == "SCARAB")
					{
						SaveLocalcar("1Apocalypse", Scarab, "Scarab");
					}
					if (Scarab.DisplayName == "SCARAB2")
					{
						SaveLocalcar("3FutureShock", Scarab, "Scarab");
					}
					if (Scarab.DisplayName == "SCARAB3")
					{
						SaveLocalcar("2NIghtmare", Scarab, "Scarab");
					}
				}
			}
			if (Bruitus != null && Bruitus.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle21 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle21);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Bruitus.DisplayName == "BRUTUS")
					{
						SaveLocalcar("1Apocalypse", Bruitus, "Bruitus");
					}
					if (Bruitus.DisplayName == "BRUTUS3")
					{
						SaveLocalcar("2NIghtmare", Bruitus, "Bruitus");
					}
					if (Bruitus.DisplayName == "BRUTUS2")
					{
						SaveLocalcar("3FutureShock", Bruitus, "Bruitus");
					}
				}
			}
			if (ZR380 != null && ZR380.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle22 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle22);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (ZR380.DisplayName == "ZR380")
					{
						SaveLocalcar("1Apocalypse", ZR380, "ZR380");
					}
					if (ZR380.DisplayName == "ZR3803")
					{
						SaveLocalcar("2NIghtmare", ZR380, "ZR380");
					}
					if (ZR380.DisplayName == "ZR3802")
					{
						SaveLocalcar("3FutureShock", ZR380, "ZR380");
					}
					UI.Notify("DN " + ZR380.DisplayName);
				}
			}
			if (Bruiser != null && Bruiser.GetPedOnSeat(VehicleSeat.Driver).IsPlayer)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Vehicle currentVehicle23 = Game.Player.Character.CurrentVehicle;
						LoadCarinToRealWorld(currentVehicle23);
					}
				}
				else if (Game.IsControlJustPressed(2, GTA.Control.Cover))
				{
					if (Bruiser.DisplayName == "BRUISER")
					{
						SaveLocalcar("1Apocalypse", Bruiser, "Bruiser");
					}
					if (Bruiser.DisplayName == "BRUISER3")
					{
						SaveLocalcar("2NIghtmare", Bruiser, "Bruiser");
					}
					if (Bruiser.DisplayName == "BRUISER2")
					{
						SaveLocalcar("3FutureShock", Bruiser, "Bruiser");
					}
					UI.Notify("DN " + Bruiser.DisplayName);
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, DrinkPos) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				Ped character = Game.Player.Character;
				Function.Call(Hash._0x142A02425FF02BD9, new InputArgument[4] { character, "WORLD_HUMAN_DRINKING", 1, true });
				Script.Wait(9000);
				Game.Player.Character.Task.ClearAll();
				Game.Player.Character.Task.ClearAllImmediately();
			}
			if (World.GetDistance(Game.Player.Character.Position, Sitpos) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				if (!IsSitting)
				{
					Game.FadeScreenOut(500);
					Script.Wait(500);
					IsSitting = true;
					Game.Player.Character.FreezePosition = true;
					Game.Player.Character.Position = Sitpos;
					Game.Player.Character.Heading = 180f;
					Function.Call(Hash._0xB4EC2312F4E5B1F1, new InputArgument[1] { 0f });
					Function.Call(Hash._0x6D0858B8EDFD2B7D, new InputArgument[1] { 0f });
					Game.Player.Character.Task.PlayAnimation("anim@amb@office@seating@male@var_e@base@", "base", 8f, -1, true, -1f);
					Script.Wait(500);
					Game.FadeScreenIn(500);
				}
				else if (IsSitting)
				{
					Game.Player.Character.FreezePosition = true;
					Game.FadeScreenOut(500);
					Script.Wait(500);
					IsSitting = false;
					Game.Player.Character.Position = new Vector3(209f, 5165f, -85f);
					Game.Player.Character.Heading = 117.5f;
					Function.Call(Hash._0xB4EC2312F4E5B1F1, new InputArgument[1] { 0f });
					Function.Call(Hash._0x6D0858B8EDFD2B7D, new InputArgument[1] { 0f });
					Game.Player.Character.Task.ClearAnimation("anim@amb@office@seating@male@var_e@base@", "base");
					Game.Player.Character.FreezePosition = false;
					Script.Wait(500);
					Game.FadeScreenIn(500);
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, CharacterSwitchPos) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				if (Game.Player.Character.Model == PedHash.Franklin)
				{
					Game.Player.ChangeModel(PedHash.Michael);
				}
				else if (Game.Player.Character.Model == PedHash.Michael)
				{
					Game.Player.ChangeModel(PedHash.Trevor);
				}
				else if (Game.Player.Character.Model == PedHash.Trevor)
				{
					Game.Player.ChangeModel(PedHash.Franklin);
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, SleepPos) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				Game.Player.Character.FreezePosition = true;
				Game.FadeScreenOut(500);
				Script.Wait(500);
				Function.Call(Hash._0xC8CA9670B9D83B3B, new InputArgument[3] { 6, 0, 0 });
				Game.Player.WantedLevel = 0;
				Function.Call(Hash._0x8FE22675A5A45817, new InputArgument[1] { Game.Player.Character });
				Function.Call(Hash._0x9C720776DAA43E7E, new InputArgument[1] { Game.Player.Character });
				Game.Player.Character.Position = SleepPos;
				Game.Player.Character.Heading = 248.15f;
				Function.Call(Hash._0xB4EC2312F4E5B1F1, new InputArgument[1] { 0f });
				Function.Call(Hash._0x6D0858B8EDFD2B7D, new InputArgument[1] { 0f });
				Game.Player.Character.FreezePosition = false;
				Script.Wait(1500);
				Game.FadeScreenIn(500);
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && World.GetDistance(Game.Player.Character.Position, JackpotTable) < 3f)
			{
				if (Game.Player.Money >= 250000)
				{
					Game.Player.Money -= 250000;
					UI.Notify("Rolling!");
					Vector3 pos = new Vector3(2796.08f, -3930.3f, 183f);
					Random random = new Random();
					int num = random.Next(1, 7);
					if (num == 1)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(3f, 2.8f, 2f), Color.Red);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(3f, 2.8f, 2f), Color.Green);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(3f, 2.8f, 2f), Color.Blue);
						UI.Notify("3");
						Script.Wait(400);
					}
					if (num == 2)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.DeepSkyBlue);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Magenta);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Yellow);
						UI.Notify("3");
						Script.Wait(400);
					}
					if (num == 3)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Violet);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.LightBlue);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Orange);
						UI.Notify("3");
						Script.Wait(400);
					}
					if (num == 4)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Orange);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.LimeGreen);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Magenta);
						UI.Notify("3");
						Script.Wait(400);
					}
					if (num == 5)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Red);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.White);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Blue);
						UI.Notify("3");
						Script.Wait(400);
					}
					if (num == 6)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Fuchsia);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Gainsboro);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.PapayaWhip);
						UI.Notify("3");
						Script.Wait(400);
					}
					if (num == 7)
					{
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.PeachPuff);
						UI.Notify("1");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Teal);
						UI.Notify("2");
						Script.Wait(400);
						World.DrawMarker(MarkerType.VerticalCylinder, pos, Vector3.Zero, Vector3.Zero, new Vector3(2.8f, 2.8f, 2f), Color.Indigo);
						UI.Notify("3");
						Script.Wait(400);
					}
					GetAJackPot();
				}
				else
				{
					UI.Notify("Alan : Come on boss, stop trying to steal from the rich!");
				}
			}
			if (Game.IsControlJustPressed(2, GTA.Control.LookBehind) && Game.Player.Character.CurrentVehicle != null)
			{
				UI.Notify("Rotation : " + Game.Player.Character.CurrentVehicle.Rotation);
				UI.Notify("Position : " + Game.Player.Character.CurrentVehicle.Position);
			}
			if (Game.IsControlJustPressed(2, GTA.Control.PhoneDown))
			{
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				if (World.GetDistance(Game.Player.Character.Position, GarageBMarkerOuside) < 2f)
				{
					EI.ReloadInterior();
					IsInInterior = false;
					DeleteVehicles();
					UI.Notify("test3D");
					isinsecondVehicleBay = true;
					Game.Player.Character.Position = ExitMarker3;
					LoadVehicles2();
				}
				if (World.GetDistance(Game.Player.Character.Position, ArenaEntry) < 2f)
				{
					EI.ReloadInterior();
					IsInInterior = false;
					DeleteVehicles();
					UI.Notify("test5A");
					Game.Player.Character.Position = ArenaExit;
					Random random2 = new Random();
					int num2 = random2.Next(1, 13);
					if (num2 == 1)
					{
						LoadDystopian_2();
					}
					if (num2 == 2)
					{
						LoadScifi_2();
					}
					if (num2 == 3)
					{
						LoadWasteland_2();
					}
					if (num2 == 4)
					{
						LoadWasteland_9();
					}
					if (num2 == 5)
					{
						LoadScifi_9();
					}
					if (num2 == 6)
					{
						LoadDystopian_3();
					}
					if (num2 == 7)
					{
						LoadDystopian_4();
					}
					if (num2 == 8)
					{
						LoadDystopian_10();
					}
					if (num2 == 9)
					{
						LoadDystopian_5();
					}
					if (num2 == 10)
					{
						LoadScifi_5();
					}
					if (num2 == 11)
					{
						LoadScifi_10();
					}
					if (num2 == 12)
					{
						LoadDystopian_7();
					}
					if (num2 == 13)
					{
						LoadWasteland_7();
					}
				}
				else if (World.GetDistance(Game.Player.Character.Position, ArenaExit) < 2f)
				{
					EI.ReloadInterior();
					DeleteVehicles();
					LoadVehicles();
					IsInInterior = true;
					isinsecondVehicleBay = false;
					isInGarage = false;
					Script.Wait(1);
					Game.Player.Character.Position = ArenaEntry;
				}
				if (World.GetDistance(Game.Player.Character.Position, VipEntry) < 2f)
				{
					EI.ReloadInterior();
					IsInInterior = false;
					DeleteVehicles();
					UI.Notify("test5A");
					if (!IsSpectatingMatch)
					{
						Random random3 = new Random();
						int num3 = random3.Next(1, 13);
						if (num3 == 1)
						{
							LoadDystopian_2();
						}
						if (num3 == 2)
						{
							LoadScifi_2();
						}
						if (num3 == 3)
						{
							LoadWasteland_2();
						}
						if (num3 == 4)
						{
							LoadWasteland_9();
						}
						if (num3 == 5)
						{
							LoadScifi_9();
						}
						if (num3 == 6)
						{
							LoadDystopian_3();
						}
						if (num3 == 7)
						{
							LoadDystopian_4();
						}
						if (num3 == 8)
						{
							LoadDystopian_10();
						}
						if (num3 == 9)
						{
							LoadDystopian_5();
						}
						if (num3 == 10)
						{
							LoadScifi_5();
						}
						if (num3 == 11)
						{
							LoadScifi_10();
						}
						if (num3 == 12)
						{
							LoadDystopian_7();
						}
						if (num3 == 13)
						{
							LoadWasteland_7();
						}
						Game.Player.Character.Position = VipExit;
						Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_vip" });
					}
					else
					{
						int num4 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 2782.99f, -3898.15f, 140f });
						Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num4, "Set_Pit_Fence_Oval" });
						Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num4, "set_wall_no_pit" });
						Game.Player.Character.Position = VipExit;
						Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_vip" });
					}
				}
				else if (World.GetDistance(Game.Player.Character.Position, VipExit) < 2f)
				{
					EI.ReloadInterior();
					DeleteVehicles();
					LoadVehicles();
					IsInInterior = true;
					isinsecondVehicleBay = false;
					isInGarage = false;
					Script.Wait(1);
					Game.Player.Character.Position = VipEntry;
					Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
				}
				else if (World.GetDistance(Game.Player.Character.Position, ArenaVehicleMenuMarker) < 2f)
				{
					if (Game.Player.Character.CurrentVehicle == null)
					{
						Script.Wait(1);
						Game.Player.Character.Position = ArenaExit;
						Random random4 = new Random();
						int num5 = random4.Next(1, 13);
						if (num5 == 1)
						{
							LoadDystopian_2();
						}
						if (num5 == 2)
						{
							LoadScifi_2();
						}
						if (num5 == 3)
						{
							LoadWasteland_2();
						}
						if (num5 == 4)
						{
							LoadWasteland_9();
						}
						if (num5 == 5)
						{
							LoadScifi_9();
						}
						if (num5 == 6)
						{
							LoadDystopian_3();
						}
						if (num5 == 7)
						{
							LoadDystopian_4();
						}
						if (num5 == 8)
						{
							LoadDystopian_10();
						}
						if (num5 == 9)
						{
							LoadDystopian_5();
						}
						if (num5 == 10)
						{
							LoadScifi_5();
						}
						if (num5 == 11)
						{
							LoadScifi_10();
						}
						if (num5 == 12)
						{
							LoadDystopian_7();
						}
						if (num5 == 13)
						{
							LoadWasteland_7();
						}
					}
					else if (Game.Player.Character.CurrentVehicle != null)
					{
						Game.Player.Character.CurrentVehicle.Position = ArenaExit;
						Game.Player.Character.Position = ArenaExit;
						Random random5 = new Random();
						int num6 = random5.Next(1, 13);
						if (num6 == 1)
						{
							LoadDystopian_2();
						}
						if (num6 == 2)
						{
							LoadScifi_2();
						}
						if (num6 == 3)
						{
							LoadWasteland_2();
						}
						if (num6 == 4)
						{
							LoadWasteland_9();
						}
						if (num6 == 5)
						{
							LoadScifi_9();
						}
						if (num6 == 6)
						{
							LoadDystopian_3();
						}
						if (num6 == 7)
						{
							LoadDystopian_4();
						}
						if (num6 == 8)
						{
							LoadDystopian_10();
						}
						if (num6 == 9)
						{
							LoadDystopian_5();
						}
						if (num6 == 10)
						{
							LoadScifi_5();
						}
						if (num6 == 11)
						{
							LoadScifi_10();
						}
						if (num6 == 12)
						{
							LoadDystopian_7();
						}
						if (num6 == 13)
						{
							LoadWasteland_7();
						}
					}
				}
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Cover) && World.GetDistance(Game.Player.Character.Position, new Vector3(-365f, -1871f, 19f)) < 2f)
			{
				EI.ReloadInterior();
				DeleteVehicles();
				isinsecondVehicleBay = false;
				UI.Notify("Test2C");
				Script.Wait(300);
				DestoryCars();
				Game.Player.Character.Position = EntryMarker;
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Cover) && World.GetDistance(Game.Player.Character.Position, GarageAMarkerInside) < 2f)
			{
				EI.ReloadInterior();
				UI.Notify("Test2D");
				DeleteVehicles();
				IsInInterior = false;
				LoadVehicles();
				if (isinsecondVehicleBay)
				{
					Game.Player.Character.Position = GarageBMarkerOuside;
				}
				else if (isInGarage)
				{
					Game.Player.Character.Position = GarageAMarkerOuside;
				}
				DeleteVehicles();
				DestoryCars();
				isInGarage = true;
				isinsecondVehicleBay = false;
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Cover) && World.GetDistance(Game.Player.Character.Position, ExitMarker3) < 2f)
			{
				if (isinsecondVehicleBay)
				{
					EI.ReloadInterior();
					DeleteVehicles();
					UI.Notify("test3A");
					LoadVehicles();
					IsInInterior = true;
					isinsecondVehicleBay = false;
					isInGarage = false;
					Game.Player.Character.Position = VehicleBayMarker;
				}
				if (isInGarage)
				{
					EI.ReloadInterior();
					DeleteVehicles();
					UI.Notify("test1A");
					DestoryCars();
					LoadVehicles();
					IsInInterior = true;
					isInGarage = false;
					Game.Player.Character.Position = SecondEntry;
				}
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				if (World.GetDistance(Game.Player.Character.Position, StadiumUpperExit) < 2f)
				{
					EI.ReloadInterior();
					IsInInterior = false;
					DeleteVehicles();
					UI.Notify("test6A");
					Game.Player.Character.Position = StadiumUpperEntry;
				}
				else if (World.GetDistance(Game.Player.Character.Position, StadiumUpperEntry) < 2f)
				{
					EI.ReloadInterior();
					DeleteVehicles();
					LoadVehicles();
					IsInInterior = true;
					isinsecondVehicleBay = false;
					isInGarage = false;
					Script.Wait(1);
					Game.Player.Character.Position = StadiumUpperExit;
					UI.Notify("test6B");
				}
				if (World.GetDistance(Game.Player.Character.Position, SecondEntry) < 2f)
				{
					EI.ReloadInterior();
					IsInInterior = false;
					DeleteVehicles();
					UI.Notify("test2B");
					isInGarage = true;
					Game.Player.Character.Position = ExitMarker3;
					Script.Wait(100);
					CreateCars("GarageA");
				}
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && World.GetDistance(Game.Player.Character.Position, GarageEntry) < 2f)
			{
				EI.ReloadInterior();
				IsInInterior = false;
				DeleteVehicles();
				UI.Notify("test2E");
				isInGarage = true;
				Game.Player.Character.Position = GarageAMarkerInside;
				Script.Wait(100);
				CreateCars("GarageA");
			}
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && World.GetDistance(Game.Player.Character.Position, VehicleBayMarker) < 2f)
			{
				EI.ReloadInterior();
				IsInInterior = false;
				DeleteVehicles();
				UI.Notify("test3B");
				isinsecondVehicleBay = true;
				Game.Player.Character.Position = ExitMarker3;
				LoadVehicles2();
			}
			if (World.GetDistance(Game.Player.Character.Position, ArenaMenuMarker) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				ArenaMainMenu.set_Visible(!ArenaMainMenu.get_Visible());
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMenuSpawn) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				GarageMenu.set_Visible(!GarageMenu.get_Visible());
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMenuMarker2) < 2f && isinsecondVehicleBay && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				GarageMenu2.set_Visible(!GarageMenu2.get_Visible());
			}
			if (Missionnum == 13 && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				if (World.GetDistance(Game.Player.Character.Position, new Vector3(213f, -936f, 24f)) < 3f)
				{
					Game.Player.Character.Position = new Vector3(227f, -1001f, -99f);
				}
				else if (World.GetDistance(Game.Player.Character.Position, new Vector3(227f, -1001f, -99f)) < 4f)
				{
					if (Game.Player.Character.CurrentVehicle != null)
					{
						Game.Player.Character.CurrentVehicle.Position = new Vector3(213f, -936f, 24f);
						Game.Player.Character.CurrentVehicle.Rotation = new Vector3(0f, 0f, -34f);
						Game.Player.WantedLevel = 2;
					}
					else
					{
						Game.Player.Character.Position = new Vector3(213f, -936f, 24f);
					}
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, MarkerEnter) < 3f)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					if (purchaselvl == 0)
					{
						if (Game.Player.Money >= 1000000)
						{
							DisplayHelpTextThisFrame("Press E to Purchase ARB ; $1,000,000");
							purchaselvl = 1;
							Game.Player.Money -= 1000000;
							Config.SetValue("Setup", "BuisnessLevel", purchaselvl);
							Config.Save();
						}
					}
					else if (purchaselvl > 0)
					{
						if (Game.Player.WantedLevel < 1)
						{
							Game.FadeScreenOut(300);
							Script.Wait(300);
							Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
							int num7 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
							Game.Player.Character.Position = MarkerExit;
							Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num7 });
							Script.Wait(300);
							Game.FadeScreenIn(300);
							IsInInterior = true;
							LoadVehicles();
						}
						else
						{
							DisplayHelpTextThisFrame("Lose the cops");
							UI.Notify("Alan : Please lose the cops boss");
						}
					}
				}
			}
			else if (World.GetDistance(Game.Player.Character.Position, MarkerExit) < 3f)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					Game.FadeScreenOut(300);
					Script.Wait(300);
					Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
					int num8 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
					Game.Player.Character.Position = MarkerEnter;
					Script.Wait(300);
					Game.FadeScreenIn(300);
					IsInInterior = false;
					DeleteVehicles();
				}
			}
			else if (World.GetDistance(Game.Player.Character.Position, MenuMarker) < 2f)
			{
				if (Game.IsControlJustPressed(2, GTA.Control.Context))
				{
					LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
					mainMenu.set_Visible(!mainMenu.get_Visible());
				}
			}
			else if (World.GetDistance(Game.Player.Character.Position, GarageMarker) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				Game.FadeScreenOut(300);
				Script.Wait(300);
				Game.Player.Character.Position = RoofEnterMarker;
				Script.Wait(300);
				Game.FadeScreenIn(300);
			}
			if (World.GetDistance(Game.Player.Character.Position, GarageMarker) < 2f && Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				Game.FadeScreenOut(300);
				Script.Wait(300);
				Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { Design });
				int num9 = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { -75.8466, -826.9893, 243.3859 });
				Game.Player.Character.Position = MarkerExit;
				Function.Call(Hash._0x41F37C3427C75AE0, new InputArgument[1] { num9 });
				Game.Player.Character.Position = RoofEnterMarker;
				Script.Wait(300);
				Game.FadeScreenIn(300);
			}
		}

		protected override void Dispose(bool A_0)
		{
			if (!A_0)
			{
				return;
			}
			foreach (Prop prop in Props)
			{
				if (prop != null)
				{
					prop.Delete();
				}
			}
			foreach (Vehicle item in ExtraV)
			{
				if (item != null)
				{
					item.Delete();
				}
			}
			if (SaveVehicle != null)
			{
				SaveVehicle.MarkAsNoLongerNeeded();
			}
			foreach (Vehicle item2 in VehiclestoCarryA)
			{
				if (item2 != null)
				{
					item2.Delete();
				}
			}
			foreach (Vehicle item3 in VehiclestoCarryB)
			{
				if (item3 != null)
				{
					item3.Delete();
				}
			}
			foreach (Vehicle item4 in VehiclestoCarryC)
			{
				if (item4 != null)
				{
					item4.Delete();
				}
			}
			if (Peds.Count > 0)
			{
				foreach (Ped ped in Peds)
				{
					if (ped != null)
					{
						ped.Delete();
					}
				}
			}
			if (PLayerVehicle2 != null)
			{
				PLayerVehicle2.Delete();
			}
			if (PLayerVehicle != null)
			{
				PLayerVehicle.Delete();
			}
			if (EndPointBlip != null)
			{
				EndPointBlip.Remove();
			}
			if (PLayerVehicle != null)
			{
				PLayerVehicle.Delete();
			}
			if (FinishLineBLip != null)
			{
				FinishLineBLip.Remove();
			}
			if (RcBandito != null)
			{
				RcBandito.Delete();
			}
			if (VehicleA != null)
			{
				VehicleA.Delete();
			}
			if (VehicleB != null)
			{
				VehicleB.Delete();
			}
			if (VehicleC != null)
			{
				VehicleC.Delete();
			}
			if (FinishLineBLip != null)
			{
				FinishLineBLip.Remove();
			}
			if (RaceBlip != null)
			{
				RaceBlip.Remove();
			}
			if (Italigto != null)
			{
				Italigto.Delete();
			}
			if (Deveste != null)
			{
				Deveste.Delete();
			}
			if (Deviant != null)
			{
				Deviant.Delete();
			}
			if (Toros != null)
			{
				Toros.Delete();
			}
			if (Schlagen != null)
			{
				Schlagen.Delete();
			}
			if (Vamos != null)
			{
				Vamos.Delete();
			}
			if (Tulip != null)
			{
				Tulip.Delete();
			}
			if (Clique != null)
			{
				Clique.Delete();
			}
			if (Vehicle1 != null)
			{
				Vehicle1.Delete();
			}
			if (Vehicle2 != null)
			{
				Vehicle2.Delete();
			}
			if (Vehicle3 != null)
			{
				Vehicle3.Delete();
			}
			if (Vehicle4 != null)
			{
				Vehicle4.Delete();
			}
			if (Vehicle5 != null)
			{
				Vehicle5.Delete();
			}
			if (Vehicle5 != null)
			{
				Vehicle5.Delete();
			}
			if (Vehicle6 != null)
			{
				Vehicle6.Delete();
			}
			if (Vehicle7 != null)
			{
				Vehicle7.Delete();
			}
			if (Vehicle8 != null)
			{
				Vehicle8.Delete();
			}
			if (Vehicle9 != null)
			{
				Vehicle9.Delete();
			}
			if (Vehicle10 != null)
			{
				Vehicle10.Delete();
			}
			if (ZR380 != null)
			{
				ZR380.Delete();
			}
			if (Bruiser != null)
			{
				Bruiser.Delete();
			}
			if (TowerBlip3 != null)
			{
				TowerBlip3.Remove();
			}
			if (TowerBlip != null)
			{
				TowerBlip.Remove();
			}
			if (TowerBlip2 != null)
			{
				TowerBlip2.Remove();
			}
			if (Bruitus != null)
			{
				Bruitus.Delete();
			}
			if (Bruitus != null)
			{
				Bruitus.Delete();
			}
			if (Impaler != null)
			{
				Impaler.Delete();
			}
			if (Slamvan != null)
			{
				Slamvan.Delete();
			}
			if (Issi != null)
			{
				Issi.Delete();
			}
			if (Monster != null)
			{
				Monster.Delete();
			}
			if (Dominator != null)
			{
				Dominator.Delete();
			}
			if (Cerberus != null)
			{
				Cerberus.Delete();
			}
			if (Scarab != null)
			{
				Scarab.Delete();
			}
			if (Imperator != null)
			{
				Imperator.Delete();
			}
			if (Deathbike != null)
			{
				Deathbike.Delete();
			}
			if (VtoGet != null)
			{
				VtoGet.Delete();
			}
			if (VtoGet1 != null)
			{
				VtoGet1.Delete();
			}
			if (VtoGet2 != null)
			{
				VtoGet2.Delete();
			}
			if (VtoGet3 != null)
			{
				VtoGet3.Delete();
			}
			if (VtoGet4 != null)
			{
				VtoGet4.Delete();
			}
			if (VtoGet5 != null)
			{
				VtoGet5.Delete();
			}
			if (VtoGet6 != null)
			{
				VtoGet6.Delete();
			}
			if (VtoGet7 != null)
			{
				VtoGet7.Delete();
			}
			if (VtoGetBlip != null)
			{
				VtoGetBlip.Remove();
			}
			if (VtoGetBlip1 != null)
			{
				VtoGetBlip1.Remove();
			}
			if (VtoGetBlip2 != null)
			{
				VtoGetBlip2.Remove();
			}
			if (VtoGetBlip3 != null)
			{
				VtoGetBlip3.Remove();
			}
			if (VtoGetBlip4 != null)
			{
				VtoGetBlip4.Remove();
			}
			if (VtoGetBlip5 != null)
			{
				VtoGetBlip5.Remove();
			}
			if (VtoGetBlip6 != null)
			{
				VtoGetBlip6.Remove();
			}
			if (VtoGetBlip7 != null)
			{
				VtoGetBlip7.Remove();
			}
			if (DropzoneBlip != null)
			{
				DropzoneBlip.Remove();
			}
			if (RentedVehicle != null)
			{
				RentedVehicle.Delete();
			}
		}
	}
}
