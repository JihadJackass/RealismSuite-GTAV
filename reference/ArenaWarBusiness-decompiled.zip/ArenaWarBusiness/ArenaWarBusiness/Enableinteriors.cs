using System;
using System.Collections.Generic;
using System.Drawing;
using GTA;
using GTA.Math;
using GTA.Native;
using NativeUI;

namespace ArenaWarBusiness
{
	public class Enableinteriors : Script
	{
		private MenuPool modMenuPool;

		private UIMenu mainMenu;

		private UIMenu InteriorOptions;

		public List<string> Workshop;

		public List<string> B1Garage;

		public string WorkGraphic;

		public string WorkOff;

		public string WorkMechanic;

		public int WColor;

		public int WColor1;

		public bool WLiving;

		public bool nopeds;

		private ScriptSettings Config;

		public Vector3 Marker = new Vector3(221.088f, 5168.41f, -90f);

		public string LoadPath = "scripts//ArenaWarBusiness//Interior//Main.ini";

		public string MarkerColorString;

		public Color MarkerColor;

		public List<string> TrinketsAndTrophies;

		public bool TrinketsAndTrophiesEnabled;

		public Enableinteriors()
		{
			//IL_0186: Unknown result type (might be due to invalid IL or missing references)
			//IL_0190: Expected O, but got Unknown
			base.Tick += OnTick;
			LoadIniFile(LoadPath);
			LoadIniFile2("scripts//ArenaWarBusiness//Main.ini");
			SetupWorkshop();
			SetupB1Garage();
			SetupT_T();
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_mod" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_Mod_2" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_mod" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_vip" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_Mod_2" });
			Enableinterior();
			modMenuPool = new MenuPool();
			mainMenu = new UIMenu("Arena War ", "Select an Option");
			modMenuPool.Add(mainMenu);
			InteriorOptions = modMenuPool.AddSubMenu(mainMenu, "Interiors");
			SetupInteriorDesignsMenu();
		}

		private void SetupT_T()
		{
			TrinketsAndTrophies = new List<string>();
			TrinketsAndTrophies.Add("SET_XMAS_DECORATIONS");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_CAREER");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_SCORE");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_WAGEWORKER");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_TIME_SERVED");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_GOT_ONE");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_OUTTA_HERE");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_SHUNT");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_BOBBY");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_KILLED");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_CROWD");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_DUCK");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_BANDITO");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_SPINNER");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_LENS");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_WAR");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_UNSTOPPABLE");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_CONTACT");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_TOWER");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_STEP");
			TrinketsAndTrophies.Add("Set_Int_MOD_TROPHY_PEGASUS");
			TrinketsAndTrophies.Add("SET_BANDITO_RC");
			TrinketsAndTrophies.Add("SET_OFFICE_TRINKET_07");
			TrinketsAndTrophies.Add("SET_OFFICE_TRINKET_06");
			TrinketsAndTrophies.Add("SET_OFFICE_TRINKET_03");
			TrinketsAndTrophies.Add("SET_OFFICE_TRINKET_04");
			TrinketsAndTrophies.Add("SET_OFFICE_TRINKET_02");
		}

		public void SetupInteriorDesignsMenu()
		{
			//IL_023c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0246: Expected O, but got Unknown
			//IL_0259: Unknown result type (might be due to invalid IL or missing references)
			//IL_0263: Expected O, but got Unknown
			//IL_0290: Unknown result type (might be due to invalid IL or missing references)
			//IL_029a: Expected O, but got Unknown
			//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b8: Expected O, but got Unknown
			//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f0: Expected O, but got Unknown
			//IL_0304: Unknown result type (might be due to invalid IL or missing references)
			//IL_030e: Expected O, but got Unknown
			//IL_033c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0346: Expected O, but got Unknown
			//IL_035a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0364: Expected O, but got Unknown
			//IL_03ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b5: Expected O, but got Unknown
			//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_03d3: Expected O, but got Unknown
			//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_03f1: Expected O, but got Unknown
			//IL_0404: Unknown result type (might be due to invalid IL or missing references)
			//IL_040e: Expected O, but got Unknown
			//IL_0423: Unknown result type (might be due to invalid IL or missing references)
			//IL_042d: Expected O, but got Unknown
			//IL_0436: Unknown result type (might be due to invalid IL or missing references)
			//IL_0440: Expected O, but got Unknown
			//IL_044a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0454: Expected O, but got Unknown
			//IL_045e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0468: Expected O, but got Unknown
			//IL_0472: Unknown result type (might be due to invalid IL or missing references)
			//IL_047c: Expected O, but got Unknown
			//IL_0486: Unknown result type (might be due to invalid IL or missing references)
			//IL_0490: Expected O, but got Unknown
			List<dynamic> listofDesigns = new List<object>();
			listofDesigns.Add("Set_Mod1_Style_01");
			listofDesigns.Add("Set_Mod1_Style_02");
			listofDesigns.Add("Set_Mod1_Style_03");
			listofDesigns.Add("Set_Mod1_Style_04");
			listofDesigns.Add("Set_Mod1_Style_05");
			listofDesigns.Add("Set_Mod1_Style_06");
			listofDesigns.Add("Set_Mod1_Style_07");
			listofDesigns.Add("Set_Mod1_Style_08");
			listofDesigns.Add("Set_Mod1_Style_09");
			List<dynamic> listofOfficeDesigns = new List<object>();
			listofOfficeDesigns.Add("SET_OFFICE_STANDARD");
			listofOfficeDesigns.Add("SET_OFFICE_HITECH");
			listofOfficeDesigns.Add("SET_OFFICE_INDUSTRIAL");
			List<dynamic> listofMechanics = new List<object>();
			listofMechanics.Add("Set_Int_MOD_BOOTH_DEF");
			listofMechanics.Add("Set_Int_MOD_BOOTH_BEN");
			listofMechanics.Add("Set_Int_MOD_BOOTH_WP");
			listofMechanics.Add("Set_Int_MOD_BOOTH_COMBO");
			List<dynamic> listofColors = new List<object>();
			listofColors.Add("0");
			listofColors.Add("1");
			listofColors.Add("1");
			listofColors.Add("2");
			listofColors.Add("3");
			listofColors.Add("4");
			listofColors.Add("6");
			listofColors.Add("7");
			listofColors.Add("8");
			listofColors.Add("9");
			UIMenu uIMenu = modMenuPool.AddSubMenu(InteriorOptions, "Workshop");
			UIMenu uIMenu2 = modMenuPool.AddSubMenu(uIMenu, "Trinkets And Trophies");
			UIMenu uIMenu3 = modMenuPool.AddSubMenu(uIMenu, "Design");
			UIMenuListItem list1 = new UIMenuListItem("Design: ", (List<object>)listofDesigns, 0);
			uIMenu3.AddItem((UIMenuItem)(object)list1);
			UIMenuItem GetDesign = new UIMenuItem("Get Design");
			uIMenu3.AddItem(GetDesign);
			UIMenu uIMenu4 = modMenuPool.AddSubMenu(uIMenu, "Office Design");
			UIMenuListItem list2 = new UIMenuListItem("Office Design: ", (List<object>)listofOfficeDesigns, 0);
			uIMenu4.AddItem((UIMenuItem)(object)list2);
			UIMenuItem GetOfficeDesign = new UIMenuItem("Get Office Design");
			uIMenu4.AddItem(GetOfficeDesign);
			UIMenu uIMenu5 = modMenuPool.AddSubMenu(uIMenu, "Mechanic");
			UIMenuListItem list3 = new UIMenuListItem("Mechanic: ", (List<object>)listofMechanics, 0);
			uIMenu5.AddItem((UIMenuItem)(object)list3);
			UIMenuItem GetMechanic = new UIMenuItem("Mechanic");
			uIMenu5.AddItem(GetMechanic);
			UIMenu uIMenu6 = modMenuPool.AddSubMenu(uIMenu, "Main Color");
			UIMenuListItem list4 = new UIMenuListItem("Color: ", (List<object>)listofColors, 0);
			uIMenu6.AddItem((UIMenuItem)(object)list4);
			UIMenuItem GetColor1 = new UIMenuItem("Get Color");
			uIMenu6.AddItem(GetColor1);
			UIMenu uIMenu7 = modMenuPool.AddSubMenu(InteriorOptions, "Workshop B1");
			UIMenu uIMenu8 = modMenuPool.AddSubMenu(uIMenu7, "Main Color");
			UIMenuListItem list5 = new UIMenuListItem("Color: ", (List<object>)listofColors, 0);
			uIMenu8.AddItem((UIMenuItem)(object)list4);
			UIMenuItem GetColor2 = new UIMenuItem("Get Color");
			uIMenu8.AddItem(GetColor2);
			UIMenuItem EnableAll = new UIMenuItem("Enable All Trinkets And Trophies ");
			uIMenu2.AddItem(EnableAll);
			UIMenuItem DisableAll = new UIMenuItem("Disable All Trinkets And Trophies ");
			uIMenu2.AddItem(DisableAll);
			uIMenu2.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == EnableAll)
				{
					TrinketsAndTrophiesEnabled = true;
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
					UI.Notify("Alan : All trinkets and Trophies have been enabled ");
				}
				if (item == DisableAll)
				{
					TrinketsAndTrophiesEnabled = false;
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
					UI.Notify("Alan : All trinkets and Trophies have been disabled ");
				}
			});
			uIMenu3.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == GetDesign)
				{
					int index6 = list1.get_Index();
					WorkGraphic = listofDesigns[index6];
					Config.SetValue<string>("Workshop", "WorkGraphic", WorkGraphic);
					Config.Save();
					Enableinterior();
					UI.Notify("Alan : Changed Interior, please reload mod to allow interior to refresh");
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
				}
			});
			uIMenu4.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == GetOfficeDesign)
				{
					int index5 = list2.get_Index();
					WorkOff = listofOfficeDesigns[index5];
					Config.SetValue<string>("Workshop", "WorkOff", WorkOff);
					Config.Save();
					Enableinterior();
					UI.Notify("Alan : Changed Interior, please reload mod to allow interior to refresh");
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
				}
			});
			uIMenu5.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == GetMechanic)
				{
					int index4 = list3.get_Index();
					WorkMechanic = listofMechanics[index4];
					Config.SetValue<string>("Workshop", "WorkMechanic", WorkMechanic);
					Config.Save();
					Enableinterior();
					UI.Notify("Alan : Changed Interior, please reload mod to allow interior to refresh");
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
				}
			});
			uIMenu6.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == GetColor1)
				{
					int index3 = list4.get_Index();
					object obj2 = int.Parse(listofColors[index3]);
					WColor = (dynamic)obj2;
					Config.SetValue("Workshop", "WColor", WColor);
					Config.Save();
					Enableinterior();
					UI.Notify("Alan : Changed Interior, please reload mod to allow interior to refresh");
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
				}
			});
			uIMenu8.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == GetColor2)
				{
					int index2 = list5.get_Index();
					object obj = int.Parse(listofColors[index2]);
					WColor1 = (dynamic)obj;
					Config.SetValue("Garage", "WColor1", WColor1);
					Config.Save();
					Enableinterior();
					UI.Notify("Alan : Changed Interior, please reload mod to allow interior to refresh");
					Game.Player.Character.FreezePosition = true;
					Script.Wait(100);
					ReloadInterior();
					Script.Wait(100);
					Game.Player.Character.FreezePosition = false;
				}
			});
		}

		private void LoadIniFile2(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				MarkerColorString = Config.GetValue<string>("Setup", "MarkerColor", MarkerColorString);
				MarkerColor = Color.FromName(MarkerColorString);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Main.ini Failed To Load.");
			}
		}

		private void LoadIniFile(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				WorkGraphic = Config.GetValue<string>("Workshop", "WorkGraphic", WorkGraphic);
				WorkOff = Config.GetValue<string>("Workshop", "WorkOff", WorkOff);
				WorkMechanic = Config.GetValue<string>("Workshop", "WorkMechanic", WorkMechanic);
				WColor = Config.GetValue("Workshop", "WColor", WColor);
				WColor1 = Config.GetValue("Garage", "WColor1", WColor1);
				WLiving = Config.GetValue("Workshop", "WLiving", WLiving);
				nopeds = Config.GetValue("Workshop", "nopeds", nopeds);
				TrinketsAndTrophiesEnabled = Config.GetValue("Workshop", "TrinketsAndTrophiesEnabled", TrinketsAndTrophiesEnabled);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Interior.ini Failed To Load.");
			}
		}

		private void SetupWorkshop()
		{
			Workshop = new List<string>();
			Workshop.Add("Set_Int_MOD_BOOTH_DEF");
			Workshop.Add("Set_Int_MOD_BOOTH_BEN");
			Workshop.Add("Set_Int_MOD_BOOTH_WP");
			Workshop.Add("Set_Int_MOD_BOOTH_COMBO");
			Workshop.Add("Set_Int_MOD_BEDROOM_BLOCKER");
			Workshop.Add("Set_Int_MOD_CONSTRUCTION_01");
			Workshop.Add("Set_Int_MOD_CONSTRUCTION_02");
			Workshop.Add("Set_Int_MOD_CONSTRUCTION_03");
			Workshop.Add("SET_OFFICE_STANDARD");
			Workshop.Add("SET_OFFICE_INDUSTRIAL");
			Workshop.Add("SET_OFFICE_HITECH");
			Workshop.Add("Set_Mod1_Style_01");
			Workshop.Add("Set_Mod1_Style_02");
			Workshop.Add("Set_Mod1_Style_03");
			Workshop.Add("Set_Mod1_Style_04");
			Workshop.Add("Set_Mod1_Style_05");
			Workshop.Add("Set_Mod1_Style_06");
			Workshop.Add("Set_Mod1_Style_07");
			Workshop.Add("Set_Mod1_Style_08");
			Workshop.Add("Set_Mod1_Style_09");
			Workshop.Add("set_arena_peds");
			Workshop.Add("set_arena_no peds");
		}

		private void SetupB1Garage()
		{
		}

		public void Enableinterior()
		{
			LoadIniFile(LoadPath);
			int num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 205f, 5180f, -90f });
			for (int i = 0; i < Workshop.Count; i++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
				{
					num,
					Workshop[i]
				});
			}
			for (int j = 0; j < TrinketsAndTrophies.Count; j++)
			{
				if (TrinketsAndTrophiesEnabled)
				{
					Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2]
					{
						num,
						TrinketsAndTrophies[j]
					});
				}
				else if (!TrinketsAndTrophiesEnabled)
				{
					Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2]
					{
						num,
						TrinketsAndTrophies[j]
					});
				}
			}
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Int_MOD_SHELL_DEF" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, WorkGraphic });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, WorkOff });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, WorkMechanic });
			if (!WLiving)
			{
				Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Int_MOD_BEDROOM_BLOCKER" });
			}
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, "Set_Int_MOD_SHELL_DEF", WColor });
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, WorkOff, WColor });
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, WorkMechanic, WColor });
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, WorkGraphic, WColor });
			if (!nopeds)
			{
				Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "set_arena_no peds" });
			}
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_mod_2" });
			num = Function.Call<int>(Hash._0xB0F7F8663821D9C3, new InputArgument[3] { 170f, 5190f, 10f });
			for (int k = 0; k < 9; k++)
			{
				Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, WorkGraphic });
			}
			Function.Call(Hash._0x420BD37289EEE162, new InputArgument[2] { num, "Set_Int_MOD2_B2" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Int_MOD2_B_TINT" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, "Set_Int_MOD2_B1" });
			Function.Call(Hash._0x55E86AF2712B36A1, new InputArgument[2] { num, WorkGraphic });
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, "Set_Int_MOD2_B_Tint", WColor1 });
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, "Set_Int_MOD2_B1", WColor1 });
			Function.Call((Hash)3590001984630001091uL, new InputArgument[3] { num, WorkGraphic, WColor1 });
		}

		public void ReloadInterior()
		{
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_mod" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_vip" });
			Function.Call(Hash._0xEE6C5AD3ECE0A82D, new InputArgument[1] { "xs_arena_interior_Mod_2" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_mod" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_vip" });
			Function.Call(Hash._0x41B4893843BBDB74, new InputArgument[1] { "xs_arena_interior_Mod_2" });
			Enableinterior();
		}

		private void DisplayHelpTextThisFrame(string text)
		{
			InputArgument[] arguments = new InputArgument[1] { "STRING" };
			Function.Call(Hash._0x8509B634FBE7DA11, arguments);
			InputArgument[] arguments2 = new InputArgument[1] { text };
			Function.Call(Hash._0x6C188BE134E074AA, arguments2);
			InputArgument[] arguments3 = new InputArgument[4] { 0, 0, 1, -1 };
			Function.Call(Hash._0x238FFE5C7B0498A6, arguments3);
		}

		public void OnTick(object sender, EventArgs e)
		{
			if (modMenuPool != null && modMenuPool.IsAnyMenuOpen())
			{
				modMenuPool.ProcessMenus();
			}
			OnKeyDown();
			if (World.GetDistance(Game.Player.Character.Position, Marker) < 3f)
			{
				DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ to Open Interior Design Menu");
			}
			if (World.GetDistance(Game.Player.Character.Position, Marker) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, Marker, Vector3.Zero, Vector3.Zero, new Vector3(1f, 1f, 1f), MarkerColor);
			}
		}

		private void OnKeyDown()
		{
			if (World.GetDistance(Game.Player.Character.Position, Marker) < 2f && Game.IsControlJustPressed(2, Control.Context))
			{
				mainMenu.set_Visible(!mainMenu.get_Visible());
			}
		}
	}
}
