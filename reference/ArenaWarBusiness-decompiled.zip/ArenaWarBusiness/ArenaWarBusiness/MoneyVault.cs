using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;
using NativeUI;

namespace ArenaWarBusiness
{
	public class MoneyVault : Script
	{
		private ScriptSettings Config;

		private Keys Key3;

		private MenuPool modMenuPool;

		private UIMenu mainMenu;

		public int MoneyVaultBought;

		public float MoneyStored;

		public float Commission;

		public UIMenu MoneyMenu;

		public Vector3 MoneyStorageMarker = new Vector3(195f, 5191f, -90f);

		public string MarkerColorString;

		public Color MarkerColor;

		public int currentbank;

		public bool read;

		public MoneyVault()
		{
			Setup();
			base.Tick += onTick;
			base.KeyDown += onKeyDown;
			LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
		}

		private void Setup()
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Expected O, but got Unknown
			currentbank = 1;
			modMenuPool = new MenuPool();
			mainMenu = new UIMenu("Arena War", "Select an Option");
			modMenuPool.Add(mainMenu);
			MoneyMenu = modMenuPool.AddSubMenu(mainMenu, "Money Options");
			SetupMoneyMenu();
		}

		private void LoadIniFile(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				MoneyVaultBought = Config.GetValue("Setup", "MoneyVaultBought", MoneyVaultBought);
				Key3 = Config.GetValue("ADDON2", "Key3", Key3);
				Commission = Config.GetValue("ADDON2", "COMMISSION", Commission);
				MoneyStored = Config.GetValue("ADDON2", "MONEYSTORED", MoneyStored);
				MarkerColorString = Config.GetValue<string>("Setup", "MarkerColor", MarkerColorString);
				MarkerColor = Color.FromName(MarkerColorString);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Config.ini Failed To Load.");
			}
		}

		public void SetupMoneyMenu()
		{
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Expected O, but got Unknown
			//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d2: Expected O, but got Unknown
			//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ef: Expected O, but got Unknown
			//IL_0102: Unknown result type (might be due to invalid IL or missing references)
			//IL_010c: Expected O, but got Unknown
			//IL_011f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0129: Expected O, but got Unknown
			//IL_013e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0148: Expected O, but got Unknown
			List<object> list6 = new List<object>();
			list6.Add("1");
			list6.Add("2");
			list6.Add("3");
			list6.Add("4");
			list6.Add("5");
			list6.Add("6");
			list6.Add("7");
			list6.Add("8");
			list6.Add("9");
			list6.Add("10");
			UIMenu uIMenu = modMenuPool.AddSubMenu(MoneyMenu, "Money Options");
			UIMenuListItem list5 = new UIMenuListItem("Vault: ", list6, 0);
			uIMenu.AddItem((UIMenuItem)(object)list5);
			UIMenuItem GetColor2 = new UIMenuItem("Change Bank Vault Number");
			uIMenu.AddItem(GetColor2);
			UIMenuItem WithDraw = new UIMenuItem("Withdraw");
			uIMenu.AddItem(WithDraw);
			UIMenuItem Deposit2 = new UIMenuItem("Deposit");
			uIMenu.AddItem(Deposit2);
			UIMenuItem balance = new UIMenuItem("Show Balance");
			uIMenu.AddItem(balance);
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == GetColor2)
				{
					int num = list5.get_Index() + 1;
					currentbank = num;
					UI.Notify("Agent 14 : Vault Changed to:  " + currentbank);
				}
				if (item == WithDraw)
				{
					Withdrawl();
				}
				if (item == Deposit2)
				{
					Deposit();
				}
				if (item == balance)
				{
					LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
					MoneyStored = Config.GetValue("ADDON2", "MONEYSTORED[" + currentbank + "]", MoneyStored);
					UI.Notify("Agent 14  : Moeny in Vault " + currentbank + ", $" + MoneyStored);
				}
			});
		}

		private void onTick(object sender, EventArgs e)
		{
			if (modMenuPool != null && modMenuPool.IsAnyMenuOpen())
			{
				modMenuPool.ProcessMenus();
			}
			if (World.GetDistance(Game.Player.Character.Position, MoneyStorageMarker) < 40f)
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
			}
			if (MoneyVaultBought == 1)
			{
				if (World.GetDistance(Game.Player.Character.Position, MoneyStorageMarker) < 3f)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ open money vault");
				}
				if (World.GetDistance(Game.Player.Character.Position, MoneyStorageMarker) < 40f)
				{
					World.DrawMarker(MarkerType.VerticalCylinder, MoneyStorageMarker, Vector3.Zero, Vector3.Zero, new Vector3(0.8f, 0.8f, 1f), MarkerColor);
				}
			}
		}

		public void Check()
		{
		}

		private void DisplayHelpTextThisFrame(string text)
		{
			InputArgument[] arguments = new InputArgument[1] { "STRING" };
			Function.Call(Hash._0x8509B634FBE7DA11, arguments);
			InputArgument[] arguments2 = new InputArgument[1] { text };
			Function.Call(Hash._0x6C188BE134E074AA, arguments2);
			InputArgument[] arguments3 = new InputArgument[4] { 0, 0, 1, -1 };
			Function.Call(Hash._0x238FFE5C7B0498A6, arguments3);
		}

		private void Deposit()
		{
			string userInput = Game.GetUserInput(12);
			if (userInput != "")
			{
				if (int.Parse(userInput) <= Game.Player.Money)
				{
					MoneyStored = int.Parse(userInput);
					Game.Player.Money -= int.Parse(userInput);
					float value = Config.GetValue("ADDON2", "MONEYSTORED[" + currentbank + "]", MoneyStored);
					Config.SetValue("ADDON2", "MONEYSTORED[" + currentbank + "]", MoneyStored + value);
					Config.Save();
				}
				else
				{
					UI.Notify("Agent 14  : boss you dont have that amount of money to deposit: value: " + int.Parse(userInput));
				}
			}
		}

		private void Withdrawl()
		{
			string userInput = Game.GetUserInput(12);
			if (userInput != "")
			{
				if (!((float)int.Parse(userInput) > MoneyStored))
				{
					MoneyStored = Config.GetValue("ADDON2", "MONEYSTORED[" + currentbank + "]", MoneyStored) - (float)int.Parse(userInput);
					Game.Player.Money += int.Parse(userInput);
					Config.SetValue("ADDON2", "MONEYSTORED[" + currentbank + "]", MoneyStored);
					Config.Save();
				}
				else
				{
					UI.Notify("Agent 14 : boss you dont have that amount of money stored to withdraw, value: " + MoneyStored);
				}
			}
		}

		private void onKeyDown(object sender, KeyEventArgs e)
		{
			if (Game.IsControlJustPressed(2, GTA.Control.Context) && World.GetDistance(Game.Player.Character.Position, MoneyStorageMarker) < 2f && Config.GetValue("Setup", "MoneyVaultBought", MoneyVaultBought) == 1)
			{
				mainMenu.set_Visible(!mainMenu.get_Visible());
			}
		}
	}
}
