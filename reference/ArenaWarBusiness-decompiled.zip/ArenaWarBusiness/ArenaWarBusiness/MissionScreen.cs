using System;
using System.Drawing;
using GTA;
using NativeUI;

namespace ArenaWarBusiness
{
	public class MissionScreen : Script
	{
		public bool Fail;

		public bool Pass;

		public string m;

		public int p;

		public string r;

		public int Timer;

		public void MissionPassed(string MissionName, int Payout)
		{
			Fail = false;
			Pass = true;
			SizeF screenResolutionMantainRatio = UIMenu.GetScreenResolutionMantainRatio();
			int x = Convert.ToInt32(screenResolutionMantainRatio.Width / 2f);
			new Sprite("mpentry", "mp_modenotselected_gradient", new Point(0, 10), new Size(Convert.ToInt32(screenResolutionMantainRatio.Width), 450), 0f, Color.FromArgb(200, 255, 255, 255)).Draw();
			new UIResText("mission passed", new Point(x, 100), 2.5f, Color.FromArgb(255, 199, 168, 87), GTA.Font.Pricedown, UIResText.Alignment.Centered).Draw();
			new UIResText(MissionName, new Point(x, 230), 0.5f, Color.White, GTA.Font.ChaletComprimeCologne, UIResText.Alignment.Centered).Draw();
			new UIResText("Payout : $" + Payout.ToString("N"), new Point(x, 300), 0.5f, Color.White, GTA.Font.ChaletLondon, UIResText.Alignment.Centered).Draw();
			Scaleform scaleform = new Scaleform(0);
			scaleform.Load("instructional_buttons");
			scaleform.Render2D();
		}

		public void MissionFailed(string Reason, string MissionName)
		{
			Pass = false;
			Fail = true;
			SizeF screenResolutionMantainRatio = UIMenu.GetScreenResolutionMantainRatio();
			int x = Convert.ToInt32(screenResolutionMantainRatio.Width / 2f);
			new Sprite("mpentry", "mp_modenotselected_gradient", new Point(0, 30), new Size(Convert.ToInt32(screenResolutionMantainRatio.Width), 450), 0f, Color.FromArgb(230, 255, 255, 255)).Draw();
			new UIResText("mission failed", new Point(x, 100), 2.5f, Color.FromArgb(255, 148, 27, 46), GTA.Font.Pricedown, UIResText.Alignment.Centered).Draw();
			new UIResText(MissionName, new Point(x, 230), 0.5f, Color.White, GTA.Font.ChaletComprimeCologne, UIResText.Alignment.Centered).Draw();
			new UIResText("Reason : " + Reason, new Point(x, 280), 0.5f, Color.White, GTA.Font.ChaletLondon, UIResText.Alignment.Centered).Draw();
			Scaleform scaleform = new Scaleform(0);
			scaleform.Load("instructional_buttons");
			scaleform.Render2D();
		}

		public void SetFail(string MissionName, int Payout, string Reason)
		{
			Audio.SetAudioFlag("LoadMPData", true);
			Audio.PlaySoundFrontend("Bed", "WastedSounds");
			Audio.SetAudioFlag("LoadMPData", false);
			Timer = 300;
			m = MissionName;
			p = Payout;
			r = Reason;
			Fail = true;
			for (int i = 0; i < 100; i++)
			{
				if (Fail)
				{
					MissionFailed(r, m);
				}
				if (Pass)
				{
					MissionPassed(m, p);
				}
				Script.Wait(1);
			}
		}

		public void SetPass(string MissionName, int Payout, string Reason)
		{
			Audio.SetAudioFlag("LoadMPData", true);
			Audio.PlaySoundFrontend("Mission_Pass_Notify", "DLC_HEISTS_GENERAL_FRONTEND_SOUNDS");
			Audio.SetAudioFlag("LoadMPData", false);
			Timer = 300;
			m = MissionName;
			p = Payout;
			r = Reason;
			Pass = true;
			for (int i = 0; i < 100; i++)
			{
				if (Fail)
				{
					MissionFailed(r, m);
				}
				if (Pass)
				{
					MissionPassed(m, p);
				}
				Script.Wait(1);
			}
		}

		public MissionScreen()
		{
			base.Tick += OnTick;
		}

		public void OnTick(object sender, EventArgs e)
		{
			if (Timer >= 0)
			{
				Timer--;
			}
		}
	}
}
