using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;
using NativeUI;

namespace ArenaWarBusiness
{
	public class GunLocker : Script
	{
		private ScriptSettings Config;

		private Keys Key1;

		private UIMenu weaponsMenu;

		public Vector3 GunLockerMarker = new Vector3(209.179f, 5162.07f, -87f);

		public int GunLockerBought;

		private UIMenu MK2Pumpshotgun;

		private UIMenu MK2SNSPistol;

		private UIMenu MK2Revolver;

		private UIMenu Mk2SpecialCarbine;

		private UIMenu MK2Bullpup;

		private UIMenu MK2MarksmanRifle;

		private UIMenu MK2Pistol;

		private UIMenu MK2SMG;

		private UIMenu MK2LMG;

		private UIMenu MK2Carbine;

		private UIMenu MK2AssaultRifle;

		private UIMenu MK2Sniper;

		private UIMenu Scifi;

		private MenuPool modMenuPool;

		private UIMenu mainMenu;

		public int Tintscount = 32;

		public string MarkerColorString;

		public Color MarkerColor;

		public GunLocker()
		{
			LoadIniFile2("scripts//ArenaWarBusiness//Main.ini");
			LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
			Setup();
			base.Tick += OnTick;
			Setup();
		}

		private void Setup()
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Expected O, but got Unknown
			modMenuPool = new MenuPool();
			mainMenu = new UIMenu("Arena War", "Select an Option");
			modMenuPool.Add(mainMenu);
			weaponsMenu = modMenuPool.AddSubMenu(mainMenu, "Weapons");
			SetupWeapons();
		}

		private void LoadIniFile2(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				MarkerColorString = Config.GetValue<string>("Setup", "MarkerColor", MarkerColorString);
				MarkerColor = Color.FromName(MarkerColorString);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Main.ini Failed To Load.");
			}
		}

		private void LoadIniFile(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				Key1 = Config.GetValue("Configurations", "Key1", Key1);
				GunLockerBought = Config.GetValue("Setup", "GunLockerBought", GunLockerBought);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Main.ini Failed To Load.");
			}
		}

		private void OnTick(object sender, EventArgs e)
		{
			if (modMenuPool != null && modMenuPool.IsAnyMenuOpen())
			{
				modMenuPool.ProcessMenus();
			}
			OnKeyDown();
			if (World.GetDistance(Game.Player.Character.Position, GunLockerMarker) < 2f)
			{
				LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
				if (GunLockerBought == 1)
				{
					DisplayHelpTextThisFrame("Press ~INPUT_CONTEXT~ open Gun Locker");
				}
				else if (GunLockerBought == 0)
				{
					DisplayHelpTextThisFrame("Please buy a Gunlocker first");
				}
			}
			if (World.GetDistance(Game.Player.Character.Position, GunLockerMarker) < 40f)
			{
				World.DrawMarker(MarkerType.VerticalCylinder, GunLockerMarker, Vector3.Zero, Vector3.Zero, new Vector3(0.8f, 0.8f, 1f), MarkerColor);
			}
		}

		public void Check()
		{
		}

		private void DisplayHelpTextThisFrame(string text)
		{
			InputArgument[] arguments = new InputArgument[1] { "STRING" };
			Function.Call(Hash._0x8509B634FBE7DA11, arguments);
			InputArgument[] arguments2 = new InputArgument[1] { text };
			Function.Call(Hash._0x6C188BE134E074AA, arguments2);
			InputArgument[] arguments3 = new InputArgument[4] { 0, 0, 1, -1 };
			Function.Call(Hash._0x238FFE5C7B0498A6, arguments3);
		}

		public void OnKeyDown()
		{
			if (Game.IsControlJustPressed(2, GTA.Control.Context))
			{
				int value = Config.GetValue("Setup", "GunLockerBought", GunLockerBought);
				if (value == 1 && World.GetDistance(Game.Player.Character.Position, GunLockerMarker) < 2f)
				{
					mainMenu.set_Visible(!mainMenu.get_Visible());
				}
			}
		}

		private void SetupWeapons()
		{
			//IL_0306: Unknown result type (might be due to invalid IL or missing references)
			//IL_0310: Expected O, but got Unknown
			//IL_032a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0334: Expected O, but got Unknown
			//IL_035c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0366: Expected O, but got Unknown
			//IL_0379: Unknown result type (might be due to invalid IL or missing references)
			//IL_0383: Expected O, but got Unknown
			//IL_0398: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a2: Expected O, but got Unknown
			//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_03bf: Expected O, but got Unknown
			//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_03de: Expected O, but got Unknown
			//IL_03e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_03f1: Expected O, but got Unknown
			//IL_0592: Unknown result type (might be due to invalid IL or missing references)
			//IL_059c: Expected O, but got Unknown
			//IL_05b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_05be: Expected O, but got Unknown
			//IL_05d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_05e0: Expected O, but got Unknown
			//IL_05f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0602: Expected O, but got Unknown
			//IL_061a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0624: Expected O, but got Unknown
			//IL_063c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0646: Expected O, but got Unknown
			//IL_065e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0668: Expected O, but got Unknown
			//IL_0680: Unknown result type (might be due to invalid IL or missing references)
			//IL_068a: Expected O, but got Unknown
			//IL_06a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_06ac: Expected O, but got Unknown
			//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_06ce: Expected O, but got Unknown
			//IL_06e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_06f0: Expected O, but got Unknown
			//IL_0708: Unknown result type (might be due to invalid IL or missing references)
			//IL_0712: Expected O, but got Unknown
			//IL_072d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0737: Expected O, but got Unknown
			//IL_074f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0759: Expected O, but got Unknown
			//IL_0771: Unknown result type (might be due to invalid IL or missing references)
			//IL_077b: Expected O, but got Unknown
			//IL_0793: Unknown result type (might be due to invalid IL or missing references)
			//IL_079d: Expected O, but got Unknown
			//IL_07b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_07bf: Expected O, but got Unknown
			//IL_07d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_07e1: Expected O, but got Unknown
			//IL_07f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0803: Expected O, but got Unknown
			//IL_081b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0825: Expected O, but got Unknown
			//IL_083d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0847: Expected O, but got Unknown
			//IL_085f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0869: Expected O, but got Unknown
			//IL_0881: Unknown result type (might be due to invalid IL or missing references)
			//IL_088b: Expected O, but got Unknown
			//IL_08a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_08ad: Expected O, but got Unknown
			//IL_08c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_08cf: Expected O, but got Unknown
			//IL_08ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_08f4: Expected O, but got Unknown
			//IL_090c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0916: Expected O, but got Unknown
			//IL_092e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0938: Expected O, but got Unknown
			//IL_0950: Unknown result type (might be due to invalid IL or missing references)
			//IL_095a: Expected O, but got Unknown
			//IL_0972: Unknown result type (might be due to invalid IL or missing references)
			//IL_097c: Expected O, but got Unknown
			//IL_0994: Unknown result type (might be due to invalid IL or missing references)
			//IL_099e: Expected O, but got Unknown
			//IL_09b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_09c0: Expected O, but got Unknown
			//IL_09d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_09e2: Expected O, but got Unknown
			//IL_09fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a04: Expected O, but got Unknown
			//IL_0a1c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a26: Expected O, but got Unknown
			//IL_0a3e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a48: Expected O, but got Unknown
			//IL_0a60: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a6a: Expected O, but got Unknown
			//IL_0a85: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a8f: Expected O, but got Unknown
			//IL_0aa7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ab1: Expected O, but got Unknown
			//IL_0ac9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ad3: Expected O, but got Unknown
			//IL_0aeb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0af5: Expected O, but got Unknown
			//IL_0b0d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b17: Expected O, but got Unknown
			//IL_0b2f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b39: Expected O, but got Unknown
			//IL_0b51: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b5b: Expected O, but got Unknown
			//IL_0b73: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b7d: Expected O, but got Unknown
			//IL_0b95: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b9f: Expected O, but got Unknown
			//IL_0bb7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bc1: Expected O, but got Unknown
			//IL_0bd9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0be3: Expected O, but got Unknown
			//IL_0bfb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c05: Expected O, but got Unknown
			//IL_0c1d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c27: Expected O, but got Unknown
			//IL_0c3f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c49: Expected O, but got Unknown
			//IL_0c61: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c6b: Expected O, but got Unknown
			//IL_0c83: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c8d: Expected O, but got Unknown
			//IL_0ca8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cb2: Expected O, but got Unknown
			//IL_0cca: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cd4: Expected O, but got Unknown
			//IL_0cec: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cf6: Expected O, but got Unknown
			//IL_0d0e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d18: Expected O, but got Unknown
			//IL_0d30: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d3a: Expected O, but got Unknown
			//IL_0d52: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d5c: Expected O, but got Unknown
			//IL_0d74: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d7e: Expected O, but got Unknown
			//IL_0d96: Unknown result type (might be due to invalid IL or missing references)
			//IL_0da0: Expected O, but got Unknown
			//IL_0db8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dc2: Expected O, but got Unknown
			//IL_0dda: Unknown result type (might be due to invalid IL or missing references)
			//IL_0de4: Expected O, but got Unknown
			//IL_0dfc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e06: Expected O, but got Unknown
			//IL_0e1e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e28: Expected O, but got Unknown
			//IL_0e40: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e4a: Expected O, but got Unknown
			//IL_0e62: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e6c: Expected O, but got Unknown
			//IL_0e84: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e8e: Expected O, but got Unknown
			//IL_0ea6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0eb0: Expected O, but got Unknown
			//IL_0ec8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ed2: Expected O, but got Unknown
			//IL_0eed: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ef7: Expected O, but got Unknown
			//IL_0f0f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f19: Expected O, but got Unknown
			//IL_0f31: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f3b: Expected O, but got Unknown
			//IL_0f53: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f5d: Expected O, but got Unknown
			//IL_0f75: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f7f: Expected O, but got Unknown
			//IL_0f97: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fa1: Expected O, but got Unknown
			//IL_0fb9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fc3: Expected O, but got Unknown
			//IL_0fdb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fe5: Expected O, but got Unknown
			//IL_0ffd: Unknown result type (might be due to invalid IL or missing references)
			//IL_1007: Expected O, but got Unknown
			//IL_101f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1029: Expected O, but got Unknown
			//IL_1041: Unknown result type (might be due to invalid IL or missing references)
			//IL_104b: Expected O, but got Unknown
			//IL_1063: Unknown result type (might be due to invalid IL or missing references)
			//IL_106d: Expected O, but got Unknown
			//IL_1085: Unknown result type (might be due to invalid IL or missing references)
			//IL_108f: Expected O, but got Unknown
			//IL_10a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_10b1: Expected O, but got Unknown
			//IL_10c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_10d3: Expected O, but got Unknown
			//IL_10eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_10f5: Expected O, but got Unknown
			//IL_1110: Unknown result type (might be due to invalid IL or missing references)
			//IL_111a: Expected O, but got Unknown
			//IL_1132: Unknown result type (might be due to invalid IL or missing references)
			//IL_113c: Expected O, but got Unknown
			//IL_1154: Unknown result type (might be due to invalid IL or missing references)
			//IL_115e: Expected O, but got Unknown
			//IL_1176: Unknown result type (might be due to invalid IL or missing references)
			//IL_1180: Expected O, but got Unknown
			//IL_1198: Unknown result type (might be due to invalid IL or missing references)
			//IL_11a2: Expected O, but got Unknown
			//IL_11ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_11c4: Expected O, but got Unknown
			//IL_11dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_11e6: Expected O, but got Unknown
			//IL_11fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_1208: Expected O, but got Unknown
			//IL_1220: Unknown result type (might be due to invalid IL or missing references)
			//IL_122a: Expected O, but got Unknown
			//IL_1242: Unknown result type (might be due to invalid IL or missing references)
			//IL_124c: Expected O, but got Unknown
			//IL_1264: Unknown result type (might be due to invalid IL or missing references)
			//IL_126e: Expected O, but got Unknown
			//IL_1286: Unknown result type (might be due to invalid IL or missing references)
			//IL_1290: Expected O, but got Unknown
			//IL_12a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_12b2: Expected O, but got Unknown
			//IL_12cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_12d7: Expected O, but got Unknown
			//IL_12ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_12f9: Expected O, but got Unknown
			//IL_1311: Unknown result type (might be due to invalid IL or missing references)
			//IL_131b: Expected O, but got Unknown
			//IL_1333: Unknown result type (might be due to invalid IL or missing references)
			//IL_133d: Expected O, but got Unknown
			//IL_1355: Unknown result type (might be due to invalid IL or missing references)
			//IL_135f: Expected O, but got Unknown
			//IL_1377: Unknown result type (might be due to invalid IL or missing references)
			//IL_1381: Expected O, but got Unknown
			//IL_1399: Unknown result type (might be due to invalid IL or missing references)
			//IL_13a3: Expected O, but got Unknown
			//IL_13bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_13c5: Expected O, but got Unknown
			//IL_13dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_13e7: Expected O, but got Unknown
			//IL_13fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_1405: Expected O, but got Unknown
			//IL_1419: Unknown result type (might be due to invalid IL or missing references)
			//IL_1423: Expected O, but got Unknown
			//IL_143b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1445: Expected O, but got Unknown
			//IL_145d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1467: Expected O, but got Unknown
			//IL_147f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1489: Expected O, but got Unknown
			//IL_14a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_14ab: Expected O, but got Unknown
			//IL_14c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_14cd: Expected O, but got Unknown
			//IL_14e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_14f2: Expected O, but got Unknown
			//IL_150a: Unknown result type (might be due to invalid IL or missing references)
			//IL_1514: Expected O, but got Unknown
			//IL_152c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1536: Expected O, but got Unknown
			//IL_154e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1558: Expected O, but got Unknown
			//IL_1570: Unknown result type (might be due to invalid IL or missing references)
			//IL_157a: Expected O, but got Unknown
			//IL_1592: Unknown result type (might be due to invalid IL or missing references)
			//IL_159c: Expected O, but got Unknown
			//IL_15b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_15be: Expected O, but got Unknown
			//IL_15d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_15e0: Expected O, but got Unknown
			//IL_15f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_1602: Expected O, but got Unknown
			//IL_161a: Unknown result type (might be due to invalid IL or missing references)
			//IL_1624: Expected O, but got Unknown
			//IL_163c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1646: Expected O, but got Unknown
			//IL_165e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1668: Expected O, but got Unknown
			//IL_1680: Unknown result type (might be due to invalid IL or missing references)
			//IL_168a: Expected O, but got Unknown
			//IL_16a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_16ac: Expected O, but got Unknown
			//IL_16c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_16ce: Expected O, but got Unknown
			//IL_16e9: Unknown result type (might be due to invalid IL or missing references)
			//IL_16f3: Expected O, but got Unknown
			//IL_170b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1715: Expected O, but got Unknown
			//IL_172d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1737: Expected O, but got Unknown
			//IL_174f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1759: Expected O, but got Unknown
			//IL_1771: Unknown result type (might be due to invalid IL or missing references)
			//IL_177b: Expected O, but got Unknown
			//IL_1793: Unknown result type (might be due to invalid IL or missing references)
			//IL_179d: Expected O, but got Unknown
			//IL_17b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_17bf: Expected O, but got Unknown
			//IL_17d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_17e1: Expected O, but got Unknown
			//IL_17f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1803: Expected O, but got Unknown
			//IL_181b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1825: Expected O, but got Unknown
			//IL_183d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1847: Expected O, but got Unknown
			//IL_185f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1869: Expected O, but got Unknown
			//IL_1881: Unknown result type (might be due to invalid IL or missing references)
			//IL_188b: Expected O, but got Unknown
			//IL_18a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_18ad: Expected O, but got Unknown
			//IL_18c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_18cf: Expected O, but got Unknown
			//IL_18ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_18f4: Expected O, but got Unknown
			//IL_190c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1916: Expected O, but got Unknown
			//IL_192e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1938: Expected O, but got Unknown
			//IL_1950: Unknown result type (might be due to invalid IL or missing references)
			//IL_195a: Expected O, but got Unknown
			//IL_1972: Unknown result type (might be due to invalid IL or missing references)
			//IL_197c: Expected O, but got Unknown
			//IL_1994: Unknown result type (might be due to invalid IL or missing references)
			//IL_199e: Expected O, but got Unknown
			//IL_19b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_19c0: Expected O, but got Unknown
			//IL_19d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_19e2: Expected O, but got Unknown
			//IL_19fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a04: Expected O, but got Unknown
			//IL_1a1c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a26: Expected O, but got Unknown
			//IL_1a3e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a48: Expected O, but got Unknown
			//IL_1a60: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a6a: Expected O, but got Unknown
			//IL_1a82: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a8c: Expected O, but got Unknown
			//IL_1aa4: Unknown result type (might be due to invalid IL or missing references)
			//IL_1aae: Expected O, but got Unknown
			//IL_1ac6: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ad0: Expected O, but got Unknown
			//IL_1aeb: Unknown result type (might be due to invalid IL or missing references)
			//IL_1af5: Expected O, but got Unknown
			//IL_1b0d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b17: Expected O, but got Unknown
			//IL_1b2f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b39: Expected O, but got Unknown
			//IL_1b51: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b5b: Expected O, but got Unknown
			//IL_1b73: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b7d: Expected O, but got Unknown
			//IL_1b95: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b9f: Expected O, but got Unknown
			//IL_1bb7: Unknown result type (might be due to invalid IL or missing references)
			//IL_1bc1: Expected O, but got Unknown
			//IL_1bd9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1be3: Expected O, but got Unknown
			//IL_1bfb: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c05: Expected O, but got Unknown
			//IL_1c1d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c27: Expected O, but got Unknown
			//IL_1c3f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c49: Expected O, but got Unknown
			//IL_1c61: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c6b: Expected O, but got Unknown
			//IL_1c83: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c8d: Expected O, but got Unknown
			//IL_1ca5: Unknown result type (might be due to invalid IL or missing references)
			//IL_1caf: Expected O, but got Unknown
			//IL_1cc7: Unknown result type (might be due to invalid IL or missing references)
			//IL_1cd1: Expected O, but got Unknown
			//IL_1ce9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1cf3: Expected O, but got Unknown
			//IL_1d0e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1d18: Expected O, but got Unknown
			//IL_1d30: Unknown result type (might be due to invalid IL or missing references)
			//IL_1d3a: Expected O, but got Unknown
			//IL_1dab: Unknown result type (might be due to invalid IL or missing references)
			//IL_1db5: Expected O, but got Unknown
			//IL_1dc9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1dd3: Expected O, but got Unknown
			//IL_1de7: Unknown result type (might be due to invalid IL or missing references)
			//IL_1df1: Expected O, but got Unknown
			//IL_1e04: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e0e: Expected O, but got Unknown
			//IL_1e21: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e2b: Expected O, but got Unknown
			//IL_1e41: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e4b: Expected O, but got Unknown
			//IL_1e54: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e5e: Expected O, but got Unknown
			//IL_1e6c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e76: Expected O, but got Unknown
			//IL_1e84: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e8e: Expected O, but got Unknown
			//IL_1e9c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ea6: Expected O, but got Unknown
			//IL_1eb4: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ebe: Expected O, but got Unknown
			//IL_1ecc: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ed6: Expected O, but got Unknown
			//IL_1ee4: Unknown result type (might be due to invalid IL or missing references)
			//IL_1eee: Expected O, but got Unknown
			//IL_1efc: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f06: Expected O, but got Unknown
			//IL_1f14: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f1e: Expected O, but got Unknown
			//IL_1f2c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f36: Expected O, but got Unknown
			//IL_1f44: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f4e: Expected O, but got Unknown
			//IL_1f5c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f66: Expected O, but got Unknown
			//IL_1f74: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f7e: Expected O, but got Unknown
			List<object> list14 = new List<object>();
			list14.Add("Classic Black");
			list14.Add("Classic Gray");
			list14.Add("Classic Two-Tone");
			list14.Add("Classic White");
			list14.Add("Classic Beige");
			list14.Add("Classic Green");
			list14.Add("Classic Blue");
			list14.Add("Classic Earth");
			list14.Add("Classic Brown & Black");
			list14.Add("Red Contrast");
			list14.Add("Blue Contrast");
			list14.Add("Yellow Contrast");
			list14.Add("Orange Contrast");
			list14.Add("Bold Pink");
			list14.Add("Bold Purple & Yellow");
			list14.Add("Bold Orange");
			list14.Add("Bold Green & Purple");
			list14.Add("Bold Red & Black");
			list14.Add("Bold Green & Black");
			list14.Add("Bold Cyan & Black");
			list14.Add("Bold Yellow & Black");
			list14.Add("Bold Red & White");
			list14.Add("Bold Blue & White");
			list14.Add("Metallic Gold");
			list14.Add("Metallic Platinum");
			list14.Add("Metallic Gray & Lilac");
			list14.Add("Metallic Purple & Lime");
			list14.Add("Metallic Red");
			list14.Add("Metallic Green");
			list14.Add("Metallic Blue");
			list14.Add("Metallic White & Aqua");
			list14.Add("Metallic Red & Yellow");
			float CPrice = 34000f;
			List<dynamic> Mk2Weapons = new List<object>();
			Mk2Weapons.Add(WeaponHash.AssaultrifleMk2);
			Mk2Weapons.Add(WeaponHash.BullpupRifleMk2);
			Mk2Weapons.Add(WeaponHash.CarbineRifleMk2);
			Mk2Weapons.Add(WeaponHash.CombatMGMk2);
			Mk2Weapons.Add(WeaponHash.HeavySniperMk2);
			Mk2Weapons.Add(WeaponHash.MarksmanRifleMk2);
			Mk2Weapons.Add(WeaponHash.PistolMk2);
			Mk2Weapons.Add(WeaponHash.PumpShotgunMk2);
			Mk2Weapons.Add(WeaponHash.RevolverMk2);
			Mk2Weapons.Add(WeaponHash.SMGMk2);
			Mk2Weapons.Add(WeaponHash.SNSPistolMk2);
			Mk2Weapons.Add(WeaponHash.SpecialCarbineMk2);
			List<dynamic> Components = new List<object>();
			Components.Add(WeaponComponent.AssaultRifleClip01);
			Components.Add(WeaponComponent.AssaultRifleClip02);
			UIMenu uIMenu = modMenuPool.AddSubMenu(weaponsMenu, "Mk2 Weapons (Advanced)");
			UIMenuListItem W = new UIMenuListItem("Weapon : ", (List<object>)Mk2Weapons, 0);
			uIMenu.AddItem((UIMenuItem)(object)W);
			UIMenuListItem C = new UIMenuListItem("Component  : ", (List<object>)Components, 0);
			uIMenu.AddItem((UIMenuItem)(object)C);
			UIMenuItem Enable = new UIMenuItem("Enable Component : $" + CPrice.ToString("N"));
			uIMenu.AddItem(Enable);
			UIMenuItem DIsable = new UIMenuItem("Disable Component");
			uIMenu.AddItem(DIsable);
			UIMenuListItem WT = new UIMenuListItem("Tint ", list14, 0);
			uIMenu.AddItem((UIMenuItem)(object)WT);
			UIMenuItem getTintAV = new UIMenuItem("Buy Tint: $10,000");
			uIMenu.AddItem(getTintAV);
			uIMenu.add_OnListChange((ListChangedEvent)delegate(UIMenu sender, UIMenuListItem item, int index)
			{
				if (item == W)
				{
					if (Game.Player.Character.Weapons.HasWeapon(Mk2Weapons[W.get_Index()]))
					{
						Components.Clear();
						Game.Player.Character.Weapons.Select(Mk2Weapons[W.get_Index()], true);
						WeaponComponent[] array = (WeaponComponent[])Enum.GetValues(typeof(WeaponComponent));
						for (int k = 0; k < array.Length; k++)
						{
							WeaponComponent weaponComponent = array[k];
							try
							{
								if (Function.Call<bool>(Hash._0x5CEE3DF569CECAB0, new InputArgument[2]
								{
									W.IndexToItem(W.get_Index()).GetHashCode(),
									weaponComponent.GetHashCode()
								}))
								{
									Components.Add(weaponComponent);
								}
							}
							catch
							{
							}
						}
					}
					string text2 = Components[C.get_Index()].ToString();
					if (text2.Contains("Muzzle"))
					{
						CPrice = 45700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Barrel"))
					{
						CPrice = 48700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Barrel"))
					{
						CPrice = 48700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Sights"))
					{
						CPrice = 24700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Tracer"))
					{
						CPrice = 42700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("FMJ"))
					{
						CPrice = 73000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("ArmourPiercing"))
					{
						CPrice = 63000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Incediary"))
					{
						CPrice = 49000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("ClipExplosive"))
					{
						CPrice = 115450f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Grip"))
					{
						CPrice = 14080f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Supp"))
					{
						CPrice = 40250f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Clip02"))
					{
						CPrice = 60000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo01"))
					{
						CPrice = 40000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo02"))
					{
						CPrice = 43500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo03"))
					{
						CPrice = 43500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo04"))
					{
						CPrice = 45500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo05"))
					{
						CPrice = 49500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo06"))
					{
						CPrice = 75500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo07"))
					{
						CPrice = 51500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo08"))
					{
						CPrice = 53500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo09"))
					{
						CPrice = 55500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Camo10"))
					{
						CPrice = 60500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text2.Contains("Independence"))
					{
						CPrice = 100500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
				}
				if (item == C)
				{
					string text3 = Components[C.get_Index()].ToString();
					if (text3.Contains("Barrel"))
					{
						CPrice = 48700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Barrel"))
					{
						CPrice = 48700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Sights"))
					{
						CPrice = 24700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Tracer"))
					{
						CPrice = 42700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("FMJ"))
					{
						CPrice = 73000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("ArmourPiercing"))
					{
						CPrice = 63000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Incediary"))
					{
						CPrice = 49000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("ClipExplosive"))
					{
						CPrice = 115450f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Grip"))
					{
						CPrice = 14080f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Supp"))
					{
						CPrice = 40250f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Clip02"))
					{
						CPrice = 60000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo01"))
					{
						CPrice = 40000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo02"))
					{
						CPrice = 43500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo03"))
					{
						CPrice = 43500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo04"))
					{
						CPrice = 45500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo05"))
					{
						CPrice = 49500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo06"))
					{
						CPrice = 75500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo07"))
					{
						CPrice = 51500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo08"))
					{
						CPrice = 53500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo09"))
					{
						CPrice = 55500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Camo10"))
					{
						CPrice = 60500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text3.Contains("Independence"))
					{
						CPrice = 100500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
				}
			});
			uIMenu.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTintAV)
				{
					try
					{
						int index15 = WT.get_Index();
						Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
						{
							Game.Player.Character,
							Game.Player.Character.Weapons.Current.GetHashCode(),
							index15
						});
						Game.Player.Character.Weapons.Current.Tint = (WeaponTint)index15;
						Game.Player.Money = Game.Player.Money - 10000;
					}
					catch (Exception)
					{
						UI.Notify("Error");
					}
				}
				if (item == Enable)
				{
					string text = Components[C.get_Index()].ToString();
					if (text.Contains("Barrel"))
					{
						CPrice = 48700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Barrel"))
					{
						CPrice = 48700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Sights"))
					{
						CPrice = 24700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Tracer"))
					{
						CPrice = 42700f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("FMJ"))
					{
						CPrice = 73000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("ArmourPiercing"))
					{
						CPrice = 63000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Incediary"))
					{
						CPrice = 49000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("ClipExplosive"))
					{
						CPrice = 115450f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Grip"))
					{
						CPrice = 14080f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Supp"))
					{
						CPrice = 40250f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Clip02"))
					{
						CPrice = 60000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo01"))
					{
						CPrice = 40000f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo02"))
					{
						CPrice = 43500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo03"))
					{
						CPrice = 43500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo04"))
					{
						CPrice = 45500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo05"))
					{
						CPrice = 49500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo06"))
					{
						CPrice = 75500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo07"))
					{
						CPrice = 51500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo08"))
					{
						CPrice = 53500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo09"))
					{
						CPrice = 55500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Camo10"))
					{
						CPrice = 60500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if (text.Contains("Independence"))
					{
						CPrice = 100500f;
						Enable.set_Text("Enable Component : $" + CPrice.ToString("N"));
					}
					if ((float)Game.Player.Money >= CPrice)
					{
						Game.Player.Money -= (int)CPrice;
						if ((Game.Player.Character.Weapons.HasWeapon(Mk2Weapons[W.get_Index()])) && Function.Call<bool>(Hash._0x5CEE3DF569CECAB0, new InputArgument[2]
						{
							W.IndexToItem(W.get_Index()).GetHashCode(),
							C.IndexToItem(C.get_Index()).GetHashCode()
						}))
						{
							Game.Player.Character.Weapons.Select(Mk2Weapons[W.get_Index()], true);
							Game.Player.Character.Weapons.Current.SetComponent(Components[C.get_Index()], true);
						}
					}
				}
				if (item == DIsable && (Game.Player.Character.Weapons.HasWeapon(Mk2Weapons[W.get_Index()])) && ((Function.Call<bool>(Hash._0x5CEE3DF569CECAB0, Mk2Weapons[W.get_Index()].GetHashCode(), Components[C.get_Index()].GetHashCode()) == true) ? true : false))
				{
					Game.Player.Character.Weapons.Select(Mk2Weapons[W.get_Index()], true);
					Game.Player.Character.Weapons.Current.SetComponent(Components[C.get_Index()], false);
				}
			});
			UIMenu uIMenu2 = modMenuPool.AddSubMenu(weaponsMenu, "Scifi Weapons");
			UIMenu uIMenu3 = modMenuPool.AddSubMenu(weaponsMenu, "Mk2 Weapons");
			UIMenu uIMenu4 = modMenuPool.AddSubMenu(weaponsMenu, "Normal Weapons");
			List<object> list15 = new List<object>();
			for (int i = 0; i < Tintscount; i++)
			{
				list15.Add(i);
			}
			MK2Pumpshotgun = modMenuPool.AddSubMenu(uIMenu3, "MK2 Pump Shotgun");
			MK2SNSPistol = modMenuPool.AddSubMenu(uIMenu3, "MK2 SNS Pistol");
			MK2Revolver = modMenuPool.AddSubMenu(uIMenu3, "MK2 Revolver");
			Mk2SpecialCarbine = modMenuPool.AddSubMenu(uIMenu3, "MK2 Special Carbine");
			MK2Bullpup = modMenuPool.AddSubMenu(uIMenu3, "MK2 Bullpup Rifle");
			MK2MarksmanRifle = modMenuPool.AddSubMenu(uIMenu3, "MK2 Marksmans Rifle");
			MK2Pistol = modMenuPool.AddSubMenu(uIMenu3, "MK2 Pistol");
			MK2SMG = modMenuPool.AddSubMenu(uIMenu3, "MK2 SMG");
			MK2LMG = modMenuPool.AddSubMenu(uIMenu3, "MK2 LMG");
			MK2Carbine = modMenuPool.AddSubMenu(uIMenu3, "MK2 Carbine");
			MK2AssaultRifle = modMenuPool.AddSubMenu(uIMenu3, "MK2 Assault Rifle");
			MK2Sniper = modMenuPool.AddSubMenu(uIMenu3, "MK2 Sniper");
			UIMenuItem mk2ShotgunP = new UIMenuItem("MK2 Pump Shotgun: $75,000");
			MK2Pumpshotgun.AddItem(mk2ShotgunP);
			UIMenuItem mk2Shotgunclip = new UIMenuItem("Normal Shells : $0");
			MK2Pumpshotgun.AddItem(mk2Shotgunclip);
			UIMenuItem mk2Shotgunclip2 = new UIMenuItem("Dragon's Breath Shells : $65,200");
			MK2Pumpshotgun.AddItem(mk2Shotgunclip2);
			UIMenuItem mk2Shotgunclip4 = new UIMenuItem("Flechette Shells: $75,140");
			MK2Pumpshotgun.AddItem(mk2Shotgunclip4);
			UIMenuItem mk2Shotgunclip3 = new UIMenuItem("Steel Buckshot Shells: $96,645");
			MK2Pumpshotgun.AddItem(mk2Shotgunclip3);
			UIMenuItem mk2Shotgunclip5 = new UIMenuItem("Explosive Shells: $145,850");
			MK2Pumpshotgun.AddItem(mk2Shotgunclip5);
			UIMenuItem mk2Shotgunsights = new UIMenuItem("Holographic Sight: $29,260");
			MK2Pumpshotgun.AddItem(mk2Shotgunsights);
			UIMenuItem mk2Shotgunsights2 = new UIMenuItem("Small Scope: $39,920");
			MK2Pumpshotgun.AddItem(mk2Shotgunsights2);
			UIMenuItem mk2Shotgunsights3 = new UIMenuItem("Medium Scope: $50,785");
			MK2Pumpshotgun.AddItem(mk2Shotgunsights3);
			UIMenuItem mk2Shotgunflashlight = new UIMenuItem("Flashlight: $10,500");
			MK2Pumpshotgun.AddItem(mk2Shotgunflashlight);
			UIMenuItem mk2ShotgunSuppressor = new UIMenuItem("Suppressor: $45,860");
			MK2Pumpshotgun.AddItem(mk2ShotgunSuppressor);
			UIMenuItem mk2Shotgunmuzzle = new UIMenuItem("Muzzle Brake: $37,650");
			MK2Pumpshotgun.AddItem(mk2Shotgunmuzzle);
			UIMenuListItem list2 = new UIMenuListItem("Tint ", list15, 0);
			MK2Pumpshotgun.AddItem((UIMenuItem)(object)list2);
			UIMenuItem getTint1 = new UIMenuItem("Buy Tint: $10,000");
			MK2Pumpshotgun.AddItem(getTint1);
			UIMenuItem mk2Snspistol = new UIMenuItem("MK2 SNS Pistol: $35,000");
			MK2SNSPistol.AddItem(mk2Snspistol);
			UIMenuItem mk2Snspistolclipn = new UIMenuItem("Default Clip: $8,000");
			MK2SNSPistol.AddItem(mk2Snspistolclipn);
			UIMenuItem mk2Snspistolclipe = new UIMenuItem("Extended Clip: $18,300");
			MK2SNSPistol.AddItem(mk2Snspistolclipe);
			UIMenuItem mk2Snspistolclip1 = new UIMenuItem("Tracer Rounds: $34,320");
			MK2SNSPistol.AddItem(mk2Snspistolclip1);
			UIMenuItem mk2Snspistolclip2 = new UIMenuItem("Incendiary Rounds: $41,700");
			MK2SNSPistol.AddItem(mk2Snspistolclip2);
			UIMenuItem mk2Snspistolclip3 = new UIMenuItem("Hollow Point Rounds : $47,580");
			MK2SNSPistol.AddItem(mk2Snspistolclip3);
			UIMenuItem mk2Snspistolclip4 = new UIMenuItem("Full Metal Jacket Rounds: $62,400");
			MK2SNSPistol.AddItem(mk2Snspistolclip4);
			UIMenuItem mk2Snspistolflash = new UIMenuItem("Flashlight: $7,500");
			MK2SNSPistol.AddItem(mk2Snspistolflash);
			UIMenuItem mk2Snspistolscope1 = new UIMenuItem("Mounted Scope: $16,250");
			MK2SNSPistol.AddItem(mk2Snspistolscope1);
			UIMenuItem mk2Snspistolsuppressor = new UIMenuItem("Suppressor: $28,750");
			MK2SNSPistol.AddItem(mk2Snspistolsuppressor);
			UIMenuItem mk2Snspistolcomp = new UIMenuItem("Compensator: $21,250");
			MK2SNSPistol.AddItem(mk2Snspistolcomp);
			UIMenuListItem list6 = new UIMenuListItem("Tint ", list15, 0);
			MK2SNSPistol.AddItem((UIMenuItem)(object)list6);
			UIMenuItem getTint5 = new UIMenuItem("Buy Tint: $10,000");
			MK2SNSPistol.AddItem(getTint5);
			UIMenuItem mk2Revolver = new UIMenuItem("MK2 Revolver: $35,000");
			MK2Revolver.AddItem(mk2Revolver);
			UIMenuItem mk2Revolverclip = new UIMenuItem("Normal Rounds: $0");
			MK2Revolver.AddItem(mk2Revolverclip);
			UIMenuItem mk2Revolverclip2 = new UIMenuItem("Tracer Rounds: $31,460");
			MK2Revolver.AddItem(mk2Revolverclip2);
			UIMenuItem mk2Revolverclip3 = new UIMenuItem("Incendiary Rounds: $38,225");
			MK2Revolver.AddItem(mk2Revolverclip3);
			UIMenuItem mk2Revolverclip4 = new UIMenuItem("Hollow Point Rounds: $43,615");
			MK2Revolver.AddItem(mk2Revolverclip4);
			UIMenuItem mk2Revolverclip5 = new UIMenuItem("Full Metal Jacket Rounds: $57,200");
			MK2Revolver.AddItem(mk2Revolverclip5);
			UIMenuItem mk2Revolversights = new UIMenuItem("Holographic Sight: $16,250");
			MK2Revolver.AddItem(mk2Revolversights);
			UIMenuItem mk2Revolversights2 = new UIMenuItem("Small Scope: $25,450");
			MK2Revolver.AddItem(mk2Revolversights2);
			UIMenuItem mk2Revolverflashlight = new UIMenuItem("Flashlight: $7,500");
			MK2Revolver.AddItem(mk2Revolverflashlight);
			UIMenuItem mk2RevolverComp = new UIMenuItem("Compensator: $21,250");
			MK2Revolver.AddItem(mk2RevolverComp);
			UIMenuListItem list7 = new UIMenuListItem("Tint ", list15, 0);
			MK2Revolver.AddItem((UIMenuItem)(object)list7);
			UIMenuItem getTint6 = new UIMenuItem("Buy Tint: $10,000");
			MK2Revolver.AddItem(getTint6);
			UIMenuItem mk2SCarbine = new UIMenuItem("MK2 Special Carbine: $65,000");
			Mk2SpecialCarbine.AddItem(mk2SCarbine);
			UIMenuItem mk2SCarbineclip = new UIMenuItem("Default Clip: $5,000");
			Mk2SpecialCarbine.AddItem(mk2SCarbineclip);
			UIMenuItem mk2SCarbineclip2 = new UIMenuItem("Extended Clip: $26,450");
			Mk2SpecialCarbine.AddItem(mk2SCarbineclip2);
			UIMenuItem mk2SCarbineclip3 = new UIMenuItem("Tracer Rounds: $61,465");
			Mk2SpecialCarbine.AddItem(mk2SCarbineclip3);
			UIMenuItem mk2SCarbineclip4 = new UIMenuItem("Incendiary Rounds : $70,950");
			Mk2SpecialCarbine.AddItem(mk2SCarbineclip4);
			UIMenuItem mk2SCarbineclip5 = new UIMenuItem("Armor Piercing Rounds : $90,750");
			Mk2SpecialCarbine.AddItem(mk2SCarbineclip5);
			UIMenuItem mk2SCarbineclip6 = new UIMenuItem("Full Metal Jacket Rounds : $104,775");
			Mk2SpecialCarbine.AddItem(mk2SCarbineclip6);
			UIMenuItem mk2SCarbineflash = new UIMenuItem("Flashlight: $10,500");
			Mk2SpecialCarbine.AddItem(mk2SCarbineflash);
			UIMenuItem mk2SCarbinesight1 = new UIMenuItem("Holographic Sight: $19,600");
			Mk2SpecialCarbine.AddItem(mk2SCarbinesight1);
			UIMenuItem mk2SCarbinesight2 = new UIMenuItem("Small Scope: $23,730");
			Mk2SpecialCarbine.AddItem(mk2SCarbinesight2);
			UIMenuItem mk2SCarbinesight3 = new UIMenuItem("Large Scope: $34,020");
			Mk2SpecialCarbine.AddItem(mk2SCarbinesight3);
			UIMenuItem mk2SCarbinesupressor = new UIMenuItem("Suppressor : $40,250");
			Mk2SpecialCarbine.AddItem(mk2SCarbinesupressor);
			UIMenuItem mk2SCarbinemuzzle = new UIMenuItem("Muzzle : $29,750");
			Mk2SpecialCarbine.AddItem(mk2SCarbinemuzzle);
			UIMenuItem mk2SCarbinegrip = new UIMenuItem("Grip : $14,080");
			Mk2SpecialCarbine.AddItem(mk2SCarbinegrip);
			UIMenuListItem list8 = new UIMenuListItem("Tint ", list15, 0);
			Mk2SpecialCarbine.AddItem((UIMenuItem)(object)list8);
			UIMenuItem getTint7 = new UIMenuItem("Buy Tint: $10,000");
			Mk2SpecialCarbine.AddItem(getTint7);
			UIMenuItem mk2Bullpup = new UIMenuItem("MK2 Bullpup Rifle: $60,000");
			MK2Bullpup.AddItem(mk2Bullpup);
			UIMenuItem mk2Bullpupclip1 = new UIMenuItem("Default Clip : $5,000");
			MK2Bullpup.AddItem(mk2Bullpupclip1);
			UIMenuItem mk2Bullpupclip2 = new UIMenuItem("Extended Clip : $22,100");
			MK2Bullpup.AddItem(mk2Bullpupclip2);
			UIMenuItem mk2Bullpupclip3 = new UIMenuItem("Tracer Rounds : $44,350");
			MK2Bullpup.AddItem(mk2Bullpupclip3);
			UIMenuItem mk2Bullpupclip4 = new UIMenuItem("Incendiary Rounds : $52,100");
			MK2Bullpup.AddItem(mk2Bullpupclip4);
			UIMenuItem mk2Bullpupclip5 = new UIMenuItem("Armor Piercing Rounds  : $87,320");
			MK2Bullpup.AddItem(mk2Bullpupclip5);
			UIMenuItem mk2Bullpupclip6 = new UIMenuItem("Full Metal Jacket Rounds : $77,490");
			MK2Bullpup.AddItem(mk2Bullpupclip6);
			UIMenuItem mk2Bullpupflash = new UIMenuItem("Flashlight  : $10,500");
			MK2Bullpup.AddItem(mk2Bullpupflash);
			UIMenuItem mk2Bullpupsight1 = new UIMenuItem("Holographic Sight : $19,600");
			MK2Bullpup.AddItem(mk2Bullpupsight1);
			UIMenuItem mk2Bullpupsight2 = new UIMenuItem("Small Scope : $23,730");
			MK2Bullpup.AddItem(mk2Bullpupsight2);
			UIMenuItem mk2Bullpupsight3 = new UIMenuItem("Medium Scope : $34,020");
			MK2Bullpup.AddItem(mk2Bullpupsight3);
			UIMenuItem mk2BullpupBarrel = new UIMenuItem("Heavy Barrel : $49,000");
			MK2Bullpup.AddItem(mk2BullpupBarrel);
			UIMenuItem mk2BullpupGrip = new UIMenuItem("Grip : $14,080");
			MK2Bullpup.AddItem(mk2BullpupGrip);
			UIMenuItem mk2Bullpupmuzzle = new UIMenuItem("Muzzle  : $29,750");
			MK2Bullpup.AddItem(mk2Bullpupmuzzle);
			UIMenuItem mk2BullpupSuppressor = new UIMenuItem("Suppressor  : $40,250");
			MK2Bullpup.AddItem(mk2BullpupSuppressor);
			UIMenuListItem list9 = new UIMenuListItem("Tint ", list15, 0);
			MK2Bullpup.AddItem((UIMenuItem)(object)list9);
			UIMenuItem getTint8 = new UIMenuItem("Buy Tint: $10,000");
			MK2Bullpup.AddItem(getTint8);
			UIMenuItem mk2marksman = new UIMenuItem("MK2 Marksman Rifle : $80,000");
			MK2MarksmanRifle.AddItem(mk2marksman);
			UIMenuItem mk2marksmanclip1 = new UIMenuItem("Default Clip : $5,000");
			MK2MarksmanRifle.AddItem(mk2marksmanclip1);
			UIMenuItem mk2marksmanclip2 = new UIMenuItem("Extended Clip : $26,850");
			MK2MarksmanRifle.AddItem(mk2marksmanclip2);
			UIMenuItem mk2marksmanclip3 = new UIMenuItem("Tracer Rounds : $49,775");
			MK2MarksmanRifle.AddItem(mk2marksmanclip3);
			UIMenuItem mk2marksmanclip4 = new UIMenuItem("Incendiary Rounds : $57,295");
			MK2MarksmanRifle.AddItem(mk2marksmanclip4);
			UIMenuItem mk2marksmanclip5 = new UIMenuItem("Armor Piercing Rounds  : $73,560");
			MK2MarksmanRifle.AddItem(mk2marksmanclip5);
			UIMenuItem mk2marksmanclip6 = new UIMenuItem("Full Metal Jacket Rounds : $85,570");
			MK2MarksmanRifle.AddItem(mk2marksmanclip6);
			UIMenuItem mk2marksmanflash = new UIMenuItem("Flashlight  : $11,250");
			MK2MarksmanRifle.AddItem(mk2marksmanflash);
			UIMenuItem mk2marksmansight1 = new UIMenuItem("Holographic Sight  : $11,485");
			MK2MarksmanRifle.AddItem(mk2marksmansight1);
			UIMenuItem mk2marksmansight2 = new UIMenuItem("Large Scope  : $17,870");
			MK2MarksmanRifle.AddItem(mk2marksmansight2);
			UIMenuItem mk2marksmansight3 = new UIMenuItem("Zoom Scope  : $27,150");
			MK2MarksmanRifle.AddItem(mk2marksmansight3);
			UIMenuItem mk2marksmanGrip = new UIMenuItem("Grip  : $14,080");
			MK2MarksmanRifle.AddItem(mk2marksmanGrip);
			UIMenuItem mk2marksmanmuzzle = new UIMenuItem("Muzzle  : $44,620");
			MK2MarksmanRifle.AddItem(mk2marksmanmuzzle);
			UIMenuItem mk2marksmanSuppressor = new UIMenuItem("Suppressor  : $60,375");
			MK2MarksmanRifle.AddItem(mk2marksmanSuppressor);
			UIMenuListItem list10 = new UIMenuListItem("Tint ", list15, 0);
			MK2MarksmanRifle.AddItem((UIMenuItem)(object)list10);
			UIMenuItem getTint9 = new UIMenuItem("Buy Tint: $10,000");
			MK2MarksmanRifle.AddItem(getTint9);
			UIMenuItem mk2pistol = new UIMenuItem("MK2 Pistol : $20,000");
			MK2Pistol.AddItem(mk2pistol);
			UIMenuItem mk2pistolClip = new UIMenuItem("Default Clip : $0");
			MK2Pistol.AddItem(mk2pistolClip);
			UIMenuItem mk2pistolClip2 = new UIMenuItem("Extended Clip : $15,250");
			MK2Pistol.AddItem(mk2pistolClip2);
			UIMenuItem mk2pistolClip3 = new UIMenuItem("Tracer Rounds : $32,850");
			MK2Pistol.AddItem(mk2pistolClip3);
			UIMenuItem mk2pistolClip4 = new UIMenuItem("Incendiary Rounds : $34,750");
			MK2Pistol.AddItem(mk2pistolClip4);
			UIMenuItem mk2pistolClip5 = new UIMenuItem("Hollow Point Rounds : $39,650");
			MK2Pistol.AddItem(mk2pistolClip5);
			UIMenuItem mk2pistolClip6 = new UIMenuItem("Full Metal Jacket Rounds  : $52,000");
			MK2Pistol.AddItem(mk2pistolClip6);
			UIMenuItem mk2pistolSight1 = new UIMenuItem("Mounted Scope : $16,250");
			MK2Pistol.AddItem(mk2pistolSight1);
			UIMenuItem mk2pistolflash = new UIMenuItem("Flashlight : $7,500");
			MK2Pistol.AddItem(mk2pistolflash);
			UIMenuItem mk2pistolsupp = new UIMenuItem("Suppressor : $28,750");
			MK2Pistol.AddItem(mk2pistolsupp);
			UIMenuItem mk2pistolcomp = new UIMenuItem("Compensator : $21,250");
			MK2Pistol.AddItem(mk2pistolcomp);
			UIMenuListItem list11 = new UIMenuListItem("Tint ", list15, 0);
			MK2Pistol.AddItem((UIMenuItem)(object)list11);
			UIMenuItem getTint10 = new UIMenuItem("Buy Tint: $10,000");
			MK2Pistol.AddItem(getTint10);
			UIMenuItem mk2smg = new UIMenuItem("MK2 SMG : $25,000");
			MK2SMG.AddItem(mk2smg);
			UIMenuItem mk2smgclip = new UIMenuItem("Default Clip : $0");
			MK2SMG.AddItem(mk2smgclip);
			UIMenuItem mk2smgclip2 = new UIMenuItem("Extended Clip : $18,300");
			MK2SMG.AddItem(mk2smgclip2);
			UIMenuItem mk2smgClip2 = new UIMenuItem("Tracer Rounds : $28,600");
			MK2SMG.AddItem(mk2smgClip2);
			UIMenuItem mk2smgClip3 = new UIMenuItem("Incendiary Rounds : $34,750");
			MK2SMG.AddItem(mk2smgClip3);
			UIMenuItem mk2smgClip4 = new UIMenuItem("Hollow Point Rounds : $39,650");
			MK2SMG.AddItem(mk2smgClip4);
			UIMenuItem mk2smgClip5 = new UIMenuItem("Full Metal Jacket Rounds  : $52,000");
			MK2SMG.AddItem(mk2smgClip5);
			UIMenuItem val = new UIMenuItem("Flashlight : $7,500");
			MK2SMG.AddItem(val);
			UIMenuItem mk2smgsight1 = new UIMenuItem("Holographic Sight : $15,200");
			MK2SMG.AddItem(mk2smgsight1);
			UIMenuItem mk2smgsight2 = new UIMenuItem("Small Scope: $19,950");
			MK2SMG.AddItem(mk2smgsight2);
			UIMenuItem mk2smgsight3 = new UIMenuItem("Holographic Sight : $24,100");
			MK2SMG.AddItem(mk2smgsight3);
			UIMenuItem mk2smgsupp = new UIMenuItem("Suppressor  : $34,500");
			MK2SMG.AddItem(mk2smgsupp);
			UIMenuItem mk2smgmuzzle = new UIMenuItem("Muzzle : $25,500");
			MK2SMG.AddItem(mk2smgmuzzle);
			UIMenuItem mk2smgbarrel = new UIMenuItem("Barrel : $22,500");
			MK2SMG.AddItem(mk2smgbarrel);
			UIMenuListItem list12 = new UIMenuListItem("Tint ", list15, 0);
			MK2SMG.AddItem((UIMenuItem)(object)list12);
			UIMenuItem getTint11 = new UIMenuItem("Buy Tint: $10,000");
			MK2SMG.AddItem(getTint11);
			UIMenuItem mk2carbine = new UIMenuItem("MK2 Carbine : $35,000");
			MK2Carbine.AddItem(mk2carbine);
			UIMenuItem mk2carbineClip1 = new UIMenuItem("Default Clip: $0");
			MK2Carbine.AddItem(mk2carbineClip1);
			UIMenuItem mk2carbineClip2 = new UIMenuItem("Extended Clip: $25,925");
			MK2Carbine.AddItem(mk2carbineClip2);
			UIMenuItem mk2carbineClip3 = new UIMenuItem("Tracer Rounds: $44,700");
			MK2Carbine.AddItem(mk2carbineClip3);
			UIMenuItem mk2carbineClip4 = new UIMenuItem("Incendiary Rounds : $51,600");
			MK2Carbine.AddItem(mk2carbineClip4);
			UIMenuItem mk2carbineClip5 = new UIMenuItem("Armor Piercing Rounds: $66,000 ");
			MK2Carbine.AddItem(mk2carbineClip5);
			UIMenuItem mk2carbineClip6 = new UIMenuItem("Full Metal Jacket Rounds: $76,200 ");
			MK2Carbine.AddItem(mk2carbineClip6);
			UIMenuItem mk2carbineGrip = new UIMenuItem("Grip: $14,080 ");
			MK2Carbine.AddItem(mk2carbineGrip);
			UIMenuItem mk2carbineFlash = new UIMenuItem("Flashlight: $10,500 ");
			MK2Carbine.AddItem(mk2carbineFlash);
			UIMenuItem mk2carbineSight1 = new UIMenuItem("Holographic Sight: $19,600  ");
			MK2Carbine.AddItem(mk2carbineSight1);
			UIMenuItem mk2carbineSight2 = new UIMenuItem("Small Scope: $23,730 ");
			MK2Carbine.AddItem(mk2carbineSight2);
			UIMenuItem mk2carbineSight3 = new UIMenuItem("Large Scope: $34,020 ");
			MK2Carbine.AddItem(mk2carbineSight3);
			UIMenuItem mk2carbineSupp = new UIMenuItem("Suppressor: $40,250 ");
			MK2Carbine.AddItem(mk2carbineSupp);
			UIMenuListItem list13 = new UIMenuListItem("Tint ", list15, 0);
			MK2Carbine.AddItem((UIMenuItem)(object)list13);
			UIMenuItem getTint12 = new UIMenuItem("Buy Tint: $10,000");
			MK2Carbine.AddItem(getTint12);
			UIMenuItem mk2AR = new UIMenuItem("MK2 Assault Rifle : $30,000");
			MK2AssaultRifle.AddItem(mk2AR);
			UIMenuItem mk2ARClip1 = new UIMenuItem("Default Clip : $0");
			MK2AssaultRifle.AddItem(mk2ARClip1);
			UIMenuItem mk2ARClip2 = new UIMenuItem("Extended Clip: $22,000");
			MK2AssaultRifle.AddItem(mk2ARClip2);
			UIMenuItem mk2ARClip3 = new UIMenuItem("Tracer Rounds  : $42,700");
			MK2AssaultRifle.AddItem(mk2ARClip3);
			UIMenuItem mk2ARClip4 = new UIMenuItem("Incendiary Rounds  : $49,400");
			MK2AssaultRifle.AddItem(mk2ARClip4);
			UIMenuItem mk2ARClip5 = new UIMenuItem("Armor Piercing Rounds : $63,200");
			MK2AssaultRifle.AddItem(mk2ARClip5);
			UIMenuItem mk2ARClip6 = new UIMenuItem("Full Metal Jacket Rounds  : $73,000");
			MK2AssaultRifle.AddItem(mk2ARClip6);
			UIMenuItem mk2ARClipFlash = new UIMenuItem("Flashlight : $10,500");
			MK2AssaultRifle.AddItem(mk2ARClipFlash);
			UIMenuItem mk2ARClipSight1 = new UIMenuItem("Holographic Sight : $19,600");
			MK2AssaultRifle.AddItem(mk2ARClipSight1);
			UIMenuItem mk2ARClipSight2 = new UIMenuItem("Small Scope : $23,730");
			MK2AssaultRifle.AddItem(mk2ARClipSight2);
			UIMenuItem mk2ARClipSight3 = new UIMenuItem("Large Scope : $33,000");
			MK2AssaultRifle.AddItem(mk2ARClipSight3);
			UIMenuItem mk2ARClipGrip = new UIMenuItem("Grip : $14,000");
			MK2AssaultRifle.AddItem(mk2ARClipGrip);
			UIMenuItem mk2ARsuppressor = new UIMenuItem("Suppressor : $40,250");
			MK2AssaultRifle.AddItem(mk2ARsuppressor);
			UIMenuListItem list3 = new UIMenuListItem("Tint ", list15, 0);
			MK2AssaultRifle.AddItem((UIMenuItem)(object)list3);
			UIMenuItem getTint2 = new UIMenuItem("Buy Tint: $10,000");
			MK2AssaultRifle.AddItem(getTint2);
			UIMenuItem mk2lmg = new UIMenuItem("MK2 LMG : $95,000");
			MK2LMG.AddItem(mk2lmg);
			UIMenuItem mk2lmgClip1 = new UIMenuItem("Default Clip : $0");
			MK2LMG.AddItem(mk2lmgClip1);
			UIMenuItem mk2lmgClip2 = new UIMenuItem("Extended Clip : $28,975");
			MK2LMG.AddItem(mk2lmgClip2);
			UIMenuItem mk2lmgClip3 = new UIMenuItem("Tracer Rounds : $57,100");
			MK2LMG.AddItem(mk2lmgClip3);
			UIMenuItem mk2lmgClip4 = new UIMenuItem("Incendiary Rounds : $64,650");
			MK2LMG.AddItem(mk2lmgClip4);
			UIMenuItem mk2lmgClip5 = new UIMenuItem("Armor Piercing Rounds : $82,550");
			MK2LMG.AddItem(mk2lmgClip5);
			UIMenuItem mk2lmgClip6 = new UIMenuItem("Full Metal Jacket Rounds  : $94,950");
			MK2LMG.AddItem(mk2lmgClip6);
			UIMenuItem mk2lmgGrip = new UIMenuItem("Grip : $20,180");
			MK2LMG.AddItem(mk2lmgGrip);
			UIMenuItem mk2lmgSight1 = new UIMenuItem("Holographic Sight : $26,600");
			MK2LMG.AddItem(mk2lmgSight1);
			UIMenuItem mk2lmgSight2 = new UIMenuItem("Small Scope : $36,290");
			MK2LMG.AddItem(mk2lmgSight2);
			UIMenuItem mk2lmgSight3 = new UIMenuItem("Large Scope : $46,170");
			MK2LMG.AddItem(mk2lmgSight3);
			UIMenuItem mk2lmgMuzzle = new UIMenuItem("Flat Muzzle Brake : $40,375");
			MK2LMG.AddItem(mk2lmgMuzzle);
			UIMenuItem mk2lmgBarrel = new UIMenuItem("Heavy Barrel : $66,500");
			MK2LMG.AddItem(mk2lmgBarrel);
			UIMenuListItem list4 = new UIMenuListItem("Tint ", list15, 0);
			MK2LMG.AddItem((UIMenuItem)(object)list4);
			UIMenuItem getTint3 = new UIMenuItem("Buy Tint: $10,000");
			MK2LMG.AddItem(getTint3);
			UIMenuItem mk2sniper = new UIMenuItem("MK2 Heavy Sniper : $100,000");
			MK2Sniper.AddItem(mk2sniper);
			UIMenuItem mk2sniperClip1 = new UIMenuItem("Default Clip : $0");
			MK2Sniper.AddItem(mk2sniperClip1);
			UIMenuItem mk2sniperClip2 = new UIMenuItem("Extended Clip : $35,025");
			MK2Sniper.AddItem(mk2sniperClip2);
			UIMenuItem mk2sniperClip3 = new UIMenuItem("Incendiary Rounds : $59,275");
			MK2Sniper.AddItem(mk2sniperClip3);
			UIMenuItem mk2sniperClip4 = new UIMenuItem("Armor Piercing Rounds : $76,100");
			MK2Sniper.AddItem(mk2sniperClip4);
			UIMenuItem mk2sniperClip5 = new UIMenuItem("Full Metal Jacket Rounds : $88,525");
			MK2Sniper.AddItem(mk2sniperClip5);
			UIMenuItem mk2sniperClip6 = new UIMenuItem("Explosive Rounds : $115,450");
			MK2Sniper.AddItem(mk2sniperClip6);
			UIMenuItem mk2sniperSight1 = new UIMenuItem("Zoom scope : $20.200");
			MK2Sniper.AddItem(mk2sniperSight1);
			UIMenuItem mk2sniperSight2 = new UIMenuItem("Advanced Scope : $32,000");
			MK2Sniper.AddItem(mk2sniperSight2);
			UIMenuItem mk2sniperSight3 = new UIMenuItem("Night Vision Scope : $57,400");
			MK2Sniper.AddItem(mk2sniperSight3);
			UIMenuItem mk2sniperSight4 = new UIMenuItem("Thermal Scope : $69,000");
			MK2Sniper.AddItem(mk2sniperSight4);
			UIMenuItem mk2sniperSupp = new UIMenuItem("Suppressor : $40,250");
			MK2Sniper.AddItem(mk2sniperSupp);
			UIMenuItem mk2sniperMuzzle = new UIMenuItem("Bell-End Muzzle Brake : $57,790");
			MK2Sniper.AddItem(mk2sniperMuzzle);
			UIMenuItem mk2sniperBarrel = new UIMenuItem("Heavy Barrel : $27,500");
			MK2Sniper.AddItem(mk2sniperBarrel);
			UIMenuListItem list5 = new UIMenuListItem("Tint ", list15, 0);
			MK2Sniper.AddItem((UIMenuItem)(object)list5);
			UIMenuItem getTint4 = new UIMenuItem("Buy Tint: $10,000");
			MK2Sniper.AddItem(getTint4);
			List<object> list16 = new List<object>();
			WeaponHash[] allweaponhashes = (WeaponHash[])Enum.GetValues(typeof(WeaponHash));
			for (int j = 0; j < allweaponhashes.Length; j++)
			{
				list16.Add(allweaponhashes[j]);
			}
			UIMenuListItem list = new UIMenuListItem("Weapon: ", list16, 0);
			uIMenu4.AddItem((UIMenuItem)(object)list);
			UIMenuItem getWeapon = new UIMenuItem("Buy Weapon : $10000");
			uIMenu4.AddItem(getWeapon);
			UIMenuItem RayGun = new UIMenuItem("Ray Gun : $100,000");
			uIMenu2.AddItem(RayGun);
			UIMenuItem UnholyHellbringer = new UIMenuItem("UnholyHellbringer : $250,000");
			uIMenu2.AddItem(UnholyHellbringer);
			UIMenuItem Widowmaker = new UIMenuItem("Widowmaker : $1,000,000");
			uIMenu2.AddItem(Widowmaker);
			uIMenu4.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getWeapon)
				{
					int index14 = list.get_Index();
					WeaponHash weaponHash = allweaponhashes[index14];
					if (weaponHash == WeaponHash.AssaultrifleMk2 || weaponHash == WeaponHash.CarbineRifleMk2 || weaponHash == WeaponHash.CombatMGMk2 || weaponHash == WeaponHash.HeavySniperMk2 || weaponHash == WeaponHash.PistolMk2 || weaponHash == WeaponHash.SMGMk2 || weaponHash == WeaponHash.PumpShotgunMk2 || weaponHash == WeaponHash.MarksmanRifleMk2 || weaponHash == WeaponHash.RevolverMk2 || weaponHash == WeaponHash.BullpupRifleMk2 || weaponHash == WeaponHash.SpecialCarbineMk2 || weaponHash == WeaponHash.SNSPistolMk2)
					{
						UI.Notify("Office Assistant : Boss, this is a MKII weapon please perchase it from the MkII page");
					}
					else
					{
						Game.Player.Character.Weapons.Give(weaponHash, 9999, true, true);
						Game.Player.Money = Game.Player.Money - 10000;
					}
				}
			});
			uIMenu2.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == RayGun)
				{
					if (Game.Player.Money >= 100000)
					{
						Game.Player.Money = Game.Player.Money - 100000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							2939590305u,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: You dont have enought money for this weapon ");
					}
				}
				if (item == UnholyHellbringer)
				{
					if (Game.Player.Money >= 250000)
					{
						Game.Player.Money = Game.Player.Money - 250000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							1198256469,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: You dont have enought money for this weapon ");
					}
				}
				if (item == Widowmaker)
				{
					if (Game.Player.Money >= 1000000)
					{
						Game.Player.Money = Game.Player.Money - 1000000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							3056410471u,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: You dont have enought money for this weapon ");
					}
				}
			});
			MK2Sniper.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint4)
				{
					int index13 = list5.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						177293209,
						list5.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2sniper)
				{
					if (Game.Player.Money > 100000)
					{
						Game.Player.Money = Game.Player.Money - 100000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							177293209,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperClip1)
				{
					if (Game.Player.Money > 0)
					{
						Game.Player.Money = Game.Player.Money;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							4196276776u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperClip2)
				{
					if (Game.Player.Money > 35025)
					{
						Game.Player.Money = Game.Player.Money - 35025;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							752418717
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperClip3)
				{
					if (Game.Player.Money > 59275)
					{
						Game.Player.Money = Game.Player.Money - 59275;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							247526935
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperClip4)
				{
					if (Game.Player.Money > 76100)
					{
						Game.Player.Money = Game.Player.Money - 76100;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							4164277972u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperClip5)
				{
					if (Game.Player.Money > 88525)
					{
						Game.Player.Money = Game.Player.Money - 88525;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1005144310
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperClip6)
				{
					if (Game.Player.Money > 115450)
					{
						Game.Player.Money = Game.Player.Money - 115450;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							2313935527u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperSight1)
				{
					if (Game.Player.Money > 20200)
					{
						Game.Player.Money = Game.Player.Money - 20200;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							2193687427u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperSight2)
				{
					if (Game.Player.Money > 32000)
					{
						Game.Player.Money = Game.Player.Money - 32000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							3159677559u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperSight3)
				{
					if (Game.Player.Money > 57400)
					{
						Game.Player.Money = Game.Player.Money - 57400;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							3061846192u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperSight4)
				{
					if (Game.Player.Money > 69000)
					{
						Game.Player.Money = Game.Player.Money - 69000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							776198721
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperSupp)
				{
					if (Game.Player.Money > 40250)
					{
						Game.Player.Money = Game.Player.Money - 40250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							2890063729u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperMuzzle)
				{
					if (Game.Player.Money > 57790)
					{
						Game.Player.Money = Game.Player.Money - 57790;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							1764221345
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2sniperBarrel)
				{
					if (Game.Player.Money > 27500)
					{
						Game.Player.Money = Game.Player.Money - 27500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							177293209,
							2425761975u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2LMG.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint3)
				{
					int index12 = list4.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						3686625920u,
						list4.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2lmg)
				{
					if (Game.Player.Money > 95000)
					{
						Game.Player.Money = Game.Player.Money - 95000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							3686625920u,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgClip1)
				{
					if (Game.Player.Money > 0)
					{
						Game.Player.Money = Game.Player.Money;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1227564412
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgClip2)
				{
					if (Game.Player.Money > 28975)
					{
						Game.Player.Money = Game.Player.Money - 28975;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							400507625
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgClip3)
				{
					if (Game.Player.Money > 57100)
					{
						Game.Player.Money = Game.Player.Money - 57100;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							4133787461u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgClip4)
				{
					if (Game.Player.Money > 64650)
					{
						Game.Player.Money = Game.Player.Money - 64650;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							3274096058u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgClip5)
				{
					if (Game.Player.Money > 82550)
					{
						Game.Player.Money = Game.Player.Money - 82550;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							696788003
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgClip6)
				{
					if (Game.Player.Money > 94950)
					{
						Game.Player.Money = Game.Player.Money - 94950;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1475288264
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgGrip)
				{
					if (Game.Player.Money > 20180)
					{
						Game.Player.Money = Game.Player.Money - 20180;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							2640679034u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgSight1)
				{
					if (Game.Player.Money > 26600)
					{
						Game.Player.Money = Game.Player.Money - 26600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgSight2)
				{
					if (Game.Player.Money > 36290)
					{
						Game.Player.Money = Game.Player.Money - 36290;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							1060929921
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgSight3)
				{
					if (Game.Player.Money > 46170)
					{
						Game.Player.Money = Game.Player.Money - 46170;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							3328927042u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgMuzzle)
				{
					if (Game.Player.Money > 40375)
					{
						Game.Player.Money = Game.Player.Money - 40375;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							3113485012u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2lmgBarrel)
				{
					if (Game.Player.Money > 66500)
					{
						Game.Player.Money = Game.Player.Money - 66500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3686625920u,
							3051509595u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2Carbine.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint12)
				{
					int index11 = list13.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						4208062921u,
						list13.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2carbine)
				{
					if (Game.Player.Money > 35000)
					{
						Game.Player.Money = Game.Player.Money - 35000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							4208062921u,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineClip1)
				{
					if (Game.Player.Money > 0)
					{
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1283078430
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineClip2)
				{
					if (Game.Player.Money > 25925)
					{
						Game.Player.Money = Game.Player.Money - 25925;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1574296533
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineClip3)
				{
					if (Game.Player.Money > 44700)
					{
						Game.Player.Money = Game.Player.Money - 44700;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							391640422
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineClip4)
				{
					if (Game.Player.Money > 51600)
					{
						Game.Player.Money = Game.Player.Money - 51600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1025884839
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineClip5)
				{
					if (Game.Player.Money > 66000)
					{
						Game.Player.Money = Game.Player.Money - 66000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							626875735
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineClip6)
				{
					if (Game.Player.Money > 76000)
					{
						Game.Player.Money = Game.Player.Money - 76000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1141059345
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineFlash)
				{
					if (Game.Player.Money > 10500)
					{
						Game.Player.Money = Game.Player.Money - 10500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							2076495324
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineGrip)
				{
					if (Game.Player.Money > 14080)
					{
						Game.Player.Money = Game.Player.Money - 14080;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							2640679034u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineSight1)
				{
					if (Game.Player.Money > 19600)
					{
						Game.Player.Money = Game.Player.Money - 19600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineSight2)
				{
					if (Game.Player.Money > 23730)
					{
						Game.Player.Money = Game.Player.Money - 23730;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							77277509
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineSight3)
				{
					if (Game.Player.Money > 34020)
					{
						Game.Player.Money = Game.Player.Money - 34020;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							3328927042u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2carbineSupp)
				{
					if (Game.Player.Money > 40250)
					{
						Game.Player.Money = Game.Player.Money - 40250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							4208062921u,
							2205435306u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2SMG.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint11)
				{
					int index10 = list12.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						2024373456,
						list12.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2smg)
				{
					if (Game.Player.Money > 25000)
					{
						Game.Player.Money = Game.Player.Money - 25000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							2024373456,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgclip)
				{
					if (Game.Player.Money > 0)
					{
						Game.Player.Money = Game.Player.Money;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1277460590
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgclip2)
				{
					if (Game.Player.Money > 18300)
					{
						Game.Player.Money = Game.Player.Money - 18300;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							3112393518u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgClip2)
				{
					if (Game.Player.Money > 32850)
					{
						Game.Player.Money = Game.Player.Money - 32850;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							2146055916
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgClip3)
				{
					if (Game.Player.Money > 34750)
					{
						Game.Player.Money = Game.Player.Money - 34750;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							3650233061u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgClip4)
				{
					if (Game.Player.Money > 39650)
					{
						Game.Player.Money = Game.Player.Money - 39650;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							974903034
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgClip5)
				{
					if (Game.Player.Money > 52000)
					{
						Game.Player.Money = Game.Player.Money - 52000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							190476639
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgsight1)
				{
					if (Game.Player.Money > 15200)
					{
						Game.Player.Money = Game.Player.Money - 15200;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							2681951826u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgsight2)
				{
					if (Game.Player.Money > 19950)
					{
						Game.Player.Money = Game.Player.Money - 19950;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							3842157419u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgsight3)
				{
					if (Game.Player.Money > 24100)
					{
						Game.Player.Money = Game.Player.Money - 24100;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1038927834
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgsupp)
				{
					if (Game.Player.Money > 34500)
					{
						Game.Player.Money = Game.Player.Money - 34500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1038927834
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgmuzzle)
				{
					if (Game.Player.Money > 25500)
					{
						Game.Player.Money = Game.Player.Money - 25500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							3113485012u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2smgbarrel)
				{
					if (Game.Player.Money > 22500)
					{
						Game.Player.Money = Game.Player.Money - 22500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							3641720545u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							2024373456,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2AssaultRifle.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint2)
				{
					int index9 = list3.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						961495388,
						list3.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2AR)
				{
					if (Game.Player.Money > 30000)
					{
						Game.Player.Money = Game.Player.Money - 30000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							961495388,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClip1)
				{
					if (Game.Player.Money > 0)
					{
						Game.Player.Money = Game.Player.Money;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							2249208895u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClip2)
				{
					if (Game.Player.Money > 22000)
					{
						Game.Player.Money = Game.Player.Money - 22000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							3509242479u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClip3)
				{
					if (Game.Player.Money > 42700)
					{
						Game.Player.Money = Game.Player.Money - 42700;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							4012669121u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClip4)
				{
					if (Game.Player.Money > 49400)
					{
						Game.Player.Money = Game.Player.Money - 49400;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							4218476627u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClip5)
				{
					if (Game.Player.Money > 63200)
					{
						Game.Player.Money = Game.Player.Money - 63200;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							2816286296u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClip6)
				{
					if (Game.Player.Money > 73000)
					{
						Game.Player.Money = Game.Player.Money - 73000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1675665560
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClipFlash)
				{
					if (Game.Player.Money > 10500)
					{
						Game.Player.Money = Game.Player.Money - 10500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							2076495324
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClipGrip)
				{
					if (Game.Player.Money > 14000)
					{
						Game.Player.Money = Game.Player.Money - 14000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							2640679034u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClipSight1)
				{
					if (Game.Player.Money > 19600)
					{
						Game.Player.Money = Game.Player.Money - 19600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClipSight2)
				{
					if (Game.Player.Money > 23730)
					{
						Game.Player.Money = Game.Player.Money - 23730;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							77277509
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARClipSight3)
				{
					if (Game.Player.Money > 33000)
					{
						Game.Player.Money = Game.Player.Money - 33000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							3328927042u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ARsuppressor)
				{
					if (Game.Player.Money > 40250)
					{
						Game.Player.Money = Game.Player.Money - 40250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							961495388,
							2805810788u
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2Pistol.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint10)
				{
					int index8 = list11.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						3219281620u,
						list11.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2pistol)
				{
					if (Game.Player.Money > 20000)
					{
						Game.Player.Money = Game.Player.Money - 20000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							3219281620u,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolClip)
				{
					if (Game.Player.Money > 0)
					{
						Game.Player.Money = Game.Player.Money;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							2499030370u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolClip2)
				{
					if (Game.Player.Money > 15250)
					{
						Game.Player.Money = Game.Player.Money - 15250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1591132456
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolClip3)
				{
					if (Game.Player.Money > 28600)
					{
						Game.Player.Money = Game.Player.Money - 28600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							634039983
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolClip4)
				{
					if (Game.Player.Money > 34750)
					{
						Game.Player.Money = Game.Player.Money - 34750;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							733837882
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolClip5)
				{
					if (Game.Player.Money > 39650)
					{
						Game.Player.Money = Game.Player.Money - 39650;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							2248057097u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolClip6)
				{
					if (Game.Player.Money > 39650)
					{
						Game.Player.Money = Game.Player.Money - 39650;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1329061674
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolflash)
				{
					if (Game.Player.Money > 7500)
					{
						Game.Player.Money = Game.Player.Money - 7500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							2396306288u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolSight1)
				{
					if (Game.Player.Money > 16250)
					{
						Game.Player.Money = Game.Player.Money - 16250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							2396306288u
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolsupp)
				{
					if (Game.Player.Money > 28750)
					{
						Game.Player.Money = Game.Player.Money - 28750;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1709866683
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2pistolcomp)
				{
					if (Game.Player.Money > 21250)
					{
						Game.Player.Money = Game.Player.Money - 21250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							568543123
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							3219281620u,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2Pumpshotgun.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint1)
				{
					int index7 = list2.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						1432025498,
						list2.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2Shotgunclip5)
				{
					if (Game.Player.Money > 145000)
					{
						Game.Player.Money = Game.Player.Money - 145000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1004815965
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunclip)
				{
					if (Game.Player.Money > 0)
					{
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							-845938367
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunclip3)
				{
					if (Game.Player.Money > 96645)
					{
						Game.Player.Money = Game.Player.Money - 96645;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1315288101
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunclip4)
				{
					if (Game.Player.Money > 75140)
					{
						Game.Player.Money = Game.Player.Money - 75140;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							-380098265
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunclip2)
				{
					if (Game.Player.Money > 65200)
					{
						Game.Player.Money = Game.Player.Money - 65200;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							-1618338827
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1000
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ShotgunP)
				{
					if (Game.Player.Money > 75000)
					{
						Game.Player.Money = Game.Player.Money - 75000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							1432025498,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunflashlight)
				{
					if (Game.Player.Money > 10500)
					{
						Game.Player.Money = Game.Player.Money - 10500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							2076495324
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunsights)
				{
					if (Game.Player.Money > 29320)
					{
						Game.Player.Money = Game.Player.Money - 29320;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunsights2)
				{
					if (Game.Player.Money > 39920)
					{
						Game.Player.Money = Game.Player.Money - 39920;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							77277509
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunsights3)
				{
					if (Game.Player.Money > 50785)
					{
						Game.Player.Money = Game.Player.Money - 50785;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1060929921
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2ShotgunSuppressor)
				{
					if (Game.Player.Money > 45860)
					{
						Game.Player.Money = Game.Player.Money - 45860;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							-1404903567
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Shotgunmuzzle)
				{
					if (Game.Player.Money > 37650)
					{
						Game.Player.Money = Game.Player.Money - 37650;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1432025498,
							1602080333
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2SNSPistol.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint5)
				{
					int index6 = list6.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						-2009644972,
						list6.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2Snspistol)
				{
					if (Game.Player.Money > 45000)
					{
						Game.Player.Money = Game.Player.Money - 45000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							-2009644972,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolclipn)
				{
					if (Game.Player.Money > 8000)
					{
						Game.Player.Money = Game.Player.Money - 8000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							21392614
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolclipe)
				{
					if (Game.Player.Money > 18300)
					{
						Game.Player.Money = Game.Player.Money - 18300;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							-829683854
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolclip1)
				{
					if (Game.Player.Money > 34320)
					{
						Game.Player.Money = Game.Player.Money - 34320;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							-1876057490
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							9999
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolclip2)
				{
					if (Game.Player.Money > 41700)
					{
						Game.Player.Money = Game.Player.Money - 41700;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							-424845447
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							9999
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolclip3)
				{
					if (Game.Player.Money > 47580)
					{
						Game.Player.Money = Game.Player.Money - 47580;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							-1928301566
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							9999
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolclip4)
				{
					if (Game.Player.Money > 62400)
					{
						Game.Player.Money = Game.Player.Money - 62400;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							-1055790298
						});
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							9999
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolcomp)
				{
					if (Game.Player.Money > 21250)
					{
						Game.Player.Money = Game.Player.Money - 21250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							-1434287169
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolflash)
				{
					if (Game.Player.Money > 7500)
					{
						Game.Player.Money = Game.Player.Money - 7500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							1246324211
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolscope1)
				{
					if (Game.Player.Money > 16250)
					{
						Game.Player.Money = Game.Player.Money - 16250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							1205768792
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Snspistolsuppressor)
				{
					if (Game.Player.Money > 28750)
					{
						Game.Player.Money = Game.Player.Money - 28750;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2009644972,
							1709866683
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2Revolver.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint6)
				{
					int index5 = list7.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						-879347409,
						list7.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2Revolver)
				{
					if (Game.Player.Money > 85000)
					{
						Game.Player.Money = Game.Player.Money - 85000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							-879347409,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolverclip)
				{
					if (Game.Player.Money > 0)
					{
						Game.Player.Money = Game.Player.Money;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							-1172055874
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolverclip2)
				{
					if (Game.Player.Money > 31460)
					{
						Game.Player.Money = Game.Player.Money - 31460;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							-958864266
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolverclip3)
				{
					if (Game.Player.Money > 38225)
					{
						Game.Player.Money = Game.Player.Money - 38225;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							15712037
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolverclip4)
				{
					if (Game.Player.Money > 43615)
					{
						Game.Player.Money = Game.Player.Money - 43615;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							284438159
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolverclip5)
				{
					if (Game.Player.Money > 57200)
					{
						Game.Player.Money = Game.Player.Money - 57200;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							231258687
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolversights)
				{
					if (Game.Player.Money > 16250)
					{
						Game.Player.Money = Game.Player.Money - 16250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolversights2)
				{
					if (Game.Player.Money > 25450)
					{
						Game.Player.Money = Game.Player.Money - 25450;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							77277509
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Revolverflashlight)
				{
					if (Game.Player.Money > 7500)
					{
						Game.Player.Money = Game.Player.Money - 7500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							899381934
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2RevolverComp)
				{
					if (Game.Player.Money > 21250)
					{
						Game.Player.Money = Game.Player.Money - 21250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-879347409,
							654802123
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			Mk2SpecialCarbine.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint7)
				{
					int index4 = list8.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						-1768145561,
						list8.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2SCarbine)
				{
					if (Game.Player.Money > 65000)
					{
						Game.Player.Money = Game.Player.Money - 65000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							-1768145561,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineclip)
				{
					if (Game.Player.Money > 5000)
					{
						Game.Player.Money = Game.Player.Money - 5000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							382112385
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineclip2)
				{
					if (Game.Player.Money > 26450)
					{
						Game.Player.Money = Game.Player.Money - 26450;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-568352468
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineclip3)
				{
					if (Game.Player.Money > 61465)
					{
						Game.Player.Money = Game.Player.Money - 61465;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-2023373174
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineclip4)
				{
					if (Game.Player.Money > 70950)
					{
						Game.Player.Money = Game.Player.Money - 70950;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-570355066
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineclip5)
				{
					if (Game.Player.Money > 90750)
					{
						Game.Player.Money = Game.Player.Money - 90750;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1362433589
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineclip6)
				{
					if (Game.Player.Money > 104775)
					{
						Game.Player.Money = Game.Player.Money - 104775;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1346235024
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbineflash)
				{
					if (Game.Player.Money > 10500)
					{
						Game.Player.Money = Game.Player.Money - 10500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							2076495324
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbinesight1)
				{
					if (Game.Player.Money > 19600)
					{
						Game.Player.Money = Game.Player.Money - 19600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbinesight2)
				{
					if (Game.Player.Money > 23730)
					{
						Game.Player.Money = Game.Player.Money - 23730;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							77277509
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbinesight3)
				{
					if (Game.Player.Money > 34020)
					{
						Game.Player.Money = Game.Player.Money - 34020;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-966040254
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbinesupressor)
				{
					if (Game.Player.Money > 40250)
					{
						Game.Player.Money = Game.Player.Money - 40250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-1489156508
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbinemuzzle)
				{
					if (Game.Player.Money > 29750)
					{
						Game.Player.Money = Game.Player.Money - 29750;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-1181482284
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2SCarbinegrip)
				{
					if (Game.Player.Money > 14080)
					{
						Game.Player.Money = Game.Player.Money - 14080;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-1768145561,
							-1654288262
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2Bullpup.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint8)
				{
					int index3 = list9.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						-2066285827,
						list9.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2Bullpup)
				{
					if (Game.Player.Money > 60000)
					{
						Game.Player.Money = Game.Player.Money - 60000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							-2066285827,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupclip1)
				{
					if (Game.Player.Money > 5000)
					{
						Game.Player.Money = Game.Player.Money - 5000;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							25766362
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupclip2)
				{
					if (Game.Player.Money > 22100)
					{
						Game.Player.Money = Game.Player.Money - 22100;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-273676760
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupclip3)
				{
					if (Game.Player.Money > 44350)
					{
						Game.Player.Money = Game.Player.Money - 44350;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-2111807319
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupclip4)
				{
					if (Game.Player.Money > 52100)
					{
						Game.Player.Money = Game.Player.Money - 52100;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-1449330342
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupclip5)
				{
					if (Game.Player.Money > 87320)
					{
						Game.Player.Money = Game.Player.Money - 87320;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-89655827
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupclip6)
				{
					if (Game.Player.Money > 77490)
					{
						Game.Player.Money = Game.Player.Money - 77490;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							9999
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							1130501904
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupflash)
				{
					if (Game.Player.Money > 10500)
					{
						Game.Player.Money = Game.Player.Money - 10500;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							2076495324
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupsight1)
				{
					if (Game.Player.Money > 19600)
					{
						Game.Player.Money = Game.Player.Money - 19600;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupsight2)
				{
					if (Game.Player.Money > 23730)
					{
						Game.Player.Money = Game.Player.Money - 23730;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-944910075
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupsight3)
				{
					if (Game.Player.Money > 34020)
					{
						Game.Player.Money = Game.Player.Money - 34020;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							1060929921
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2BullpupBarrel)
				{
					if (Game.Player.Money > 49000)
					{
						Game.Player.Money = Game.Player.Money - 49000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							1704640795
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2BullpupGrip)
				{
					if (Game.Player.Money > 14080)
					{
						Game.Player.Money = Game.Player.Money - 14080;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-1654288262
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2BullpupSuppressor)
				{
					if (Game.Player.Money > 40250)
					{
						Game.Player.Money = Game.Player.Money - 40250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-2089531990
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2Bullpupmuzzle)
				{
					if (Game.Player.Money > 29750)
					{
						Game.Player.Money = Game.Player.Money - 29750;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							-2066285827,
							-1181482284
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
			MK2MarksmanRifle.add_OnItemSelect((ItemSelectEvent)delegate(UIMenu sender, UIMenuItem item, int index)
			{
				if (item == getTint9)
				{
					int index2 = list10.get_Index();
					Function.Call(Hash._0x50969B9B89ED5738, new InputArgument[3]
					{
						Game.Player.Character,
						1785463520,
						list10.get_Index()
					});
					Game.Player.Money = Game.Player.Money - 10000;
				}
				if (item == mk2marksman)
				{
					if (Game.Player.Money > 60000)
					{
						Game.Player.Money = Game.Player.Money - 60000;
						Function.Call(Hash._0xBF0FD6E56C964FCB, new InputArgument[5]
						{
							Game.Player.Character,
							1785463520,
							999999,
							true,
							true
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanclip1)
				{
					if (Game.Player.Money > 5000)
					{
						Game.Player.Money = Game.Player.Money - 5000;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-1797182002
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanclip3)
				{
					if (Game.Player.Money > 49775)
					{
						Game.Player.Money = Game.Player.Money - 49775;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-679861550
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanclip4)
				{
					if (Game.Player.Money > 57295)
					{
						Game.Player.Money = Game.Player.Money - 57295;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1842849902
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanclip5)
				{
					if (Game.Player.Money > 73560)
					{
						Game.Player.Money = Game.Player.Money - 73560;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-193998727
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanclip6)
				{
					if (Game.Player.Money > 85570)
					{
						Game.Player.Money = Game.Player.Money - 85570;
						Function.Call(Hash._0x78F0424C34306220, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1000
						});
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-515203373
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanclip2)
				{
					if (Game.Player.Money > 26850)
					{
						Game.Player.Money = Game.Player.Money - 26850;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-422587990
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanflash)
				{
					if (Game.Player.Money > 11250)
					{
						Game.Player.Money = Game.Player.Money - 11250;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							2076495324
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmansight1)
				{
					if (Game.Player.Money > 11485)
					{
						Game.Player.Money = Game.Player.Money - 11485;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1108334355
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmansight2)
				{
					if (Game.Player.Money > 17870)
					{
						Game.Player.Money = Game.Player.Money - 17870;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-966040254
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmansight3)
				{
					if (Game.Player.Money > 27150)
					{
						Game.Player.Money = Game.Player.Money - 27150;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							1528590652
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanGrip)
				{
					if (Game.Player.Money > 14080)
					{
						Game.Player.Money = Game.Player.Money - 14080;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-1654288262
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanSuppressor)
				{
					if (Game.Player.Money > 60375)
					{
						Game.Player.Money = Game.Player.Money - 60375;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-2089531990
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
				if (item == mk2marksmanmuzzle)
				{
					if (Game.Player.Money > 44620)
					{
						Game.Player.Money = Game.Player.Money - 44620;
						Function.Call(Hash._0xD966D51AA5B28BB9, new InputArgument[3]
						{
							Game.Player.Character,
							1785463520,
							-1181482284
						});
						UI.Notify("Agent 14: Have fun with your new toy");
					}
					else
					{
						UI.Notify("Agent 14: you do not have enought money to purchase this Weapon!");
					}
				}
			});
		}
	}
}
