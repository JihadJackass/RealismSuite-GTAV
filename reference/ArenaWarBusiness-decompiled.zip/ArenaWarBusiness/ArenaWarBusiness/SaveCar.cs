using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;

namespace ArenaWarBusiness
{
	public class SaveCar : Script
	{
		public ScriptSettings Config;

		public Vehicle VehicleId;

		public string VehicleName;

		public int RoofId;

		public int AerialsId;

		public int AirfilterId;

		public int ArchCoverId;

		public int ArmorId;

		public int BackWheelsId;

		public int BrakesId;

		public int ColumnShifterLeversId;

		public int DashboardId;

		public int DialDesignId;

		public int DoorSpeekersId;

		public int EngineId;

		public int EngineBlockId;

		public int ExaustId;

		public int FenderId;

		public int FrameId;

		public int FrontBumperId;

		public int FrontWheelsId;

		public int GrilleId;

		public int HoodId;

		public int HornsId;

		public int HydralicsId;

		public int LiveryId;

		public int OrnamentsId;

		public int PlaquesId;

		public int Plateholder;

		public int RearBumperId;

		public int RightFenderId;

		public int SeatsId;

		public int SideSkirt;

		public int speakers;

		public int SpoilersId;

		public int SteeringWheelId;

		public int StrutId;

		public int SuspensionId;

		public int TankId;

		public int TransmissionId;

		public int TrimId;

		public int TrimDesignId;

		public int TrunkId;

		public int VanityPlatesId;

		public int WindowId;

		public VehicleColor PearlCent;

		public Color NeonColour;

		public VehicleColor PrimaryColor;

		public VehicleColor SecondaryColor;

		public Vector3 VehhicleLoc;

		public Vehicle SavedVehicle;

		public Vehicle newvehicle;

		public Vehicle VehicletoCheck;

		public bool HasTurbo;

		public bool HasXenonLights;

		public VehicleWindowTint TintId;

		public string PlanteNo;

		public int Blades;

		public int LightColor;

		public string VehicleHash;

		public bool TurboActive;

		public Color NeonColor;

		public bool RightNeonOn;

		public bool LeftNeonOn;

		public bool FrontNeonOn;

		public bool BackNeonOn;

		public List<bool> ExtraOn = new List<bool>();

		public bool HasTireSmoke;

		public VehicleColor Wheelcolour;

		public VehicleColor DashBoardColour;

		public Color TireSmokeColor;

		public bool TireSmoke;

		public bool BulletProofTires;

		public VehicleColor TrimColor;

		public float Torque;

		public float Power;

		public bool HasClanTag;

		public VehiclesEmblem VE = new VehiclesEmblem();

		public SaveCar()
		{
			base.Tick += OnTick;
			base.KeyDown += onKeyDown;
			Setup();
		}

		public void SetupVehicle(Vehicle Car, int I)
		{
			if (I == 0)
			{
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { Car.Handle, 0 });
				Car.SetMod(VehicleMod.Roof, 0, true);
				Car.SetMod(VehicleMod.Frame, 2, true);
				Car.SetMod(VehicleMod.Hood, 2, true);
			}
		}

		public void SaveName()
		{
			VehicleName = "null";
			Config.SetValue<string>("Configurations", "VehicleName", VehicleName);
			Config.Save();
		}

		public void LoadIniFile(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				VehicleName = Config.GetValue<string>("Configurations", "VehicleName", VehicleName);
				RoofId = Config.GetValue("Configurations", "RoofId", RoofId);
				AerialsId = Config.GetValue("Configurations", "AerialsId", AerialsId);
				AirfilterId = Config.GetValue("Configurations", "AirfilterId", AirfilterId);
				ArchCoverId = Config.GetValue("Configurations", "ArchCoverId", ArchCoverId);
				ArmorId = Config.GetValue("Configurations", "ArmorId", ArmorId);
				BackWheelsId = Config.GetValue("Configurations", "BackWheelsId", BackWheelsId);
				BrakesId = Config.GetValue("Configurations", "BrakesId", BrakesId);
				ColumnShifterLeversId = Config.GetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
				DashboardId = Config.GetValue("Configurations", "DashboardId", DashboardId);
				DialDesignId = Config.GetValue("Configurations", "DialDesignId", DialDesignId);
				DoorSpeekersId = Config.GetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
				EngineId = Config.GetValue("Configurations", "EngineId", EngineId);
				EngineBlockId = Config.GetValue("Configurations", "EngineBlockId", EngineBlockId);
				ExaustId = Config.GetValue("Configurations", "ExaustId", ExaustId);
				FenderId = Config.GetValue("Configurations", "FenderId", FenderId);
				FrameId = Config.GetValue("Configurations", "FrameId", FrameId);
				FrontBumperId = Config.GetValue("Configurations", "FrontBumperId", FrontBumperId);
				FrontWheelsId = Config.GetValue("Configurations", "FrontWheelsId", FrontWheelsId);
				GrilleId = Config.GetValue("Configurations", "GrilleId", GrilleId);
				HoodId = Config.GetValue("Configurations", "HoodId", HoodId);
				HornsId = Config.GetValue("Configurations", "HornsId", HornsId);
				HydralicsId = Config.GetValue("Configurations", "HydralicsId", HydralicsId);
				LiveryId = Config.GetValue("Configurations", "LiveryId", LiveryId);
				OrnamentsId = Config.GetValue("Configurations", "OrnamentsId", OrnamentsId);
				PlaquesId = Config.GetValue("Configurations", "PlaquesId", PlaquesId);
				Plateholder = Config.GetValue("Configurations", "Plateholder", Plateholder);
				RearBumperId = Config.GetValue("Configurations", "RearBumperId", RearBumperId);
				RightFenderId = Config.GetValue("Configurations", "RightFenderId", RightFenderId);
				SeatsId = Config.GetValue("Configurations", "SeatsId", SeatsId);
				SideSkirt = Config.GetValue("Configurations", "SideSkirt", SideSkirt);
				speakers = Config.GetValue("Configurations", "speakers", speakers);
				SpoilersId = Config.GetValue("Configurations", "SpoilersId", SpoilersId);
				SteeringWheelId = Config.GetValue("Configurations", "SteeringWheelId", SteeringWheelId);
				StrutId = Config.GetValue("Configurations", "StrutId", StrutId);
				SuspensionId = Config.GetValue("Configurations", "SuspensionId", SuspensionId);
				TankId = Config.GetValue("Configurations", "TankId", TankId);
				TransmissionId = Config.GetValue("Configurations", "TransmissionId", TransmissionId);
				TrimId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
				TrimDesignId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
				TrunkId = Config.GetValue("Configurations", "TrunkId", TrunkId);
				VanityPlatesId = Config.GetValue("Configurations", "VanityPlatesId", VanityPlatesId);
				WindowId = Config.GetValue("Configurations", "WindowId", WindowId);
				PrimaryColor = Config.GetValue("Configurations", "PrimaryColor", PrimaryColor);
				SecondaryColor = Config.GetValue("Configurations", "SecondaryColor", SecondaryColor);
				Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
				DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
				PearlCent = Config.GetValue("Configurations", "PearlCent", PearlCent);
				NeonColour = Config.GetValue("Configurations", "NeonColour", NeonColour);
				TintId = Config.GetValue("Configurations", "TintId", TintId);
				PlanteNo = Config.GetValue<string>("Configurations", "PlanteNo", PlanteNo);
				Blades = Config.GetValue("Configurations", "Blades", Blades);
				LightColor = Config.GetValue("Configurations", "LightColor", LightColor);
				HasXenonLights = Config.GetValue("Configurations", "HasXenonLights", HasXenonLights);
				TurboActive = Config.GetValue("Configurations", "TurboActive", TurboActive);
				NeonColor = Config.GetValue("Configurations", "NeonColor", NeonColor);
				RightNeonOn = Config.GetValue("Configurations", "RightNeonOn", RightNeonOn);
				LeftNeonOn = Config.GetValue("Configurations", "LeftNeonOn", LeftNeonOn);
				FrontNeonOn = Config.GetValue("Configurations", "FrontNeonOn", FrontNeonOn);
				BackNeonOn = Config.GetValue("Configurations", "BackNeonOn", BackNeonOn);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Config.ini Failed To Load.");
			}
		}

		private void Setup()
		{
			VehhicleLoc = new Vector3(849.007f, -3238.2f, -98f);
		}

		public void Delete()
		{
			if (SavedVehicle != null)
			{
				VehicleId = SavedVehicle;
				SavedVehicle.Delete();
			}
		}

		public void LoadAV()
		{
			Load2();
		}

		private void Load2()
		{
			RoofId = Config.GetValue("Configurations", "RoofId", RoofId);
			AerialsId = Config.GetValue("Configurations", "AerialsId", AerialsId);
			AirfilterId = Config.GetValue("Configurations", "AirfilterId", AirfilterId);
			ArchCoverId = Config.GetValue("Configurations", "ArchCoverId", ArchCoverId);
			ArmorId = Config.GetValue("Configurations", "ArmorId", ArmorId);
			BackWheelsId = Config.GetValue("Configurations", "BackWheelsId", BackWheelsId);
			BrakesId = Config.GetValue("Configurations", "BrakesId", BrakesId);
			ColumnShifterLeversId = Config.GetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
			DashboardId = Config.GetValue("Configurations", "DashboardId", DashboardId);
			DialDesignId = Config.GetValue("Configurations", "DialDesignId", DialDesignId);
			DoorSpeekersId = Config.GetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
			EngineId = Config.GetValue("Configurations", "EngineId", EngineId);
			EngineBlockId = Config.GetValue("Configurations", "EngineBlockId", EngineBlockId);
			ExaustId = Config.GetValue("Configurations", "ExaustId", ExaustId);
			FenderId = Config.GetValue("Configurations", "FenderId", FenderId);
			FrameId = Config.GetValue("Configurations", "FrameId", FrameId);
			FrontBumperId = Config.GetValue("Configurations", "FrontBumperId", FrontBumperId);
			FrontWheelsId = Config.GetValue("Configurations", "FrontWheelsId", FrontWheelsId);
			GrilleId = Config.GetValue("Configurations", "GrilleId", GrilleId);
			HoodId = Config.GetValue("Configurations", "HoodId", HoodId);
			HornsId = Config.GetValue("Configurations", "HornsId", HornsId);
			HydralicsId = Config.GetValue("Configurations", "HydralicsId", HydralicsId);
			LiveryId = Config.GetValue("Configurations", "LiveryId", LiveryId);
			OrnamentsId = Config.GetValue("Configurations", "OrnamentsId", OrnamentsId);
			PlaquesId = Config.GetValue("Configurations", "PlaquesId", PlaquesId);
			Plateholder = Config.GetValue("Configurations", "Plateholder", Plateholder);
			RearBumperId = Config.GetValue("Configurations", "RearBumperId", RearBumperId);
			RightFenderId = Config.GetValue("Configurations", "RightFenderId", RightFenderId);
			SeatsId = Config.GetValue("Configurations", "SeatsId", SeatsId);
			SideSkirt = Config.GetValue("Configurations", "SideSkirt", SideSkirt);
			speakers = Config.GetValue("Configurations", "speakers", speakers);
			SpoilersId = Config.GetValue("Configurations", "SpoilersId", SpoilersId);
			SteeringWheelId = Config.GetValue("Configurations", "SteeringWheelId", SteeringWheelId);
			StrutId = Config.GetValue("Configurations", "StrutId", StrutId);
			SuspensionId = Config.GetValue("Configurations", "SuspensionId", SuspensionId);
			TankId = Config.GetValue("Configurations", "TankId", TankId);
			TransmissionId = Config.GetValue("Configurations", "TransmissionId", TransmissionId);
			TrimId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
			TrimDesignId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
			TrunkId = Config.GetValue("Configurations", "TrunkId", TrunkId);
			VanityPlatesId = Config.GetValue("Configurations", "VanityPlatesId", VanityPlatesId);
			WindowId = Config.GetValue("Configurations", "WindowId", WindowId);
			PrimaryColor = Config.GetValue("Configurations", "PrimaryColor", PrimaryColor);
			SecondaryColor = Config.GetValue("Configurations", "SecondaryColor", SecondaryColor);
			Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
			DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
			PearlCent = Config.GetValue("Configurations", "PearlCent", PearlCent);
			NeonColour = Config.GetValue("Configurations", "NeonColour", NeonColour);
			TintId = Config.GetValue("Configurations", "TintId", TintId);
			PlanteNo = Config.GetValue<string>("Configurations", "PlanteNo", PlanteNo);
			Blades = Config.GetValue("Configurations", "Blades", Blades);
			LightColor = Config.GetValue("Configurations", "LightColor", LightColor);
			HasXenonLights = Config.GetValue("Configurations", "HasXenonLights", HasXenonLights);
			TurboActive = Config.GetValue("Configurations", "TurboActive", TurboActive);
			NeonColor = Config.GetValue("Configurations", "NeonColor", NeonColor);
			RightNeonOn = Config.GetValue("Configurations", "RightNeonOn", RightNeonOn);
			LeftNeonOn = Config.GetValue("Configurations", "LeftNeonOn", LeftNeonOn);
			FrontNeonOn = Config.GetValue("Configurations", "FrontNeonOn", FrontNeonOn);
			BackNeonOn = Config.GetValue("Configurations", "BackNeonOn", BackNeonOn);
			TrimColor = Config.GetValue("Configurations", "TrimColor", TrimColor);
			BulletProofTires = Config.GetValue("Configurations", "BulletProofTires", BulletProofTires);
			Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
			DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
			TireSmokeColor = Config.GetValue("Configurations", "TireSmokeColor", TireSmokeColor);
			TireSmoke = Config.GetValue("Configurations", "TireSmoke", TireSmoke);
			try
			{
				Torque = Config.GetValue("Configurations", "Torque", Torque);
				Power = Config.GetValue("Configurations", "Power", Power);
			}
			catch
			{
				Torque = 1f;
				Config.SetValue("Configurations", "Torque", Torque);
				Power = 1f;
				Config.SetValue("Configurations", "Power", Power);
				Config.Save();
			}
			HasClanTag = Config.GetValue("Configurations", "CLanTagOn", HasClanTag);
			ExtraOn.Clear();
			for (int i = 0; i < 21; i++)
			{
				if (Config.GetValue("ToggleableExtras", "Extras" + i, true))
				{
					ExtraOn.Add(true);
				}
				else
				{
					ExtraOn.Add(false);
				}
			}
			newvehicle = World.CreateVehicle(VehicleName.ToString(), VehhicleLoc, -90f);
			Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { newvehicle.Handle, 0 });
			newvehicle.SetMod(VehicleMod.Roof, RoofId, true);
			newvehicle.SetMod(VehicleMod.Roof, RoofId, true);
			newvehicle.SetMod(VehicleMod.Aerials, AerialsId, true);
			newvehicle.SetMod(VehicleMod.AirFilter, AirfilterId, true);
			newvehicle.SetMod(VehicleMod.ArchCover, ArchCoverId, true);
			newvehicle.SetMod(VehicleMod.Armor, ArmorId, true);
			newvehicle.SetMod(VehicleMod.BackWheels, BackWheelsId, true);
			newvehicle.SetMod(VehicleMod.Brakes, BrakesId, true);
			newvehicle.SetMod(VehicleMod.ColumnShifterLevers, ColumnShifterLeversId, true);
			newvehicle.SetMod(VehicleMod.Dashboard, DashboardId, true);
			newvehicle.SetMod(VehicleMod.DialDesign, DialDesignId, true);
			newvehicle.SetMod(VehicleMod.DoorSpeakers, DoorSpeekersId, true);
			newvehicle.SetMod(VehicleMod.Engine, EngineId, true);
			newvehicle.SetMod(VehicleMod.EngineBlock, EngineBlockId, true);
			newvehicle.SetMod(VehicleMod.Exhaust, ExaustId, true);
			newvehicle.SetMod(VehicleMod.Fender, FenderId, true);
			newvehicle.SetMod(VehicleMod.Frame, FrameId, true);
			newvehicle.SetMod(VehicleMod.FrontBumper, FrontBumperId, true);
			newvehicle.SetMod(VehicleMod.FrontWheels, FrontWheelsId, true);
			newvehicle.SetMod(VehicleMod.Grille, GrilleId, true);
			newvehicle.SetMod(VehicleMod.Hood, HoodId, true);
			newvehicle.SetMod(VehicleMod.Horns, HornsId, true);
			newvehicle.SetMod(VehicleMod.Hydraulics, HydralicsId, true);
			newvehicle.SetMod(VehicleMod.Livery, LiveryId, true);
			newvehicle.SetMod(VehicleMod.Ornaments, OrnamentsId, true);
			newvehicle.SetMod(VehicleMod.Plaques, PlaquesId, true);
			newvehicle.SetMod(VehicleMod.PlateHolder, Plateholder, true);
			newvehicle.SetMod(VehicleMod.RearBumper, RearBumperId, true);
			newvehicle.SetMod(VehicleMod.RightFender, RightFenderId, true);
			newvehicle.SetMod(VehicleMod.Seats, SeatsId, true);
			newvehicle.SetMod(VehicleMod.SideSkirt, SideSkirt, true);
			newvehicle.SetMod(VehicleMod.Speakers, speakers, true);
			newvehicle.SetMod(VehicleMod.Spoilers, SpoilersId, true);
			newvehicle.SetMod(VehicleMod.SteeringWheels, SteeringWheelId, true);
			newvehicle.SetMod(VehicleMod.Struts, StrutId, true);
			newvehicle.SetMod(VehicleMod.Suspension, SuspensionId, true);
			newvehicle.SetMod(VehicleMod.Tank, TankId, true);
			newvehicle.SetMod(VehicleMod.Transmission, TransmissionId, true);
			newvehicle.SetMod(VehicleMod.Trim, TrimId, true);
			newvehicle.SetMod(VehicleMod.TrimDesign, TrimDesignId, true);
			newvehicle.SetMod(VehicleMod.Trunk, TrunkId, true);
			newvehicle.SetMod(VehicleMod.VanityPlates, VanityPlatesId, true);
			newvehicle.SetMod(VehicleMod.Windows, WindowId, true);
			newvehicle.SetMod(VehicleMod.Trim, Blades, true);
			newvehicle.ToggleMod(VehicleToggleMod.XenonHeadlights, HasXenonLights);
			newvehicle.ToggleMod(VehicleToggleMod.Turbo, TurboActive);
			Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { newvehicle, LightColor });
			try
			{
				if (HasClanTag)
				{
					VE.CheckforEmblem(newvehicle);
					VE.CreateVehEmblem(newvehicle, Game.Player.Character);
				}
			}
			catch (Exception)
			{
			}
			if (RightNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Right, true);
			}
			if (LeftNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Left, true);
			}
			if (BackNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Back, true);
			}
			if (FrontNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Front, true);
			}
			newvehicle.WindowTint = TintId;
			newvehicle.PrimaryColor = PrimaryColor;
			newvehicle.SecondaryColor = SecondaryColor;
			newvehicle.RimColor = Wheelcolour;
			newvehicle.DashboardColor = DashBoardColour;
			newvehicle.PearlescentColor = PearlCent;
			newvehicle.NeonLightsColor = NeonColour;
			newvehicle.NumberPlate = PlanteNo;
			newvehicle.IsDriveable = false;
			newvehicle.ToggleMod(VehicleToggleMod.TireSmoke, TireSmoke);
			newvehicle.RimColor = Wheelcolour;
			newvehicle.DashboardColor = DashBoardColour;
			newvehicle.TireSmokeColor = TireSmokeColor;
			newvehicle.EngineTorqueMultiplier = Torque;
			newvehicle.EnginePowerMultiplier = Power;
			newvehicle.TrimColor = TrimColor;
			newvehicle.CanTiresBurst = BulletProofTires;
			for (int j = 0; j < 21; j++)
			{
				if (Config.GetValue("ToggleableExtras", "Extras" + j, ExtraOn[j]))
				{
					newvehicle.ToggleExtra(j, ExtraOn[j]);
				}
			}
			SavedVehicle = newvehicle;
		}

		public void Load(Vehicle V, string VehicleName2, Vector3 VehicleLoc2, int Rot)
		{
			newvehicle = V;
			RoofId = Config.GetValue("Configurations", "RoofId", RoofId);
			AerialsId = Config.GetValue("Configurations", "AerialsId", AerialsId);
			AirfilterId = Config.GetValue("Configurations", "AirfilterId", AirfilterId);
			ArchCoverId = Config.GetValue("Configurations", "ArchCoverId", ArchCoverId);
			ArmorId = Config.GetValue("Configurations", "ArmorId", ArmorId);
			BackWheelsId = Config.GetValue("Configurations", "BackWheelsId", BackWheelsId);
			BrakesId = Config.GetValue("Configurations", "BrakesId", BrakesId);
			ColumnShifterLeversId = Config.GetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
			DashboardId = Config.GetValue("Configurations", "DashboardId", DashboardId);
			DialDesignId = Config.GetValue("Configurations", "DialDesignId", DialDesignId);
			DoorSpeekersId = Config.GetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
			EngineId = Config.GetValue("Configurations", "EngineId", EngineId);
			EngineBlockId = Config.GetValue("Configurations", "EngineBlockId", EngineBlockId);
			ExaustId = Config.GetValue("Configurations", "ExaustId", ExaustId);
			FenderId = Config.GetValue("Configurations", "FenderId", FenderId);
			FrameId = Config.GetValue("Configurations", "FrameId", FrameId);
			FrontBumperId = Config.GetValue("Configurations", "FrontBumperId", FrontBumperId);
			FrontWheelsId = Config.GetValue("Configurations", "FrontWheelsId", FrontWheelsId);
			GrilleId = Config.GetValue("Configurations", "GrilleId", GrilleId);
			HoodId = Config.GetValue("Configurations", "HoodId", HoodId);
			HornsId = Config.GetValue("Configurations", "HornsId", HornsId);
			HydralicsId = Config.GetValue("Configurations", "HydralicsId", HydralicsId);
			LiveryId = Config.GetValue("Configurations", "LiveryId", LiveryId);
			OrnamentsId = Config.GetValue("Configurations", "OrnamentsId", OrnamentsId);
			PlaquesId = Config.GetValue("Configurations", "PlaquesId", PlaquesId);
			Plateholder = Config.GetValue("Configurations", "Plateholder", Plateholder);
			RearBumperId = Config.GetValue("Configurations", "RearBumperId", RearBumperId);
			RightFenderId = Config.GetValue("Configurations", "RightFenderId", RightFenderId);
			SeatsId = Config.GetValue("Configurations", "SeatsId", SeatsId);
			SideSkirt = Config.GetValue("Configurations", "SideSkirt", SideSkirt);
			speakers = Config.GetValue("Configurations", "speakers", speakers);
			SpoilersId = Config.GetValue("Configurations", "SpoilersId", SpoilersId);
			SteeringWheelId = Config.GetValue("Configurations", "SteeringWheelId", SteeringWheelId);
			StrutId = Config.GetValue("Configurations", "StrutId", StrutId);
			SuspensionId = Config.GetValue("Configurations", "SuspensionId", SuspensionId);
			TankId = Config.GetValue("Configurations", "TankId", TankId);
			TransmissionId = Config.GetValue("Configurations", "TransmissionId", TransmissionId);
			TrimId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
			TrimDesignId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
			TrunkId = Config.GetValue("Configurations", "TrunkId", TrunkId);
			VanityPlatesId = Config.GetValue("Configurations", "VanityPlatesId", VanityPlatesId);
			WindowId = Config.GetValue("Configurations", "WindowId", WindowId);
			PrimaryColor = Config.GetValue("Configurations", "PrimaryColor", PrimaryColor);
			SecondaryColor = Config.GetValue("Configurations", "SecondaryColor", SecondaryColor);
			Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
			DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
			PearlCent = Config.GetValue("Configurations", "PearlCent", PearlCent);
			NeonColour = Config.GetValue("Configurations", "NeonColour", NeonColour);
			TintId = Config.GetValue("Configurations", "TintId", TintId);
			PlanteNo = Config.GetValue<string>("Configurations", "PlanteNo", PlanteNo);
			Blades = Config.GetValue("Configurations", "Blades", Blades);
			LightColor = Config.GetValue("Configurations", "LightColor", LightColor);
			HasXenonLights = Config.GetValue("Configurations", "HasXenonLights", HasXenonLights);
			TurboActive = Config.GetValue("Configurations", "TurboActive", TurboActive);
			NeonColor = Config.GetValue("Configurations", "NeonColor", NeonColor);
			RightNeonOn = Config.GetValue("Configurations", "RightNeonOn", RightNeonOn);
			LeftNeonOn = Config.GetValue("Configurations", "LeftNeonOn", LeftNeonOn);
			FrontNeonOn = Config.GetValue("Configurations", "FrontNeonOn", FrontNeonOn);
			BackNeonOn = Config.GetValue("Configurations", "BackNeonOn", BackNeonOn);
			TrimColor = Config.GetValue("Configurations", "TrimColor", TrimColor);
			BulletProofTires = Config.GetValue("Configurations", "BulletProofTires", BulletProofTires);
			Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
			DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
			TireSmokeColor = Config.GetValue("Configurations", "TireSmokeColor", TireSmokeColor);
			TireSmoke = Config.GetValue("Configurations", "TireSmoke", TireSmoke);
			try
			{
				Torque = Config.GetValue("Configurations", "Torque", Torque);
				Power = Config.GetValue("Configurations", "Power", Power);
			}
			catch
			{
				Torque = 1f;
				Config.SetValue("Configurations", "Torque", Torque);
				Power = 1f;
				Config.SetValue("Configurations", "Power", Power);
				Config.Save();
			}
			HasClanTag = Config.GetValue("Configurations", "CLanTagOn", HasClanTag);
			ExtraOn.Clear();
			for (int i = 0; i < 21; i++)
			{
				if (Config.GetValue("ToggleableExtras", "Extras" + i, true))
				{
					ExtraOn.Add(true);
				}
				else
				{
					ExtraOn.Add(false);
				}
			}
			newvehicle = World.CreateVehicle(VehicleName2, VehicleLoc2, Rot);
			Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { newvehicle.Handle, 0 });
			newvehicle.SetMod(VehicleMod.Roof, RoofId, true);
			newvehicle.SetMod(VehicleMod.Roof, RoofId, true);
			newvehicle.SetMod(VehicleMod.Aerials, AerialsId, true);
			newvehicle.SetMod(VehicleMod.AirFilter, AirfilterId, true);
			newvehicle.SetMod(VehicleMod.ArchCover, ArchCoverId, true);
			newvehicle.SetMod(VehicleMod.Armor, ArmorId, true);
			newvehicle.SetMod(VehicleMod.BackWheels, BackWheelsId, true);
			newvehicle.SetMod(VehicleMod.Brakes, BrakesId, true);
			newvehicle.SetMod(VehicleMod.ColumnShifterLevers, ColumnShifterLeversId, true);
			newvehicle.SetMod(VehicleMod.Dashboard, DashboardId, true);
			newvehicle.SetMod(VehicleMod.DialDesign, DialDesignId, true);
			newvehicle.SetMod(VehicleMod.DoorSpeakers, DoorSpeekersId, true);
			newvehicle.SetMod(VehicleMod.Engine, EngineId, true);
			newvehicle.SetMod(VehicleMod.EngineBlock, EngineBlockId, true);
			newvehicle.SetMod(VehicleMod.Exhaust, ExaustId, true);
			newvehicle.SetMod(VehicleMod.Fender, FenderId, true);
			newvehicle.SetMod(VehicleMod.Frame, FrameId, true);
			newvehicle.SetMod(VehicleMod.FrontBumper, FrontBumperId, true);
			newvehicle.SetMod(VehicleMod.FrontWheels, FrontWheelsId, true);
			newvehicle.SetMod(VehicleMod.Grille, GrilleId, true);
			newvehicle.SetMod(VehicleMod.Hood, HoodId, true);
			newvehicle.SetMod(VehicleMod.Horns, HornsId, true);
			newvehicle.SetMod(VehicleMod.Hydraulics, HydralicsId, true);
			newvehicle.SetMod(VehicleMod.Livery, LiveryId, true);
			newvehicle.SetMod(VehicleMod.Ornaments, OrnamentsId, true);
			newvehicle.SetMod(VehicleMod.Plaques, PlaquesId, true);
			newvehicle.SetMod(VehicleMod.PlateHolder, Plateholder, true);
			newvehicle.SetMod(VehicleMod.RearBumper, RearBumperId, true);
			newvehicle.SetMod(VehicleMod.RightFender, RightFenderId, true);
			newvehicle.SetMod(VehicleMod.Seats, SeatsId, true);
			newvehicle.SetMod(VehicleMod.SideSkirt, SideSkirt, true);
			newvehicle.SetMod(VehicleMod.Speakers, speakers, true);
			newvehicle.SetMod(VehicleMod.Spoilers, SpoilersId, true);
			newvehicle.SetMod(VehicleMod.SteeringWheels, SteeringWheelId, true);
			newvehicle.SetMod(VehicleMod.Struts, StrutId, true);
			newvehicle.SetMod(VehicleMod.Suspension, SuspensionId, true);
			newvehicle.SetMod(VehicleMod.Tank, TankId, true);
			newvehicle.SetMod(VehicleMod.Transmission, TransmissionId, true);
			newvehicle.SetMod(VehicleMod.Trim, TrimId, true);
			newvehicle.SetMod(VehicleMod.TrimDesign, TrimDesignId, true);
			newvehicle.SetMod(VehicleMod.Trunk, TrunkId, true);
			newvehicle.SetMod(VehicleMod.VanityPlates, VanityPlatesId, true);
			newvehicle.SetMod(VehicleMod.Windows, WindowId, true);
			newvehicle.SetMod(VehicleMod.Trim, Blades, true);
			newvehicle.ToggleMod(VehicleToggleMod.XenonHeadlights, HasXenonLights);
			newvehicle.ToggleMod(VehicleToggleMod.Turbo, TurboActive);
			Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { newvehicle, LightColor });
			try
			{
				if (HasClanTag)
				{
					VE.CheckforEmblem(newvehicle);
					VE.CreateVehEmblem(newvehicle, Game.Player.Character);
				}
			}
			catch (Exception)
			{
			}
			if (RightNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Right, true);
			}
			if (LeftNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Left, true);
			}
			if (BackNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Back, true);
			}
			if (FrontNeonOn)
			{
				newvehicle.NeonLightsColor = NeonColor;
				newvehicle.SetNeonLightsOn(VehicleNeonLight.Front, true);
			}
			newvehicle.WindowTint = TintId;
			newvehicle.PrimaryColor = PrimaryColor;
			newvehicle.SecondaryColor = SecondaryColor;
			newvehicle.PearlescentColor = PearlCent;
			newvehicle.NeonLightsColor = NeonColour;
			newvehicle.NumberPlate = PlanteNo;
			newvehicle.IsDriveable = false;
			SavedVehicle = newvehicle;
			newvehicle.EngineTorqueMultiplier = Torque;
			newvehicle.EnginePowerMultiplier = Power;
			newvehicle.ToggleMod(VehicleToggleMod.TireSmoke, TireSmoke);
			newvehicle.RimColor = Wheelcolour;
			newvehicle.DashboardColor = DashBoardColour;
			newvehicle.TireSmokeColor = TireSmokeColor;
			newvehicle.TrimColor = TrimColor;
			newvehicle.CanTiresBurst = BulletProofTires;
			for (int j = 0; j < 21; j++)
			{
				if (Config.GetValue("ToggleableExtras", "Extras" + j, ExtraOn[j]))
				{
					newvehicle.ToggleExtra(j, ExtraOn[j]);
				}
			}
		}

		public void Load(Vehicle newvehicle)
		{
			VehicletoCheck = newvehicle;
			if ((newvehicle.Model.IsInCdImage && newvehicle.Model.IsValid) || newvehicle != null)
			{
				RoofId = Config.GetValue("Configurations", "RoofId", RoofId);
				AerialsId = Config.GetValue("Configurations", "AerialsId", AerialsId);
				AirfilterId = Config.GetValue("Configurations", "AirfilterId", AirfilterId);
				ArchCoverId = Config.GetValue("Configurations", "ArchCoverId", ArchCoverId);
				ArmorId = Config.GetValue("Configurations", "ArmorId", ArmorId);
				BackWheelsId = Config.GetValue("Configurations", "BackWheelsId", BackWheelsId);
				BrakesId = Config.GetValue("Configurations", "BrakesId", BrakesId);
				ColumnShifterLeversId = Config.GetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
				DashboardId = Config.GetValue("Configurations", "DashboardId", DashboardId);
				DialDesignId = Config.GetValue("Configurations", "DialDesignId", DialDesignId);
				DoorSpeekersId = Config.GetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
				EngineId = Config.GetValue("Configurations", "EngineId", EngineId);
				EngineBlockId = Config.GetValue("Configurations", "EngineBlockId", EngineBlockId);
				ExaustId = Config.GetValue("Configurations", "ExaustId", ExaustId);
				FenderId = Config.GetValue("Configurations", "FenderId", FenderId);
				FrameId = Config.GetValue("Configurations", "FrameId", FrameId);
				FrontBumperId = Config.GetValue("Configurations", "FrontBumperId", FrontBumperId);
				FrontWheelsId = Config.GetValue("Configurations", "FrontWheelsId", FrontWheelsId);
				GrilleId = Config.GetValue("Configurations", "GrilleId", GrilleId);
				HoodId = Config.GetValue("Configurations", "HoodId", HoodId);
				HornsId = Config.GetValue("Configurations", "HornsId", HornsId);
				HydralicsId = Config.GetValue("Configurations", "HydralicsId", HydralicsId);
				LiveryId = Config.GetValue("Configurations", "LiveryId", LiveryId);
				OrnamentsId = Config.GetValue("Configurations", "OrnamentsId", OrnamentsId);
				PlaquesId = Config.GetValue("Configurations", "PlaquesId", PlaquesId);
				Plateholder = Config.GetValue("Configurations", "Plateholder", Plateholder);
				RearBumperId = Config.GetValue("Configurations", "RearBumperId", RearBumperId);
				RightFenderId = Config.GetValue("Configurations", "RightFenderId", RightFenderId);
				SeatsId = Config.GetValue("Configurations", "SeatsId", SeatsId);
				SideSkirt = Config.GetValue("Configurations", "SideSkirt", SideSkirt);
				speakers = Config.GetValue("Configurations", "speakers", speakers);
				SpoilersId = Config.GetValue("Configurations", "SpoilersId", SpoilersId);
				SteeringWheelId = Config.GetValue("Configurations", "SteeringWheelId", SteeringWheelId);
				StrutId = Config.GetValue("Configurations", "StrutId", StrutId);
				SuspensionId = Config.GetValue("Configurations", "SuspensionId", SuspensionId);
				TankId = Config.GetValue("Configurations", "TankId", TankId);
				TransmissionId = Config.GetValue("Configurations", "TransmissionId", TransmissionId);
				TrimId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
				TrimDesignId = Config.GetValue("Configurations", "TrimDesignId", TrimDesignId);
				TrunkId = Config.GetValue("Configurations", "TrunkId", TrunkId);
				VanityPlatesId = Config.GetValue("Configurations", "VanityPlatesId", VanityPlatesId);
				WindowId = Config.GetValue("Configurations", "WindowId", WindowId);
				PrimaryColor = Config.GetValue("Configurations", "PrimaryColor", PrimaryColor);
				SecondaryColor = Config.GetValue("Configurations", "SecondaryColor", SecondaryColor);
				Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
				DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
				PearlCent = Config.GetValue("Configurations", "PearlCent", PearlCent);
				NeonColour = Config.GetValue("Configurations", "NeonColour", NeonColour);
				TintId = Config.GetValue("Configurations", "TintId", TintId);
				PlanteNo = Config.GetValue<string>("Configurations", "PlanteNo", PlanteNo);
				Blades = Config.GetValue("Configurations", "Blades", Blades);
				HasXenonLights = Config.GetValue("Configurations", "HasXenonLights", HasXenonLights);
				TurboActive = Config.GetValue("Configurations", "TurboActive", TurboActive);
				LightColor = Config.GetValue("Configurations", "LightColor", LightColor);
				NeonColor = Config.GetValue("Configurations", "NeonColor", NeonColor);
				RightNeonOn = Config.GetValue("Configurations", "RightNeonOn", RightNeonOn);
				LeftNeonOn = Config.GetValue("Configurations", "LeftNeonOn", LeftNeonOn);
				FrontNeonOn = Config.GetValue("Configurations", "FrontNeonOn", FrontNeonOn);
				BackNeonOn = Config.GetValue("Configurations", "BackNeonOn", BackNeonOn);
				TrimColor = Config.GetValue("Configurations", "TrimColor", TrimColor);
				BulletProofTires = Config.GetValue("Configurations", "BulletProofTires", BulletProofTires);
				try
				{
					Torque = Config.GetValue("Configurations", "Torque", Torque);
					Power = Config.GetValue("Configurations", "Power", Power);
				}
				catch
				{
					Torque = 1f;
					Config.SetValue("Configurations", "Torque", Torque);
					Power = 1f;
					Config.SetValue("Configurations", "Power", Power);
					Config.Save();
				}
				Wheelcolour = Config.GetValue("Configurations", "Wheelcolour", Wheelcolour);
				DashBoardColour = Config.GetValue("Configurations", "DashBoardColour", DashBoardColour);
				TireSmokeColor = Config.GetValue("Configurations", "TireSmokeColor", TireSmokeColor);
				TireSmoke = Config.GetValue("Configurations", "TireSmoke", TireSmoke);
				HasClanTag = Config.GetValue("Configurations", "CLanTagOn", HasClanTag);
				ExtraOn.Clear();
				for (int i = 0; i < 21; i++)
				{
					if (Config.GetValue("ToggleableExtras", "Extras" + i, true))
					{
						ExtraOn.Add(true);
					}
					else
					{
						ExtraOn.Add(false);
					}
				}
				Function.Call(Hash._0x1F2AA07F00B3217A, new InputArgument[2] { newvehicle.Handle, 0 });
				newvehicle.SetMod(VehicleMod.Livery, LiveryId, false);
				newvehicle.SetMod(VehicleMod.Roof, RoofId, true);
				newvehicle.SetMod(VehicleMod.Aerials, AerialsId, true);
				newvehicle.SetMod(VehicleMod.AirFilter, AirfilterId, true);
				newvehicle.SetMod(VehicleMod.ArchCover, ArchCoverId, true);
				newvehicle.SetMod(VehicleMod.Armor, ArmorId, true);
				newvehicle.SetMod(VehicleMod.BackWheels, BackWheelsId, true);
				newvehicle.SetMod(VehicleMod.Brakes, BrakesId, true);
				newvehicle.SetMod(VehicleMod.ColumnShifterLevers, ColumnShifterLeversId, true);
				newvehicle.SetMod(VehicleMod.Dashboard, DashboardId, true);
				newvehicle.SetMod(VehicleMod.DialDesign, DialDesignId, true);
				newvehicle.SetMod(VehicleMod.DoorSpeakers, DoorSpeekersId, true);
				newvehicle.SetMod(VehicleMod.Engine, EngineId, true);
				newvehicle.SetMod(VehicleMod.EngineBlock, EngineBlockId, true);
				newvehicle.SetMod(VehicleMod.Exhaust, ExaustId, true);
				newvehicle.SetMod(VehicleMod.Fender, FenderId, true);
				newvehicle.SetMod(VehicleMod.Frame, FrameId, true);
				newvehicle.SetMod(VehicleMod.FrontBumper, FrontBumperId, true);
				newvehicle.SetMod(VehicleMod.FrontWheels, FrontWheelsId, true);
				newvehicle.SetMod(VehicleMod.Grille, GrilleId, true);
				newvehicle.SetMod(VehicleMod.Hood, HoodId, true);
				newvehicle.SetMod(VehicleMod.Horns, HornsId, true);
				newvehicle.SetMod(VehicleMod.Hydraulics, HydralicsId, true);
				newvehicle.SetMod(VehicleMod.Livery, LiveryId, false);
				newvehicle.SetMod(VehicleMod.Ornaments, OrnamentsId, true);
				newvehicle.SetMod(VehicleMod.Plaques, PlaquesId, true);
				newvehicle.SetMod(VehicleMod.PlateHolder, Plateholder, true);
				newvehicle.SetMod(VehicleMod.RearBumper, RearBumperId, true);
				newvehicle.SetMod(VehicleMod.RightFender, RightFenderId, true);
				newvehicle.SetMod(VehicleMod.Seats, SeatsId, true);
				newvehicle.SetMod(VehicleMod.SideSkirt, SideSkirt, true);
				newvehicle.SetMod(VehicleMod.Speakers, speakers, true);
				newvehicle.SetMod(VehicleMod.Spoilers, SpoilersId, true);
				newvehicle.SetMod(VehicleMod.SteeringWheels, SteeringWheelId, true);
				newvehicle.SetMod(VehicleMod.Struts, StrutId, true);
				newvehicle.SetMod(VehicleMod.Suspension, SuspensionId, true);
				newvehicle.SetMod(VehicleMod.Tank, TankId, true);
				newvehicle.SetMod(VehicleMod.Transmission, TransmissionId, true);
				newvehicle.SetMod(VehicleMod.Trim, TrimId, true);
				newvehicle.SetMod(VehicleMod.TrimDesign, TrimDesignId, true);
				newvehicle.SetMod(VehicleMod.Trunk, TrunkId, true);
				newvehicle.SetMod(VehicleMod.VanityPlates, VanityPlatesId, true);
				newvehicle.SetMod(VehicleMod.Windows, WindowId, true);
				newvehicle.SetMod(VehicleMod.Trim, Blades, true);
				newvehicle.ToggleMod(VehicleToggleMod.XenonHeadlights, HasXenonLights);
				newvehicle.ToggleMod(VehicleToggleMod.Turbo, TurboActive);
				Function.Call((Hash)16433691881432431111uL, new InputArgument[2] { newvehicle, LightColor });
				newvehicle.EngineTorqueMultiplier = Torque;
				newvehicle.EnginePowerMultiplier = Power;
				try
				{
					if (HasClanTag)
					{
						VE.CheckforEmblem(newvehicle);
						VE.CreateVehEmblem(newvehicle, Game.Player.Character);
					}
				}
				catch (Exception)
				{
				}
				if (RightNeonOn)
				{
					newvehicle.NeonLightsColor = NeonColor;
					newvehicle.SetNeonLightsOn(VehicleNeonLight.Right, true);
				}
				if (LeftNeonOn)
				{
					newvehicle.NeonLightsColor = NeonColor;
					newvehicle.SetNeonLightsOn(VehicleNeonLight.Left, true);
				}
				if (BackNeonOn)
				{
					newvehicle.NeonLightsColor = NeonColor;
					newvehicle.SetNeonLightsOn(VehicleNeonLight.Back, true);
				}
				if (FrontNeonOn)
				{
					newvehicle.NeonLightsColor = NeonColor;
					newvehicle.SetNeonLightsOn(VehicleNeonLight.Front, true);
				}
				newvehicle.WindowTint = TintId;
				newvehicle.PrimaryColor = PrimaryColor;
				newvehicle.SecondaryColor = SecondaryColor;
				newvehicle.RimColor = Wheelcolour;
				newvehicle.DashboardColor = DashBoardColour;
				newvehicle.PearlescentColor = PearlCent;
				newvehicle.NeonLightsColor = NeonColour;
				newvehicle.NumberPlate = PlanteNo;
				newvehicle.IsDriveable = false;
				SavedVehicle = newvehicle;
				newvehicle.ToggleMod(VehicleToggleMod.TireSmoke, TireSmoke);
				newvehicle.RimColor = Wheelcolour;
				newvehicle.DashboardColor = DashBoardColour;
				newvehicle.TireSmokeColor = TireSmokeColor;
				newvehicle.TrimColor = TrimColor;
				newvehicle.CanTiresBurst = BulletProofTires;
				for (int j = 0; j < 21; j++)
				{
					if (Config.GetValue("ToggleableExtras", "Extras" + j, ExtraOn[j]))
					{
						newvehicle.ToggleExtra(j, ExtraOn[j]);
					}
				}
				VehicleHash = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { newvehicle.DisplayName }).ToString();
				Config.SetValue<string>("Configurations", "VehicleHash", VehicleHash);
				Config.Save();
			}
			else
			{
				UI.Notify(string.Concat("~r~Error~w~: ", VehicletoCheck, " is not a Base Game vehicle or has issues with saving, contack HKH191 for more info or help!"));
			}
		}

		public Model CheckCar(string iniName)
		{
			LoadIniFile(iniName);
			VehicleName = Config.GetValue<string>("Configurations", "VehicleName", VehicleName);
			if (VehicleName == "CARBON")
			{
				VehicleName = "CARBONRS";
			}
			if (VehicleName == "UTILTRUC")
			{
				VehicleName = "UTILLITRUCK";
			}
			if (VehicleName == "FORK")
			{
				VehicleName = "FORKLIFT";
			}
			if (VehicleName == "LANDSTAL")
			{
				VehicleName = "LANDSTALKER";
			}
			if (VehicleName == "CAVCADE")
			{
				VehicleName = "CAVALCADE";
			}
			if (VehicleName == "SANCHEZ02")
			{
				VehicleName = "SANCHEZ2";
			}
			if (VehicleName == "SANCHEZ01")
			{
				VehicleName = "SANCHEZ";
			}
			if (VehicleName == "FAGGION")
			{
				VehicleName = "FAGGIO";
			}
			if (VehicleName == "STINGERG")
			{
				VehicleName = "FELTZER3";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "KHAMEL")
			{
				VehicleName = "KHAMELION";
			}
			if (VehicleName == "FURORE")
			{
				VehicleName = "FUROREGT";
			}
			if (VehicleName == "COGCABRI")
			{
				VehicleName = "COGCABRIO";
			}
			if (VehicleName == "RLOADER")
			{
				VehicleName = "RATLOADER";
			}
			if (VehicleName == "RLOADER2")
			{
				VehicleName = "RATLOADER2";
			}
			if (VehicleName == "FELTZER")
			{
				VehicleName = "FELTZER2";
			}
			if (VehicleName == "WASHINGT")
			{
				VehicleName = "WASHINGTON";
			}
			if (VehicleName == "BUFFALO02")
			{
				VehicleName = "BUFFALO2";
			}
			if (VehicleName == "TAILGATE")
			{
				VehicleName = "TAILGATER";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "ASTROPE")
			{
				VehicleName = "ASTEROPE";
			}
			if (VehicleName == "SANDKIN2")
			{
				VehicleName = "SANDKING2";
			}
			if (VehicleName == "REBEL02")
			{
				VehicleName = "REBEL2";
			}
			if (VehicleName == "REBEL01")
			{
				VehicleName = "REBEL";
			}
			if (VehicleName == "RANCHERX")
			{
				VehicleName = "RANCHERXL";
			}
			if (VehicleName == "BFINJECT")
			{
				VehicleName = "BFINJECTION";
			}
			if (VehicleName == "DOMINATO2")
			{
				VehicleName = "DOMINATOR2";
			}
			if (VehicleName == "DILETTAN")
			{
				VehicleName = "DILETTANTE";
			}
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
			if (VehicleName == "ABMULAN")
			{
				VehicleName = "AMBULANCE";
			}
			if (VehicleName == "Ruiner3")
			{
				VehicleName = "Ruiner3";
			}
			if (VehicleName == "BUCCANEE2")
			{
				VehicleName = "BUCCANEER2";
			}
			if (VehicleName == "BUCCANEE")
			{
				VehicleName = "BUCCANEER";
			}
			if (VehicleName == "CARBONIZ")
			{
				VehicleName = "CARBONIZZARE";
			}
			if (VehicleName == "penetrator")
			{
				VehicleName = "PENETRATOR";
			}
			if (VehicleName == "TROPHY")
			{
				VehicleName = "TROPHYTRUCK";
			}
			if (VehicleName == "TROPHY2")
			{
				VehicleName = "TROPHYTRUCK2";
			}
			if (VehicleName == "ROOSEVELT")
			{
				VehicleName = "Btype";
			}
			if (VehicleName == "VERLIER")
			{
				VehicleName = "VERLIERER2";
			}
			if (VehicleName == "BTYPE2")
			{
				VehicleName = "Btype2";
			}
			if (VehicleName == "ROOSEVELT2")
			{
				VehicleName = "Btype3";
			}
			if (VehicleName == "DOMINATO")
			{
				VehicleName = "DOMINATOR";
			}
			if (VehicleName == "NITESHAD")
			{
				VehicleName = "NIGHTSHADE";
			}
			Model result = new Model(VehicleName);
			result.Request(250);
			if (result.IsInCdImage && result.IsValid)
			{
				while (!result.IsLoaded)
				{
					Script.Wait(50);
				}
				return result;
			}
			result.MarkAsNoLongerNeeded();
			return result;
		}

		public void SaveWithoutDelete()
		{
			if (!(Game.Player.Character.CurrentVehicle != null))
			{
				return;
			}
			VehicleName = Game.Player.Character.CurrentVehicle.DisplayName;
			RoofId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Roof);
			AerialsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Aerials);
			AirfilterId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.AirFilter);
			ArchCoverId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.ArchCover);
			ArmorId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Armor);
			BackWheelsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.BackWheels);
			BrakesId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Brakes);
			ColumnShifterLeversId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.ColumnShifterLevers);
			DashboardId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Dashboard);
			DialDesignId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.DialDesign);
			DoorSpeekersId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.DoorSpeakers);
			EngineId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Engine);
			EngineBlockId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.EngineBlock);
			ExaustId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Exhaust);
			FenderId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Fender);
			FrameId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Frame);
			FrontBumperId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.FrontBumper);
			FrontWheelsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.FrontWheels);
			GrilleId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Grille);
			HoodId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Hood);
			HornsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Horns);
			HydralicsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Hydraulics);
			LiveryId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Livery);
			OrnamentsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Ornaments);
			PlaquesId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Plaques);
			Plateholder = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.PlateHolder);
			RearBumperId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.RearBumper);
			RightFenderId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.RightFender);
			SeatsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Seats);
			SideSkirt = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.SideSkirt);
			speakers = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Speakers);
			SpoilersId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Spoilers);
			SteeringWheelId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.SteeringWheels);
			StrutId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Struts);
			SuspensionId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Suspension);
			TankId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Tank);
			TransmissionId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Transmission);
			TrimId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Trim);
			TrimDesignId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.TrimDesign);
			TrunkId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Trunk);
			VanityPlatesId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.VanityPlates);
			WindowId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Windows);
			PrimaryColor = Game.Player.Character.CurrentVehicle.PrimaryColor;
			SecondaryColor = Game.Player.Character.CurrentVehicle.SecondaryColor;
			TintId = Game.Player.Character.CurrentVehicle.WindowTint;
			Wheelcolour = Game.Player.Character.CurrentVehicle.RimColor;
			DashBoardColour = Game.Player.Character.CurrentVehicle.DashboardColor;
			PearlCent = Game.Player.Character.CurrentVehicle.PearlescentColor;
			NeonColour = Game.Player.Character.CurrentVehicle.NeonLightsColor;
			PlanteNo = Game.Player.Character.CurrentVehicle.NumberPlate;
			Blades = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Trim);
			Vehicle currentVehicle = Game.Player.Character.CurrentVehicle;
			HasXenonLights = currentVehicle.IsToggleModOn(VehicleToggleMod.XenonHeadlights);
			TurboActive = currentVehicle.IsToggleModOn(VehicleToggleMod.Turbo);
			LightColor = Function.Call<int>((Hash)4467343895069330651uL, new InputArgument[1] { currentVehicle });
			RightNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Right);
			LeftNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Left);
			BackNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Back);
			FrontNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Front);
			NeonColor = currentVehicle.NeonLightsColor;
			TireSmoke = currentVehicle.IsToggleModOn(VehicleToggleMod.TireSmoke);
			Wheelcolour = currentVehicle.RimColor;
			DashBoardColour = currentVehicle.DashboardColor;
			TireSmokeColor = currentVehicle.TireSmokeColor;
			VehicleHash = Game.Player.Character.CurrentVehicle.GetHashCode().ToString();
			BulletProofTires = currentVehicle.CanTiresBurst;
			TrimColor = currentVehicle.TrimColor;
			try
			{
				HasClanTag = VE.ReturnClanEmblemOn(currentVehicle);
				Config.SetValue("Configurations", "CLanTagOn", HasClanTag);
			}
			catch (Exception)
			{
			}
			if (VehicleName == "CARBON")
			{
				VehicleName = "CARBONRS";
			}
			if (VehicleName == "UTILTRUC")
			{
				VehicleName = "UTILLITRUCK";
			}
			if (VehicleName == "FORK")
			{
				VehicleName = "FORKLIFT";
			}
			if (VehicleName == "LANDSTAL")
			{
				VehicleName = "LANDSTALKER";
			}
			if (VehicleName == "CAVCADE")
			{
				VehicleName = "CAVALCADE";
			}
			if (VehicleName == "SANCHEZ02")
			{
				VehicleName = "SANCHEZ2";
			}
			if (VehicleName == "SANCHEZ01")
			{
				VehicleName = "SANCHEZ";
			}
			if (VehicleName == "FAGGION")
			{
				VehicleName = "FAGGIO";
			}
			if (VehicleName == "STINGERG")
			{
				VehicleName = "FELTZER3";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "KHAMEL")
			{
				VehicleName = "KHAMELION";
			}
			if (VehicleName == "FURORE")
			{
				VehicleName = "FUROREGT";
			}
			if (VehicleName == "COGCABRI")
			{
				VehicleName = "COGCABRIO";
			}
			if (VehicleName == "RLOADER")
			{
				VehicleName = "RATLOADER";
			}
			if (VehicleName == "RLOADER2")
			{
				VehicleName = "RATLOADER2";
			}
			if (VehicleName == "FELTZER")
			{
				VehicleName = "FELTZER2";
			}
			if (VehicleName == "WASHINGT")
			{
				VehicleName = "WASHINGTON";
			}
			if (VehicleName == "BUFFALO02")
			{
				VehicleName = "BUFFALO2";
			}
			if (VehicleName == "TAILGATE")
			{
				VehicleName = "TAILGATER";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "ASTROPE")
			{
				VehicleName = "ASTEROPE";
			}
			if (VehicleName == "SANDKIN2")
			{
				VehicleName = "SANDKING2";
			}
			if (VehicleName == "REBEL02")
			{
				VehicleName = "REBEL2";
			}
			if (VehicleName == "REBEL01")
			{
				VehicleName = "REBEL";
			}
			if (VehicleName == "RANCHERX")
			{
				VehicleName = "RANCHERXL";
			}
			if (VehicleName == "BFINJECT")
			{
				VehicleName = "BFINJECTION";
			}
			if (VehicleName == "DOMINATO2")
			{
				VehicleName = "DOMINATOR2";
			}
			if (VehicleName == "DILETTAN")
			{
				VehicleName = "DILETTANTE";
			}
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
			if (VehicleName == "ABMULAN")
			{
				VehicleName = "AMBULANCE";
			}
			if (VehicleName == "Ruiner3")
			{
				VehicleName = "Ruiner3";
			}
			if (VehicleName == "BUCCANEE2")
			{
				VehicleName = "BUCCANEER2";
			}
			if (VehicleName == "BUCCANEE")
			{
				VehicleName = "BUCCANEER";
			}
			if (VehicleName == "CARBONIZ")
			{
				VehicleName = "CARBONIZZARE";
			}
			if (VehicleName == "penetrator")
			{
				VehicleName = "PENETRATOR";
			}
			if (VehicleName == "TROPHY")
			{
				VehicleName = "TROPHYTRUCK";
			}
			if (VehicleName == "TROPHY2")
			{
				VehicleName = "TROPHYTRUCK2";
			}
			if (VehicleName == "ROOSEVELT")
			{
				VehicleName = "Btype";
			}
			if (VehicleName == "VERLIER")
			{
				VehicleName = "VERLIERER2";
			}
			if (VehicleName == "BTYPE2")
			{
				VehicleName = "Btype2";
			}
			if (VehicleName == "ROOSEVELT2")
			{
				VehicleName = "Btype3";
			}
			if (VehicleName == "DOMINATO")
			{
				VehicleName = "DOMINATOR";
			}
			if (VehicleName == "NITESHAD")
			{
				VehicleName = "NIGHTSHADE";
			}
			Config.SetValue<string>("Configurations", "VehicleName", VehicleName);
			Config.SetValue("Configurations", "Roof", RoofId);
			Config.SetValue("Configurations", "AerialsId", AerialsId);
			Config.SetValue("Configurations", "AirfilterId", AirfilterId);
			Config.SetValue("Configurations", "ArchCoverId", ArchCoverId);
			Config.SetValue("Configurations", "ArmorId", ArmorId);
			Config.SetValue("Configurations", "BackWheelsId", BackWheelsId);
			Config.SetValue("Configurations", "BrakesId", BrakesId);
			Config.SetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
			Config.SetValue("Configurations", "DashboardId", DashboardId);
			Config.SetValue("Configurations", "DialDesignId", DialDesignId);
			Config.SetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
			Config.SetValue("Configurations", "EngineId", EngineId);
			Config.SetValue("Configurations", "EngineBlockId", EngineBlockId);
			Config.SetValue("Configurations", "ExaustId", ExaustId);
			Config.SetValue("Configurations", "FenderId", FenderId);
			Config.SetValue("Configurations", "FrameId", FrameId);
			Config.SetValue("Configurations", "FrontBumperId", FrontBumperId);
			Config.SetValue("Configurations", "FrontWheelsId", FrontWheelsId);
			Config.SetValue("Configurations", "GrilleId", GrilleId);
			Config.SetValue("Configurations", "HoodId", HoodId);
			Config.SetValue("Configurations", "HornsId", HornsId);
			Config.SetValue("Configurations", "HydralicsId", HydralicsId);
			Config.SetValue("Configurations", "LiveryId", LiveryId);
			Config.SetValue("Configurations", "OrnamentsId", OrnamentsId);
			Config.SetValue("Configurations", "PlaquesId", PlaquesId);
			Config.SetValue("Configurations", "Plateholder", Plateholder);
			Config.SetValue("Configurations", "RearBumperId", RearBumperId);
			Config.SetValue("Configurations", "RightFenderId", RightFenderId);
			Config.SetValue("Configurations", "SeatsId", SeatsId);
			Config.SetValue("Configurations", "speakers", speakers);
			Config.SetValue("Configurations", "speakers", speakers);
			Config.SetValue("Configurations", "SpoilersId", SpoilersId);
			Config.SetValue("Configurations", "SteeringWheelId", SteeringWheelId);
			Config.SetValue("Configurations", "StrutId", StrutId);
			Config.SetValue("Configurations", "RoofId", RoofId);
			Config.SetValue("Configurations", "SuspensionId", SuspensionId);
			Config.SetValue("Configurations", "TransmissionId", TransmissionId);
			Config.SetValue("Configurations", "TrimDesignId", TrimDesignId);
			Config.SetValue("Configurations", "TrimDesignId", TrimDesignId);
			Config.SetValue("Configurations", "TrunkId", TrunkId);
			Config.SetValue("Configurations", "VanityPlatesId", VanityPlatesId);
			Config.SetValue("Configurations", "WindowId", WindowId);
			Config.SetValue("Configurations", "TintId", TintId);
			Config.SetValue("Configurations", "Wheelcolour", Wheelcolour);
			Config.SetValue("Configurations", "DashBoardColour", DashBoardColour);
			Config.SetValue("Configurations", "PearlCent", PearlCent);
			Config.SetValue("Configurations", "NeonColour", NeonColour);
			Config.SetValue<string>("Configurations", "PlanteNo", PlanteNo);
			Config.SetValue("Configurations", "PrimaryColor", PrimaryColor);
			Config.SetValue("Configurations", "SecondaryColor", SecondaryColor);
			Config.SetValue("Configurations", "Blades", Blades);
			Config.SetValue("Configurations", "HasXenonLights", HasXenonLights);
			Config.SetValue("Configurations", "TurboActive", TurboActive);
			Config.SetValue("Configurations", "LightColor", LightColor);
			Config.SetValue<string>("Configurations", "VehicleHash", VehicleHash);
			Config.SetValue("Configurations", "NeonColor", NeonColor);
			Config.SetValue("Configurations", "RightNeonOn", RightNeonOn);
			Config.SetValue("Configurations", "LeftNeonOn", LeftNeonOn);
			Config.SetValue("Configurations", "FrontNeonOn", FrontNeonOn);
			Config.SetValue("Configurations", "BackNeonOn", BackNeonOn);
			Config.SetValue("Configurations", "Wheelcolour", Wheelcolour);
			Config.SetValue("Configurations", "DashBoardColour", DashBoardColour);
			Config.SetValue("Configurations", "TireSmokeColor", TireSmokeColor);
			Config.SetValue("Configurations", "TireSmoke", TireSmoke);
			Config.SetValue("Configurations", "TrimColor", TrimColor);
			Config.SetValue("Configurations", "BulletProofTires", BulletProofTires);
			if (ExtraOn.Count >= 1)
			{
				for (int i = 0; i < ExtraOn.Count; i++)
				{
					Config.SetValue("ToggleableExtras", "Extras" + i, ExtraOn[i]);
				}
			}
			Config.Save();
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
		}

		public void Save()
		{
			if (!(Game.Player.Character.CurrentVehicle != null))
			{
				return;
			}
			VehicleName = Game.Player.Character.CurrentVehicle.DisplayName;
			RoofId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Roof);
			AerialsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Aerials);
			AirfilterId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.AirFilter);
			ArchCoverId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.ArchCover);
			ArmorId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Armor);
			BackWheelsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.BackWheels);
			BrakesId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Brakes);
			ColumnShifterLeversId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.ColumnShifterLevers);
			DashboardId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Dashboard);
			DialDesignId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.DialDesign);
			DoorSpeekersId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.DoorSpeakers);
			EngineId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Engine);
			EngineBlockId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.EngineBlock);
			ExaustId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Exhaust);
			FenderId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Fender);
			FrameId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Frame);
			FrontBumperId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.FrontBumper);
			FrontWheelsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.FrontWheels);
			GrilleId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Grille);
			HoodId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Hood);
			HornsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Horns);
			HydralicsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Hydraulics);
			LiveryId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Livery);
			OrnamentsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Ornaments);
			PlaquesId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Plaques);
			Plateholder = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.PlateHolder);
			RearBumperId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.RearBumper);
			RightFenderId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.RightFender);
			SeatsId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Seats);
			SideSkirt = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.SideSkirt);
			speakers = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Speakers);
			SpoilersId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Spoilers);
			SteeringWheelId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.SteeringWheels);
			StrutId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Struts);
			SuspensionId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Suspension);
			TankId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Tank);
			TransmissionId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Transmission);
			TrimId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Trim);
			TrimDesignId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.TrimDesign);
			TrunkId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Trunk);
			VanityPlatesId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.VanityPlates);
			WindowId = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Windows);
			PrimaryColor = Game.Player.Character.CurrentVehicle.PrimaryColor;
			SecondaryColor = Game.Player.Character.CurrentVehicle.SecondaryColor;
			Wheelcolour = Game.Player.Character.CurrentVehicle.RimColor;
			DashBoardColour = Game.Player.Character.CurrentVehicle.DashboardColor;
			PearlCent = Game.Player.Character.CurrentVehicle.PearlescentColor;
			NeonColour = Game.Player.Character.CurrentVehicle.NeonLightsColor;
			TintId = Game.Player.Character.CurrentVehicle.WindowTint;
			PlanteNo = Game.Player.Character.CurrentVehicle.NumberPlate;
			Blades = Game.Player.Character.CurrentVehicle.GetMod(VehicleMod.Trim);
			Vehicle currentVehicle = Game.Player.Character.CurrentVehicle;
			HasXenonLights = currentVehicle.IsToggleModOn(VehicleToggleMod.XenonHeadlights);
			TurboActive = currentVehicle.IsToggleModOn(VehicleToggleMod.Turbo);
			LightColor = Function.Call<int>((Hash)4467343895069330651uL, new InputArgument[1] { currentVehicle });
			VehicleHash = Game.Player.Character.CurrentVehicle.GetHashCode().ToString();
			RightNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Right);
			LeftNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Left);
			BackNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Back);
			FrontNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Front);
			NeonColor = currentVehicle.NeonLightsColor;
			BulletProofTires = currentVehicle.CanTiresBurst;
			TrimColor = currentVehicle.TrimColor;
			TireSmoke = currentVehicle.IsToggleModOn(VehicleToggleMod.TireSmoke);
			Wheelcolour = currentVehicle.RimColor;
			DashBoardColour = currentVehicle.DashboardColor;
			TireSmokeColor = currentVehicle.TireSmokeColor;
			try
			{
				HasClanTag = VE.ReturnClanEmblemOn(currentVehicle);
				Config.SetValue("Configurations", "CLanTagOn", HasClanTag);
			}
			catch (Exception)
			{
			}
			if (VehicleName == "CARBON")
			{
				VehicleName = "CARBONRS";
			}
			if (VehicleName == "UTILTRUC")
			{
				VehicleName = "UTILLITRUCK";
			}
			if (VehicleName == "FORK")
			{
				VehicleName = "FORKLIFT";
			}
			if (VehicleName == "LANDSTAL")
			{
				VehicleName = "LANDSTALKER";
			}
			if (VehicleName == "CAVCADE")
			{
				VehicleName = "CAVALCADE";
			}
			if (VehicleName == "SANCHEZ02")
			{
				VehicleName = "SANCHEZ2";
			}
			if (VehicleName == "SANCHEZ01")
			{
				VehicleName = "SANCHEZ";
			}
			if (VehicleName == "FAGGION")
			{
				VehicleName = "FAGGIO";
			}
			if (VehicleName == "STINGERG")
			{
				VehicleName = "FELTZER3";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "KHAMEL")
			{
				VehicleName = "KHAMELION";
			}
			if (VehicleName == "FURORE")
			{
				VehicleName = "FUROREGT";
			}
			if (VehicleName == "COGCABRI")
			{
				VehicleName = "COGCABRIO";
			}
			if (VehicleName == "RLOADER")
			{
				VehicleName = "RATLOADER";
			}
			if (VehicleName == "RLOADER2")
			{
				VehicleName = "RATLOADER2";
			}
			if (VehicleName == "FELTZER")
			{
				VehicleName = "FELTZER2";
			}
			if (VehicleName == "WASHINGT")
			{
				VehicleName = "WASHINGTON";
			}
			if (VehicleName == "BUFFALO02")
			{
				VehicleName = "BUFFALO2";
			}
			if (VehicleName == "TAILGATE")
			{
				VehicleName = "TAILGATER";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "ASTROPE")
			{
				VehicleName = "ASTEROPE";
			}
			if (VehicleName == "SANDKIN2")
			{
				VehicleName = "SANDKING2";
			}
			if (VehicleName == "REBEL02")
			{
				VehicleName = "REBEL2";
			}
			if (VehicleName == "REBEL01")
			{
				VehicleName = "REBEL";
			}
			if (VehicleName == "RANCHERX")
			{
				VehicleName = "RANCHERXL";
			}
			if (VehicleName == "BFINJECT")
			{
				VehicleName = "BFINJECTION";
			}
			if (VehicleName == "DOMINATO2")
			{
				VehicleName = "DOMINATOR2";
			}
			if (VehicleName == "DILETTAN")
			{
				VehicleName = "DILETTANTE";
			}
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
			if (VehicleName == "ABMULAN")
			{
				VehicleName = "AMBULANCE";
			}
			if (VehicleName == "Ruiner3")
			{
				VehicleName = "Ruiner3";
			}
			if (VehicleName == "BUCCANEE2")
			{
				VehicleName = "BUCCANEER2";
			}
			if (VehicleName == "BUCCANEE")
			{
				VehicleName = "BUCCANEER";
			}
			if (VehicleName == "CARBONIZ")
			{
				VehicleName = "CARBONIZZARE";
			}
			if (VehicleName == "penetrator")
			{
				VehicleName = "PENETRATOR";
			}
			if (VehicleName == "TROPHY")
			{
				VehicleName = "TROPHYTRUCK";
			}
			if (VehicleName == "TROPHY2")
			{
				VehicleName = "TROPHYTRUCK2";
			}
			if (VehicleName == "ROOSEVELT")
			{
				VehicleName = "Btype";
			}
			if (VehicleName == "VERLIER")
			{
				VehicleName = "VERLIERER2";
			}
			if (VehicleName == "BTYPE2")
			{
				VehicleName = "Btype2";
			}
			if (VehicleName == "ROOSEVELT2")
			{
				VehicleName = "Btype3";
			}
			if (VehicleName == "DOMINATO")
			{
				VehicleName = "DOMINATOR";
			}
			if (VehicleName == "NITESHAD")
			{
				VehicleName = "NIGHTSHADE";
			}
			Config.SetValue<string>("Configurations", "VehicleName", VehicleName);
			Config.SetValue<string>("Configurations", "VehicleName", VehicleName);
			Config.SetValue("Configurations", "Roof", RoofId);
			Config.SetValue("Configurations", "AerialsId", AerialsId);
			Config.SetValue("Configurations", "AirfilterId", AirfilterId);
			Config.SetValue("Configurations", "ArchCoverId", ArchCoverId);
			Config.SetValue("Configurations", "ArmorId", ArmorId);
			Config.SetValue("Configurations", "BackWheelsId", BackWheelsId);
			Config.SetValue("Configurations", "BrakesId", BrakesId);
			Config.SetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
			Config.SetValue("Configurations", "DashboardId", DashboardId);
			Config.SetValue("Configurations", "DialDesignId", DialDesignId);
			Config.SetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
			Config.SetValue("Configurations", "EngineId", EngineId);
			Config.SetValue("Configurations", "EngineBlockId", EngineBlockId);
			Config.SetValue("Configurations", "ExaustId", ExaustId);
			Config.SetValue("Configurations", "FenderId", FenderId);
			Config.SetValue("Configurations", "FrameId", FrameId);
			Config.SetValue("Configurations", "FrontBumperId", FrontBumperId);
			Config.SetValue("Configurations", "FrontWheelsId", FrontWheelsId);
			Config.SetValue("Configurations", "GrilleId", GrilleId);
			Config.SetValue("Configurations", "HoodId", HoodId);
			Config.SetValue("Configurations", "HornsId", HornsId);
			Config.SetValue("Configurations", "HydralicsId", HydralicsId);
			Config.SetValue("Configurations", "LiveryId", LiveryId);
			Config.SetValue("Configurations", "OrnamentsId", OrnamentsId);
			Config.SetValue("Configurations", "PlaquesId", PlaquesId);
			Config.SetValue("Configurations", "Plateholder", Plateholder);
			Config.SetValue("Configurations", "RearBumperId", RearBumperId);
			Config.SetValue("Configurations", "RightFenderId", RightFenderId);
			Config.SetValue("Configurations", "SeatsId", SeatsId);
			Config.SetValue("Configurations", "speakers", speakers);
			Config.SetValue("Configurations", "speakers", speakers);
			Config.SetValue("Configurations", "SpoilersId", SpoilersId);
			Config.SetValue("Configurations", "SteeringWheelId", SteeringWheelId);
			Config.SetValue("Configurations", "StrutId", StrutId);
			Config.SetValue("Configurations", "RoofId", RoofId);
			Config.SetValue("Configurations", "SuspensionId", SuspensionId);
			Config.SetValue("Configurations", "TransmissionId", TransmissionId);
			Config.SetValue("Configurations", "TrimDesignId", TrimDesignId);
			Config.SetValue("Configurations", "TrimDesignId", TrimDesignId);
			Config.SetValue("Configurations", "TrunkId", TrunkId);
			Config.SetValue("Configurations", "VanityPlatesId", VanityPlatesId);
			Config.SetValue("Configurations", "WindowId", WindowId);
			Config.SetValue("Configurations", "PrimaryColor", PrimaryColor);
			Config.SetValue("Configurations", "SecondaryColor", SecondaryColor);
			Config.SetValue("Configurations", "Wheelcolour", Wheelcolour);
			Config.SetValue("Configurations", "DashBoardColour", DashBoardColour);
			Config.SetValue("Configurations", "PearlCent", PearlCent);
			Config.SetValue("Configurations", "NeonColour", NeonColour);
			Config.SetValue("Configurations", "TintId", TintId);
			Config.SetValue<string>("Configurations", "PlanteNo", PlanteNo);
			Config.SetValue("Configurations", "Blades", Blades);
			Config.SetValue("Configurations", "HasXenonLights", HasXenonLights);
			Config.SetValue("Configurations", "LightColor", LightColor);
			Config.SetValue("Configurations", "TurboActive", TurboActive);
			VehicleHash = Function.Call<int>(Hash._0xD24D37CC275948CC, new InputArgument[1] { VehicleName }).ToString();
			Config.SetValue("Configurations", "NeonColor", NeonColor);
			Config.SetValue("Configurations", "RightNeonOn", RightNeonOn);
			Config.SetValue("Configurations", "LeftNeonOn", LeftNeonOn);
			Config.SetValue("Configurations", "FrontNeonOn", FrontNeonOn);
			Config.SetValue("Configurations", "BackNeonOn", BackNeonOn);
			Config.SetValue<string>("Configurations", "VehicleHash", VehicleHash);
			Config.SetValue("Configurations", "Wheelcolour", Wheelcolour);
			Config.SetValue("Configurations", "DashBoardColour", DashBoardColour);
			Config.SetValue("Configurations", "TireSmokeColor", TireSmokeColor);
			Config.SetValue("Configurations", "TireSmoke", TireSmoke);
			Config.SetValue("Configurations", "TrimColor", TrimColor);
			Config.SetValue("Configurations", "BulletProofTires", BulletProofTires);
			if (ExtraOn.Count >= 1)
			{
				for (int i = 0; i < ExtraOn.Count; i++)
				{
					Config.SetValue("ToggleableExtras", "Extras" + i, ExtraOn[i]);
				}
			}
			Config.Save();
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
			if (Game.Player.Character.CurrentVehicle != null)
			{
				Game.Player.Character.CurrentVehicle.Delete();
			}
		}

		public void SaveCurrentCar(string car, Vehicle V)
		{
			VehicleName = car;
			RoofId = V.GetMod(VehicleMod.Roof);
			AerialsId = V.GetMod(VehicleMod.Aerials);
			AirfilterId = V.GetMod(VehicleMod.AirFilter);
			ArchCoverId = V.GetMod(VehicleMod.ArchCover);
			ArmorId = V.GetMod(VehicleMod.Armor);
			BackWheelsId = V.GetMod(VehicleMod.BackWheels);
			BrakesId = V.GetMod(VehicleMod.Brakes);
			ColumnShifterLeversId = V.GetMod(VehicleMod.ColumnShifterLevers);
			DashboardId = V.GetMod(VehicleMod.Dashboard);
			DialDesignId = V.GetMod(VehicleMod.DialDesign);
			DoorSpeekersId = V.GetMod(VehicleMod.DoorSpeakers);
			EngineId = V.GetMod(VehicleMod.Engine);
			EngineBlockId = V.GetMod(VehicleMod.EngineBlock);
			ExaustId = V.GetMod(VehicleMod.Exhaust);
			FenderId = V.GetMod(VehicleMod.Fender);
			FrameId = V.GetMod(VehicleMod.Frame);
			FrontBumperId = V.GetMod(VehicleMod.FrontBumper);
			FrontWheelsId = V.GetMod(VehicleMod.FrontWheels);
			GrilleId = V.GetMod(VehicleMod.Grille);
			HoodId = V.GetMod(VehicleMod.Hood);
			HornsId = V.GetMod(VehicleMod.Horns);
			HydralicsId = V.GetMod(VehicleMod.Hydraulics);
			LiveryId = V.GetMod(VehicleMod.Livery);
			OrnamentsId = V.GetMod(VehicleMod.Ornaments);
			PlaquesId = V.GetMod(VehicleMod.Plaques);
			Plateholder = V.GetMod(VehicleMod.PlateHolder);
			RearBumperId = V.GetMod(VehicleMod.RearBumper);
			RightFenderId = V.GetMod(VehicleMod.RightFender);
			SeatsId = V.GetMod(VehicleMod.Seats);
			SideSkirt = V.GetMod(VehicleMod.SideSkirt);
			speakers = V.GetMod(VehicleMod.Speakers);
			SpoilersId = V.GetMod(VehicleMod.Spoilers);
			SteeringWheelId = V.GetMod(VehicleMod.SteeringWheels);
			StrutId = V.GetMod(VehicleMod.Struts);
			SuspensionId = V.GetMod(VehicleMod.Suspension);
			TankId = V.GetMod(VehicleMod.Tank);
			TransmissionId = V.GetMod(VehicleMod.Transmission);
			TrimId = V.GetMod(VehicleMod.Trim);
			TrimDesignId = V.GetMod(VehicleMod.TrimDesign);
			TrunkId = V.GetMod(VehicleMod.Trunk);
			VanityPlatesId = V.GetMod(VehicleMod.VanityPlates);
			WindowId = V.GetMod(VehicleMod.Windows);
			Blades = V.GetMod(VehicleMod.Trim);
			PrimaryColor = V.PrimaryColor;
			SecondaryColor = V.SecondaryColor;
			Wheelcolour = V.RimColor;
			DashBoardColour = V.DashboardColor;
			PearlCent = V.PearlescentColor;
			NeonColour = V.NeonLightsColor;
			Vehicle currentVehicle = Game.Player.Character.CurrentVehicle;
			HasXenonLights = currentVehicle.IsToggleModOn(VehicleToggleMod.XenonHeadlights);
			TurboActive = currentVehicle.IsToggleModOn(VehicleToggleMod.Turbo);
			LightColor = Function.Call<int>((Hash)4467343895069330651uL, new InputArgument[1] { currentVehicle });
			TintId = V.WindowTint;
			RightNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Right);
			LeftNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Left);
			BackNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Back);
			FrontNeonOn = currentVehicle.IsNeonLightsOn(VehicleNeonLight.Front);
			NeonColor = currentVehicle.NeonLightsColor;
			TireSmoke = currentVehicle.IsToggleModOn(VehicleToggleMod.TireSmoke);
			Wheelcolour = currentVehicle.RimColor;
			DashBoardColour = currentVehicle.DashboardColor;
			TireSmokeColor = currentVehicle.TireSmokeColor;
			VehicleHash = V.GetHashCode().ToString();
			PlanteNo = V.NumberPlate;
			BulletProofTires = V.CanTiresBurst;
			TrimColor = V.TrimColor;
			try
			{
				HasClanTag = VE.ReturnClanEmblemOn(V);
				Config.SetValue("Configurations", "CLanTagOn", HasClanTag);
			}
			catch (Exception)
			{
			}
			if (VehicleName == "CARBON")
			{
				VehicleName = "CARBONRS";
			}
			if (VehicleName == "UTILTRUC")
			{
				VehicleName = "UTILLITRUCK";
			}
			if (VehicleName == "FORK")
			{
				VehicleName = "FORKLIFT";
			}
			if (VehicleName == "LANDSTAL")
			{
				VehicleName = "LANDSTALKER";
			}
			if (VehicleName == "CAVCADE")
			{
				VehicleName = "CAVALCADE";
			}
			if (VehicleName == "SANCHEZ02")
			{
				VehicleName = "SANCHEZ2";
			}
			if (VehicleName == "SANCHEZ01")
			{
				VehicleName = "SANCHEZ";
			}
			if (VehicleName == "FAGGION")
			{
				VehicleName = "FAGGIO";
			}
			if (VehicleName == "STINGERG")
			{
				VehicleName = "FELTZER3";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "KHAMEL")
			{
				VehicleName = "KHAMELION";
			}
			if (VehicleName == "FURORE")
			{
				VehicleName = "FUROREGT";
			}
			if (VehicleName == "COGCABRI")
			{
				VehicleName = "COGCABRIO";
			}
			if (VehicleName == "RLOADER")
			{
				VehicleName = "RATLOADER";
			}
			if (VehicleName == "RLOADER2")
			{
				VehicleName = "RATLOADER2";
			}
			if (VehicleName == "FELTZER")
			{
				VehicleName = "FELTZER2";
			}
			if (VehicleName == "WASHINGT")
			{
				VehicleName = "WASHINGTON";
			}
			if (VehicleName == "BUFFALO02")
			{
				VehicleName = "BUFFALO2";
			}
			if (VehicleName == "TAILGATE")
			{
				VehicleName = "TAILGATER";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "ASTROPE")
			{
				VehicleName = "ASTEROPE";
			}
			if (VehicleName == "SANDKIN2")
			{
				VehicleName = "SANDKING2";
			}
			if (VehicleName == "REBEL02")
			{
				VehicleName = "REBEL2";
			}
			if (VehicleName == "REBEL01")
			{
				VehicleName = "REBEL";
			}
			if (VehicleName == "RANCHERX")
			{
				VehicleName = "RANCHERXL";
			}
			if (VehicleName == "BFINJECT")
			{
				VehicleName = "BFINJECTION";
			}
			if (VehicleName == "DOMINATO2")
			{
				VehicleName = "DOMINATOR2";
			}
			if (VehicleName == "DILETTAN")
			{
				VehicleName = "DILETTANTE";
			}
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
			if (VehicleName == "ABMULAN")
			{
				VehicleName = "AMBULANCE";
			}
			if (VehicleName == "Ruiner3")
			{
				VehicleName = "Ruiner3";
			}
			if (VehicleName == "BUCCANEE2")
			{
				VehicleName = "BUCCANEER2";
			}
			if (VehicleName == "BUCCANEE")
			{
				VehicleName = "BUCCANEER";
			}
			if (VehicleName == "CARBONIZ")
			{
				VehicleName = "CARBONIZZARE";
			}
			if (VehicleName == "penetrator")
			{
				VehicleName = "PENETRATOR";
			}
			if (VehicleName == "TROPHY")
			{
				VehicleName = "TROPHYTRUCK";
			}
			if (VehicleName == "TROPHY2")
			{
				VehicleName = "TROPHYTRUCK2";
			}
			if (VehicleName == "ROOSEVELT")
			{
				VehicleName = "Btype";
			}
			if (VehicleName == "VERLIER")
			{
				VehicleName = "VERLIERER2";
			}
			if (VehicleName == "BTYPE2")
			{
				VehicleName = "Btype2";
			}
			if (VehicleName == "ROOSEVELT2")
			{
				VehicleName = "Btype3";
			}
			if (VehicleName == "DOMINATO")
			{
				VehicleName = "DOMINATOR";
			}
			if (VehicleName == "NITESHAD")
			{
				VehicleName = "NIGHTSHADE";
			}
			Config.SetValue<string>("Configurations", "VehicleName", VehicleName);
			Config.SetValue("Configurations", "Roof", RoofId);
			Config.SetValue("Configurations", "AerialsId", AerialsId);
			Config.SetValue("Configurations", "AirfilterId", AirfilterId);
			Config.SetValue("Configurations", "ArchCoverId", ArchCoverId);
			Config.SetValue("Configurations", "ArmorId", ArmorId);
			Config.SetValue("Configurations", "BackWheelsId", BackWheelsId);
			Config.SetValue("Configurations", "BrakesId", BrakesId);
			Config.SetValue("Configurations", "ColumnShifterLeversId", ColumnShifterLeversId);
			Config.SetValue("Configurations", "DashboardId", DashboardId);
			Config.SetValue("Configurations", "DialDesignId", DialDesignId);
			Config.SetValue("Configurations", "DoorSpeekersId", DoorSpeekersId);
			Config.SetValue("Configurations", "EngineId", EngineId);
			Config.SetValue("Configurations", "EngineBlockId", EngineBlockId);
			Config.SetValue("Configurations", "ExaustId", ExaustId);
			Config.SetValue("Configurations", "FenderId", FenderId);
			Config.SetValue("Configurations", "FrameId", FrameId);
			Config.SetValue("Configurations", "FrontBumperId", FrontBumperId);
			Config.SetValue("Configurations", "FrontWheelsId", FrontWheelsId);
			Config.SetValue("Configurations", "GrilleId", GrilleId);
			Config.SetValue("Configurations", "HoodId", HoodId);
			Config.SetValue("Configurations", "HornsId", HornsId);
			Config.SetValue("Configurations", "HydralicsId", HydralicsId);
			Config.SetValue("Configurations", "LiveryId", LiveryId);
			Config.SetValue("Configurations", "OrnamentsId", OrnamentsId);
			Config.SetValue("Configurations", "PlaquesId", PlaquesId);
			Config.SetValue("Configurations", "Plateholder", Plateholder);
			Config.SetValue("Configurations", "RearBumperId", RearBumperId);
			Config.SetValue("Configurations", "RightFenderId", RightFenderId);
			Config.SetValue("Configurations", "SeatsId", SeatsId);
			Config.SetValue("Configurations", "speakers", speakers);
			Config.SetValue("Configurations", "speakers", speakers);
			Config.SetValue("Configurations", "SpoilersId", SpoilersId);
			Config.SetValue("Configurations", "SteeringWheelId", SteeringWheelId);
			Config.SetValue("Configurations", "StrutId", StrutId);
			Config.SetValue("Configurations", "RoofId", RoofId);
			Config.SetValue("Configurations", "SuspensionId", SuspensionId);
			Config.SetValue("Configurations", "TransmissionId", TransmissionId);
			Config.SetValue("Configurations", "TrimDesignId", TrimDesignId);
			Config.SetValue("Configurations", "TrimDesignId", TrimDesignId);
			Config.SetValue("Configurations", "TrunkId", TrunkId);
			Config.SetValue("Configurations", "VanityPlatesId", VanityPlatesId);
			Config.SetValue("Configurations", "WindowId", WindowId);
			Config.SetValue("Configurations", "PrimaryColor", PrimaryColor);
			Config.SetValue("Configurations", "SecondaryColor", SecondaryColor);
			Config.SetValue("Configurations", "Wheelcolour", Wheelcolour);
			Config.SetValue("Configurations", "DashBoardColour", DashBoardColour);
			Config.SetValue("Configurations", "PearlCent", PearlCent);
			Config.SetValue("Configurations", "NeonColour", NeonColour);
			Config.SetValue("Configurations", "TintId", TintId);
			Config.SetValue<string>("Configurations", "PlanteNo", PlanteNo);
			Config.SetValue("Configurations", "Blades", Blades);
			Config.SetValue("Configurations", "HasXenonLights", HasXenonLights);
			Config.SetValue("Configurations", "LightColor", LightColor);
			Config.SetValue<string>("Configurations", "VehicleHash", VehicleHash);
			Config.SetValue("Configurations", "TurboActive", TurboActive);
			Config.SetValue("Configurations", "NeonColor", NeonColor);
			Config.SetValue("Configurations", "RightNeonOn", RightNeonOn);
			Config.SetValue("Configurations", "LeftNeonOn", LeftNeonOn);
			Config.SetValue("Configurations", "FrontNeonOn", FrontNeonOn);
			Config.SetValue("Configurations", "BackNeonOn", BackNeonOn);
			Config.SetValue("Configurations", "Wheelcolour", Wheelcolour);
			Config.SetValue("Configurations", "DashBoardColour", DashBoardColour);
			Config.SetValue("Configurations", "TireSmokeColor", TireSmokeColor);
			Config.SetValue("Configurations", "TireSmoke", TireSmoke);
			Config.SetValue("Configurations", "TrimColor", TrimColor);
			Config.SetValue("Configurations", "BulletProofTires", BulletProofTires);
			if (ExtraOn.Count >= 1)
			{
				for (int i = 0; i < ExtraOn.Count; i++)
				{
					Config.SetValue("ToggleableExtras", "Extras" + i, ExtraOn[i]);
				}
			}
			Config.Save();
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
		}

		private void onKeyDown(object sender, KeyEventArgs e)
		{
		}

		private void DisplayHelpTextThisFrame(string text)
		{
			InputArgument[] arguments = new InputArgument[1] { "STRING" };
			Function.Call(Hash._0x8509B634FBE7DA11, arguments);
			InputArgument[] arguments2 = new InputArgument[1] { text };
			Function.Call(Hash._0x6C188BE134E074AA, arguments2);
			InputArgument[] arguments3 = new InputArgument[4] { 0, 0, 1, -1 };
			Function.Call(Hash._0x238FFE5C7B0498A6, arguments3);
		}

		public void SaveName(string Name)
		{
			VehicleName = Name;
			Config.SetValue<string>("Configurations", "VehicleName", VehicleName);
			Config.Save();
		}

		public void OnTick(object sender, EventArgs e)
		{
		}

		public Model CheckCar2(string iniName)
		{
			LoadIniFile(iniName);
			VehicleName = Config.GetValue<string>("Configurations", "VehicleName", VehicleName);
			if (VehicleName == "CARBON")
			{
				VehicleName = "CARBONRS";
			}
			if (VehicleName == "UTILTRUC")
			{
				VehicleName = "UTILLITRUCK";
			}
			if (VehicleName == "FORK")
			{
				VehicleName = "FORKLIFT";
			}
			if (VehicleName == "LANDSTAL")
			{
				VehicleName = "LANDSTALKER";
			}
			if (VehicleName == "CAVCADE")
			{
				VehicleName = "CAVALCADE";
			}
			if (VehicleName == "SANCHEZ02")
			{
				VehicleName = "SANCHEZ2";
			}
			if (VehicleName == "SANCHEZ01")
			{
				VehicleName = "SANCHEZ";
			}
			if (VehicleName == "FAGGION")
			{
				VehicleName = "FAGGIO";
			}
			if (VehicleName == "STINGERG")
			{
				VehicleName = "FELTZER3";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "SCHWARZE")
			{
				VehicleName = "SCHWARZER";
			}
			if (VehicleName == "KHAMEL")
			{
				VehicleName = "KHAMELION";
			}
			if (VehicleName == "FURORE")
			{
				VehicleName = "FUROREGT";
			}
			if (VehicleName == "COGCABRI")
			{
				VehicleName = "COGCABRIO";
			}
			if (VehicleName == "RLOADER")
			{
				VehicleName = "RATLOADER";
			}
			if (VehicleName == "RLOADER2")
			{
				VehicleName = "RATLOADER2";
			}
			if (VehicleName == "FELTZER")
			{
				VehicleName = "FELTZER2";
			}
			if (VehicleName == "WASHINGT")
			{
				VehicleName = "WASHINGTON";
			}
			if (VehicleName == "BUFFALO02")
			{
				VehicleName = "BUFFALO2";
			}
			if (VehicleName == "TAILGATE")
			{
				VehicleName = "TAILGATER";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "SCHAFTER")
			{
				VehicleName = "SCHAFTER2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC2")
			{
				VehicleName = "COGNOSCENTI2";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "COGNOSC")
			{
				VehicleName = "COGNOSCENTI";
			}
			if (VehicleName == "ASTROPE")
			{
				VehicleName = "ASTEROPE";
			}
			if (VehicleName == "SANDKIN2")
			{
				VehicleName = "SANDKING2";
			}
			if (VehicleName == "REBEL02")
			{
				VehicleName = "REBEL2";
			}
			if (VehicleName == "REBEL01")
			{
				VehicleName = "REBEL";
			}
			if (VehicleName == "RANCHERX")
			{
				VehicleName = "RANCHERXL";
			}
			if (VehicleName == "BFINJECT")
			{
				VehicleName = "BFINJECTION";
			}
			if (VehicleName == "DOMINATO2")
			{
				VehicleName = "DOMINATOR2";
			}
			if (VehicleName == "DILETTAN")
			{
				VehicleName = "DILETTANTE";
			}
			if (VehicleName == "VOODOO2")
			{
				VehicleName = "VOODOO";
			}
			else if (VehicleName == "VOODOO")
			{
				VehicleName = "VOODOO2";
			}
			if (VehicleName == "ABMULAN")
			{
				VehicleName = "AMBULANCE";
			}
			if (VehicleName == "Ruiner3")
			{
				VehicleName = "Ruiner3";
			}
			if (VehicleName == "BUCCANEE2")
			{
				VehicleName = "BUCCANEER2";
			}
			if (VehicleName == "BUCCANEE")
			{
				VehicleName = "BUCCANEER";
			}
			if (VehicleName == "CARBONIZ")
			{
				VehicleName = "CARBONIZZARE";
			}
			if (VehicleName == "penetrator")
			{
				VehicleName = "PENETRATOR";
			}
			if (VehicleName == "TROPHY")
			{
				VehicleName = "TROPHYTRUCK";
			}
			if (VehicleName == "TROPHY2")
			{
				VehicleName = "TROPHYTRUCK2";
			}
			if (VehicleName == "ROOSEVELT")
			{
				VehicleName = "Btype";
			}
			if (VehicleName == "VERLIER")
			{
				VehicleName = "VERLIERER2";
			}
			if (VehicleName == "BTYPE2")
			{
				VehicleName = "Btype2";
			}
			if (VehicleName == "ROOSEVELT2")
			{
				VehicleName = "Btype3";
			}
			if (VehicleName == "DOMINATO")
			{
				VehicleName = "DOMINATOR";
			}
			if (VehicleName == "NITESHAD")
			{
				VehicleName = "NIGHTSHADE";
			}
			Model result = new Model(VehicleName);
			result.Request(250);
			if (result.IsInCdImage && result.IsValid)
			{
				while (!result.IsLoaded)
				{
					Script.Wait(50);
				}
				return result;
			}
			result.MarkAsNoLongerNeeded();
			return result;
		}
	}
}
