using System;
using System.Windows.Forms;
using GTA;
using GTA.Native;

namespace ArenaWarBusiness
{
	public class AllStocks : Script
	{
		private ScriptSettings Config;

		public int waittime;

		public int stockstimer;

		public int purchaselvl;

		public int maxstocks;

		public float stocksvalue;

		public float profitMargin;

		public int stockscount;

		public bool ShowStockIncrease;

		public DateTime CurrentDate;

		public DateTime NextDate;

		public int DaysWait = 3;

		public int NextDay;

		public int NextMonth;

		public int NextYear;

		public bool BYPASS_NOSAVE_OR_CRASH = true;

		public int DAYSTORESET_UPDATETIME = 12;

		public int Now;

		public AllStocks()
		{
			base.Tick += OnTick;
			base.KeyDown += OnKeyDown;
			LoadIniFile("scripts//ArenaWarBusiness//Main.ini");
			Now = GetDay();
		}

		public void IncreaseGain(string iniName)
		{
			LoadIniFile2(iniName);
			stocksvalue += (float)(125000 * purchaselvl) / 0.75f;
			Config.SetValue("Setup", "StocksValue", stocksvalue);
			Config.Save();
		}

		public void DecreaseGain(string iniName)
		{
			LoadIniFile2(iniName);
			stocksvalue -= (float)(125000 * purchaselvl) / 1.45f;
			Config.SetValue("Setup", "StocksValue", stocksvalue);
			Config.Save();
		}

		public void SetDate()
		{
			LoadIniFile("scripts//ExecutiveBusiness//Main.ini");
			if (GetDay() + DaysWait <= 30)
			{
				NextDay = GetDay() + DaysWait;
				NextMonth = GetMonth();
			}
			if (GetDay() + DaysWait > 30)
			{
				int num = GetDay() + DaysWait;
				num = 30 - num;
				num = (NextDay = -num);
				if (GetMonth() + 1 <= 12)
				{
					NextMonth = GetDay() + 1;
				}
				if (GetMonth() + 1 > 12)
				{
					NextMonth = 1;
				}
			}
			NextYear = GetYear();
			Config.SetValue("Setup", "NextYear", NextYear);
			Config.SetValue("Setup", "NextDay", NextDay);
			Config.SetValue("Setup", "NextMonth", NextMonth);
			Config.Save();
		}

		private void DisplayHelpTextThisFrame(string text)
		{
			InputArgument[] arguments = new InputArgument[1] { "STRING" };
			Function.Call(Hash._0x8509B634FBE7DA11, arguments);
			InputArgument[] arguments2 = new InputArgument[1] { text };
			Function.Call(Hash._0x6C188BE134E074AA, arguments2);
			InputArgument[] arguments3 = new InputArgument[4] { 0, 0, 1, -1 };
			Function.Call(Hash._0x238FFE5C7B0498A6, arguments3);
		}

		public void GetDateRelative()
		{
			if (!BYPASS_NOSAVE_OR_CRASH || Now == GetDay())
			{
				return;
			}
			Now = GetDay();
			int num = GetDay() + DAYSTORESET_UPDATETIME;
			int num2 = GetMonth();
			int year = GetYear();
			if (num < 0)
			{
				num = -num;
				if (GetMonth() + 1 <= 12)
				{
					num2 = GetMonth() + 1;
				}
				if (GetMonth() + 1 > 12)
				{
					num2 = 1;
				}
			}
			if (num > 30)
			{
				num = 30;
			}
			if (GetMonth() + 1 > 12)
			{
				num2 = 1;
			}
			if ((num <= NextDay && num2 <= NextMonth) || num2 < NextMonth || num2 > NextMonth || year != NextYear)
			{
				NextMonth = GetMonth();
				NextDay = GetDay() + DaysWait;
				NextYear = GetYear();
				Config.SetValue("Setup", "NextYear", NextYear);
				Config.SetValue("Setup", "NextDay", NextDay);
				Config.SetValue("Setup", "NextMonth", NextMonth);
				Config.Save();
			}
		}

		public int GetHour()
		{
			return Function.Call<int>(Hash._0x25223CA6B4D20B7F, new InputArgument[0]);
		}

		public int GetMinutes()
		{
			return Function.Call<int>(Hash._0x13D2B8ADD79640F2, new InputArgument[0]);
		}

		public int GetDay()
		{
			return Function.Call<int>(Hash._0x3D10BC92A4DB1D35, new InputArgument[0]);
		}

		public int GetMonth()
		{
			return Function.Call<int>(Hash._0xBBC72712E80257A1, new InputArgument[0]);
		}

		public int GetYear()
		{
			return Function.Call<int>(Hash._0x961777E64BDAF717, new InputArgument[0]);
		}

		private void OnTick(object sender, EventArgs e)
		{
			GetDateRelative();
			if (GetDay() == NextDay && GetMonth() == NextMonth)
			{
				SetDate();
				LoadIniFile2("scripts//ArenaWarBusiness//Main.ini");
				if (Config.GetValue("Setup", "BuisnessLevel", purchaselvl) >= 1)
				{
					Random random = new Random();
					int num = random.Next(1, 1000);
					if (num < 350)
					{
						DecreaseGain("scripts//ArenaWarBusiness//Main.ini");
						if (ShowStockIncrease && Config.GetValue("Setup", "BuisnessLevel", purchaselvl) != 0)
						{
							UI.Notify("~m~Alan~w~  : Stocks for our Arena War Business just Decreased!");
						}
					}
					else if (num >= 350)
					{
						IncreaseGain("scripts//ArenaWarBusiness//Main.ini");
						if (ShowStockIncrease && Config.GetValue("Setup", "BuisnessLevel", purchaselvl) != 0)
						{
							UI.Notify("~m~Alan~w~ : Stocks for our Arena War Business just increased!");
						}
					}
				}
				Config.Save();
				stockstimer = 0;
			}
			else
			{
				stockstimer++;
			}
		}

		private void OnKeyDown(object sender, KeyEventArgs e)
		{
		}

		private void LoadIniFile2(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				purchaselvl = Config.GetValue("Setup", "BuisnessLevel", purchaselvl);
				stockscount = Config.GetValue("Setup", "stockslevel", stockscount);
				stocksvalue = Config.GetValue("Setup", "StocksValue", stocksvalue);
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Config.ini Failed To Load.");
			}
		}

		private void LoadIniFile(string iniName)
		{
			try
			{
				Config = ScriptSettings.Load(iniName);
				ShowStockIncrease = Config.GetValue("Setup", "ShowStockIncrease", ShowStockIncrease);
				try
				{
					NextDay = Config.GetValue("Setup", "NextDay", NextDay);
					NextMonth = Config.GetValue("Setup", "NextMonth", NextMonth);
					NextYear = Config.GetValue("Setup", "NextYear", NextYear);
					DaysWait = Config.GetValue("Setup", "DaysWait", DaysWait);
					BYPASS_NOSAVE_OR_CRASH = Config.GetValue("Setup", "BYPASS_NOSAVE_OR_CRASH", BYPASS_NOSAVE_OR_CRASH);
					DAYSTORESET_UPDATETIME = Config.GetValue("Setup", "DAYSTORESET_UPDATETIME", DAYSTORESET_UPDATETIME);
				}
				catch (Exception)
				{
					NextDay = 10;
					Config.SetValue("Setup", "NextDay", NextDay);
					NextMonth = 10;
					Config.SetValue("Setup", "NextMonth", NextMonth);
					NextYear = 2010;
					Config.SetValue("Setup", "NextYear", NextYear);
					DaysWait = 3;
					Config.SetValue("Setup", "DaysWait", DaysWait);
					BYPASS_NOSAVE_OR_CRASH = true;
					Config.SetValue("Setup", "BYPASS_NOSAVE_OR_CRASH", BYPASS_NOSAVE_OR_CRASH);
					DAYSTORESET_UPDATETIME = 12;
					Config.SetValue("Setup", "DAYSTORESET_UPDATETIME", DAYSTORESET_UPDATETIME);
					Config.Save();
				}
			}
			catch (Exception)
			{
				UI.Notify("~r~Error~w~: Config.ini Failed To Load.");
			}
		}
	}
}
